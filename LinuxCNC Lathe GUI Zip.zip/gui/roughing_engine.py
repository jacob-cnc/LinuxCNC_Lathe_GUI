"""
Roughing Engine — Pure Algorithm Module
=========================================
Extracted from conv_profile.py for testability and separation of concerns.

This module contains NO PyQt, NO G-code string formatting, NO UI logic.
It takes profile geometry + parameters and returns a structured plan of
tool moves (rapids, feeds, arcs, dwells) that the caller formats into G-code.

Coordinate conventions (matching conv_profile.py):
  - X is DIAMETER in all external interfaces
  - Internally, arc math uses RADIUS (X/2) because LinuxCNC G-code R is radius-space
  - Z is always absolute machine Z
  - Positive radius = CW (G02), negative = CCW (G03)

Version A: Refactored extraction — same behavior as the inline conv_profile.py logic.
"""

import math
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional, Any


# ===========================================================================
# Data Structures
# ===========================================================================

@dataclass
class RoughingParams:
    """Parameters controlling the roughing operation."""
    doc: float                  # depth of cut on RADIUS
    fin_allowance: float        # total finish allowance on RADIUS (fin_passes * fin_doc)
    feed: float                 # roughing feed rate (IPR or IPM depending on mode)
    retract_dist: float         # retract distance on DIAMETER
    z_lift: float               # Z lift for diagonal retract (on radius, typically retract_dist/2)
    peck_enabled: bool = False
    peck_depth: float = 0.0     # Z peck increment
    peck_dwell: float = 0.0     # seconds between pecks


@dataclass
class StockDef:
    """Stock/workpiece definition."""
    diameter: float             # stock OD for OD mode, bore start diameter for ID mode
    z_start: float              # Z face position (where profile begins)
    safe_x: float              # safe X for rapids (user-defined)
    safe_z: float              # safe Z for rapids (user-defined)


@dataclass
class ProfileMove:
    """A single segment in the finish profile."""
    type: str               # "LINE" or "ARC"
    x: float                # endpoint X diameter
    z: float                # endpoint Z
    radius: float = 0.0     # signed: +CW (G02), -CCW (G03). 0 for LINE.


@dataclass
class ToolMove:
    """Single machine move in the roughing plan."""
    move_type: str          # "RAPID", "FEED", "ARC_CW", "ARC_CCW", "DWELL"
    x: float = None         # X diameter (None = no X motion)
    z: float = None         # Z position (None = no Z motion)
    feed: float = None      # feed rate (None = rapid or inherit previous)
    radius: float = None    # arc radius (for ARC moves only)
    dwell: float = None     # seconds (for DWELL only)
    comment: str = ""       # annotation for G-code comment


@dataclass
class RoughingPass:
    """One complete roughing pass (approach + cut + retract)."""
    pass_num: int
    interval_idx: int       # 0 for single-interval, 0..N for multi-interval
    x_level: float          # cutting diameter for this pass
    z_start: float          # where cut begins (Z)
    z_end: float            # where cut ends (Z)
    moves: List[ToolMove] = field(default_factory=list)


@dataclass
class RoughingResult:
    """Complete roughing output from plan_roughing()."""
    passes: List[RoughingPass] = field(default_factory=list)
    cleanup_pass: List[ToolMove] = field(default_factory=list)
    point_chart: Dict[float, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)


# ===========================================================================
# Constants
# ===========================================================================

_EPS = 1e-9
_ARC_EXTENT_EPS = 0.0001
_SWEEP_EPS = 0.0001
_ID_FLOOR_OFFSET = 0.004  # on diameter — never retract past X Start minus this


# ===========================================================================
# Arc Geometry Utilities (single source of truth)
# ===========================================================================

def _compute_arc_center(x1, z1, x2, z2, signed_radius):
    """Compute arc center from two endpoints and signed radius.

    All coordinates in RADIUS space (X/2) and Z.
    Sign convention: positive = CW (G02), negative = CCW (G03).

    Returns (cx, cz, ar, sa, ea, cw) where:
        cx, cz = center in radius space
        ar = effective radius (clamped if chord > 2R)
        sa = start angle
        ea = end angle
        cw = True if clockwise

    Uses atan2(x - cx, z - cz) convention to match PositionGraph.sim_load.
    """
    R = abs(signed_radius)
    dx = x2 - x1
    dz = z2 - z1
    chord = math.sqrt(dx * dx + dz * dz)

    if R < _EPS or chord < _EPS or chord > 2.0 * R + 1e-6:
        return None  # degenerate arc

    ar = max(R, chord / 2 + 0.0001)
    h = math.sqrt(max(0, ar * ar - (chord / 2) ** 2))
    mx = (x1 + x2) / 2.0
    mz = (z1 + z2) / 2.0
    px = -dz / chord
    pz = dx / chord

    cw = signed_radius > 0
    g_r = abs(signed_radius)

    # Center selection — matches PositionGraph.sim_load exactly
    if g_r > 0:
        if cw:
            cx, cz = mx - h * px, mz - h * pz
        else:
            cx, cz = mx + h * px, mz + h * pz
    else:
        if cw:
            cx, cz = mx + h * px, mz + h * pz
        else:
            cx, cz = mx - h * px, mz - h * pz

    # Angle computation and correction
    sa = math.atan2(x1 - cx, z1 - cz)
    ea = math.atan2(x2 - cx, z2 - cz)

    if cw:
        if ea >= sa:
            ea -= 2 * math.pi
        if abs(ea - sa) > math.pi and g_r > 0:
            cx, cz = 2 * mx - cx, 2 * mz - cz
            sa = math.atan2(x1 - cx, z1 - cz)
            ea = math.atan2(x2 - cx, z2 - cz)
            if ea >= sa:
                ea -= 2 * math.pi
    else:
        if ea <= sa:
            ea += 2 * math.pi
        if abs(ea - sa) > math.pi and g_r > 0:
            cx, cz = 2 * mx - cx, 2 * mz - cz
            sa = math.atan2(x1 - cx, z1 - cz)
            ea = math.atan2(x2 - cx, z2 - cz)
            if ea <= sa:
                ea += 2 * math.pi

    return (cx, cz, ar, sa, ea, cw)


def _angle_on_sweep(angle, sa, ea, cw):
    """Check if an angle lies within an arc's angular sweep.

    CW arcs: sweep goes from sa DOWN to ea (sa > ea after normalization).
    CCW arcs: sweep goes from sa UP to ea (ea > sa after normalization).

    Returns True if angle is on the sweep.
    """
    if cw:
        a = angle
        while a > sa + _SWEEP_EPS:
            a -= 2 * math.pi
        while a < ea - _SWEEP_EPS:
            a += 2 * math.pi
        return (ea - _SWEEP_EPS <= a <= sa + _SWEEP_EPS)
    else:
        a = angle
        while a < sa - _SWEEP_EPS:
            a += 2 * math.pi
        while a > ea + _SWEEP_EPS:
            a -= 2 * math.pi
        return (sa - _SWEEP_EPS <= a <= ea + _SWEEP_EPS)


def _arc_x_extent(cx, cz, ar, sa, ea, cw):
    """Compute the true X extent of an arc in diameter space.

    Convention: x_radius = cx + ar * sin(angle)
        min X at angle = -pi/2 (sin = -1)
        max X at angle = +pi/2 (sin = +1)

    Returns (x_min_diameter, x_max_diameter).
    """
    # Endpoint X values in diameter
    x1_d = (cx + ar * math.sin(sa)) * 2.0
    x2_d = (cx + ar * math.sin(ea)) * 2.0

    # Check if arc passes through min X (angle = -pi/2)
    if _angle_on_sweep(-math.pi / 2.0, sa, ea, cw):
        x_min_d = (cx - ar) * 2.0
    else:
        x_min_d = min(x1_d, x2_d)

    # Check if arc passes through max X (angle = +pi/2)
    if _angle_on_sweep(math.pi / 2.0, sa, ea, cw):
        x_max_d = (cx + ar) * 2.0
    else:
        x_max_d = max(x1_d, x2_d)

    return (x_min_d, x_max_d)


def _linearize_arc(prev_x, prev_z, end_x, end_z, radius, step=0.010):
    """Linearize an arc segment into intermediate (x_dia, z) points.

    All X coordinates are in diameter. The arc goes from (prev_x, prev_z)
    to (end_x, end_z) with the given signed radius (positive = G02/CW,
    negative = G03/CCW). Returns a list of intermediate points (excluding
    the start point but including the endpoint).

    Uses the same arc center selection and sampling algorithm as the
    PositionGraph simulation renderer to guarantee consistency.
    """
    # Convert to radius space for arc math
    rx1, rz1 = prev_x / 2.0, prev_z
    rx2, rz2 = end_x / 2.0, end_z

    result = _compute_arc_center(rx1, rz1, rx2, rz2, radius)
    if result is None:
        return [(end_x, end_z)]

    cx, cz, ar, sa, ea, cw = result

    # Sample the arc
    arc_len = abs(ea - sa) * ar
    n_steps = max(2, int(math.ceil(arc_len / step)))

    pts = []
    for i in range(1, n_steps + 1):
        t = sa + (ea - sa) * i / n_steps
        ax = cx + ar * math.sin(t)
        az = cz + ar * math.cos(t)
        pts.append((ax * 2.0, az))  # back to diameter

    if pts:
        pts[-1] = (end_x, end_z)

    return pts


# ===========================================================================
# Monotonicity Classification
# ===========================================================================

def _classify_monotonicity(finish_moves, x_start_d, z_start, mode):
    """Determine if the profile is monotonic in the cutting direction.

    OD monotonic: X only decreases (profile only gets smaller toward center)
    ID monotonic: X only increases (bore only gets wider) OR only decreases

    Non-monotonic profiles have peaks/valleys requiring interval-based roughing.

    Also checks arc segments for internal extrema that the endpoint-based
    check would miss (e.g., vertical arcs whose min/max X is between endpoints).

    Returns: True if non-monotonic (has peaks/valleys), False if monotonic.
    """
    # --- Check arc segments for internal extrema ---
    prev_pt = (x_start_d, z_start)
    for mv in finish_moves:
        if mv.type == "ARC" and mv.radius != 0:
            arc_x1 = prev_pt[0]
            arc_x2 = mv.x
            R_abs = abs(mv.radius)

            # Convert to radius space
            rx1, rz1 = arc_x1 / 2.0, prev_pt[1]
            rx2, rz2 = arc_x2 / 2.0, mv.z

            result = _compute_arc_center(rx1, rz1, rx2, rz2, mv.radius)
            if result is not None:
                cx, cz, ar, sa, ea, cw = result

                # For OD: a valley (X minimum internal to arc) means non-monotonic
                # For ID: a peak (X maximum internal to arc) means non-monotonic
                if mode == "OD":
                    # Check if arc passes through min X (angle = -pi/2)
                    if _angle_on_sweep(-math.pi / 2.0, sa, ea, cw):
                        arc_min_x_d = (cx - ar) * 2.0
                        endpoints_min = min(arc_x1, arc_x2)
                        if arc_min_x_d < endpoints_min - _ARC_EXTENT_EPS:
                            return True
                else:
                    # Check if arc passes through max X (angle = +pi/2)
                    if _angle_on_sweep(math.pi / 2.0, sa, ea, cw):
                        arc_max_x_d = (cx + ar) * 2.0
                        endpoints_max = max(arc_x1, arc_x2)
                        if arc_max_x_d > endpoints_max + _ARC_EXTENT_EPS:
                            return True

            prev_pt = (mv.x, mv.z)
        else:
            prev_pt = (mv.x, mv.z)

    # --- Linearize profile and check point-by-point ---
    rough_pts = [(x_start_d, z_start)]
    prev_pt = (x_start_d, z_start)
    for mv in finish_moves:
        if mv.type == "ARC" and mv.radius != 0:
            arc_pts = _linearize_arc(prev_pt[0], prev_pt[1], mv.x, mv.z, mv.radius)
            rough_pts.extend(arc_pts)
        else:
            rough_pts.append((mv.x, mv.z))
        prev_pt = (mv.x, mv.z)

    # Check for local peaks/valleys
    for i in range(1, len(rough_pts) - 1):
        x_prev = rough_pts[i - 1][0]
        x_curr = rough_pts[i][0]
        x_next = rough_pts[i + 1][0]
        if x_curr > x_prev + 0.001 and x_curr > x_next + 0.001:
            return True  # peak
        if x_curr < x_prev - 0.001 and x_curr < x_next - 0.001:
            return True  # valley

    # Check for direction reversal (catches plateaus between descent/ascent)
    last_dir = 0
    for i in range(1, len(rough_pts)):
        dx = rough_pts[i][0] - rough_pts[i - 1][0]
        if dx > 0.001:
            cur_dir = 1
        elif dx < -0.001:
            cur_dir = -1
        else:
            continue
        if last_dir != 0 and cur_dir != last_dir:
            return True
        last_dir = cur_dir

    return False


# ===========================================================================
# Z-Limit Chart (Monotonic Profiles)
# ===========================================================================

def _build_z_limit_chart(finish_moves, x_start_d, z_start, x_levels,
                         fin_allowance, mode):
    """Build a point chart of Z limits for each roughing pass X level.

    For monotonic profiles: each X level has exactly one Z limit where
    the roughing boundary blocks further travel.

    Uses the cleanup pass geometry (part boundary + finish DOC offset).
    For LINE segments: exact linear interpolation.
    For ARC segments: solve the circle equation directly using the arc
    center computed from the offset endpoints and R. No linearization.

    Args:
        finish_moves: List of ProfileMove objects
        x_start_d: Starting X diameter of the profile
        z_start: Starting Z position
        x_levels: List of roughing X diameters to compute Z limits for
        fin_allowance: Finish allowance on radius
        mode: "OD" or "ID"

    Returns:
        Dict mapping x_level (float) to z_limit (float).
    """
    offset_d = fin_allowance * 2  # on diameter

    # Build the cleanup pass segment list with offset endpoints
    if mode == "OD":
        cp_start_x = x_start_d + offset_d
    else:
        cp_start_x = x_start_d - offset_d

    segments = []
    prev_x, prev_z = cp_start_x, z_start
    for mv in finish_moves:
        if mv.type == "LINE":
            ox = mv.x + offset_d if mode == "OD" else mv.x - offset_d
            oz = mv.z + fin_allowance
            segments.append(("LINE", prev_x, prev_z, ox, oz))
            prev_x, prev_z = ox, oz
        elif mv.type == "ARC":
            ox = mv.x + offset_d if mode == "OD" else mv.x - offset_d
            oz = mv.z + fin_allowance
            segments.append(("ARC", prev_x, prev_z, ox, oz, mv.radius))
            prev_x, prev_z = ox, oz

    if not segments:
        return {}

    last_z = segments[-1][4]
    chart = {}

    for current_d in x_levels:
        z_limit = None
        found_safe = False

        for seg in segments:
            x1, z1 = seg[1], seg[2]
            x2, z2 = seg[3], seg[4]

            if mode == "OD":
                safe1 = x1 < current_d - _EPS
                safe2 = x2 < current_d - _EPS
            else:
                safe1 = x1 > current_d + _EPS
                safe2 = x2 > current_d + _EPS

            if safe1:
                found_safe = True
            if safe2:
                found_safe = True

            if seg[0] == "LINE":
                if safe1 and not safe2:
                    denom = x2 - x1
                    if abs(denom) < _EPS:
                        z_cross = (z1 + z2) / 2.0
                    else:
                        t = (current_d - x1) / (x2 - x1)
                        t = max(0.0, min(1.0, t))
                        z_cross = z1 + t * (z2 - z1)
                    z_limit = z_cross
                elif not safe1 and safe2:
                    denom = x2 - x1
                    if abs(denom) < _EPS:
                        z_cross = (z1 + z2) / 2.0
                    else:
                        t = (current_d - x1) / (x2 - x1)
                        t = max(0.0, min(1.0, t))
                        z_cross = z1 + t * (z2 - z1)
                    z_limit = z_cross

            elif seg[0] == "ARC":
                arc_r = seg[5]
                R = abs(arc_r)

                # Convert to radius space for arc math
                rx1 = x1 / 2.0
                rz1 = z1
                rx2 = x2 / 2.0
                rz2 = z2
                r_current = current_d / 2.0

                result = _compute_arc_center(rx1, rz1, rx2, rz2, arc_r)
                if result is None:
                    # Degenerate — treat as line
                    if safe1 and not safe2:
                        denom = x2 - x1
                        if abs(denom) > _EPS:
                            t = (current_d - x1) / (x2 - x1)
                            t = max(0.0, min(1.0, t))
                            z_limit = z1 + t * (z2 - z1)
                    elif not safe1 and safe2:
                        denom = x2 - x1
                        if abs(denom) > _EPS:
                            t = (current_d - x1) / (x2 - x1)
                            t = max(0.0, min(1.0, t))
                            z_limit = z1 + t * (z2 - z1)
                    continue

                cx, cz, ar, sa, ea, cw = result

                # Compute true X extent
                x_min_d, x_max_d = _arc_x_extent(cx, cz, ar, sa, ea, cw)

                # X range check
                if current_d < x_min_d - _EPS or current_d > x_max_d + _EPS:
                    if safe1 and not safe2:
                        z_limit = z2
                    elif not safe1 and safe2:
                        z_limit = z2
                    continue

                # Solve circle equation in radius space
                val_sq = ar * ar - (r_current - cx) ** 2
                if val_sq < 0:
                    continue

                val = math.sqrt(val_sq)
                z_candidates = [cz + val, cz - val]

                # Validate each candidate lies on the arc sweep
                best_z = None
                for zc in z_candidates:
                    angle = math.atan2(r_current - cx, zc - cz)
                    if _angle_on_sweep(angle, sa, ea, cw):
                        if best_z is None or zc < best_z:
                            best_z = zc

                if best_z is not None:
                    z_limit = best_z

        if z_limit is not None:
            chart[current_d] = z_limit
        elif found_safe:
            chart[current_d] = last_z

    return chart


# ===========================================================================
# Z-Interval Chart (Non-Monotonic Profiles)
# ===========================================================================

def _build_z_interval_chart(finish_moves, x_start_d, z_start, x_levels,
                            fin_allowance, mode):
    """Build a chart of Z intervals where material exists for each roughing X level.

    For non-monotonic profiles: at a given X level, there may be multiple
    disjoint Z intervals where material exists (separated by peaks/humps).

    Uses a linearized boundary polyline for arc segments to avoid offset
    geometry issues. Arcs are sampled at the proper equidistant offset
    (same center, R ± fin_allowance) to guarantee no overcutting.

    Args:
        finish_moves: List of ProfileMove objects
        x_start_d: Starting X diameter of the profile
        z_start: Starting Z position
        x_levels: List of roughing X diameters to compute intervals for
        fin_allowance: Finish allowance on radius
        mode: "OD" or "ID"

    Returns:
        Dict mapping x_level (float) to list of (z_begin, z_end) tuples.
        z_begin is closer to z_start (more positive Z), z_end is further
        from z_start (more negative Z). Material exists in each interval.
    """
    offset_d = fin_allowance * 2  # on diameter

    # --- Step 1: Build the roughing boundary as a dense polyline ---
    if mode == "OD":
        cp_start_x = x_start_d + offset_d
    else:
        cp_start_x = x_start_d - offset_d

    boundary = [(cp_start_x, z_start)]
    orig_prev = (x_start_d, z_start)

    for mv in finish_moves:
        if mv.type == "LINE":
            ox = mv.x + offset_d if mode == "OD" else mv.x - offset_d
            oz = mv.z + fin_allowance
            boundary.append((ox, oz))
            orig_prev = (mv.x, mv.z)

        elif mv.type == "ARC":
            R_abs = abs(mv.radius)
            # Arc math in RADIUS space (X/2)
            orx1 = orig_prev[0] / 2.0
            orz1 = orig_prev[1]
            orx2 = mv.x / 2.0
            orz2 = mv.z

            result = _compute_arc_center(orx1, orz1, orx2, orz2, mv.radius)
            if result is None:
                ox = mv.x + offset_d if mode == "OD" else mv.x - offset_d
                oz = mv.z + fin_allowance
                boundary.append((ox, oz))
            else:
                a_cx, a_cz, a_ar, a_sa, a_ea, a_cw = result

                # Offset arc: same center, adjusted radius
                if mode == "OD":
                    offset_ar = max(1e-9, a_ar - fin_allowance * 2)
                else:
                    offset_ar = a_ar + fin_allowance * 2

                arc_len = abs(a_ea - a_sa) * offset_ar
                n_steps = max(20, int(math.ceil(arc_len / 0.002)))
                for i in range(1, n_steps + 1):
                    t = a_sa + (a_ea - a_sa) * i / n_steps
                    bx_r = a_cx + offset_ar * math.sin(t)
                    bz = a_cz + offset_ar * math.cos(t)
                    boundary.append((bx_r * 2.0, bz))

            orig_prev = (mv.x, mv.z)

    if len(boundary) < 2:
        return {}

    # --- Step 2: For each X level, find Z crossings on the polyline ---
    chart = {}

    for current_d in x_levels:
        intervals = []
        in_material = False
        interval_start = None

        for i in range(len(boundary) - 1):
            bx1, bz1 = boundary[i]
            bx2, bz2 = boundary[i + 1]

            # Determine material state at each endpoint
            if mode == "OD":
                mat1 = bx1 < current_d - _EPS
                mat2 = bx2 < current_d - _EPS
            else:
                mat1 = bx1 > current_d + _EPS
                mat2 = bx2 > current_d + _EPS

            # Handle state at first point
            if i == 0:
                if mat1:
                    in_material = True
                    interval_start = bz1

            # Check for crossing within this segment
            if mat1 != mat2:
                denom = bx2 - bx1
                if abs(denom) < _EPS:
                    z_cross = (bz1 + bz2) / 2.0
                else:
                    t = (current_d - bx1) / denom
                    t = max(0.0, min(1.0, t))
                    z_cross = bz1 + t * (bz2 - bz1)

                if mat1 and not mat2:
                    # Exiting material
                    if in_material and interval_start is not None:
                        intervals.append((interval_start, z_cross))
                        interval_start = None
                    in_material = False
                elif not mat1 and mat2:
                    # Entering material
                    in_material = True
                    interval_start = z_cross
            else:
                # No crossing — handle state transitions at segment boundaries
                if mat2 and not in_material:
                    in_material = True
                    interval_start = bz2
                elif not mat2 and in_material:
                    in_material = False
                    if interval_start is not None:
                        intervals.append((interval_start, bz2))
                        interval_start = None

        # Close any open interval at the end of the boundary
        if in_material and interval_start is not None:
            last_z = boundary[-1][1]
            intervals.append((interval_start, last_z))

        if intervals:
            # Ensure all intervals are properly ordered (z_begin >= z_end)
            ordered = []
            for zb, ze in intervals:
                if zb >= ze:
                    ordered.append((zb, ze))
                else:
                    ordered.append((ze, zb))
            chart[current_d] = ordered

    return chart


# ===========================================================================
# Pass Planning — Monotonic Profiles
# ===========================================================================

def _plan_passes_monotonic(z_chart, x_levels, stock, params, mode):
    """Plan roughing passes for a monotonic profile using single Z-limit logic.

    Each pass cuts at a constant X level from z_start to z_limit.

    Returns list of RoughingPass objects.
    """
    passes = []
    pass_num = 1
    z_clear = stock.z_start + 0.050

    if mode == "OD":
        x_clear = stock.diameter + params.retract_dist
    else:
        x_clear = stock.diameter - _ID_FLOOR_OFFSET

    for x_level in x_levels:
        z_limit = z_chart.get(x_level)
        if z_limit is None:
            continue

        rpass = RoughingPass(
            pass_num=pass_num,
            interval_idx=0,
            x_level=x_level,
            z_start=stock.z_start,
            z_end=z_limit,
            moves=[]
        )

        # --- Approach ---
        if mode == "OD":
            pass_clear = x_level + params.retract_dist
            rpass.moves.append(ToolMove("RAPID", x=pass_clear, z=z_clear,
                                        comment=f"Pass {pass_num}  chart: X{x_level:.4f}->Z{z_limit:.4f}"))
            rpass.moves.append(ToolMove("RAPID", x=x_level, z=stock.z_start))
        else:
            # ID: approach depends on bore direction
            pass_clear = x_level - params.retract_dist
            rpass.moves.append(ToolMove("RAPID", x=pass_clear, z=z_clear,
                                        comment=f"Pass {pass_num}  chart: X{x_level:.4f}->Z{z_limit:.4f}"))
            rpass.moves.append(ToolMove("RAPID", x=x_level, z=stock.z_start))

        # --- Cut (with optional peck) ---
        if params.peck_enabled and params.peck_depth > 0:
            z_pos = stock.z_start
            peck_num = 1
            while z_pos - params.peck_depth > z_limit + 0.0001:
                z_pos -= params.peck_depth
                rpass.moves.append(ToolMove("FEED", z=z_pos, feed=params.feed,
                                            comment=f"Peck {peck_num}"))
                rpass.moves.append(ToolMove("DWELL", dwell=params.peck_dwell,
                                            comment="Chip break"))
                peck_num += 1
            rpass.moves.append(ToolMove("FEED", z=z_limit, feed=params.feed,
                                        comment=f"Peck {peck_num} — final"))
            rpass.moves.append(ToolMove("DWELL", dwell=params.peck_dwell,
                                        comment="Chip break"))
        else:
            rpass.moves.append(ToolMove("FEED", z=z_limit, feed=params.feed))

        # --- Retract (diagonal pullaway) ---
        pullaway_z = z_limit + params.z_lift
        if mode == "OD":
            rpass.moves.append(ToolMove("RAPID", x=pass_clear, z=pullaway_z,
                                        comment="Diagonal retract"))
        else:
            rpass.moves.append(ToolMove("RAPID", x=pass_clear, z=pullaway_z,
                                        comment="Diagonal retract"))
        rpass.moves.append(ToolMove("RAPID", z=z_clear))

        passes.append(rpass)
        pass_num += 1

    return passes


# ===========================================================================
# Pass Planning — Non-Monotonic (Interval-Based)
# ===========================================================================

def _plan_passes_interval(interval_chart, x_levels, stock, params, mode):
    """Plan roughing passes for non-monotonic profiles using interval logic.

    At each X level, there may be multiple Z intervals where material exists.
    Each interval gets its own cut, with safe traverses between intervals.

    Returns list of RoughingPass objects.
    """
    passes = []
    pass_num = 1
    z_clear = stock.z_start + 0.050
    doc_d = params.doc * 2  # DOC on diameter

    if mode == "OD":
        x_clear = stock.diameter + params.retract_dist
    else:
        x_clear = stock.diameter - _ID_FLOOR_OFFSET

    for x_level in x_levels:
        intervals = interval_chart.get(x_level, [])
        if not intervals:
            continue

        num_intervals = len(intervals)

        for iv_idx, (z_begin, z_end) in enumerate(intervals):
            iv_label = f"Pass {pass_num}" if num_intervals == 1 else f"Pass {pass_num}.{iv_idx + 1}"
            is_last_interval = (iv_idx == num_intervals - 1)

            rpass = RoughingPass(
                pass_num=pass_num,
                interval_idx=iv_idx,
                x_level=x_level,
                z_start=z_begin,
                z_end=z_end,
                moves=[]
            )

            # --- Approach ---
            if mode == "OD":
                pass_clear = x_level + params.retract_dist
                prev_pass_x = x_level + doc_d

                if iv_idx == 0:
                    # First interval: normal approach
                    rpass.moves.append(ToolMove("RAPID", x=pass_clear, z=z_clear,
                                                comment=f"{iv_label}  chart: X{x_level:.4f} [{z_begin:.4f} to {z_end:.4f}]"))
                    rpass.moves.append(ToolMove("RAPID", x=prev_pass_x))
                    rpass.moves.append(ToolMove("FEED", x=x_level, feed=params.feed))
                else:
                    # Subsequent intervals: retract to x_clear, traverse Z
                    rpass.moves.append(ToolMove("RAPID", x=x_clear,
                                                comment=f"{iv_label}  chart: X{x_level:.4f} [{z_begin:.4f} to {z_end:.4f}]"))
                    rpass.moves.append(ToolMove("RAPID", z=z_begin))
                    rpass.moves.append(ToolMove("RAPID", x=prev_pass_x))
                    rpass.moves.append(ToolMove("FEED", x=x_level, feed=params.feed))
            else:
                # ID mode
                prev_pass_x = x_level - doc_d
                if iv_idx == 0:
                    rpass.moves.append(ToolMove("RAPID", x=x_clear, z=z_clear,
                                                comment=f"{iv_label}  chart: X{x_level:.4f} [{z_begin:.4f} to {z_end:.4f}]"))
                    rpass.moves.append(ToolMove("RAPID", z=z_begin))
                    rpass.moves.append(ToolMove("RAPID", x=prev_pass_x))
                    rpass.moves.append(ToolMove("FEED", x=x_level, feed=params.feed))
                else:
                    rpass.moves.append(ToolMove("RAPID", x=x_clear,
                                                comment=f"{iv_label}  chart: X{x_level:.4f} [{z_begin:.4f} to {z_end:.4f}]"))
                    rpass.moves.append(ToolMove("RAPID", z=z_begin))
                    rpass.moves.append(ToolMove("RAPID", x=prev_pass_x))
                    rpass.moves.append(ToolMove("FEED", x=x_level, feed=params.feed))

            # --- Cut (with optional peck) ---
            if params.peck_enabled and params.peck_depth > 0:
                z_pos = z_begin
                peck_num = 1
                while z_pos - params.peck_depth > z_end + 0.0001:
                    z_pos -= params.peck_depth
                    rpass.moves.append(ToolMove("FEED", z=z_pos, feed=params.feed,
                                                comment=f"Peck {peck_num}"))
                    rpass.moves.append(ToolMove("DWELL", dwell=params.peck_dwell,
                                                comment="Chip break"))
                    peck_num += 1
                rpass.moves.append(ToolMove("FEED", z=z_end, feed=params.feed,
                                            comment=f"Peck {peck_num} — final"))
                rpass.moves.append(ToolMove("DWELL", dwell=params.peck_dwell,
                                            comment="Chip break"))
            else:
                rpass.moves.append(ToolMove("FEED", z=z_end, feed=params.feed))

            # --- Retract ---
            pullaway_z = z_end + params.z_lift
            if num_intervals == 1:
                # Single interval: diagonal retract to pass_clear
                if mode == "OD":
                    rpass.moves.append(ToolMove("RAPID", x=pass_clear, z=pullaway_z,
                                                comment="Diagonal retract"))
                else:
                    rpass.moves.append(ToolMove("RAPID", x=x_clear, z=pullaway_z,
                                                comment="Diagonal retract"))
                rpass.moves.append(ToolMove("RAPID", z=z_clear))
            elif is_last_interval:
                # Last interval of multi: retract to x_clear
                rpass.moves.append(ToolMove("RAPID", x=x_clear, z=pullaway_z,
                                            comment="Diagonal retract"))
                rpass.moves.append(ToolMove("RAPID", z=z_clear))
            else:
                # More intervals follow: retract to x_clear for safe traverse
                rpass.moves.append(ToolMove("RAPID", x=x_clear, z=pullaway_z,
                                            comment="Diagonal retract"))

            passes.append(rpass)

        pass_num += 1

    return passes


# ===========================================================================
# Cleanup Pass (Contour-Following)
# ===========================================================================

def _plan_cleanup_pass(finish_moves, x_start_d, z_start, stock, params, mode):
    """Plan the cleanup pass that traces the roughing boundary contour.

    This pass removes the staircase left by constant-X roughing passes,
    leaving a uniform finish allowance on the profile.

    Returns list of ToolMove objects.
    """
    fin_allowance = params.fin_allowance
    offset_d = fin_allowance * 2
    z_clear = stock.z_start + 0.050
    z_lift = params.z_lift

    if mode == "OD":
        x_clear = stock.diameter + params.retract_dist
        start_x = x_start_d + offset_d
    else:
        x_clear = stock.diameter - _ID_FLOOR_OFFSET
        start_x = x_start_d - offset_d

    moves = []

    # Approach
    moves.append(ToolMove("RAPID", x=x_clear, z=z_clear,
                          comment="Cleanup pass"))
    moves.append(ToolMove("RAPID", x=start_x, z=z_start))

    # Trace each segment with offset
    for mv in finish_moves:
        if mv.type == "LINE":
            if mode == "OD":
                ox = mv.x + offset_d
            else:
                ox = mv.x - offset_d
            oz = mv.z + fin_allowance
            moves.append(ToolMove("FEED", x=ox, z=oz, feed=params.feed))
        elif mv.type == "ARC":
            if mode == "OD":
                ox = mv.x + offset_d
            else:
                ox = mv.x - offset_d
            oz = mv.z + fin_allowance
            if mv.radius > 0:
                moves.append(ToolMove("ARC_CW", x=ox, z=oz,
                                      radius=abs(mv.radius), feed=params.feed))
            else:
                moves.append(ToolMove("ARC_CCW", x=ox, z=oz,
                                      radius=abs(mv.radius), feed=params.feed))

    # Diagonal retract
    last_z = None
    last_x = None
    for mv in reversed(finish_moves):
        if mv.type in ("LINE", "ARC"):
            if mode == "OD":
                last_x = mv.x + offset_d
            else:
                last_x = mv.x - offset_d
            last_z = mv.z + fin_allowance
            break

    if last_z is not None:
        pullaway_z = last_z + z_lift
        if mode == "OD":
            moves.append(ToolMove("RAPID", x=x_clear, z=pullaway_z,
                                  comment="Diagonal retract"))
            moves.append(ToolMove("RAPID", z=z_clear))
        else:
            # ID retract logic
            if last_x is not None and last_x > x_start_d:
                # Widening bore: retract toward center
                moves.append(ToolMove("RAPID", x=x_clear, z=pullaway_z,
                                      comment="Diagonal retract"))
                moves.append(ToolMove("RAPID", z=z_clear))
            else:
                # Narrowing bore: retract toward center from current X
                retract_x = (last_x - params.retract_dist) if last_x else x_clear
                moves.append(ToolMove("RAPID", x=retract_x, z=pullaway_z,
                                      comment="Diagonal retract"))
                moves.append(ToolMove("RAPID", z=z_clear))
                moves.append(ToolMove("RAPID", x=x_clear))
    else:
        moves.append(ToolMove("RAPID", x=x_clear))
        moves.append(ToolMove("RAPID", z=z_clear))

    return moves


# ===========================================================================
# X-Level Computation
# ===========================================================================

def _compute_x_levels(stock, finish_moves, x_start_d, z_start, params, mode):
    """Compute the X diameter for each roughing pass.

    OD: start at stock_diameter, step inward by doc*2 (diameter)
    ID: start at bore_start, step outward or inward depending on profile

    Returns: ordered list of X diameters for each pass.
    """
    doc_d = params.doc * 2  # DOC on diameter
    fin_allowance = params.fin_allowance
    offset_d = fin_allowance * 2

    # Linearize profile to find extent
    rough_pts = [(x_start_d, z_start)]
    prev_pt = (x_start_d, z_start)
    for mv in finish_moves:
        if mv.type == "ARC" and mv.radius != 0:
            arc_pts = _linearize_arc(prev_pt[0], prev_pt[1], mv.x, mv.z, mv.radius)
            rough_pts.extend(arc_pts)
        else:
            rough_pts.append((mv.x, mv.z))
        prev_pt = (mv.x, mv.z)

    # Build roughing boundary (offset by fin_allowance)
    roughing_bnd = []
    for x, z in rough_pts:
        if mode == "OD":
            roughing_bnd.append((x + offset_d, z))
        else:
            roughing_bnd.append((x - offset_d, z))

    if mode == "OD":
        min_roughing_x = min(bx for bx, bz in roughing_bnd)
        current_d = stock.diameter
        levels = []
        cd = current_d - doc_d
        while cd > min_roughing_x:
            levels.append(cd)
            cd -= doc_d
        return levels

    else:  # ID
        max_roughing_x = max(bx for bx, bz in roughing_bnd)
        min_roughing_x = min(bx for bx, bz in roughing_bnd if bx > 0.01)
        current_d = stock.diameter  # bore start

        # Determine if bore widens or narrows
        bore_widens = max_roughing_x > current_d + doc_d

        if bore_widens:
            levels = []
            cd = current_d + doc_d
            while cd < max_roughing_x:
                levels.append(cd)
                cd += doc_d
            return levels
        else:
            levels = []
            cd = current_d - doc_d
            while cd > min_roughing_x:
                levels.append(cd)
                cd -= doc_d
            # ID narrowing: process from smallest to largest
            return sorted(levels)


# ===========================================================================
# Main Entry Point
# ===========================================================================

def plan_roughing(finish_moves: List[ProfileMove],
                  stock: StockDef,
                  params: RoughingParams,
                  mode: str) -> RoughingResult:
    """Plan all roughing passes for a profile. Pure algorithm, no G-code.

    This is the main entry point. It:
    1. Classifies the profile monotonicity
    2. Computes X levels (pass depths)
    3. Routes to monotonic or interval-based strategy
    4. Plans the cleanup pass
    5. Returns a complete RoughingResult

    Args:
        finish_moves: Ordered list of ProfileMove objects defining the finish profile
        stock: Stock/workpiece definition
        params: Roughing parameters (DOC, feed, retract, etc.)
        mode: "OD" or "ID"

    Returns:
        RoughingResult with passes, cleanup_pass, point_chart, and metadata
    """
    x_start_d = finish_moves[0].x if finish_moves else stock.diameter
    z_start = stock.z_start

    # For the profile start point, we use the stock definition
    # The first move in finish_moves is the first segment endpoint
    # (the start point is implicitly (x_start_d, z_start) from the parent block)
    # We need to figure out x_start_d from context — it's passed via stock for OD,
    # but for the profile it's the user's "X Start" field.
    # In the current conv_profile.py, x_start_d comes from self.x_start field.
    # We'll accept it as part of stock.diameter for now and let the caller set it.
    # Actually, we need a separate x_start for the profile vs stock diameter.
    # Let's use the first point convention: profile starts at (stock.diameter, z_start) for OD
    # or the caller passes the correct x_start_d.

    # Determine profile start from stock context
    profile_start_x = stock.diameter  # This is x_start_d for the profile
    # For OD: stock.diameter is the raw stock OD, profile_start_x is where profile begins
    # The caller should set stock.diameter appropriately:
    #   OD mode: stock.diameter = stock OD (for x_clear), but we also need x_start_d
    #   ID mode: stock.diameter = bore start diameter

    # We'll add x_start to StockDef or accept it separately.
    # For now, use a simple heuristic matching current behavior:
    # The profile always starts at the first segment's "from" point which is
    # defined by the parent block's X Start field.

    # Compute X levels
    x_levels = _compute_x_levels(stock, finish_moves, profile_start_x, z_start, params, mode)

    # Classify monotonicity
    has_peaks = _classify_monotonicity(finish_moves, profile_start_x, z_start, mode)

    # Route to appropriate strategy
    if has_peaks:
        strategy = "interval"
        interval_chart = _build_z_interval_chart(
            finish_moves, profile_start_x, z_start, x_levels, params.fin_allowance, mode)
        passes = _plan_passes_interval(interval_chart, x_levels, stock, params, mode)
        point_chart = interval_chart
    else:
        strategy = "monotonic"
        z_chart = _build_z_limit_chart(
            finish_moves, profile_start_x, z_start, x_levels, params.fin_allowance, mode)
        passes = _plan_passes_monotonic(z_chart, x_levels, stock, params, mode)
        point_chart = z_chart

    # Plan cleanup pass
    cleanup = _plan_cleanup_pass(
        finish_moves, profile_start_x, z_start, stock, params, mode)

    # Build metadata
    metadata = {
        "strategy": strategy,
        "num_passes": len(passes),
        "num_x_levels": len(x_levels),
        "has_peaks": has_peaks,
        "mode": mode,
        "profile_start_x": profile_start_x,
    }

    return RoughingResult(
        passes=passes,
        cleanup_pass=cleanup,
        point_chart=point_chart,
        metadata=metadata,
    )
