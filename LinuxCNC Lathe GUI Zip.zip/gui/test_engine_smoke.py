"""Quick smoke test for roughing_engine.py"""
import sys
sys.path.insert(0, r'c:\Users\jhonick\linuxcnc\my-lathe\gui')
from roughing_engine import plan_roughing, ProfileMove, StockDef, RoughingParams

# === Test 1: Simple OD straight turn ===
print("=== Test 1: Simple OD straight turn ===")
stock = StockDef(diameter=2.0, z_start=0.0, safe_x=2.5, safe_z=1.0)
params = RoughingParams(doc=0.050, fin_allowance=0.010, feed=0.005,
                        retract_dist=0.100, z_lift=0.020)
moves = [ProfileMove("LINE", 1.5, -1.0)]

result = plan_roughing(moves, stock, params, "OD")
print(f"  Strategy: {result.metadata['strategy']}")
print(f"  Passes: {result.metadata['num_passes']}")
print(f"  X levels: {result.metadata['num_x_levels']}")
for p in result.passes[:3]:
    print(f"    Pass {p.pass_num}: X={p.x_level:.4f} Z_end={p.z_end:.4f} ({len(p.moves)} moves)")
if len(result.passes) > 3:
    print(f"    ... ({len(result.passes) - 3} more)")
print(f"  Cleanup: {len(result.cleanup_pass)} moves")
print()

# === Test 2: OD taper ===
print("=== Test 2: OD taper (2.0 to 1.0 over 0.5 Z) ===")
moves2 = [ProfileMove("LINE", 1.0, -0.5)]
result2 = plan_roughing(moves2, stock, params, "OD")
print(f"  Strategy: {result2.metadata['strategy']}")
print(f"  Passes: {result2.metadata['num_passes']}")
for p in result2.passes[:5]:
    print(f"    Pass {p.pass_num}: X={p.x_level:.4f} Z_end={p.z_end:.4f}")
print()

# === Test 3: Non-monotonic (hump) ===
print("=== Test 3: Non-monotonic OD (step down, back up, down again) ===")
moves3 = [
    ProfileMove("LINE", 1.5, -0.3),   # step down
    ProfileMove("LINE", 1.5, -0.5),   # horizontal
    ProfileMove("LINE", 1.8, -0.5),   # step back up (face)
    ProfileMove("LINE", 1.8, -0.8),   # horizontal at larger dia
    ProfileMove("LINE", 1.5, -0.8),   # step down again
    ProfileMove("LINE", 1.5, -1.2),   # horizontal to end
]
result3 = plan_roughing(moves3, stock, params, "OD")
print(f"  Strategy: {result3.metadata['strategy']}")
print(f"  Has peaks: {result3.metadata['has_peaks']}")
print(f"  Passes: {result3.metadata['num_passes']}")
# Show interval chart for a few levels
if isinstance(result3.point_chart, dict):
    chart_keys = sorted(result3.point_chart.keys(), reverse=True)
    for k in chart_keys[:5]:
        v = result3.point_chart[k]
        if isinstance(v, list):
            intervals_str = ", ".join(f"[{zb:.4f} to {ze:.4f}]" for zb, ze in v)
            print(f"    X{k:.4f} -> {intervals_str}")
        else:
            print(f"    X{k:.4f} -> Z{v:.4f}")
print()

# === Test 4: Simple ID bore ===
print("=== Test 4: Simple ID bore (1.0 start, bore to 0.8 over 0.5 Z) ===")
stock_id = StockDef(diameter=1.0, z_start=0.0, safe_x=0.5, safe_z=1.0)
params_id = RoughingParams(doc=0.025, fin_allowance=0.005, feed=0.003,
                           retract_dist=0.050, z_lift=0.020)
moves4 = [ProfileMove("LINE", 0.8, -0.5)]
result4 = plan_roughing(moves4, stock_id, params_id, "ID")
print(f"  Strategy: {result4.metadata['strategy']}")
print(f"  Passes: {result4.metadata['num_passes']}")
for p in result4.passes[:3]:
    print(f"    Pass {p.pass_num}: X={p.x_level:.4f} Z_end={p.z_end:.4f}")
print()

# === Test 5: Arc profile ===
print("=== Test 5: OD with convex arc (ball nose) ===")
moves5 = [ProfileMove("ARC", 1.5, -0.25, radius=-0.25)]
result5 = plan_roughing(moves5, stock, params, "OD")
print(f"  Strategy: {result5.metadata['strategy']}")
print(f"  Passes: {result5.metadata['num_passes']}")
for p in result5.passes[:5]:
    print(f"    Pass {p.pass_num}: X={p.x_level:.4f} Z_end={p.z_end:.4f}")
print()

print("=== All smoke tests passed ===")
