# Requirements Document

## Introduction

Per-tool Z-axis soft limits for a CNC lathe GUI to prevent collisions with the headstock (Z-) and tailstock (Z+). Each tool in the tool library gets its own Z- and Z+ machine-coordinate limits that are enforced in real-time during jogging and program execution. Limits are stored in a sidecar JSON file, displayed in a dedicated limits view accessible from the tool tab, and visualized on the position graph.

## Glossary

- **Limit_Manager**: The module responsible for loading, saving, validating, and querying per-tool Z-axis soft limits from the `tool_limits.json` sidecar file.
- **Limit_Enforcer**: The component within the periodic update loop that monitors the active tool's machine Z position against its configured limits and issues a soft stop when a limit is reached.
- **Limits_View**: The UI panel (opened from the tool tab header) that displays a card-per-tool layout with Z- and Z+ limit fields and "Set Here" capture buttons.
- **Position_Graph**: The existing widget that renders live tool position, trails, and G-code simulation; extended to display active tool limit lines.
- **Tool_Library**: The existing set of tools defined in the tool tab, each identified by a pocket number (1–N) mapped to library tool numbers (T1xx).
- **Machine_Coordinates**: The absolute coordinate frame referenced to the machine home position, independent of work offsets (G5x).
- **Soft_Stop**: A controlled halt of axis motion issued by the GUI when a tool's Z limit is reached, without triggering an E-stop or fault.
- **Homed_State**: The condition where all axes have completed their homing sequence, as reported by `linuxcnc.stat().homed`.
- **Sidecar_File**: The `tool_limits.json` file stored alongside the tool table in the `my-lathe/` directory.

## Requirements

### Requirement 1: Limit Storage

**User Story:** As a machinist, I want per-tool Z-axis limits stored in a dedicated file, so that limits persist across sessions and are independent of the tool table format.

#### Acceptance Criteria

1. THE Limit_Manager SHALL store per-tool Z- and Z+ limits in a `tool_limits.json` file in the same directory as the tool table.
2. WHEN a tool has no entry in `tool_limits.json`, THE Limit_Manager SHALL treat that tool as having no Z-axis restrictions.
3. THE Limit_Manager SHALL store limit values as machine-coordinate floats in inches.
4. WHEN `tool_limits.json` is modified, THE Limit_Manager SHALL validate that Z- is less than Z+ for every tool entry.
5. IF `tool_limits.json` contains invalid JSON or fails validation, THEN THE Limit_Manager SHALL log a warning, ignore the invalid file, and treat all tools as having no limits.
6. THE Limit_Manager SHALL support partial entries where a tool has only a Z- limit or only a Z+ limit defined.
7. FOR ALL valid tool limit entries, writing then reading the `tool_limits.json` file SHALL produce equivalent limit values (round-trip property).

### Requirement 2: Limit Enforcement During Jog

**User Story:** As a machinist, I want the machine to stop before hitting the headstock or tailstock when I'm jogging, so that I don't crash expensive tooling or workholding.

#### Acceptance Criteria

1. WHILE the machine is in Homed_State and a tool with configured limits is active, THE Limit_Enforcer SHALL monitor the machine Z position on every periodic update cycle.
2. WHEN the machine Z position reaches or exceeds the active tool's Z+ limit during a jog, THE Limit_Enforcer SHALL issue a Soft_Stop.
3. WHEN the machine Z position reaches or falls below the active tool's Z- limit during a jog, THE Limit_Enforcer SHALL issue a Soft_Stop.
4. WHILE the machine is not in Homed_State, THE Limit_Enforcer SHALL not enforce any tool limits.
5. WHEN a tool with no configured limits is active, THE Limit_Enforcer SHALL allow unrestricted Z-axis motion.
6. WHEN a Soft_Stop is issued due to a limit violation, THE Limit_Enforcer SHALL display a status bar message identifying the violated limit (Z- or Z+) and the tool number.

### Requirement 3: Limit Enforcement During Program Execution

**User Story:** As a machinist, I want limits enforced during automatic program execution, so that a programming error doesn't cause a collision.

#### Acceptance Criteria

1. WHILE a G-code program is executing and the machine is in Homed_State, THE Limit_Enforcer SHALL monitor the machine Z position against the active tool's limits on every periodic update cycle.
2. WHEN the machine Z position violates the active tool's Z- or Z+ limit during program execution, THE Limit_Enforcer SHALL issue a feed hold followed by a Soft_Stop.
3. WHEN a tool change occurs during program execution (T-word), THE Limit_Enforcer SHALL apply the newly active tool's limits immediately.
4. WHEN a Soft_Stop is issued during program execution, THE Limit_Enforcer SHALL display a status bar message identifying the violated limit and the tool number.

### Requirement 4: Homing Interlock

**User Story:** As a machinist, I want limits disabled during homing, so that the homing sequence can reach the switches without interference.

#### Acceptance Criteria

1. WHILE any axis is performing a homing sequence, THE Limit_Enforcer SHALL disable all per-tool Z-axis limit checks.
2. WHEN all axes complete homing and enter Homed_State, THE Limit_Enforcer SHALL re-enable per-tool Z-axis limit enforcement for the active tool.

### Requirement 5: Limits View UI

**User Story:** As a machinist, I want a dedicated view to set and review Z limits for each tool, so that I can configure collision boundaries without leaving the tool tab.

#### Acceptance Criteria

1. THE Limits_View SHALL be accessible via a button in the tool tab header area, replacing the tool table filename display (`table_name_label`).
2. WHEN the limits button is clicked, THE Limits_View SHALL display a card-per-tool layout matching the tool library's current tool list.
3. THE Limits_View SHALL display two editable fields per tool: Z- (headstock limit) and Z+ (tailstock limit).
4. WHEN a limit field is left empty, THE Limits_View SHALL treat that limit as not configured for that tool.
5. THE Limits_View SHALL display limit values in the active unit mode (inches or millimeters) consistent with the rest of the GUI.
6. WHEN the user edits a limit value, THE Limits_View SHALL validate that Z- is less than Z+ (when both are set) before saving.
7. IF the user enters a Z- value greater than or equal to Z+, THEN THE Limits_View SHALL highlight the invalid field and display an inline error message.

### Requirement 6: "Set Here" Position Capture

**User Story:** As a machinist, I want to capture the current machine Z position as a limit value, so that I can set limits by jogging to the desired boundary.

#### Acceptance Criteria

1. THE Limits_View SHALL provide a "Set Here" button adjacent to each Z- and Z+ field for every tool.
2. WHEN the "Set Here" button is clicked, THE Limits_View SHALL populate the adjacent limit field with the current machine Z position.
3. WHILE the machine is not in Homed_State, THE Limits_View SHALL disable all "Set Here" buttons.
4. WHEN a "Set Here" button captures a position, THE Limits_View SHALL immediately persist the value to `tool_limits.json`.

### Requirement 7: Position Graph Visualization

**User Story:** As a machinist, I want to see the active tool's Z limits on the position graph, so that I have visual awareness of my safe travel zone.

#### Acceptance Criteria

1. WHILE a tool with configured Z limits is active, THE Position_Graph SHALL render the Z- limit as a vertical colored line.
2. WHILE a tool with configured Z limits is active, THE Position_Graph SHALL render the Z+ limit as a vertical colored line.
3. THE Position_Graph SHALL use a distinct color from the existing fence lines to differentiate tool limits from go-to fences.
4. WHEN the active tool changes, THE Position_Graph SHALL update the displayed limit lines to reflect the new tool's limits.
5. WHEN a tool has no configured limits, THE Position_Graph SHALL not display any tool limit lines.

### Requirement 8: Tool Change Limit Activation

**User Story:** As a machinist, I want limits to automatically switch when I change tools, so that each tool's unique clearance requirements are always active.

#### Acceptance Criteria

1. WHEN a tool change is detected (via `linuxcnc.stat().tool_in_spindle`), THE Limit_Manager SHALL look up the new tool's limits from `tool_limits.json`.
2. WHEN a tool change is detected, THE Limit_Enforcer SHALL immediately begin enforcing the new tool's limits.
3. WHEN a tool change is detected, THE Position_Graph SHALL update the displayed limit lines to reflect the new tool's configured limits.
4. WHEN the new tool has no configured limits, THE Limit_Enforcer SHALL allow unrestricted Z-axis motion and THE Position_Graph SHALL hide limit lines.

### Requirement 9: Persistence and Auto-Save

**User Story:** As a machinist, I want limit changes saved automatically, so that I don't lose my configuration if I forget to save manually.

#### Acceptance Criteria

1. WHEN a limit value is changed in the Limits_View, THE Limit_Manager SHALL persist the change to `tool_limits.json` within 1 second.
2. WHEN a tool is added to the tool library, THE Limit_Manager SHALL not create a default limit entry for the new tool.
3. WHEN a tool is removed from the tool library, THE Limit_Manager SHALL remove the corresponding entry from `tool_limits.json`.
4. IF writing to `tool_limits.json` fails (permission error, disk full), THEN THE Limit_Manager SHALL display a status bar warning and retain the in-memory limits until the next successful write.

### Requirement 10: Offline Preview Mode Compatibility

**User Story:** As a developer, I want the limits feature to work in offline preview mode, so that I can develop and test on Windows without LinuxCNC hardware.

#### Acceptance Criteria

1. WHILE running in offline preview mode (`HAS_LINUXCNC = False`), THE Limit_Manager SHALL load and save `tool_limits.json` normally.
2. WHILE running in offline preview mode, THE Limits_View SHALL function with simulated position data for "Set Here" capture.
3. WHILE running in offline preview mode, THE Position_Graph SHALL display tool limit lines based on loaded limit data.
4. WHILE running in offline preview mode, THE Limit_Enforcer SHALL skip enforcement checks (no Soft_Stop issued).
