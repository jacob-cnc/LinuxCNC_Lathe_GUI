# Implementation Plan: Per-Tool Soft Limits

## Overview

Implement per-tool Z-axis soft limits for the CNC lathe GUI. The feature consists of four components built incrementally: LimitManager (file I/O and validation), LimitEnforcer (position monitoring and soft stop), LimitsView (UI panel), and PositionGraph extensions (limit line rendering). Each component is wired into the existing LatheGUI periodic update loop.

## Tasks

- [x] 1. Create LimitManager core module
  - [x] 1.1 Create `gui/limit_manager.py` with ToolLimit dataclass and LimitManager skeleton
    - Create the file with imports (json, os, logging, dataclasses, typing)
    - Implement `ToolLimit` dataclass with `tool_num: int`, `z_minus: Optional[float]`, `z_plus: Optional[float]`
    - Add `is_valid()` method: returns True if z_minus < z_plus when both set, else True
    - Implement `LimitManager.__init__(self, limits_dir: str)` — store path, initialize empty `_limits: Dict[int, ToolLimit]`
    - Implement `get_limits(tool_num)` — return `(z_minus, z_plus)` tuple or None if not in dict
    - Implement `all_limits()` — return dict of all configured limits
    - Implement `validate()` — iterate all entries, return True if all are valid
    - _Requirements: 1.2, 1.3, 1.6_

  - [x] 1.2 Implement LimitManager `load()` method
    - Read `tool_limits.json` from `limits_dir`
    - Parse JSON, extract `limits` dict from top-level object
    - Convert each entry to a `ToolLimit` instance
    - If file missing: set empty limits, return True (normal first-use)
    - If invalid JSON: log warning, set empty limits, return False
    - If validation fails (any z_minus >= z_plus): log warning, set empty limits, return False
    - _Requirements: 1.1, 1.4, 1.5_

  - [x] 1.3 Implement LimitManager `save()` method
    - Serialize `_limits` dict to JSON with `version: 1` field
    - Write to `tool_limits.json` atomically (write to temp file, then rename)
    - Return True on success, False on write failure (log warning)
    - _Requirements: 1.1, 1.3, 1.7_

  - [x] 1.4 Implement LimitManager `set_limit()` and `remove_tool()` methods
    - `set_limit(tool_num, z_minus=None, z_plus=None)` — validate z_minus < z_plus when both set, update `_limits` dict, return True/False
    - `remove_tool(tool_num)` — delete entry from `_limits` dict if present
    - _Requirements: 1.4, 1.6, 9.3_

  - [ ]* 1.5 Write property tests for LimitManager serialization (Property 1)
    - Create `gui/tests/test_limit_manager.py`
    - **Property 1: Serialization round-trip**
    - Generate random valid limit dicts with arbitrary tool numbers (1-99), optional z_minus/z_plus where z_minus < z_plus
    - Write to temp file via `save()`, read back via `load()`, assert `all_limits()` produces equivalent data
    - Use `@settings(max_examples=100)`
    - **Validates: Requirements 1.7, 1.3, 1.6**

  - [ ]* 1.6 Write property tests for LimitManager validation (Property 2)
    - **Property 2: Validation rejects invalid limit pairs**
    - Generate random float pairs, call `set_limit()`, verify returns False when z_minus >= z_plus
    - Verify returns True when z_minus < z_plus
    - **Validates: Requirements 1.4, 5.6**

  - [ ]* 1.7 Write property tests for invalid file fallback (Property 3)
    - **Property 3: Invalid file produces graceful fallback**
    - Generate random byte strings (non-JSON) and write directly to `tool_limits.json`
    - Call `load()`, verify returns False
    - Verify `get_limits(tool_num)` returns None for arbitrary tool numbers
    - **Validates: Requirements 1.5**

- [x] 2. Checkpoint - Ensure all LimitManager tests pass
  - Run `pytest gui/tests/test_limit_manager.py -v`
  - Ensure all tests pass, ask the user if questions arise.

- [x] 3. Create LimitEnforcer module
  - [x] 3.1 Create `gui/limit_enforcer.py` with LimitEnforcer skeleton and `check()` method
    - Create the file with imports
    - Implement `__init__(self, limit_manager, cmd=None)` — store references, init `_enabled = True`, `_last_violation = None`
    - Implement `set_enabled(enabled)` — set `_enabled` flag
    - Implement `active_limits` property — call `limit_manager.get_limits()` for current tool
    - Implement `check(z_machine, tool_num, is_homed, is_program_running)`:
      - If not enabled or not homed: return None
      - Get limits for tool_num; if None: return None
      - Check z_machine against z_minus and z_plus
      - If violation and same as last violation: return None (avoid repeated messages)
      - If new violation: store as last violation, return message string
      - If no violation: clear last violation, return None
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 4.1, 4.2_

  - [x] 3.2 Add soft stop commands to LimitEnforcer `check()` method
    - When violation detected and `cmd` is not None:
      - If `is_program_running`: call `cmd.feedhold()` first
      - Then call `cmd.abort()`
    - Format violation message: include tool number and direction (Z- or Z+)
    - _Requirements: 2.6, 3.1, 3.2, 3.3, 3.4_

  - [ ]* 3.3 Write property tests for unconfigured tool (Property 4)
    - Add to `gui/tests/test_limit_enforcer.py`
    - **Property 4: Unconfigured tool allows unrestricted motion**
    - Generate random tool numbers not in limits, random Z positions
    - Verify `check()` returns None regardless of position
    - **Validates: Requirements 1.2, 2.5, 8.4**

  - [ ]* 3.4 Write property tests for violation detection (Property 5)
    - **Property 5: Position outside configured limits triggers violation**
    - Generate limits (z_minus, z_plus) and positions
    - Verify violation returned iff z <= z_minus or z >= z_plus when homed
    - Verify no violation when z_minus < z < z_plus
    - **Validates: Requirements 2.2, 2.3, 3.1, 3.3, 8.1, 8.2**

  - [ ]* 3.5 Write property tests for homing interlock (Property 6)
    - **Property 6: Enforcement disabled when not homed**
    - Generate any position with is_homed=False, verify no violation returned
    - Also test set_enabled(False) produces no violation
    - **Validates: Requirements 2.4, 4.1, 4.2**

  - [ ]* 3.6 Write property tests for violation message content (Property 7)
    - **Property 7: Violation message identifies tool and direction**
    - Generate violations, verify message contains tool number and "Z-" or "Z+" indicator
    - **Validates: Requirements 2.6, 3.4**

- [x] 4. Checkpoint - Ensure all LimitEnforcer tests pass
  - Run `pytest gui/tests/test_limit_enforcer.py -v`
  - Ensure all tests pass, ask the user if questions arise.

- [x] 5. Extend PositionGraph with limit line rendering
  - [x] 5.1 Add limit line instance variables and setter methods to PositionGraph
    - In `gui/lathe_gui.py` (PositionGraph class), add `_tool_limit_z_minus = None` and `_tool_limit_z_plus = None` in `__init__`
    - Implement `set_tool_limits(z_minus, z_plus)` — store values, call `self.update()`
    - Implement `clear_tool_limits()` — set both to None, call `self.update()`
    - _Requirements: 7.4, 7.5_

  - [x] 5.2 Render limit lines in PositionGraph `paintEvent`
    - In `paintEvent`, after existing fence line drawing:
    - If `_tool_limit_z_minus` is not None: draw vertical dashed line at that Z position in warm orange (`#E67E22`)
    - If `_tool_limit_z_plus` is not None: draw vertical dashed line at that Z position in warm orange (`#E67E22`)
    - Convert machine Z coordinates to pixel X coordinates using existing graph scaling logic
    - Use `QPen` with `Qt.DashLine` style, 2px width
    - _Requirements: 7.1, 7.2, 7.3_

- [x] 6. Create LimitsView UI panel
  - [x] 6.1 Create `gui/limits_view.py` with LimitsView skeleton and scroll layout
    - Create the file with imports (PyQt5 widgets, LimitManager type hint)
    - Implement `LimitsView(QWidget)` with `limits_changed = pyqtSignal()`
    - In `__init__`: create a `QVBoxLayout` with a `QScrollArea` containing a vertical card container
    - Store references to `limit_manager` and `tool_tab`
    - Store `_machine_z = 0.0`, `_is_homed = False`, `_metric = False`
    - Implement `set_machine_z(z)`, `set_homed(homed)`, `set_metric_display(metric)` — store values, update UI state
    - _Requirements: 5.1, 5.2_

  - [x] 6.2 Create LimitCard widget for a single tool's limits
    - In `gui/limits_view.py`, add `LimitCard(QFrame)` class
    - Layout: tool number label (large, styled like tool tab), description label, then Z- row and Z+ row
    - Each row: label ("Z−" / "Z+"), QLineEdit (float input), "Set Here" QPushButton
    - Add an error label (hidden by default) for validation messages
    - Style to match existing tool tab cards (COLORS dict, border-radius, background)
    - _Requirements: 5.3, 5.4_

  - [x] 6.3 Implement LimitCard field editing, validation, and save logic
    - Connect QLineEdit `editingFinished` signal to a validation handler
    - On edit: parse float values, validate z_minus < z_plus when both set
    - If invalid: show red border on field, display inline error message
    - If valid: call `limit_manager.set_limit()` then `limit_manager.save()`, emit `limits_changed`
    - Empty field → pass None for that limit direction
    - _Requirements: 5.6, 5.7, 9.1_

  - [x] 6.4 Implement "Set Here" button logic and homing state
    - Connect each "Set Here" button to capture `_machine_z` into the adjacent field
    - After capture: trigger the same validation and save logic as manual edit
    - In `set_homed(homed)`: enable/disable all "Set Here" buttons based on homing state
    - Add tooltip "Home all axes first" when disabled
    - _Requirements: 6.1, 6.2, 6.3, 6.4_

  - [x] 6.5 Implement `refresh()` and unit display conversion
    - `refresh()`: clear all cards, rebuild from tool library's current tool list and limit data
    - `set_metric_display(metric)`: when metric=True, display values as stored_value × 25.4; when False, display raw inches
    - On unit change: re-populate all fields with converted values
    - _Requirements: 5.2, 5.5_

  - [ ]* 6.6 Write property test for unit display conversion (Property 8)
    - Add to `gui/tests/test_limits_view.py`
    - **Property 8: Unit display conversion preserves value**
    - Generate random inch values, verify metric display = value × 25.4 (within float tolerance)
    - **Validates: Requirements 5.5**

  - [ ]* 6.7 Write unit tests for LimitsView behavior
    - Test card count matches tool count after `refresh()`
    - Test "Set Here" populates field with current machine Z
    - Test "Set Here" buttons disabled when not homed
    - Test empty field saves as None
    - Test error styling applied when z_minus >= z_plus
    - _Requirements: 5.2, 5.3, 5.4, 5.7, 6.1, 6.2, 6.3_

- [x] 7. Checkpoint - Ensure all LimitsView tests pass
  - Run `pytest gui/tests/test_limits_view.py -v`
  - Ensure all tests pass, ask the user if questions arise.

- [x] 8. Integrate components into LatheGUI
  - [x] 8.1 Instantiate LimitManager and LimitEnforcer in LatheGUI.__init__()
    - Import LimitManager and LimitEnforcer at top of `gui/lathe_gui.py`
    - In `LatheGUI.__init__()`: create `self.limit_manager = LimitManager(limits_dir)` and call `load()`
    - In `LatheGUI.__init__()`: create `self.limit_enforcer = LimitEnforcer(self.limit_manager, self.lcnc_cmd)`
    - In offline mode: pass `cmd=None` to LimitEnforcer
    - _Requirements: 10.4_

  - [x] 8.2 Add limit enforcement to `periodic_update()` loop
    - After polling `linuxcnc.stat()`, extract `z_machine` from `stat.actual_position`
    - Determine `is_homed` from `stat.homed` (all axes)
    - Determine `is_program_running` from `stat.task_mode == linuxcnc.MODE_AUTO` and `stat.interp_state != INTERP_IDLE`
    - Call `self.limit_enforcer.check(z_machine, tool_in_spindle, is_homed, is_program_running)`
    - If result is not None: display message in status bar
    - _Requirements: 2.1, 3.1_

  - [x] 8.3 Add homing interlock logic to `periodic_update()`
    - Detect homing-in-progress: any axis where `stat.homing` is non-zero or transitioning to homed
    - When homing detected: call `self.limit_enforcer.set_enabled(False)`
    - When all axes homed and no homing in progress: call `self.limit_enforcer.set_enabled(True)`
    - _Requirements: 4.1, 4.2_

  - [x] 8.4 Add tool change detection and graph limit update to `periodic_update()`
    - Track `self._last_tool_in_spindle` to detect changes
    - When `stat.tool_in_spindle` changes: look up new tool's limits via `limit_manager.get_limits()`
    - If limits exist: call `self.position_graph.set_tool_limits(z_minus, z_plus)`
    - If no limits: call `self.position_graph.clear_tool_limits()`
    - _Requirements: 8.1, 8.2, 8.3, 8.4_

  - [x] 8.5 Add "Limits" button to tool tab header and wire LimitsView toggle
    - In tool tab header area: replace `table_name_label` with a "Limits" QPushButton (styled as toggle)
    - Create `self.limits_view = LimitsView(self.limit_manager, self.tool_tab)`
    - Add LimitsView to tool tab layout (hidden by default)
    - On button click: toggle visibility of tool table vs LimitsView
    - Connect `limits_view.limits_changed` signal to refresh enforcer active limits and graph lines
    - _Requirements: 5.1_

  - [x] 8.6 Feed live data to LimitsView in `periodic_update()`
    - Call `self.limits_view.set_machine_z(z_machine)` each cycle
    - Call `self.limits_view.set_homed(is_homed)` each cycle
    - On unit mode change: call `self.limits_view.set_metric_display(is_metric)`
    - _Requirements: 6.2, 6.3_

  - [x] 8.7 Handle tool removal cleanup
    - When a tool is removed from the tool library, call `self.limit_manager.remove_tool(tool_num)` and `self.limit_manager.save()`
    - Refresh LimitsView if visible
    - _Requirements: 9.2, 9.3_

  - [x] 8.8 Handle offline preview mode specifics
    - In offline mode: LimitManager loads/saves normally (no special handling needed)
    - In offline mode: LimitsView uses simulated position from `_offline_demo()` Z value
    - In offline mode: PositionGraph displays limit lines (no special handling needed)
    - In offline mode: LimitEnforcer `check()` returns None always (cmd=None means no abort issued)
    - _Requirements: 10.1, 10.2, 10.3, 10.4_

- [x] 9. Checkpoint - Ensure integration works
  - Run the GUI in offline preview mode: `python gui/lathe_gui.py`
  - Verify: Limits button appears in tool tab header
  - Verify: Clicking Limits button shows card-per-tool layout
  - Verify: Limit lines appear on position graph when limits are set
  - Ask the user if questions arise.

- [ ]* 10. Write integration tests
  - [ ]* 10.1 Test periodic_update enforcement cycle
    - Mock `linuxcnc.stat` and `linuxcnc.command`
    - Set up tool with limits, simulate position at limit boundary
    - Verify `abort()` is called
    - _Requirements: 2.1, 2.2, 3.2_

  - [ ]* 10.2 Test tool change switches enforced limits
    - Mock tool change (tool_in_spindle changes)
    - Verify new tool's limits are applied to enforcer and graph
    - _Requirements: 8.1, 8.2, 8.3_

  - [ ]* 10.3 Test LimitsView edit persists to file
    - Edit a limit in LimitsView, verify `tool_limits.json` is updated
    - Reload LimitManager, verify new value is present
    - _Requirements: 9.1_

  - [ ]* 10.4 Test write failure preserves in-memory state
    - Make `tool_limits.json` read-only, attempt save
    - Verify in-memory limits are retained
    - _Requirements: 9.4_

- [x] 11. Final checkpoint - Ensure all tests pass
  - Run `pytest gui/tests/ -v`
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties from the design document
- Unit tests validate specific examples and edge cases
- All test files go in `gui/tests/` using pytest + hypothesis
- The design specifies Python with PyQt5 — all code uses this stack
- Limit values are always stored in inches (machine coordinates) regardless of display mode
- The warm orange color `#E67E22` is used for limit lines to distinguish from fence lines (`#E056A0`)

## Task Dependency Graph

```json
{
  "waves": [
    { "id": 0, "tasks": ["1.1"] },
    { "id": 1, "tasks": ["1.2", "1.3", "1.4"] },
    { "id": 2, "tasks": ["1.5", "1.6", "1.7", "3.1"] },
    { "id": 3, "tasks": ["3.2", "3.3", "3.4", "3.5", "3.6", "5.1"] },
    { "id": 4, "tasks": ["5.2", "6.1"] },
    { "id": 5, "tasks": ["6.2", "6.3", "6.4"] },
    { "id": 6, "tasks": ["6.5", "6.6", "6.7"] },
    { "id": 7, "tasks": ["8.1"] },
    { "id": 8, "tasks": ["8.2", "8.3", "8.4"] },
    { "id": 9, "tasks": ["8.5", "8.6"] },
    { "id": 10, "tasks": ["8.7", "8.8"] },
    { "id": 11, "tasks": ["10.1", "10.2", "10.3", "10.4"] }
  ]
}
```
