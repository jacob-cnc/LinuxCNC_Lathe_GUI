# Design Document: Per-Tool Soft Limits

## Overview

This feature adds per-tool Z-axis soft limits to the CNC lathe GUI, preventing collisions with the headstock (Z-) and tailstock (Z+) during jogging and program execution. Each tool in the library gets independent Z- and Z+ machine-coordinate boundaries that are enforced in real-time by the periodic update loop.

The system consists of four components:
1. **LimitManager** — loads, validates, and persists per-tool limits from `tool_limits.json`
2. **LimitEnforcer** — monitors machine Z position each update cycle and issues soft stops on violation
3. **LimitsView** — UI panel for viewing/editing limits, accessible from the tool tab header
4. **PositionGraph extensions** — renders active tool limit lines on the coordinate plot

Key design decisions:
- Limits stored in a sidecar JSON file (not the tool table) to avoid format coupling
- Enforcement only active after homing — prevents interference with homing sequence
- Soft stop via `linuxcnc.command().abort()` — halts motion without triggering E-stop
- Feed hold issued before abort during program execution for controlled deceleration
- Visualization uses a distinct color (warm orange `#E67E22`) to differentiate from fence lines (pink `#E056A0`)

## Architecture

```mermaid
graph TD
    subgraph Storage
        JSON[tool_limits.json]
    end

    subgraph Core Logic
        LM[LimitManager]
        LE[LimitEnforcer]
    end

    subgraph GUI
        LV[LimitsView]
        PG[PositionGraph]
        TT[ToolTab]
        SB[StatusBar]
    end

    subgraph LinuxCNC
        STAT[linuxcnc.stat]
        CMD[linuxcnc.command]
    end

    JSON -->|load| LM
    LM -->|save| JSON
    LM -->|get_limits(tool)| LE
    LM -->|get_limits(tool)| PG
    LM -->|all_limits| LV

    STAT -->|position, homed, tool_in_spindle| LE
    LE -->|abort / feed_hold| CMD
    LE -->|violation message| SB

    LV -->|edit limits| LM
    LV -->|"Set Here" capture| STAT
    TT -->|open limits view| LV

    LE -->|active limits| PG
```

### Data Flow — Periodic Update Cycle

```mermaid
sequenceDiagram
    participant Timer as QTimer (100ms)
    participant GUI as LatheGUI.periodic_update
    participant Stat as linuxcnc.stat
    participant LE as LimitEnforcer
    participant Cmd as linuxcnc.command
    participant SB as StatusBar

    Timer->>GUI: timeout
    GUI->>Stat: poll()
    Stat-->>GUI: position, homed, tool_in_spindle, task_mode
    GUI->>LE: check(z_machine, tool_num, is_homed, task_mode)
    alt Limit violated
        LE->>Cmd: feed_hold() [if AUTO mode]
        LE->>Cmd: abort()
        LE->>SB: showMessage("Z+ limit reached — T101")
    end
```

## Components and Interfaces

### LimitManager

Pure data management class — no Qt dependencies. Handles file I/O, validation, and lookup.

```python
class LimitManager:
    """Manages per-tool Z-axis soft limits stored in tool_limits.json."""

    def __init__(self, limits_dir: str):
        """Initialize with directory path where tool_limits.json lives."""

    def load(self) -> bool:
        """Load limits from disk. Returns True on success, False on invalid/missing file."""

    def save(self) -> bool:
        """Persist current in-memory limits to disk. Returns True on success."""

    def get_limits(self, tool_num: int) -> Optional[Tuple[Optional[float], Optional[float]]]:
        """Return (z_minus, z_plus) for a tool, or None if no limits configured.
        
        Each component may be None if only one limit is set (partial entry).
        """

    def set_limit(self, tool_num: int, z_minus: Optional[float] = None, 
                  z_plus: Optional[float] = None) -> bool:
        """Set limits for a tool. Returns False if validation fails (z_minus >= z_plus)."""

    def remove_tool(self, tool_num: int) -> None:
        """Remove a tool's limit entry entirely."""

    def all_limits(self) -> Dict[int, Dict[str, Optional[float]]]:
        """Return all configured limits as {tool_num: {"z_minus": float|None, "z_plus": float|None}}."""

    def validate(self) -> bool:
        """Validate all entries: z_minus < z_plus where both are set."""
```

### LimitEnforcer

Stateless check function called each periodic update cycle. Keeps minimal state (last violation tool/direction to avoid repeated messages).

```python
class LimitEnforcer:
    """Monitors machine Z position and issues soft stops on limit violations."""

    def __init__(self, limit_manager: LimitManager, cmd=None):
        """Initialize with LimitManager reference and optional linuxcnc.command."""

    def check(self, z_machine: float, tool_num: int, is_homed: bool,
              is_program_running: bool) -> Optional[str]:
        """Check position against active tool limits.
        
        Returns violation message string if limit hit, None otherwise.
        Issues abort/feed-hold as side effect when violation detected.
        """

    def set_enabled(self, enabled: bool) -> None:
        """Enable/disable enforcement (disabled during homing)."""

    @property
    def active_limits(self) -> Optional[Tuple[Optional[float], Optional[float]]]:
        """Return the currently enforced (z_minus, z_plus) for graph display."""
```

### LimitsView

QWidget panel displayed in place of the tool table when the limits button is clicked. Card-per-tool layout matching the existing tool tab style.

```python
class LimitsView(QWidget):
    """UI panel for viewing and editing per-tool Z-axis soft limits."""

    limits_changed = pyqtSignal()  # Emitted when any limit is modified

    def __init__(self, limit_manager: LimitManager, tool_tab: ToolTab, parent=None):
        """Initialize with LimitManager and ToolTab references."""

    def refresh(self) -> None:
        """Rebuild the card list from current tool library and limit data."""

    def set_machine_z(self, z: float) -> None:
        """Update the current machine Z position for 'Set Here' capture."""

    def set_homed(self, homed: bool) -> None:
        """Enable/disable 'Set Here' buttons based on homing state."""

    def set_metric_display(self, metric: bool) -> None:
        """Toggle display units between inches and millimeters."""
```

### PositionGraph Extensions

New methods added to the existing `PositionGraph` class:

```python
# Added to PositionGraph
def set_tool_limits(self, z_minus: Optional[float], z_plus: Optional[float]) -> None:
    """Set the active tool's Z limit lines for display.
    
    Pass None for either to hide that limit line.
    Values are in machine coordinates (inches).
    """

def clear_tool_limits(self) -> None:
    """Hide all tool limit lines."""
```

### Integration Points in LatheGUI

The main `LatheGUI` class orchestrates the components:

- `__init__`: Creates `LimitManager` (path = `my-lathe/` directory), `LimitEnforcer`, wires signals
- `periodic_update`: After polling stat, calls `LimitEnforcer.check()` with current Z machine position
- Tool change detection: When `tool_in_spindle` changes, updates enforcer and graph limit lines
- Limits button in tool tab header: Toggles between tool table view and LimitsView

## Data Models

### tool_limits.json Schema

```json
{
  "version": 1,
  "limits": {
    "1": {"z_minus": -0.050, "z_plus": 6.500},
    "2": {"z_minus": -0.100},
    "3": {"z_plus": 5.000},
    "4": {"z_minus": -0.050, "z_plus": 4.250}
  }
}
```

Field definitions:
- `version`: Schema version integer for future migration
- `limits`: Object keyed by tool pocket number (string representation of integer)
- `z_minus`: Z- limit in machine coordinates (inches), toward headstock. Optional.
- `z_plus`: Z+ limit in machine coordinates (inches), toward tailstock. Optional.

Constraints:
- All values are floats in inches (machine coordinates)
- When both `z_minus` and `z_plus` are present: `z_minus < z_plus`
- Tool numbers correspond to pocket numbers (1-based), matching `ToolGeometryRow.tool_num`
- Missing keys mean "no limit in that direction"
- Missing tool entry means "no limits for that tool"

### Internal Data Structures

```python
@dataclass
class ToolLimit:
    """In-memory representation of a single tool's Z limits."""
    tool_num: int
    z_minus: Optional[float] = None  # Machine Z coordinate, inches
    z_plus: Optional[float] = None   # Machine Z coordinate, inches

    def is_valid(self) -> bool:
        """Check z_minus < z_plus when both are set."""
        if self.z_minus is not None and self.z_plus is not None:
            return self.z_minus < self.z_plus
        return True
```


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Serialization round-trip

*For any* valid set of tool limit entries (with arbitrary tool numbers, optional z_minus, optional z_plus, where z_minus < z_plus when both present), serializing to `tool_limits.json` and then deserializing SHALL produce an equivalent set of limit entries.

**Validates: Requirements 1.7, 1.3, 1.6**

### Property 2: Validation rejects invalid limit pairs

*For any* pair of floats (z_minus, z_plus) where z_minus >= z_plus, the LimitManager SHALL reject the entry and return a validation failure. Conversely, for any pair where z_minus < z_plus, validation SHALL succeed.

**Validates: Requirements 1.4, 5.6**

### Property 3: Invalid file produces graceful fallback

*For any* byte string that is not valid JSON or contains entries failing validation, loading the file SHALL result in all tools reporting no configured limits (get_limits returns None for all tool numbers).

**Validates: Requirements 1.5**

### Property 4: Unconfigured tool allows unrestricted motion

*For any* tool number that has no entry in the limits data, and *for any* machine Z position, the LimitEnforcer SHALL report no violation regardless of position value.

**Validates: Requirements 1.2, 2.5, 8.4**

### Property 5: Position outside configured limits triggers violation

*For any* tool with configured limits (z_minus, z_plus), and *for any* machine Z position where z <= z_minus or z >= z_plus, the LimitEnforcer SHALL detect a violation when the machine is homed. Conversely, for any position where z_minus < z < z_plus, no violation SHALL be detected.

**Validates: Requirements 2.2, 2.3, 3.1, 3.3, 8.1, 8.2**

### Property 6: Enforcement disabled when not homed

*For any* tool with configured limits, and *for any* machine Z position (including positions that would violate limits), the LimitEnforcer SHALL report no violation when is_homed is False.

**Validates: Requirements 2.4, 4.1, 4.2**

### Property 7: Violation message identifies tool and direction

*For any* limit violation detected by the LimitEnforcer, the returned message string SHALL contain the tool number and an indicator of which limit was violated (Z- or Z+).

**Validates: Requirements 2.6, 3.4**

### Property 8: Unit display conversion preserves value

*For any* limit value stored in inches, the displayed value in metric mode SHALL equal the stored value multiplied by 25.4, and the displayed value in inch mode SHALL equal the stored value unchanged.

**Validates: Requirements 5.5**

## Error Handling

| Scenario | Behavior | User Feedback |
|----------|----------|---------------|
| `tool_limits.json` missing | LimitManager treats all tools as unlimited | None (normal for first use) |
| `tool_limits.json` invalid JSON | LimitManager ignores file, all tools unlimited | Warning in status bar |
| `tool_limits.json` validation failure (z_minus >= z_plus) | Entire file rejected, all tools unlimited | Warning in status bar |
| Write failure (permissions, disk full) | In-memory limits retained, save retried on next change | Warning in status bar: "Failed to save tool limits" |
| LinuxCNC not connected (offline mode) | LimitManager loads/saves normally; LimitEnforcer skips checks | No enforcement messages |
| Tool number not in limits file | No limits enforced for that tool | None |
| Limit violated during jog | `linuxcnc.command().abort()` issued | Status bar: "Z+ limit reached — T101" |
| Limit violated during program | `feed_hold()` then `abort()` issued | Status bar: "Z- limit reached — T102 (program halted)" |
| "Set Here" clicked when not homed | Button is disabled (greyed out) | Tooltip: "Home all axes first" |

### Recovery from Soft Stop

After a limit-triggered soft stop:
1. The machine is halted but not in E-stop — axes remain powered
2. The operator can jog in the opposite direction (away from the limit)
3. The program can be restarted from the beginning or a safe line
4. No special reset sequence is required

## Testing Strategy

### Property-Based Tests (Hypothesis)

The project already uses Hypothesis for property-based testing. Each correctness property maps to a dedicated test function with minimum 100 iterations.

**Library:** `hypothesis` (already in project dependencies)
**Configuration:** `@settings(max_examples=100)` minimum per property test
**Tag format:** Comment referencing design property, e.g.:
```python
# Feature: per-tool-soft-limits, Property 1: Serialization round-trip
```

Properties to implement:
1. **Round-trip serialization** — Generate random valid limit dicts, write to temp file, read back, assert equality
2. **Validation logic** — Generate random float pairs, verify accept/reject matches z_minus < z_plus
3. **Invalid file fallback** — Generate random non-JSON bytes and invalid structures, verify graceful degradation
4. **Unconfigured tool** — Generate random tool numbers absent from limits, verify no violation at any position
5. **Violation detection** — Generate limits and positions, verify violation iff position outside range and homed
6. **Homing interlock** — Generate any position with is_homed=False, verify no violation
7. **Message content** — Generate violations, verify message contains tool number and direction
8. **Unit conversion** — Generate random inch values, verify metric display = value × 25.4

### Unit Tests (pytest)

Example-based tests for specific scenarios and UI behavior:
- LimitsView card count matches tool count
- "Set Here" populates field with current machine Z
- "Set Here" buttons disabled when not homed
- Empty field saves as None (no limit)
- Error styling applied when z_minus >= z_plus
- Feed hold called before abort in program mode
- Tool removal cleans up limits entry
- File write failure preserves in-memory state

### Integration Tests

- Full periodic_update cycle with limit violation triggers abort
- Tool change during program execution switches enforced limits
- LimitsView edit → file written → LimitManager reload produces correct data
- Offline mode: full feature works without LinuxCNC modules

### Test File Organization

```
gui/tests/
  test_limit_manager.py      # Properties 1-4, unit tests for LimitManager
  test_limit_enforcer.py     # Properties 5-7, unit tests for LimitEnforcer
  test_limits_view.py        # Property 8, UI unit tests
  test_limits_integration.py # Integration tests
```
