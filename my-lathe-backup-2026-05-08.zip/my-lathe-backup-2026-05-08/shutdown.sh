#!/bin/bash
# Clean shutdown script for My-Lathe LinuxCNC
# Ensures work offsets and tool table are saved before power-off.
#
# Usage:
#   ./shutdown.sh          — shutdown LinuxCNC cleanly
#   ./shutdown.sh poweroff — shutdown LinuxCNC then power off the machine
#
# Can be called from:
#   - A desktop shortcut
#   - A physical shutdown button via HAL + a script
#   - The system shutdown sequence (/etc/rc0.d/ or systemd)

LINUXCNC_INI="$HOME/linuxcnc/my-lathe/my-lathe.ini"

echo "=== My-Lathe Clean Shutdown ==="
echo "$(date): Starting clean shutdown sequence..."

# 1. Send abort to stop any running program
if command -v halcmd &> /dev/null; then
    echo "Aborting any active program..."
    halcmd setp halui.abort 1
    sleep 0.5
    halcmd setp halui.abort 0
fi

# 2. Issue M2 via MDI to force parameter file save
if command -v linuxcnc_var_save &> /dev/null; then
    echo "Saving parameters via linuxcnc_var_save..."
    linuxcnc_var_save
elif command -v halcmd &> /dev/null; then
    # Use halui MDI interface to issue M2
    echo "Issuing M2 to save parameters..."
    halcmd setp halui.mode.mdi 1
    sleep 0.3
    halcmd setp halui.mode.mdi 0
    # M2 triggers parameter save
    halcmd setp halui.mdi-command "M2"
    sleep 1
fi

# 3. Wait for LinuxCNC to finish writing
sleep 1

# 4. Verify var file was updated recently
VAR_FILE="$HOME/linuxcnc/my-lathe/my-lathe.var"
if [ -f "$VAR_FILE" ]; then
    MOD_TIME=$(stat -c %Y "$VAR_FILE" 2>/dev/null || stat -f %m "$VAR_FILE" 2>/dev/null)
    NOW=$(date +%s)
    AGE=$((NOW - MOD_TIME))
    if [ "$AGE" -lt 10 ]; then
        echo "✓ Parameter file saved (${AGE}s ago)"
    else
        echo "⚠ Parameter file last modified ${AGE}s ago — may not have saved"
    fi
else
    echo "⚠ Parameter file not found: $VAR_FILE"
fi

# 5. Kill LinuxCNC gracefully
if pgrep -x "linuxcncsvr" > /dev/null 2>&1; then
    echo "Stopping LinuxCNC server..."
    pkill -TERM linuxcncsvr
    sleep 2
fi

if pgrep -f "linuxcnc" > /dev/null 2>&1; then
    echo "Stopping remaining LinuxCNC processes..."
    pkill -TERM -f "linuxcnc"
    sleep 2
fi

echo "$(date): Clean shutdown complete."

# 6. Optional: power off the machine
if [ "$1" = "poweroff" ]; then
    echo "Powering off system..."
    sudo shutdown -h now
fi
