import sys
sys.path.insert(0, r'c:\Users\jhonick\linuxcnc\alt-lathe\gui')
sys.path.insert(0, r'c:\Users\jhonick\linuxcnc\alt-lathe\gui\tests')
from test_roughing_clipping import _make_profile_block, _set_profile_fields, _add_segments

blk = _make_profile_block()
_set_profile_fields(blk, mode='OD', stock_dia='1.250', x_start='0.000',
    z_start='0.1', doc='0.030', fin_passes='1', fin_doc='0.002',
    feed_r='0.005', feed_f='0.003', retract='0.100', rough_tool='1',
    finish_tool='1', rpm='1200', safe_x='3.000', safe_z='1.000')
_add_segments(blk, [
    {'x_end': '1.000', 'z_end': '0.000'},
    {'x_end': '1.000', 'z_end': '-0.500'},
    {'x_end': '1.000', 'z_end': '-1.000', 'is_arc': True, 'arc_r': '0.250', 'arc_dir': 'CW'},
    {'x_end': '1.000', 'z_end': '-1.500'},
    {'x_end': '1.000', 'z_end': '-2.000'},
])
gcode = blk.generate_gcode()

# Show chart for key X levels
lines = gcode.split('\n')
print("=== Point Chart (key levels) ===")
for l in lines:
    s = l.strip()
    if s.startswith(';   X') and any(x in s for x in ['1.01', '0.98', '0.95', '0.80', '0.50']):
        print(s)

print("\n=== Pass 8 (last full-length pass) ===")
for l in lines:
    if 'Pass 8 ' in l:
        print(l)
        break

print("\n=== Pass 9 (first arc-zone pass) ===")
count = 0
for l in lines:
    if 'Pass 9' in l:
        count = 1
    if count > 0:
        print(l)
        count += 1
    if count > 8:
        break

print("\n=== Retract check (should use pass_clear, not x_clear for single intervals) ===")
for l in lines:
    if 'Diagonal retract' in l and 'Pass 8' not in l:
        # Check first few retracts
        print(l)
        break
