"""
Shared G-code Editor Base — LineNumberArea + GCodeEditor
=========================================================
Extracted from tabs/program.py so both the Program tab (read-only)
and the Edit tab (read-write) can reuse the same gutter/editor base.
"""

from PyQt5.QtWidgets import QWidget, QPlainTextEdit
from PyQt5.QtCore import Qt, QRect, QSize
from PyQt5.QtGui import QPainter, QColor

from theme import COLORS, mono_font


# ---------------------------------------------------------------------------
# LineNumberArea — gutter widget (Qt "Code Editor Example" pattern)
# ---------------------------------------------------------------------------
class LineNumberArea(QWidget):
    """Gutter widget that displays line numbers for a QPlainTextEdit.

    Delegates all sizing and painting to its parent editor via
    ``line_number_area_width()`` and ``line_number_area_paint_event()``.
    """

    def __init__(self, editor):
        super().__init__(editor)
        self._editor = editor

    def sizeHint(self):
        return QSize(self._editor.line_number_area_width(), 0)

    def paintEvent(self, event):
        self._editor.line_number_area_paint_event(event)


# ---------------------------------------------------------------------------
# GCodeEditor — QPlainTextEdit with line-number gutter support
# ---------------------------------------------------------------------------
class GCodeEditor(QPlainTextEdit):
    """QPlainTextEdit subclass that hosts a LineNumberArea gutter.

    Public interface:
        line_number_area_width() -> int
        line_number_area_paint_event(event)
        update_line_number_area_width()
        update_line_number_area(rect, dy)
        resizeEvent(event)
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._line_number_area = LineNumberArea(self)
        self.blockCountChanged.connect(self.update_line_number_area_width)
        self.updateRequest.connect(self.update_line_number_area)
        self.update_line_number_area_width()

    # --- gutter width ---
    def line_number_area_width(self):
        digits = max(1, len(str(max(1, self.blockCount()))))
        fm = self.fontMetrics()
        # padding: 10px left + 6px right
        return 16 + fm.horizontalAdvance('9') * digits

    def update_line_number_area_width(self, _=0):
        self.setViewportMargins(self.line_number_area_width(), 0, 0, 0)

    def update_line_number_area(self, rect, dy):
        if dy:
            self._line_number_area.scroll(0, dy)
        else:
            self._line_number_area.update(
                0, rect.y(),
                self._line_number_area.width(), rect.height()
            )
        if rect.contains(self.viewport().rect()):
            self.update_line_number_area_width()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        cr = self.contentsRect()
        self._line_number_area.setGeometry(
            QRect(cr.left(), cr.top(),
                  self.line_number_area_width(), cr.height())
        )

    def line_number_area_paint_event(self, event):
        painter = QPainter(self._line_number_area)
        painter.fillRect(event.rect(), QColor(COLORS['bg_mid']))

        block = self.firstVisibleBlock()
        block_number = block.blockNumber()
        top = round(
            self.blockBoundingGeometry(block)
            .translated(self.contentOffset()).top()
        )
        bottom = top + round(self.blockBoundingRect(block).height())

        painter.setFont(self.font())
        text_color = QColor(COLORS['text_dim'])

        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                painter.setPen(text_color)
                painter.drawText(
                    0, top,
                    self._line_number_area.width() - 6,
                    self.fontMetrics().height(),
                    Qt.AlignRight, str(block_number + 1)
                )
            block = block.next()
            top = bottom
            bottom = top + round(self.blockBoundingRect(block).height())
            block_number += 1

        painter.end()
