# My-Lathe Custom GUI

Custom PyQt5 GUI for LinuxCNC lathe operation.

## File Structure
```
gui/
├── lathe_gui.py          — Main window + entry point
├── theme.py              — Colors, stylesheet, font helpers
├── widgets.py            — DRO, StatusIndicator, SpindlePanel, OverridePanel
├── position_graph.py     — 2D X/Z position plot with G-code simulation
├── tabs/
│   ├── manual.py         — Touch-off and quick positioning
│   ├── program.py        — G-code file loading and execution
│   ├── mdi.py            — Manual Data Input with history
│   ├── tool.py           — Mazak-style tool geometry editor
│   ├── offsets.py        — Work coordinate offset management
│   └── tuning.py         — Stepper, encoder, PID tuning
├── conversational.py     — Step-based conversational programming
├── conv_profile.py       — Mazatrol-style profile conversational
└── fonts/                — Bundled font files (Inter, JetBrains Mono)
```

## Features
- Large DRO with diameter/radius toggle for X axis
- 2D position graph with zoom/pan and G-code simulation playback
- Manual tab: jog controls, tool touch-off, quick positioning
- Program tab: G-code file loading, display, execution controls
- MDI tab: command entry with quick-command buttons and history
- Conv tab: Mazatrol-style profile conversational programming
- Tool tab: tool table management with orientation graphics
- Offsets tab: work coordinate offset management
- Tuning tab: stepper, encoder, PID parameter editing
- Spindle RPM display (read-only — manual spindle)
- Feed/spindle/rapid override display
- E-Stop and Power controls
- Dark machinist theme (steel blue-gray)

## Running

```bash
# Preview on Windows (offline mode):
python linuxcnc/my-lathe/gui/lathe_gui.py

# On LinuxCNC machine, set in my-lathe.ini:
# DISPLAY = lathe_gui.py
```

## Requirements
- Python 3
- PyQt5 (`pip install PyQt5` or `apt install python3-pyqt5`)
- LinuxCNC Python module (included with LinuxCNC installation)
