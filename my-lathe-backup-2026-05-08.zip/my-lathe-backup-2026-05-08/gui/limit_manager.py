"""Per-tool Z-axis soft limit management.

Handles loading, saving, validating, and querying per-tool Z-axis soft limits
from the tool_limits.json sidecar file.
"""

import json
import os
import tempfile
import logging
from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple

logger = logging.getLogger(__name__)


@dataclass
class ToolLimit:
    """In-memory representation of a single tool's Z limits."""

    tool_num: int
    z_minus: Optional[float] = None  # Machine Z coordinate, inches
    z_plus: Optional[float] = None   # Machine Z coordinate, inches

    def is_valid(self) -> bool:
        """Check z_minus < z_plus when both are set."""
        if self.z_minus is not None and self.z_plus is not None:
            return self.z_minus < self.z_plus
        return True


class LimitManager:
    """Manages per-tool Z-axis soft limits stored in tool_limits.json."""

    def __init__(self, limits_dir: str):
        """Initialize with directory path where tool_limits.json lives."""
        self._limits_dir = limits_dir
        self._limits: Dict[int, ToolLimit] = {}

    def load(self) -> bool:
        """Load limits from disk.

        Returns True on success (including file-not-found for first use).
        Returns False on invalid JSON or validation failure.
        """
        filepath = os.path.join(self._limits_dir, 'tool_limits.json')

        # File missing is normal for first use
        if not os.path.exists(filepath):
            self._limits = {}
            return True

        try:
            with open(filepath, 'r') as f:
                data = json.load(f)
        except (json.JSONDecodeError, ValueError, OSError) as e:
            logger.warning("Invalid JSON in tool_limits.json: %s", e)
            self._limits = {}
            return False

        # Extract limits dict from top-level object
        limits_data = data.get('limits', {})
        if not isinstance(limits_data, dict):
            logger.warning("tool_limits.json 'limits' field is not a dict")
            self._limits = {}
            return False

        # Convert each entry to a ToolLimit instance
        parsed: Dict[int, ToolLimit] = {}
        for key, entry in limits_data.items():
            try:
                tool_num = int(key)
            except (ValueError, TypeError):
                logger.warning("Invalid tool number key in tool_limits.json: %s", key)
                self._limits = {}
                return False

            if not isinstance(entry, dict):
                logger.warning("Invalid entry for tool %s in tool_limits.json", key)
                self._limits = {}
                return False

            z_minus = entry.get('z_minus')
            z_plus = entry.get('z_plus')

            # Coerce to float if present
            if z_minus is not None:
                try:
                    z_minus = float(z_minus)
                except (ValueError, TypeError):
                    logger.warning("Invalid z_minus value for tool %s", key)
                    self._limits = {}
                    return False

            if z_plus is not None:
                try:
                    z_plus = float(z_plus)
                except (ValueError, TypeError):
                    logger.warning("Invalid z_plus value for tool %s", key)
                    self._limits = {}
                    return False

            parsed[tool_num] = ToolLimit(tool_num=tool_num, z_minus=z_minus, z_plus=z_plus)

        # Validate all entries: z_minus < z_plus when both are set
        for limit in parsed.values():
            if not limit.is_valid():
                logger.warning(
                    "Validation failed for tool %d: z_minus (%.4f) >= z_plus (%.4f)",
                    limit.tool_num, limit.z_minus, limit.z_plus
                )
                self._limits = {}
                return False

        self._limits = parsed
        return True

    def get_limits(self, tool_num: int) -> Optional[Tuple[Optional[float], Optional[float]]]:
        """Return (z_minus, z_plus) for a tool, or None if no limits configured.

        Each component may be None if only one limit is set (partial entry).
        """
        limit = self._limits.get(tool_num)
        if limit is None:
            return None
        return (limit.z_minus, limit.z_plus)

    def set_limit(self, tool_num: int, z_minus: Optional[float] = None,
                  z_plus: Optional[float] = None) -> bool:
        """Set limits for a tool. Returns False if validation fails (z_minus >= z_plus).

        If both z_minus and z_plus are None, removes the tool entry entirely.
        """
        if z_minus is None and z_plus is None:
            self.remove_tool(tool_num)
            return True

        # Validate z_minus < z_plus when both are provided
        if z_minus is not None and z_plus is not None:
            if z_minus >= z_plus:
                return False

        self._limits[tool_num] = ToolLimit(
            tool_num=tool_num,
            z_minus=z_minus,
            z_plus=z_plus,
        )
        return True

    def remove_tool(self, tool_num: int) -> None:
        """Remove a tool's limit entry entirely."""
        self._limits.pop(tool_num, None)

    def save(self) -> bool:
        """Persist current in-memory limits to disk atomically.

        Writes to a temporary file first, then renames to tool_limits.json
        to avoid corruption on crash or power loss.

        Returns True on success, False on write failure.
        """
        # Build the limits dict with string keys, omitting None values
        limits_data = {}
        for tool_num, limit in self._limits.items():
            entry = {}
            if limit.z_minus is not None:
                entry["z_minus"] = limit.z_minus
            if limit.z_plus is not None:
                entry["z_plus"] = limit.z_plus
            limits_data[str(tool_num)] = entry

        data = {"version": 1, "limits": limits_data}

        target_path = os.path.join(self._limits_dir, "tool_limits.json")
        try:
            # Write to a temp file in the same directory, then atomically replace
            fd, tmp_path = tempfile.mkstemp(
                dir=self._limits_dir, suffix=".tmp", prefix="tool_limits_"
            )
            try:
                with os.fdopen(fd, "w") as f:
                    json.dump(data, f, indent=2)
                os.replace(tmp_path, target_path)
            except Exception:
                # Clean up temp file on failure
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
                raise
        except Exception as e:
            logger.warning("Failed to save tool limits: %s", e)
            return False

        return True

    def all_limits(self) -> Dict[int, Dict[str, Optional[float]]]:
        """Return all configured limits as {tool_num: {"z_minus": float|None, "z_plus": float|None}}."""
        return {
            tool_num: {"z_minus": limit.z_minus, "z_plus": limit.z_plus}
            for tool_num, limit in self._limits.items()
        }

    def validate(self) -> bool:
        """Validate all entries: z_minus < z_plus where both are set."""
        return all(limit.is_valid() for limit in self._limits.values())
