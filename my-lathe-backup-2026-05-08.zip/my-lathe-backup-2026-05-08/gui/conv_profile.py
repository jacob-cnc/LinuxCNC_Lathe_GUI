"""
Profile-Based Conversational Programming Module
=================================================
Mazatrol-style parent/child profile definition.

Parent block: stock definition, tools, feeds, speeds, DOC
Child blocks: sequential profile segments (X end, Z end) with optional arc

Corner breaks (chamfer/radius) are defined between segments using dedicated
CornerBreakRow widgets. Chamfers support configurable angle (Mazak C×A style):
  - C = leg length along the entering segment direction
  - A = angle from the entering segment direction (default 45°)
Radii are quarter-circle fillets.

The system infers move type from geometry:
  - Same X, different Z = straight OD/ID
  - Same Z, different X = face
  - Different X and Z = taper/angle
  - Arc option with radius and center point
"""

import math
import json
import logging
from datetime import datetime
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel,
    QPushButton, QComboBox, QGroupBox, QLineEdit, QTextEdit,
    QFrame, QScrollArea, QMessageBox, QFileDialog, QCheckBox
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont, QColor, QTextCursor, QTextCharFormat

import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from theme import COLORS, TOUCH_SIZES, mono_font, ui_font
from line_numbers import add_line_numbers
import thread_data

LBL = f"color: {COLORS['text_secondary']}; font-size: 16px; background: transparent;"
VAL = (f"background-color: {COLORS['bg_light']}; color: {COLORS['text']}; "
       f"border: 1px solid {COLORS['border']}; border-radius: 5px; padding: 4px 6px; font-size: 16px;")

# Conversion factor
_IN_TO_MM = 25.4


def _conv_field_to_metric(field, is_metric_now):
    """Convert a QLineEdit field value from inches to mm (or vice versa).

    Called when the display unit toggles. Reads current text, converts, rewrites.
    """
    try:
        val = float(field.text())
    except (ValueError, TypeError):
        return
    if is_metric_now:
        field.setText(f"{val * _IN_TO_MM:.3f}")
    else:
        field.setText(f"{val / _IN_TO_MM:.4f}")


def _inch_val(field, metric):
    """Read a field value and return it in inches regardless of display mode."""
    val = float(field.text())
    if metric:
        val /= _IN_TO_MM
    return val


# ---------------------------------------------------------------------------

def _lib_tool_num(prog_tool):
    """Convert program tool number to library tool number.

    Convention: T1 in program = T101 in library, T2 = T102, etc.
    Input can be string or int. Returns formatted string for G-code.
    """
    try:
        t = int(prog_tool)
        return str(100 + t)
    except (ValueError, TypeError):
        return str(prog_tool)


def _f(label, default="", tip="", w=80):
    l = QLabel(label)
    l.setStyleSheet(LBL)
    l.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
    f = QLineEdit(default)
    f.setStyleSheet(VAL)
    f.setFixedWidth(w)
    if tip: f.setToolTip(tip); l.setToolTip(tip)
    return l, f


def _linearize_arc(prev_x, prev_z, end_x, end_z, radius, step=0.010):
    """Linearize an arc segment into intermediate (x_dia, z) points.

    All X coordinates are in diameter.  The arc goes from (prev_x, prev_z)
    to (end_x, end_z) with the given signed radius (positive = G02/CW,
    negative = G03/CCW).  Returns a list of intermediate points (excluding
    the start point but including the endpoint).

    Uses the same arc center selection and sampling algorithm as the
    PositionGraph simulation renderer to guarantee consistency.
    """
    R = abs(radius)
    dx = end_x - prev_x
    dz = end_z - prev_z
    chord = math.sqrt(dx * dx + dz * dz)

    if R < 1e-9 or chord < 1e-9 or chord > 2.0 * R + 1e-6:
        return [(end_x, end_z)]

    ar = max(R, chord / 2 + 0.0001)
    h = math.sqrt(max(0, ar * ar - (chord / 2) ** 2))
    mx = (prev_x + end_x) / 2.0
    mz = (prev_z + end_z) / 2.0
    px = -dz / chord
    pz = dx / chord

    cw = radius > 0

    # Center selection — matches PositionGraph.sim_load exactly
    if radius > 0:
        if cw:  # arc_cw
            ccx, ccz = mx - h * px, mz - h * pz
        else:
            ccx, ccz = mx + h * px, mz + h * pz
    else:
        if cw:
            ccx, ccz = mx + h * px, mz + h * pz
        else:
            ccx, ccz = mx - h * px, mz - h * pz

    # Angles — using atan2(x - cx, z - cz) to match simulation
    sa = math.atan2(prev_x - ccx, prev_z - ccz)
    ea = math.atan2(end_x - ccx, end_z - ccz)

    if cw:
        if ea >= sa:
            ea -= 2 * math.pi
        if abs(ea - sa) > math.pi and radius > 0:
            ccx, ccz = 2 * mx - ccx, 2 * mz - ccz
            sa = math.atan2(prev_x - ccx, prev_z - ccz)
            ea = math.atan2(end_x - ccx, end_z - ccz)
            if ea >= sa:
                ea -= 2 * math.pi
    else:
        if ea <= sa:
            ea += 2 * math.pi
        if abs(ea - sa) > math.pi and radius > 0:
            ccx, ccz = 2 * mx - ccx, 2 * mz - ccz
            sa = math.atan2(prev_x - ccx, prev_z - ccz)
            ea = math.atan2(end_x - ccx, end_z - ccz)
            if ea <= sa:
                ea += 2 * math.pi

    # Sample the arc
    arc_len = abs(ea - sa) * ar
    n_steps = max(2, int(math.ceil(arc_len / step)))

    pts = []
    for i in range(1, n_steps + 1):
        t = sa + (ea - sa) * i / n_steps
        ax = ccx + ar * math.sin(t)
        az = ccz + ar * math.cos(t)
        pts.append((ax, az))

    if pts:
        pts[-1] = (end_x, end_z)

    return pts


def _linearize_arc_with_normals(prev_x, prev_z, end_x, end_z, radius, step=0.010):
    """Linearize an arc and return points with outward normal directions.

    Returns a list of (x, z, nx, nz) tuples where (nx, nz) is the unit
    outward normal at each point (pointing away from the arc center).
    Excludes the start point, includes the endpoint.
    """
    R = abs(radius)
    dx = end_x - prev_x
    dz = end_z - prev_z
    chord = math.sqrt(dx * dx + dz * dz)

    if R < 1e-9 or chord < 1e-9 or chord > 2.0 * R + 1e-6:
        return [(end_x, end_z, 0.0, 0.0)]

    mx = (prev_x + end_x) / 2.0
    mz = (prev_z + end_z) / 2.0
    d = chord / 2.0
    h_sq = R * R - d * d
    if h_sq < 0:
        h_sq = 0.0
    h = math.sqrt(h_sq)

    nx = -dz / chord
    nz = dx / chord

    c1x = mx + h * nx
    c1z = mz + h * nz
    c2x = mx - h * nx
    c2z = mz - h * nz

    def _sweep(cx, cz, cw):
        a1 = math.atan2(prev_z - cz, prev_x - cx)
        a2 = math.atan2(end_z - cz, end_x - cx)
        s = a2 - a1
        if cw:
            if s > 0:
                s -= 2.0 * math.pi
        else:
            if s < 0:
                s += 2.0 * math.pi
        return s

    cw = radius > 0
    s1 = _sweep(c1x, c1z, cw)
    s2 = _sweep(c2x, c2z, cw)

    if abs(s1) <= math.pi + 1e-9:
        cx, cz, sweep = c1x, c1z, s1
    else:
        cx, cz, sweep = c2x, c2z, s2

    ang1 = math.atan2(prev_z - cz, prev_x - cx)

    arc_len = abs(sweep) * R
    n_steps = max(2, int(math.ceil(arc_len / step)))

    pts = []
    for i in range(1, n_steps + 1):
        t = i / n_steps
        ang = ang1 + sweep * t
        px = cx + R * math.cos(ang)
        pz = cz + R * math.sin(ang)
        # Outward normal = direction from center to point
        out_x = math.cos(ang)
        out_z = math.sin(ang)
        pts.append((px, pz, out_x, out_z))

    if pts:
        pts[-1] = (end_x, end_z, pts[-1][2], pts[-1][3])

    return pts


def build_z_limit_chart(finish_moves, x_start_d, z_start, x_levels,
                        fin_allowance, mode):
    """Build a point chart of Z limits for each roughing pass X level.

    Uses the cleanup pass geometry (part boundary + finish DOC offset).
    For LINE segments: exact linear interpolation.
    For ARC segments: solve the circle equation directly using the arc
    center computed from the offset endpoints and R. No linearization.

    Args:
        finish_moves: List of ("LINE", x, z) or ("ARC", x, z, r) tuples
        x_start_d: Starting X diameter of the profile
        z_start: Starting Z position
        x_levels: List of roughing X diameters to compute Z limits for
        fin_allowance: Finish allowance on radius
        mode: "OD" or "ID"

    Returns:
        Dict mapping current_d (float) to z_limit (float).
    """
    EPS = 1e-9
    offset_d = fin_allowance * 2  # on diameter

    # Build the cleanup pass segment list with offset endpoints.
    if mode == "OD":
        cp_start_x = x_start_d + offset_d
    else:
        cp_start_x = x_start_d - offset_d

    segments = []
    prev_x, prev_z = cp_start_x, z_start
    for mv in finish_moves:
        if mv[0] == "LINE":
            ox = mv[1] + offset_d if mode == "OD" else mv[1] - offset_d
            oz = mv[2] + fin_allowance  # Z offset for LINE segments
            segments.append(("LINE", prev_x, prev_z, ox, oz))
            prev_x, prev_z = ox, oz
        elif mv[0] == "ARC":
            ox = mv[1] + offset_d if mode == "OD" else mv[1] - offset_d
            oz = mv[2] + fin_allowance
            segments.append(("ARC", prev_x, prev_z, ox, oz, mv[3]))
            prev_x, prev_z = ox, oz

    if not segments:
        return {}

    last_z = segments[-1][4]
    chart = {}

    for current_d in x_levels:
        z_limit = None
        found_safe = False

        for seg in segments:
            x1, z1 = seg[1], seg[2]
            x2, z2 = seg[3], seg[4]

            if mode == "OD":
                safe1 = x1 < current_d - EPS
                safe2 = x2 < current_d - EPS
            else:
                safe1 = x1 > current_d + EPS
                safe2 = x2 > current_d + EPS

            if safe1:
                found_safe = True
            if safe2:
                found_safe = True

            if seg[0] == "LINE":
                if safe1 and not safe2:
                    denom = x2 - x1
                    if abs(denom) < EPS:
                        z_cross = (z1 + z2) / 2.0
                    else:
                        t = (current_d - x1) / (x2 - x1)
                        t = max(0.0, min(1.0, t))
                        z_cross = z1 + t * (z2 - z1)
                    z_limit = z_cross
                elif not safe1 and safe2:
                    # Reverse crossing: unsafe→safe (ID segments go small X → large X)
                    denom = x2 - x1
                    if abs(denom) < EPS:
                        z_cross = (z1 + z2) / 2.0
                    else:
                        t = (current_d - x1) / (x2 - x1)
                        t = max(0.0, min(1.0, t))
                        z_cross = z1 + t * (z2 - z1)
                    z_limit = z_cross

            elif seg[0] == "ARC":
                arc_r = seg[5]
                R = abs(arc_r)

                # --- Compute arc center BEFORE X range check (Change 5) ---
                # This reordering allows us to compute the true X extent
                # from center and radius, fixing the zero-width range bug
                # for vertical/near-vertical arcs.
                # LinuxCNC computes arcs in RADIUS space (X/2) even though
                # G-code X is diameter. Convert to radius for arc math.
                rx1 = x1 / 2.0
                rz1 = z1
                rx2 = x2 / 2.0
                rz2 = z2
                r_current = current_d / 2.0

                dx = rx2 - rx1
                dz = rz2 - rz1
                chord = math.sqrt(dx * dx + dz * dz)

                if R < EPS or chord < EPS or chord > 2.0 * R + 1e-6:
                    # Degenerate — treat as line (tolerance matches _linearize_arc)
                    if safe1 and not safe2:
                        denom = x2 - x1
                        if abs(denom) > EPS:
                            t = (current_d - x1) / (x2 - x1)
                            t = max(0.0, min(1.0, t))
                            z_cross = z1 + t * (z2 - z1)
                            z_limit = z_cross
                    elif not safe1 and safe2:
                        denom = x2 - x1
                        if abs(denom) > EPS:
                            t = (current_d - x1) / (x2 - x1)
                            t = max(0.0, min(1.0, t))
                            z_cross = z1 + t * (z2 - z1)
                            z_limit = z_cross
                    continue

                ar = R
                if chord / 2.0 > R:
                    ar = chord / 2.0 + 0.0001
                h = math.sqrt(max(0, ar * ar - (chord / 2) ** 2))
                rmx = (rx1 + rx2) / 2.0
                rmz = (rz1 + rz2) / 2.0
                px = -dz / chord
                pz = dx / chord

                # Center selection — must match PositionGraph.sim_load
                # exactly.  sim_load sees the G-code R (always positive)
                # and the G-word (G02 = arc_cw, G03 = arc_ccw).
                # Internally arc_r > 0 means CW (G02), < 0 means CCW
                # (G03), but the G-code R magnitude is always positive.
                cw = arc_r > 0  # positive = G02/CW
                g_r = abs(arc_r)  # G-code R is always positive

                # sim_load center selection uses g_r > 0 (always true
                # for normal arcs) combined with move_type:
                if g_r > 0:
                    if cw:   # arc_cw
                        cx, cz = rmx - h * px, rmz - h * pz
                    else:    # arc_ccw
                        cx, cz = rmx + h * px, rmz + h * pz
                else:
                    if cw:
                        cx, cz = rmx + h * px, rmz + h * pz
                    else:
                        cx, cz = rmx - h * px, rmz - h * pz

                # Angle-based correction (matches sim_load)
                sa = math.atan2(rx1 - cx, rz1 - cz)
                ea = math.atan2(rx2 - cx, rz2 - cz)
                if cw:
                    if ea >= sa:
                        ea -= 2 * math.pi
                    if abs(ea - sa) > math.pi and g_r > 0:
                        cx, cz = 2 * rmx - cx, 2 * rmz - cz
                        sa = math.atan2(rx1 - cx, rz1 - cz)
                        ea = math.atan2(rx2 - cx, rz2 - cz)
                        if ea >= sa:
                            ea -= 2 * math.pi
                else:
                    if ea <= sa:
                        ea += 2 * math.pi
                    if abs(ea - sa) > math.pi and g_r > 0:
                        cx, cz = 2 * rmx - cx, 2 * rmz - cz
                        sa = math.atan2(rx1 - cx, rz1 - cz)
                        ea = math.atan2(rx2 - cx, rz2 - cz)
                        if ea <= sa:
                            ea += 2 * math.pi

                # --- Compute true X extent with angular sweep clamping ---
                # The arc's X extent may exceed the endpoints for vertical
                # arcs. Use center/radius and check if the arc passes
                # through the min/max X angles.
                # Convention: x = cx + ar * sin(angle), so:
                #   min X at angle = -pi/2 (sin = -1)
                #   max X at angle = +pi/2 (sin = +1)
                _ARC_EXTENT_EPS = 0.0001

                # Check if arc passes through min X (angle = -pi/2)
                min_x_angle = -math.pi / 2.0
                arc_passes_min_x = False
                if cw:
                    a = min_x_angle
                    while a > sa + _ARC_EXTENT_EPS:
                        a -= 2 * math.pi
                    while a < ea - _ARC_EXTENT_EPS:
                        a += 2 * math.pi
                    if ea - _ARC_EXTENT_EPS <= a <= sa + _ARC_EXTENT_EPS:
                        arc_passes_min_x = True
                else:
                    a = min_x_angle
                    while a < sa - _ARC_EXTENT_EPS:
                        a += 2 * math.pi
                    while a > ea + _ARC_EXTENT_EPS:
                        a -= 2 * math.pi
                    if sa - _ARC_EXTENT_EPS <= a <= ea + _ARC_EXTENT_EPS:
                        arc_passes_min_x = True

                # Check if arc passes through max X (angle = +pi/2)
                max_x_angle = math.pi / 2.0
                arc_passes_max_x = False
                if cw:
                    a = max_x_angle
                    while a > sa + _ARC_EXTENT_EPS:
                        a -= 2 * math.pi
                    while a < ea - _ARC_EXTENT_EPS:
                        a += 2 * math.pi
                    if ea - _ARC_EXTENT_EPS <= a <= sa + _ARC_EXTENT_EPS:
                        arc_passes_max_x = True
                else:
                    a = max_x_angle
                    while a < sa - _ARC_EXTENT_EPS:
                        a += 2 * math.pi
                    while a > ea + _ARC_EXTENT_EPS:
                        a -= 2 * math.pi
                    if sa - _ARC_EXTENT_EPS <= a <= ea + _ARC_EXTENT_EPS:
                        arc_passes_max_x = True

                # True X extent in diameter space (cx, ar are in radius space)
                if arc_passes_min_x:
                    true_x_min_d = (cx - ar) * 2.0
                else:
                    true_x_min_d = min(x1, x2)

                if arc_passes_max_x:
                    true_x_max_d = (cx + ar) * 2.0
                else:
                    true_x_max_d = max(x1, x2)

                # X range check using true extent
                if current_d < true_x_min_d - EPS or current_d > true_x_max_d + EPS:
                    if safe1 and not safe2:
                        z_limit = z2
                    elif not safe1 and safe2:
                        z_limit = z2
                    continue

                # Solve circle equation in radius space:
                # (X_radius - cx)² + (Z - cz)² = R²
                val_sq = ar * ar - (r_current - cx) ** 2
                if val_sq < 0:
                    continue

                val = math.sqrt(val_sq)
                z_candidate_1 = cz + val
                z_candidate_2 = cz - val

                # --- Angular sweep validation (Change 5) ---
                # Validate each Z candidate lies on the actual arc sweep,
                # rejecting phantom crossings on the opposite side of the
                # circle that pass the endpoint Z range filter.
                _SWEEP_EPS = 0.0001
                best_z = None
                for zc in [z_candidate_1, z_candidate_2]:
                    # Compute the angle for this candidate point
                    angle = math.atan2(r_current - cx, zc - cz)
                    # Check if angle lies within the arc's angular sweep
                    on_sweep = False
                    if cw:
                        # CW: sweep goes from sa down to ea (sa > ea)
                        a = angle
                        while a > sa + _SWEEP_EPS:
                            a -= 2 * math.pi
                        while a < ea - _SWEEP_EPS:
                            a += 2 * math.pi
                        if ea - _SWEEP_EPS <= a <= sa + _SWEEP_EPS:
                            on_sweep = True
                    else:
                        # CCW: sweep goes from sa up to ea (sa < ea)
                        a = angle
                        while a < sa - _SWEEP_EPS:
                            a += 2 * math.pi
                        while a > ea + _SWEEP_EPS:
                            a -= 2 * math.pi
                        if sa - _SWEEP_EPS <= a <= ea + _SWEEP_EPS:
                            on_sweep = True

                    if on_sweep:
                        if best_z is None or zc < best_z:
                            best_z = zc

                if best_z is not None:
                    z_limit = best_z

        if z_limit is not None:
            chart[current_d] = z_limit
        elif found_safe:
            chart[current_d] = last_z

    return chart


def build_z_interval_chart(finish_moves, x_start_d, z_start, x_levels, fin_allowance, mode="ID"):
    """Build a chart of Z intervals where material exists for each roughing X level.

    For each X level, walks the cleanup boundary segments sequentially and
    identifies contiguous Z intervals where material exists:
      - ID mode: material where boundary_x > cutting_x (bore wall farther from
        center than tool — material between tool and wall)
      - OD mode: material where boundary_x < cutting_x (profile smaller than
        tool — stock material between tool and profile)

    Uses a linearized boundary polyline for arc segments to avoid offset
    geometry issues. Arcs are sampled at the proper equidistant offset
    (same center, R + fin_allowance) to guarantee no overcutting.

    Args:
        finish_moves: List of ("LINE", x, z) or ("ARC", x, z, r) tuples
        x_start_d: Starting X diameter of the profile
        z_start: Starting Z position
        x_levels: List of roughing X diameters to compute intervals for
        fin_allowance: Finish allowance on radius
        mode: "OD" or "ID" (default "ID" for backward compatibility)

    Returns:
        Dict mapping current_d (float) to list of (z_begin, z_end) tuples.
        z_begin is closer to z_start (more positive Z), z_end is further
        from z_start (more negative Z). Material exists in each interval.
    """
    EPS = 1e-9
    offset_d = fin_allowance * 2  # on diameter

    # --- Step 1: Build the roughing boundary as a dense polyline ---
    # For LINE segments: simple X/Z offset (same as before).
    # For ARC segments: compute the original arc center, then sample the
    # offset arc (same center, R + fin_allowance) as a polyline.
    # This gives the proper equidistant offset without circle-equation issues.
    if mode == "OD":
        cp_start_x = x_start_d + offset_d
    else:
        cp_start_x = x_start_d - offset_d

    boundary = [(cp_start_x, z_start)]
    orig_prev = (x_start_d, z_start)

    for mv in finish_moves:
        if mv[0] == "LINE":
            ox = mv[1] + offset_d if mode == "OD" else mv[1] - offset_d
            oz = mv[2] + fin_allowance
            boundary.append((ox, oz))
            orig_prev = (mv[1], mv[2])

        elif mv[0] == "ARC":
            R_abs = abs(mv[3])
            # Arc math in RADIUS space (X/2) because G-code R is radius-space.
            orx1 = orig_prev[0] / 2.0
            orz1 = orig_prev[1]
            orx2 = mv[1] / 2.0
            orz2 = mv[2]

            adx = orx2 - orx1
            adz = orz2 - orz1
            achord = math.sqrt(adx * adx + adz * adz)

            if R_abs < 1e-9 or achord < 1e-9 or achord > 2.0 * R_abs + 1e-6:
                ox = mv[1] + offset_d if mode == "OD" else mv[1] - offset_d
                oz = mv[2] + fin_allowance
                boundary.append((ox, oz))
            else:
                a_ar = max(R_abs, achord / 2 + 0.0001)
                a_h = math.sqrt(max(0, a_ar * a_ar - (achord / 2) ** 2))
                a_mx = (orx1 + orx2) / 2.0
                a_mz = (orz1 + orz2) / 2.0
                a_px = -adz / achord
                a_pz = adx / achord

                if mv[3] > 0:
                    a_cx = a_mx - a_h * a_px
                    a_cz = a_mz - a_h * a_pz
                else:
                    a_cx = a_mx + a_h * a_px
                    a_cz = a_mz + a_h * a_pz

                a_sa = math.atan2(orx1 - a_cx, orz1 - a_cz)
                a_ea = math.atan2(orx2 - a_cx, orz2 - a_cz)
                a_cw = mv[3] > 0
                if a_cw:
                    if a_ea >= a_sa:
                        a_ea -= 2 * math.pi
                    if abs(a_ea - a_sa) > math.pi and mv[3] > 0:
                        a_cx = 2 * a_mx - a_cx
                        a_cz = 2 * a_mz - a_cz
                        a_sa = math.atan2(orx1 - a_cx, orz1 - a_cz)
                        a_ea = math.atan2(orx2 - a_cx, orz2 - a_cz)
                        if a_ea >= a_sa:
                            a_ea -= 2 * math.pi
                else:
                    if a_ea <= a_sa:
                        a_ea += 2 * math.pi
                    if abs(a_ea - a_sa) > math.pi and mv[3] > 0:
                        a_cx = 2 * a_mx - a_cx
                        a_cz = 2 * a_mz - a_cz
                        a_sa = math.atan2(orx1 - a_cx, orz1 - a_cz)
                        a_ea = math.atan2(orx2 - a_cx, orz2 - a_cz)
                        if a_ea <= a_sa:
                            a_ea += 2 * math.pi

                # Offset arc in radius space: R - 2*fin_allowance for OD valley.
                # The 2x factor accounts for the coordinate space mismatch
                # between the radius-space arc math and the cleanup pass's
                # endpoint-offset approach.
                if mode == "OD":
                    offset_ar = max(1e-9, a_ar - fin_allowance * 2)
                else:
                    offset_ar = a_ar + fin_allowance * 2

                arc_len = abs(a_ea - a_sa) * offset_ar
                n_steps = max(20, int(math.ceil(arc_len / 0.002)))
                for i in range(1, n_steps + 1):
                    t = a_sa + (a_ea - a_sa) * i / n_steps
                    bx_r = a_cx + offset_ar * math.sin(t)
                    bz = a_cz + offset_ar * math.cos(t)
                    boundary.append((bx_r * 2.0, bz))

            orig_prev = (mv[1], mv[2])

    if len(boundary) < 2:
        return {}

    # --- Step 2: For each X level, find Z crossings on the polyline ---
    chart = {}

    for current_d in x_levels:
        intervals = []
        in_material = False
        interval_start = None

        for i in range(len(boundary) - 1):
            bx1, bz1 = boundary[i]
            bx2, bz2 = boundary[i + 1]

            # Determine material state at each endpoint
            if mode == "OD":
                mat1 = bx1 < current_d - EPS
                mat2 = bx2 < current_d - EPS
            else:
                mat1 = bx1 > current_d + EPS
                mat2 = bx2 > current_d + EPS

            # Handle state at segment start
            if i == 0:
                if mat1:
                    in_material = True
                    interval_start = bz1

            # Check for crossing within this segment
            if mat1 != mat2:
                # Linear interpolation to find Z crossing
                denom = bx2 - bx1
                if abs(denom) < EPS:
                    z_cross = (bz1 + bz2) / 2.0
                else:
                    t = (current_d - bx1) / denom
                    t = max(0.0, min(1.0, t))
                    z_cross = bz1 + t * (bz2 - bz1)

                if mat1 and not mat2:
                    # Exiting material
                    if in_material and interval_start is not None:
                        intervals.append((interval_start, z_cross))
                        interval_start = None
                    in_material = False
                elif not mat1 and mat2:
                    # Entering material
                    in_material = True
                    interval_start = z_cross
            else:
                # No crossing — but handle state transitions at segment boundaries
                if mat2 and not in_material:
                    in_material = True
                    interval_start = bz2
                elif not mat2 and in_material:
                    in_material = False
                    if interval_start is not None:
                        intervals.append((interval_start, bz2))
                        interval_start = None

        # Close any open interval at the end of the boundary
        if in_material and interval_start is not None:
            last_z = boundary[-1][1]
            intervals.append((interval_start, last_z))

        if intervals:
            # Ensure all intervals are properly ordered (z_begin >= z_end)
            ordered = []
            for zb, ze in intervals:
                if zb >= ze:
                    ordered.append((zb, ze))
                else:
                    ordered.append((ze, zb))
            chart[current_d] = ordered

    return chart


# ---------------------------------------------------------------------------
# Child Segment Row
# ---------------------------------------------------------------------------
class CornerBreakRow(QFrame):
    """Corner break between two segments: None / Chamfer / Radius.

    Chamfer supports a configurable angle (Mazak C×A style).
    Radius is a quarter-circle fillet.
    """

    def __init__(self, corner_num=1, parent=None):
        super().__init__(parent)
        self.corner_num = corner_num
        self.setStyleSheet(
            f"QFrame {{ background-color: {COLORS['bg_dark']}; "
            f"border: 1px dashed {COLORS['border']}; border-radius: 6px; "
            f"margin: 0 20px; padding: 2px 6px; }}"
        )
        self.setFixedHeight(40)

        layout = QHBoxLayout(self)
        layout.setSpacing(8)
        layout.setContentsMargins(8, 2, 8, 2)

        # Corner label
        self.label = QLabel(f"↕ {corner_num}→{corner_num + 1}")
        self.label.setFont(mono_font(11, QFont.Bold))
        self.label.setStyleSheet(
            f"color: {COLORS['text_dim']}; background: transparent; border: none;")
        self.label.setFixedWidth(55)
        layout.addWidget(self.label)

        # Type combo
        self.cr_type = QComboBox()
        self.cr_type.addItems(["None", "Chamfer", "Radius"])
        self.cr_type.setFixedWidth(105)
        self.cr_type.setFixedHeight(30)
        self.cr_type.view().setMinimumWidth(120)
        self.cr_type.setStyleSheet(
            f"QComboBox {{ background: {COLORS['bg_light']}; color: {COLORS['text']}; "
            f"border: 1px solid {COLORS['border']}; border-radius: 4px; "
            f"padding: 2px 6px; font-size: 13px; min-height: 26px; }}"
            f"QComboBox QAbstractItemView::item {{ min-height: {TOUCH_SIZES['target_min']}px; padding: 8px 12px; }}")
        layout.addWidget(self.cr_type)

        # Size field
        l_size = QLabel("C:")
        l_size.setStyleSheet(
            f"color: {COLORS['text_dim']}; font-size: 13px; background: transparent; border: none;")
        layout.addWidget(l_size)
        self.cr_val = QLineEdit("0.030")
        self.cr_val.setStyleSheet(
            f"background-color: {COLORS['bg_light']}; color: {COLORS['text']}; "
            f"border: 1px solid {COLORS['border']}; border-radius: 4px; "
            f"padding: 2px 6px; font-size: 13px; min-height: 26px;")
        self.cr_val.setFixedWidth(60)
        self.cr_val.setFixedHeight(30)
        self.cr_val.setEnabled(False)
        self.cr_val.setToolTip("Chamfer leg length or fillet radius")
        layout.addWidget(self.cr_val)

        # Angle field (Chamfer only)
        self.angle_label = QLabel("A:")
        self.angle_label.setStyleSheet(
            f"color: {COLORS['text_dim']}; font-size: 13px; background: transparent; border: none;")
        layout.addWidget(self.angle_label)
        self.cr_angle = QLineEdit("45")
        self.cr_angle.setStyleSheet(
            f"background-color: {COLORS['bg_light']}; color: {COLORS['text']}; "
            f"border: 1px solid {COLORS['border']}; border-radius: 4px; "
            f"padding: 2px 6px; font-size: 13px; min-height: 26px;")
        self.cr_angle.setFixedWidth(44)
        self.cr_angle.setFixedHeight(30)
        self.cr_angle.setEnabled(False)
        self.cr_angle.setToolTip("Chamfer angle in degrees (from entering segment direction)")
        layout.addWidget(self.cr_angle)

        layout.addStretch()

        # Wire enable/disable
        self.cr_type.currentIndexChanged.connect(self._on_type_changed)
        self._on_type_changed(0)

    def _on_type_changed(self, index):
        is_active = index > 0
        is_chamfer = self.cr_type.currentText() == "Chamfer"
        self.cr_val.setEnabled(is_active)
        self.cr_angle.setEnabled(is_chamfer)
        self.angle_label.setVisible(is_chamfer)
        self.cr_angle.setVisible(is_chamfer)

    def set_num(self, n):
        self.corner_num = n
        self.label.setText(f"↕ {n}→{n + 1}")

    def get_data(self):
        return {
            "cr_type": self.cr_type.currentText(),
            "cr_val": self.cr_val.text(),
            "cr_angle": self.cr_angle.text(),
        }

    def set_metric_display(self, metric: bool):
        """Convert distance fields between inch and metric display.

        cr_val is a distance (chamfer leg or fillet radius).
        cr_angle is degrees — not converted.
        """
        _conv_field_to_metric(self.cr_val, metric)


class SegmentRow(QFrame):
    """One profile segment: X end (dia), Z end, with optional arc."""

    def __init__(self, seg_num=1, parent=None):
        super().__init__(parent)
        self.seg_num = seg_num
        self.setStyleSheet(
            f"QFrame {{ background-color: {COLORS['bg_mid']}; "
            f"border: 1px solid {COLORS['border']}; border-radius: 8px; "
            f"margin: 1px 0; padding: 2px; }}"
        )

        layout = QHBoxLayout(self)
        layout.setSpacing(6)
        layout.setContentsMargins(6, 4, 6, 4)

        self.num_label = QLabel(f"{seg_num}")
        self.num_label.setFont(mono_font(13, QFont.Bold))
        self.num_label.setStyleSheet(f"color: {COLORS['accent_blue']}; background: transparent; border: none;")
        self.num_label.setFixedWidth(20)
        layout.addWidget(self.num_label)

        self.type_label = QLabel("—")
        self.type_label.setFixedWidth(46)
        self.type_label.setAlignment(Qt.AlignCenter)
        self.type_label.setStyleSheet(
            f"color: {COLORS['accent_green']}; background: {COLORS['bg_light']}; "
            f"border-radius: 4px; border: none; font-size: 14px; font-weight: bold;")
        layout.addWidget(self.type_label)

        l, self.x_end = _f("X:", "0.000", "End X (diameter)", 70)
        layout.addWidget(l); layout.addWidget(self.x_end)

        l, self.z_end = _f("Z:", "0.000", "End Z", 70)
        layout.addWidget(l); layout.addWidget(self.z_end)

        # Arc option
        self.arc_check = QCheckBox("Arc")
        self.arc_check.setStyleSheet(f"color: {COLORS['text_secondary']}; background: transparent; border: none;")
        layout.addWidget(self.arc_check)

        self.arc_dir = QComboBox()
        self.arc_dir.addItems(["CW", "CCW"])
        self.arc_dir.setFixedWidth(168)
        self.arc_dir.setEnabled(False)
        layout.addWidget(self.arc_dir)

        l, self.arc_r = _f("R:", "", "Arc radius (always positive)", 50)
        l.setFixedWidth(20)
        layout.addWidget(l); layout.addWidget(self.arc_r)
        self.arc_r.setEnabled(False)
        self.arc_check.toggled.connect(self.arc_r.setEnabled)
        self.arc_check.toggled.connect(self.arc_dir.setEnabled)

        self.btn_remove = QPushButton("✕")
        self.btn_remove.setFixedSize(24, 24)
        self.btn_remove.setStyleSheet(
            f"QPushButton {{ border: none; border-radius: 6px; font-size: 16px; "
            f"background: {COLORS['accent']}; color: white; }}")
        layout.addWidget(self.btn_remove, 0, Qt.AlignVCenter)

    def set_num(self, n):
        self.seg_num = n
        self.num_label.setText(f"{n}")

    def get_data(self):
        return {
            "x_end": self.x_end.text(),
            "z_end": self.z_end.text(),
            "is_arc": self.arc_check.isChecked(),
            "arc_r": self.arc_r.text(),
            "arc_dir": self.arc_dir.currentText(),
        }

    def set_metric_display(self, metric: bool):
        """Convert distance fields between inch and metric display."""
        # x_end, z_end, arc_r are distance fields
        for field in (self.x_end, self.z_end, self.arc_r):
            _conv_field_to_metric(field, metric)

    def update_type_label(self, prev_x, prev_z):
        try:
            x1, z1 = float(prev_x), float(prev_z)
            x2, z2 = float(self.x_end.text()), float(self.z_end.text())
        except ValueError:
            self.type_label.setText("—"); return

        if self.arc_check.isChecked():
            label, color = "ARC", COLORS['accent_orange']
        else:
            dx, dz = abs(x2 - x1), abs(z2 - z1)
            if dx < 0.0005 and dz < 0.0005:
                label, color = "—", COLORS['text_dim']
            elif dx < 0.0005:
                label, color = "STR", COLORS['accent_green']
            elif dz < 0.0005:
                label, color = "FACE", COLORS['accent_blue']
            elif 0.9 < (dx / dz if dz > 0 else 999) < 1.1:
                label, color = "45°", COLORS['accent_yellow']
            else:
                label, color = "TAPER", COLORS['accent_orange']

        self.type_label.setText(label)
        self.type_label.setStyleSheet(
            f"color: {color}; background: {COLORS['bg_light']}; "
            f"border-radius: 4px; border: none; font-size: 14px; font-weight: bold;")


# ---------------------------------------------------------------------------
# Parent Profile Block
# ---------------------------------------------------------------------------
class ProfileBlock(QFrame):
    """Parent block: stock definition + child segments defining the finish profile."""

    def __init__(self, block_num=1, parent=None):
        super().__init__(parent)
        self.block_num = block_num
        self.segments = []
        self.corners = []
        self._expanded = True

        self.setStyleSheet(
            f"QFrame#profileBlock {{ background-color: {COLORS['bg_dark']}; "
            f"border: 1px solid {COLORS['accent_blue']}; border-radius: 10px; "
            f"margin: 2px 0; }}"
        )
        self.setObjectName("profileBlock")

        main = QVBoxLayout(self)
        main.setSpacing(4)
        main.setContentsMargins(8, 8, 8, 8)

        # --- Header ---
        hdr = QHBoxLayout()
        self.title = QLineEdit(f"Profile {block_num}")
        self.title.setFont(ui_font(14, QFont.Bold))
        self.title.setStyleSheet(
            f"color: {COLORS['accent_blue']}; background: transparent; "
            f"border: none; border-bottom: 1px solid transparent; padding: 2px 4px;")
        self.title.setToolTip("Click to rename this profile")
        self.title.setMaximumWidth(250)
        hdr.addWidget(self.title)
        hdr.addStretch()

        _hdr_btn = "border: none; border-radius: 8px; min-height: 0px; max-height: 36px; padding: 0px;"

        self.btn_collapse = QPushButton("▼")
        self.btn_collapse.setFixedSize(36, 36)
        self.btn_collapse.setFont(ui_font(14))
        self.btn_collapse.setStyleSheet(f"QPushButton {{ {_hdr_btn} background: {COLORS['bg_light']}; color: {COLORS['text']}; }}")
        self.btn_collapse.clicked.connect(self._toggle)
        hdr.addWidget(self.btn_collapse)

        self.btn_duplicate = QPushButton("x2")
        self.btn_duplicate.setFixedSize(36, 36)
        self.btn_duplicate.setFont(ui_font(13, QFont.Bold))
        self.btn_duplicate.setToolTip("Duplicate this profile block")
        self.btn_duplicate.setStyleSheet(
            f"QPushButton {{ {_hdr_btn} background: {COLORS['accent_blue']}; color: white; }}")
        hdr.addWidget(self.btn_duplicate)

        self.btn_move_up = QPushButton("↑")
        self.btn_move_up.setFixedSize(36, 36)
        self.btn_move_up.setFont(ui_font(16))
        self.btn_move_up.setToolTip("Move up")
        self.btn_move_up.setStyleSheet(f"QPushButton {{ {_hdr_btn} background: {COLORS['bg_light']}; color: {COLORS['text']}; }}")
        hdr.addWidget(self.btn_move_up)

        self.btn_move_down = QPushButton("↓")
        self.btn_move_down.setFixedSize(36, 36)
        self.btn_move_down.setFont(ui_font(16))
        self.btn_move_down.setToolTip("Move down")
        self.btn_move_down.setStyleSheet(f"QPushButton {{ {_hdr_btn} background: {COLORS['bg_light']}; color: {COLORS['text']}; }}")
        hdr.addWidget(self.btn_move_down)

        self.btn_remove = QPushButton("✕")
        self.btn_remove.setFixedSize(36, 36)
        self.btn_remove.setFont(ui_font(14, QFont.Bold))
        self.btn_remove.setStyleSheet(
            f"QPushButton {{ {_hdr_btn} background: {COLORS['accent']}; color: white; }}")
        hdr.addWidget(self.btn_remove)

        hdr.setContentsMargins(0, 0, 0, 0)
        main.addLayout(hdr)

        # --- Collapsible body ---
        self.body = QWidget()
        body_layout = QVBoxLayout(self.body)
        body_layout.setSpacing(4)
        body_layout.setContentsMargins(0, 0, 0, 0)

        # --- Parameters in a clean grid layout ---
        # Columns group like parameters:
        # Col 0: Setup (Mode, Safe X, DOC, F Fin)
        # Col 1: Stock/Position (Stock Dia, Safe Z, Fin, Rough T#)
        # Col 2: Start/Cut (X Start, Retract, Fin DOC, Finish T#)
        # Col 3: Start/Feed (Z Start, RPM, F Rough)
        params = QGridLayout()
        params.setHorizontalSpacing(20)
        params.setVerticalSpacing(4)
        params.setContentsMargins(0, 4, 0, 4)

        def _param_pair(row, col, label_text, default, tip="", w=80):
            pair = QHBoxLayout()
            pair.setSpacing(2)
            lbl = QLabel(label_text)
            lbl.setStyleSheet(LBL)
            lbl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            _, field = _f("", default, tip, w)
            pair.addWidget(lbl)
            pair.addWidget(field)
            params.addLayout(pair, row, col)
            return field

        # Row 0: Mode, Safe X, DOC, Fin
        mode_pair = QHBoxLayout()
        mode_pair.setSpacing(2)
        lbl_mode = QLabel("Mode:")
        lbl_mode.setStyleSheet(LBL)
        lbl_mode.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItems(["OD", "ID"])
        self.cmb_mode.setFixedWidth(90)
        mode_pair.addWidget(lbl_mode)
        mode_pair.addWidget(self.cmb_mode)
        params.addLayout(mode_pair, 0, 0)

        self.safe_x = _param_pair(0, 1, "Safe X:", "3.000", "Safe X (diameter)", 80)
        self.doc = _param_pair(0, 2, "DOC:", "0.030", "Depth of cut per roughing pass (on diameter)", 80)
        self.fin_passes = _param_pair(0, 3, "Fin:", "1", "Number of finish passes", 80)

        # Row 1: Stock Dia, Safe Z, F Rough, Fin DOC
        self.stock_dia_label = QLabel("Stock Dia:")
        sd_pair = QHBoxLayout()
        sd_pair.setSpacing(2)
        self.stock_dia_label.setStyleSheet(LBL)
        self.stock_dia_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        _, self.stock_dia = _f("", "2.000", "Raw material OD or bore ID", 80)
        sd_pair.addWidget(self.stock_dia_label)
        sd_pair.addWidget(self.stock_dia)
        params.addLayout(sd_pair, 1, 0)

        self.safe_z = _param_pair(1, 1, "Safe Z:", "1.000", "Safe Z position", 80)
        self.feed_r = _param_pair(1, 2, "F Rough:", "0.005", "Roughing feed (ipr)", 80)
        self.fin_doc = _param_pair(1, 3, "Fin DOC:", "0.002", "Finish pass depth (on diameter)", 80)

        # Row 2: X Start, Retract, Rough T#, F Fin
        self.x_start = _param_pair(2, 0, "X Start:", "0", "Starting X (diameter)", 80)
        self.retract = _param_pair(2, 1, "Retract:", "0.100", "X retract clearance (diameter)", 80)
        self.rough_tool = _param_pair(2, 2, "Rough T#:", "1", "Roughing tool number", 80)
        self.feed_f = _param_pair(2, 3, "F Fin:", "0.003", "Finishing feed (ipr)", 80)

        # Row 3: Z Start, RPM, Peck, Finish T#
        self.z_start = _param_pair(3, 0, "Z Start:", "0.1", "Starting Z position", 80)
        self.rpm = _param_pair(3, 1, "RPM:", "1200", "Spindle RPM", 80)
        self.finish_tool = _param_pair(3, 3, "Finish T#:", "1", "Finishing tool number", 80)

        # Row 3, Col 2: Peck roughing checkbox + depth field
        peck_pair = QHBoxLayout()
        peck_pair.setSpacing(2)
        self.peck_check = QCheckBox("Peck:")
        self.peck_check.setStyleSheet(
            f"QCheckBox {{ color: {COLORS['text_secondary']}; font-size: 16px; background: transparent; }}"
            f"QCheckBox::indicator {{ width: 16px; height: 16px; }}")
        self.peck_check.setToolTip("Enable peck roughing — tool dwells briefly every peck depth to break chips")
        _, self.peck_depth = _f("", "0.250", "Peck depth in Z (inches) — distance between chip-break dwells", 80)
        self.peck_depth.setEnabled(False)
        self.peck_check.toggled.connect(self.peck_depth.setEnabled)
        peck_pair.addWidget(self.peck_check)
        peck_pair.addWidget(self.peck_depth)
        params.addLayout(peck_pair, 3, 2)

        # Center the params grid horizontally
        params_wrapper = QHBoxLayout()
        params_wrapper.addStretch()
        params_wrapper.addLayout(params)
        params_wrapper.addStretch()
        body_layout.addLayout(params_wrapper)

        # --- Segment list header ---
        seg_hdr = QHBoxLayout()
        seg_title = QLabel("Profile Segments")
        seg_title.setFont(ui_font(12, QFont.Bold))
        seg_title.setStyleSheet(f"color: {COLORS['text_secondary']}; background: transparent;")
        seg_hdr.addWidget(seg_title)
        seg_hdr.addStretch()

        self.btn_add_seg = QPushButton("＋ Segment")
        self.btn_add_seg.setStyleSheet(
            f"QPushButton {{ "
            f"  background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #4a9eff, stop:1 {COLORS['accent_blue']}); "
            f"  color: white; border: 1px solid {COLORS['accent_blue']}; "
            f"  border-bottom: 2px solid #1750AC; border-radius: 8px; "
            f"  padding: 6px 14px; font-size: 14px; font-weight: 700; "
            f"  min-height: 36px; min-width: 90px; }}"
            f"QPushButton:hover {{ "
            f"  background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #6cb3ff, stop:1 #4a9eff); "
            f"  border: 1px solid #4a9eff; }}"
            f"QPushButton:pressed {{ "
            f"  background: #1750AC; border-top: 2px solid #0f3a7a; border-bottom: 1px solid {COLORS['accent_blue']}; }}")
        self.btn_add_seg.clicked.connect(self.add_segment)
        seg_hdr.addWidget(self.btn_add_seg)
        body_layout.addLayout(seg_hdr)

        # Segment container
        self.seg_container = QWidget()
        self.seg_layout = QVBoxLayout(self.seg_container)
        self.seg_layout.setSpacing(2)
        self.seg_layout.setContentsMargins(0, 0, 0, 0)
        self.seg_layout.addStretch()
        body_layout.addWidget(self.seg_container)

        main.addWidget(self.body)

        # --- Connect signals ---
        self.cmb_mode.currentIndexChanged.connect(self._on_mode_changed)

        # Add one default segment
        self.add_segment()

    def _toggle(self):
        self._expanded = not self._expanded
        self.body.setVisible(self._expanded)
        self.btn_collapse.setText("▼" if self._expanded else "▶")

    def set_metric_display(self, metric: bool):
        """Convert distance fields between inch and metric display."""
        self._metric_display = metric
        # Distance fields (not: rpm, tool numbers, fin_passes)
        for field in (self.safe_x, self.stock_dia, self.safe_z, self.doc,
                      self.x_start, self.z_start, self.retract, self.fin_doc,
                      self.peck_depth, self.feed_r, self.feed_f):
            _conv_field_to_metric(field, metric)
        # Propagate to segments and corners
        for seg in self.segments:
            seg.set_metric_display(metric)
        for corner in self.corners:
            corner.set_metric_display(metric)

    def _on_mode_changed(self, index):
        """Update stock diameter label and retract default based on OD/ID mode."""
        if self.cmb_mode.currentText() == "ID":
            self.stock_dia_label.setText("Stock Dia:")
            self.stock_dia_label.setVisible(False)
            self.stock_dia.setVisible(False)
            if self.retract.text() == "0.100":
                self.retract.setText("0.005")
            if self.doc.text() == "0.030":
                self.doc.setText("0.020")
            # Auto-populate x_start with pilot hole diameter
            self.x_start.setToolTip("Starting X position (diameter) — bore starting diameter for roughing")
            # Set safe_x to inside-bore value (less than bore start)
            self.safe_x.setText("0.000")
        else:
            self.stock_dia_label.setText("Stock Dia:")
            self.stock_dia_label.setVisible(True)
            self.stock_dia.setVisible(True)
            if self.retract.text() == "0.005":
                self.retract.setText("0.100")
            if self.doc.text() == "0.020":
                self.doc.setText("0.030")
            # Restore OD-appropriate tooltip and safe_x
            self.x_start.setToolTip("Starting X position (diameter) — 0 for face start")
            self.safe_x.setText("3.000")

    def set_num(self, n):
        old_default = f"Profile {self.block_num}"
        self.block_num = n
        # Only update title if it still has the default name
        if self.title.text() == old_default:
            self.title.setText(f"Profile {n}")

    def add_segment(self):
        n = len(self.segments) + 1
        seg = SegmentRow(n)
        seg.btn_remove.clicked.connect(lambda _, s=seg: self.remove_segment(s))
        # Auto-update type labels when fields change
        seg.x_end.textChanged.connect(lambda: self._update_types())
        seg.z_end.textChanged.connect(lambda: self._update_types())
        seg.arc_check.toggled.connect(lambda: self._update_types())
        # Default arc direction: CW for OD, CCW for ID
        if self.cmb_mode.currentText() == "ID":
            seg.arc_dir.setCurrentIndex(1)  # CCW
        else:
            seg.arc_dir.setCurrentIndex(0)  # CW

        # If there are existing segments, add a corner break row before this one
        if self.segments:
            corner = CornerBreakRow(len(self.segments))
            self.corners.append(corner)
            self.seg_layout.insertWidget(self.seg_layout.count() - 1, corner)

        self.segments.append(seg)
        self.seg_layout.insertWidget(self.seg_layout.count() - 1, seg)
        self._update_types()

    def remove_segment(self, seg):
        if seg in self.segments:
            idx = self.segments.index(seg)
            self.segments.remove(seg)
            self.seg_layout.removeWidget(seg)
            seg.deleteLater()

            # Remove the associated corner break row
            if self.corners:
                if idx > 0:
                    # Remove the corner BEFORE this segment
                    corner_idx = idx - 1
                elif idx == 0 and self.corners:
                    # Removing first segment: remove the corner after it
                    corner_idx = 0
                else:
                    corner_idx = None

                if corner_idx is not None and corner_idx < len(self.corners):
                    corner = self.corners.pop(corner_idx)
                    self.seg_layout.removeWidget(corner)
                    corner.deleteLater()

            self._renumber()
            self._update_types()

    def _renumber(self):
        for i, s in enumerate(self.segments):
            s.set_num(i + 1)
        for i, c in enumerate(self.corners):
            c.set_num(i + 1)

    def _update_types(self):
        """Update all segment type labels based on chained coordinates."""
        try:
            px = self.x_start.text()
            pz = self.z_start.text()
        except Exception:
            return
        for seg in self.segments:
            seg.update_type_label(px, pz)
            px = seg.x_end.text()
            pz = seg.z_end.text()

    def export_data(self):
        """Export all block data as a dict for duplication."""
        data = {
            "profile_mode": self.cmb_mode.currentText(),
            "title": self.title.text(),
            "stock_dia": self.stock_dia.text(),
            "x_start": self.x_start.text(),
            "z_start": self.z_start.text(),
            "safe_x": self.safe_x.text(),
            "safe_z": self.safe_z.text(),
            "doc": self.doc.text(),
            "fin_passes": self.fin_passes.text(),
            "fin_doc": self.fin_doc.text(),
            "feed_r": self.feed_r.text(),
            "feed_f": self.feed_f.text(),
            "retract": self.retract.text(),
            "rough_tool": self.rough_tool.text(),
            "finish_tool": self.finish_tool.text(),
            "rpm": self.rpm.text(),
            "peck_enabled": self.peck_check.isChecked(),
            "peck_depth": self.peck_depth.text(),
            "segments": [seg.get_data() for seg in self.segments],
            "corners": [c.get_data() for c in self.corners],
        }
        return data

    def import_data(self, data):
        """Import block data from a dict."""
        # Restore mode (default to OD for backward compatibility)
        mode = data.get("profile_mode", "OD")
        idx = self.cmb_mode.findText(mode)
        if idx >= 0:
            self.cmb_mode.setCurrentIndex(idx)

        if "title" in data:
            self.title.setText(data["title"] + " (copy)")
        for key in ["stock_dia", "x_start", "z_start",
                     "safe_x", "safe_z", "doc", "fin_passes", "fin_doc",
                     "feed_r", "feed_f", "retract", "rough_tool", "finish_tool", "rpm",
                     "peck_depth"]:
            widget = getattr(self, key, None)
            if widget and key in data:
                widget.setText(str(data[key]))

        # Restore peck checkbox state (default off for backward compatibility)
        self.peck_check.setChecked(data.get("peck_enabled", False))

        # Clear existing segments and corners
        for seg in list(self.segments):
            self.remove_segment(seg)

        seg_list = data.get("segments", [])
        corner_list = data.get("corners", [])

        # Backward compatibility: migrate old Entry/Exit C/R to corner breaks
        # Old format had start_cr_type/start_cr_val/end_cr_type/end_cr_val per segment.
        # Exit C/R of segment i → corner between i and i+1 (corner index i).
        # Entry C/R of segment i → corner between i-1 and i (corner index i-1), as fallback.
        if not corner_list and seg_list:
            migrated_corners = {}
            for i, sd in enumerate(seg_list):
                e_cr = sd.get("end_cr_type", "None")
                e_cv = sd.get("end_cr_val", "0.030")
                if e_cr in ("Chamfer", "Radius") and i < len(seg_list) - 1:
                    migrated_corners[i] = {"cr_type": e_cr, "cr_val": e_cv, "cr_angle": "45"}

                s_cr = sd.get("start_cr_type", "None")
                s_cv = sd.get("start_cr_val", "0.030")
                if s_cr in ("Chamfer", "Radius") and i > 0:
                    if (i - 1) not in migrated_corners:
                        migrated_corners[i - 1] = {"cr_type": s_cr, "cr_val": s_cv, "cr_angle": "45"}

            # Build corner_list in order
            for i in range(len(seg_list) - 1):
                corner_list.append(migrated_corners.get(i, {"cr_type": "None", "cr_val": "0.030", "cr_angle": "45"}))

        for seg_data in seg_list:
            self.add_segment()
            seg = self.segments[-1]
            if "x_end" in seg_data:
                seg.x_end.setText(seg_data["x_end"])
            if "z_end" in seg_data:
                seg.z_end.setText(seg_data["z_end"])
            if "is_arc" in seg_data:
                seg.arc_check.setChecked(seg_data["is_arc"])
            if "arc_r" in seg_data:
                seg.arc_r.setText(seg_data["arc_r"])
            if "arc_dir" in seg_data:
                idx = seg.arc_dir.findText(seg_data["arc_dir"])
                if idx >= 0:
                    seg.arc_dir.setCurrentIndex(idx)

        # Restore corner break data
        for i, cd in enumerate(corner_list):
            if i < len(self.corners):
                corner = self.corners[i]
                idx = corner.cr_type.findText(cd.get("cr_type", "None"))
                if idx >= 0:
                    corner.cr_type.setCurrentIndex(idx)
                corner.cr_val.setText(cd.get("cr_val", "0.030"))
                corner.cr_angle.setText(cd.get("cr_angle", "45"))

        self._update_types()


    def generate_gcode(self):
        """Generate G-code: rough the profile in depth passes, then finish trace."""
        mode = self.cmb_mode.currentText()  # "OD" or "ID"
        metric = getattr(self, '_metric_display', False)
        try:
            stock_d = _inch_val(self.stock_dia, metric)
            x_start_d = _inch_val(self.x_start, metric)
            z_start = _inch_val(self.z_start, metric)
            doc = _inch_val(self.doc, metric) / 2.0  # GUI is diameter, backend uses radius
            fin_p = int(self.fin_passes.text())
            fin_doc = _inch_val(self.fin_doc, metric) / 2.0  # GUI is diameter, backend uses radius
            feed_r = _inch_val(self.feed_r, metric)
            feed_f = _inch_val(self.feed_f, metric)
            retract_d = _inch_val(self.retract, metric)
            r_tool = self.rough_tool.text()
            f_tool = self.finish_tool.text()
            rpm = self.rpm.text()
            safe_x = _inch_val(self.safe_x, metric)
            safe_z = _inch_val(self.safe_z, metric)
            peck_enabled = self.peck_check.isChecked()
            peck_depth = _inch_val(self.peck_depth, metric) if peck_enabled else 0.0
        except ValueError as e:
            return f"; ERROR: Invalid input — {e}\n"

        # Peck dwell: 5 spindle revolutions
        # G04 P is in seconds on LinuxCNC
        if peck_enabled and peck_depth > 0:
            try:
                rpm_val = float(rpm)
                if rpm_val > 0:
                    peck_dwell = (5.0 / rpm_val) * 60.0  # 5 revs in seconds
                else:
                    peck_dwell = 0.25  # fallback
            except ValueError:
                peck_dwell = 0.25
        else:
            peck_dwell = 0

        # Parse segments
        raw_profile = []
        for seg in self.segments:
            d = seg.get_data()
            try:
                xd = float(d["x_end"])
                zd = float(d["z_end"])
                if metric:
                    xd /= _IN_TO_MM
                    zd /= _IN_TO_MM
                is_arc = d["is_arc"]
                arc_r_raw = abs(float(d["arc_r"])) if d["arc_r"] and is_arc else 0
                if metric and arc_r_raw:
                    arc_r_raw /= _IN_TO_MM
                arc_dir = d.get("arc_dir", "CW")
                # R is always positive; sign encodes direction for internal use
                # UI CW = visually clockwise on graph (hill) = G03 = negative R
                # UI CCW = visually counter-clockwise on graph (valley) = G02 = positive R
                ar = -arc_r_raw if arc_dir == "CW" else arc_r_raw
            except ValueError:
                continue
            raw_profile.append((xd, zd, is_arc, ar))

        # Parse corner breaks from corner rows
        corner_breaks = {}
        for i, corner in enumerate(self.corners):
            cd = corner.get_data()
            cr_type = cd["cr_type"]
            if cr_type in ("Chamfer", "Radius"):
                try:
                    cr_val = float(cd["cr_val"]) if cd["cr_val"] else 0
                    if metric and cr_val:
                        cr_val /= _IN_TO_MM
                    cr_angle = float(cd["cr_angle"]) if cd["cr_angle"] else 45
                except ValueError:
                    cr_val = 0
                    cr_angle = 45
                if cr_val > 0:
                    # Corner i is between segment i and segment i+1
                    # In raw_pts, that's the point at index i+1
                    corner_breaks[i + 1] = (cr_type, cr_val, cr_angle)

        if not raw_profile:
            return "; ERROR: No segments defined\n"

        separate_tools = r_tool.strip() != f_tool.strip()

        # Z retract lift: matches the programmed X retract clearance value
        # (retract_d is on diameter, divide by 2 for actual linear distance).
        z_lift = retract_d / 2.0

        # ID X retract floor: never retract past X Start minus 0.002" on radius
        # (0.004" on diameter) to avoid re-cutting the bore entry.
        ID_FLOOR_OFFSET = 0.004  # on diameter

        if mode == "ID":
            x_clear = x_start_d - ID_FLOOR_OFFSET
            if x_clear <= 0:
                return "; ERROR: X_Clear is zero or negative — X Start too small for retract distance\n"
        else:
            x_clear = stock_d + retract_d
        z_clear = z_start + 0.050

        # Safe position warnings
        safe_warn = ""
        if mode == "OD" and safe_x < stock_d:
            safe_warn = f"; WARNING: Safe X ({safe_x:.4f}) is less than stock diameter ({stock_d:.4f}) — tool may be inside stock"
        elif mode == "ID" and safe_x > x_start_d:
            safe_warn = f"; WARNING: Safe X ({safe_x:.4f}) is greater than bore start ({x_start_d:.4f}) — tool may be outside bore"

        if mode == "ID":
            op_type = "Profile Boring — Conversational"
            stock_label = f"X Start: {x_start_d:.4f} dia, Z {z_start:.4f}, Mode: {mode}"
        else:
            op_type = "Profile Turning — Conversational"
            stock_label = f"Stock: {stock_d:.4f} dia, Z {z_start:.4f}, Mode: {mode}"

        lines = [
            f"; {op_type}",
            f"; {stock_label}",
            f"; Z range: {z_start:.4f} to {raw_profile[-1][1]:.4f}",
            f"; Profile: {len(raw_profile)} segments",
            f"; Rough DOC: {doc*2:.4f} dia ({doc:.4f} rad)  Feed: {feed_r}  Tool: T{_lib_tool_num(r_tool)}",
            f"; Finish: {fin_p} passes, DOC {fin_doc*2:.4f} dia ({fin_doc:.4f} rad)  Feed: {feed_f}  Tool: T{_lib_tool_num(f_tool)}",
            f"; Safe position: X{safe_x:.4f} Z{safe_z:.4f}",
            f"; RPM: {rpm}",
        ]
        if peck_enabled and peck_depth > 0:
            lines.append(f"; Peck roughing: {peck_depth:.4f} depth, {peck_dwell:.3f}s dwell (5 revs @ {rpm} RPM)")
        if safe_warn:
            lines.append(safe_warn)
        lines.extend([
            f"",
            f"G20 G18 G40 G49 G80",
            f"G90",
            f"",
            f"; --- Move to safe position ---",
            f"G00 X{safe_x:.4f} Z{safe_z:.4f}",
            f"",
            f"; --- Load roughing tool ---",
            f"T{_lib_tool_num(r_tool)} M6",
            f"G43",
            f"",
        ])

        # --- Build finish profile move list with corner C/R ---
        # Each corner between segments gets ONE break from the corner_breaks dict.
        # Chamfer: angled cut, C = leg along entering segment, A = angle from that direction
        # Radius: quarter-circle arc, radius = C/R value

        raw_pts = [(x_start_d, z_start)]
        seg_data = []
        for xd, zd, is_arc, ar in raw_profile:
            raw_pts.append((xd, zd))
            seg_data.append((is_arc, ar))

        finish_moves = []
        finish_comments = {}  # index -> comment string for corner break moves

        for i in range(len(seg_data)):
            px, pz = raw_pts[i]
            ex, ez = raw_pts[i + 1]
            is_arc, ar = seg_data[i]

            if is_arc and ar != 0:
                finish_moves.append(("ARC", ex, ez, ar))
                continue

            # Check if there's a corner break at the START of this segment (corner at raw_pts[i])
            if i in corner_breaks:
                cr_type, cr_val, cr_angle = corner_breaks[i]
                # Previous point
                if i > 0:
                    ppx, ppz = raw_pts[i - 1]

                    # Convert to radius space for geometry — X is diameter in
                    # G-code but the chamfer angle must be measured in real
                    # (radius, Z) space so a 45° chamfer actually cuts at 45°.
                    ppx_r, px_r, ex_r = ppx / 2.0, px / 2.0, ex / 2.0

                    # Direction of previous segment (into corner) in radius space
                    d_prev_x = px_r - ppx_r
                    d_prev_z = pz - ppz
                    l_prev = math.sqrt(d_prev_x**2 + d_prev_z**2)
                    # Direction of this segment (out of corner) in radius space
                    d_this_x = ex_r - px_r
                    d_this_z = ez - pz
                    l_this = math.sqrt(d_this_x**2 + d_this_z**2)

                    if l_prev > 0.001 and l_this > 0.001:
                        # Normalize in radius space
                        n1x, n1z = d_prev_x / l_prev, d_prev_z / l_prev
                        n2x, n2z = d_this_x / l_this, d_this_z / l_this

                        if cr_type == "Chamfer":
                            # Mazak C×A style: C = leg along entering segment,
                            # A = angle from entering segment direction.
                            # All geometry in radius space, then convert X back
                            # to diameter for the G-code coordinates.
                            angle_rad = math.radians(cr_angle)
                            # Offset back along entering segment by C (radius space)
                            b_xr = px_r - n1x * cr_val
                            b_z = pz - n1z * cr_val
                            # Offset forward along exiting segment by C * tan(angle)
                            exit_leg = cr_val * math.tan(angle_rad) if abs(math.cos(angle_rad)) > 0.001 else cr_val
                            a_xr = px_r + n2x * exit_leg
                            a_z = pz + n2z * exit_leg
                            # Convert back to diameter
                            b_x = b_xr * 2.0
                            a_x = a_xr * 2.0
                        else:
                            # Radius fillet: equal offset along both segments
                            # (radius space)
                            b_xr = px_r - n1x * cr_val
                            b_z = pz - n1z * cr_val
                            a_xr = px_r + n2x * cr_val
                            a_z = pz + n2z * cr_val
                            b_x = b_xr * 2.0
                            a_x = a_xr * 2.0

                        # Determine arc direction from corner geometry.
                        # Cross product of entering/exiting directions (radius
                        # space) tells us if the profile turns left or right:
                        #   cross < 0 → outside corner (convex) for OD
                        #   cross > 0 → inside corner (concave) for OD
                        cross = n1x * n2z - n1z * n2x
                        if mode == "OD":
                            # Outside → G03 (CCW, neg R); Inside → G02 (CW, pos R)
                            arc_sign = -cr_val if cross < 0 else cr_val
                        else:
                            # ID is mirrored
                            arc_sign = cr_val if cross < 0 else -cr_val

                        # Replace the corner: remove last move if it was the corner point
                        if finish_moves and finish_moves[-1][0] == "LINE":
                            lx, lz = finish_moves[-1][1], finish_moves[-1][2]
                            if abs(lx - px) < 0.001 and abs(lz - pz) < 0.001:
                                finish_moves.pop()

                        # Build comment for the corner break move
                        if cr_type == "Chamfer":
                            cr_comment = f"Chamfer C{cr_val:.4f} A{cr_angle:.0f}°"
                        else:
                            cr_comment = f"Radius R{cr_val:.4f}"

                        finish_moves.append(("LINE", b_x, b_z))
                        if cr_type == "Chamfer":
                            cr_idx = len(finish_moves)
                            finish_moves.append(("LINE", a_x, a_z))
                            finish_comments[cr_idx] = cr_comment
                        else:
                            cr_idx = len(finish_moves)
                            finish_moves.append(("ARC", a_x, a_z, arc_sign))
                            finish_comments[cr_idx] = cr_comment

            # Main endpoint
            finish_moves.append(("LINE", ex, ez))

        # --- Build simple (x, z) list for roughing calculations ---
        # rough_pts: the part boundary points
        # roughing_bnd: the roughing boundary (part boundary + finish DOC)
        #   Simple X offset by fin_allowance * 2 for all points.
        rough_pts = [(x_start_d, z_start)]
        for mv in finish_moves:
            if mv[0] == "LINE":
                rough_pts.append((mv[1], mv[2]))
            elif mv[0] == "ARC":
                prev_x, prev_z = rough_pts[-1]
                arc_pts = _linearize_arc(prev_x, prev_z,
                                         mv[1], mv[2], mv[3])
                rough_pts.extend(arc_pts)

        # --- Roughing passes ---
        # DOC is on radius. Roughing leaves fin_allowance on radius for finish pass.
        stock_r = stock_d / 2.0
        fin_allowance = fin_p * fin_doc  # on radius

        # Build roughing boundary points (part boundary + finish DOC).
        # Simple X offset for all points — sufficient accuracy for roughing.
        offset_d = fin_allowance * 2  # offset on diameter
        roughing_bnd = []
        for x, z in rough_pts:
            if mode == "OD":
                roughing_bnd.append((x + offset_d, z))
            else:
                roughing_bnd.append((x - offset_d, z))

        # Find minimum OD in profile (exclude face moves near centerline)
        od_pts = [(x, z) for x, z in rough_pts if x > 0.05]
        if not od_pts:
            od_pts = rough_pts

        lines.append(f"; --- Roughing passes ---")
        current_d = stock_d if mode == "OD" else x_start_d
        pass_num = 1

        if mode == "ID":
            # ID roughing: determine direction based on profile geometry
            max_roughing_x = max(bx for bx, bz in roughing_bnd)
            min_roughing_x = min(bx for bx, bz in roughing_bnd if bx > 0.01)

            # Determine if bore widens (needs interval logic) or narrows (original logic)
            bore_widens = max_roughing_x > current_d + doc * 2

            if bore_widens:
                # Widening bore: step outward from x_start using interval-based logic
                x_levels = []
                cd = current_d + doc * 2
                while cd < max_roughing_x:
                    x_levels.append(cd)
                    cd += doc * 2

                z_interval_chart = build_z_interval_chart(finish_moves, x_start_d, z_start,
                                                          x_levels, fin_allowance)

                # Print point chart as G-code comment for verification
                lines.append(f"; --- Point Chart (Z intervals at each roughing X) ---")
                for xl in sorted(z_interval_chart.keys()):
                    intervals = z_interval_chart[xl]
                    interval_strs = [f"Z{zb:.4f} to Z{ze:.4f}" for zb, ze in intervals]
                    lines.append(f";   X{xl:.4f} -> [{', '.join(interval_strs)}]")
                lines.append(f"")

                while current_d + doc * 2 < max_roughing_x:
                    current_d += doc * 2
                    pass_clear = max(current_d - retract_d, x_start_d - ID_FLOOR_OFFSET)

                    intervals = z_interval_chart.get(current_d, [])
                    if not intervals:
                        continue

                    for iv_idx, (z_begin, z_end) in enumerate(intervals):
                        iv_label = f"Pass {pass_num}" if len(intervals) == 1 else f"Pass {pass_num}.{iv_idx+1}"
                        prev_pass_d = current_d - doc * 2  # previous pass already cleared to here
                        lines.append(f"G00 X{x_clear:.4f} Z{z_clear:.4f}  ({iv_label}  chart: X{current_d:.4f} [{z_begin:.4f} to {z_end:.4f}])")
                        lines.append(f"G00 Z{z_begin:.4f}")
                        lines.append(f"G00 X{prev_pass_d:.4f}")
                        lines.append(f"G01 X{current_d:.4f} F{feed_r}")
                        if peck_enabled and peck_depth > 0:
                            z_pos = z_begin
                            peck_num = 1
                            while z_pos - peck_depth > z_end + 0.0001:
                                z_pos -= peck_depth
                                lines.append(f"G01 Z{z_pos:.4f} F{feed_r}  (Peck {peck_num})")
                                lines.append(f"G04 P{peck_dwell:.3f}  (Chip break — 5 revs)")
                                peck_num += 1
                            lines.append(f"G01 Z{z_end:.4f} F{feed_r}  (Peck {peck_num} — final)")
                            lines.append(f"G04 P{peck_dwell:.3f}  (Chip break — 5 revs)")
                        else:
                            lines.append(f"G01 Z{z_end:.4f} F{feed_r}")
                        # Diagonal retract: move to x_clear (toward center, clamped to
                        # ID floor) while lifting 0.020" in Z to clear shoulder ridges.
                        pullaway_z = z_end + z_lift
                        lines.append(f"G00 X{x_clear:.4f} Z{pullaway_z:.4f}  (Diagonal retract)")
                        lines.append(f"G00 Z{z_clear:.4f}")
                        lines.append(f"")
                    pass_num += 1

            else:
                # Narrowing bore: step inward from x_start using original z_limit logic
                x_levels = []
                cd = current_d - doc * 2
                while cd > min_roughing_x:
                    x_levels.append(cd)
                    cd -= doc * 2

                z_chart = build_z_limit_chart(finish_moves, x_start_d, z_start,
                                              x_levels, fin_allowance, "ID")

                # Print point chart as G-code comment for verification
                lines.append(f"; --- Point Chart (cleanup arc Z at each roughing X) ---")
                for xl in sorted(z_chart.keys(), reverse=True):
                    lines.append(f";   X{xl:.4f} -> Z{z_chart[xl]:.4f}")
                lines.append(f"")

                # ID boring always steps outward from centerline — process
                # levels from smallest to largest so each pass has the
                # previous pass's cleared bore behind it for safe retract.
                for level_d in sorted(x_levels):
                    pass_clear = level_d - retract_d

                    z_limit = z_chart.get(level_d)
                    if z_limit is None:
                        continue

                    lines.append(f"G00 X{pass_clear:.4f} Z{z_clear:.4f}  (Pass {pass_num}  chart: X{level_d:.4f}->Z{z_limit:.4f})")
                    lines.append(f"G00 X{level_d:.4f} Z{z_start:.4f}")
                    if peck_enabled and peck_depth > 0:
                        z_pos = z_start
                        peck_num = 1
                        while z_pos - peck_depth > z_limit + 0.0001:
                            z_pos -= peck_depth
                            lines.append(f"G01 Z{z_pos:.4f} F{feed_r}  (Peck {peck_num})")
                            lines.append(f"G04 P{peck_dwell:.3f}  (Chip break — 5 revs)")
                            peck_num += 1
                        lines.append(f"G01 Z{z_limit:.4f} F{feed_r}  (Peck {peck_num} — final)")
                        lines.append(f"G04 P{peck_dwell:.3f}  (Chip break — 5 revs)")
                    else:
                        lines.append(f"G01 Z{z_limit:.4f} F{feed_r}")
                    # Diagonal retract: move to pass_clear X (toward center) while
                    # lifting 0.020" in Z to clear shoulder ridges, then Z retract.
                    pullaway_z = z_limit + z_lift
                    lines.append(f"G00 X{pass_clear:.4f} Z{pullaway_z:.4f}  (Diagonal retract)")
                    lines.append(f"G00 Z{z_clear:.4f}")
                    lines.append(f"")
                    pass_num += 1

            # Cleanup pass: trace the roughing boundary contour
            # (part boundary offset inward by fin_allowance * 2 in X,
            #  fin_allowance in Z for LINE segments only)
            lines.append(f"; --- Cleanup pass (roughing boundary contour) ---")
            lines.append(f"G00 X{x_clear:.4f} Z{z_clear:.4f}")
            lines.append(f"G00 X{x_start_d - fin_allowance * 2:.4f} Z{z_start:.4f}")
            for mi, mv in enumerate(finish_moves):
                comment = f"  ({finish_comments[mi]})" if mi in finish_comments else ""
                if mv[0] == "LINE":
                    _, mx, mz = mv
                    ox = mx - fin_allowance * 2
                    oz = mz + fin_allowance
                    lines.append(f"G01 X{ox:.4f} Z{oz:.4f} F{feed_r}{comment}")
                elif mv[0] == "ARC":
                    _, mx, mz, mr = mv
                    ox = mx - fin_allowance * 2
                    oz = mz + fin_allowance
                    g = "G02" if mr > 0 else "G03"
                    lines.append(f"{g} X{ox:.4f} Z{oz:.4f} R{abs(mr):.4f} F{feed_r}{comment}")
            # Diagonal retract after cleanup pass: lift 0.020" in Z while
            # retracting X to clear shoulder ridges.
            last_cleanup_x = finish_moves[-1][1] - fin_allowance * 2 if finish_moves else x_start_d
            last_cleanup_z = None
            for mv in reversed(finish_moves):
                if mv[0] == "LINE":
                    last_cleanup_z = mv[2] + fin_allowance
                    break
                elif mv[0] == "ARC":
                    last_cleanup_z = mv[2] + fin_allowance
                    break
            if last_cleanup_z is not None:
                pullaway_z = last_cleanup_z + z_lift
                if last_cleanup_x > x_start_d:
                    # Widening bore: tool is at large X, retract toward center
                    # (to x_clear near X Start) with Z lift, then Z retract.
                    lines.append(f"G00 X{x_clear:.4f} Z{pullaway_z:.4f}  (Diagonal retract)")
                    lines.append(f"G00 Z{z_clear:.4f}")
                else:
                    # Narrowing bore: tool is at small X (inside bore), retract
                    # toward center with Z lift, then Z retract. Use current X
                    # minus retract distance (toward center) for the diagonal.
                    retract_x = last_cleanup_x - retract_d
                    lines.append(f"G00 X{retract_x:.4f} Z{pullaway_z:.4f}  (Diagonal retract)")
                    lines.append(f"G00 Z{z_clear:.4f}")
                    lines.append(f"G00 X{x_clear:.4f}")
            else:
                if last_cleanup_x > x_start_d:
                    lines.append(f"G00 X{x_clear:.4f}")
                    lines.append(f"G00 Z{z_clear:.4f}")
                else:
                    lines.append(f"G00 Z{z_clear:.4f}")
                    lines.append(f"G00 X{x_clear:.4f}")
            lines.append(f"")
        else:
            # OD: step inward from stock diameter toward profile
            min_profile_d = min(x for x, z in od_pts)
            min_target_d = min_profile_d + fin_allowance * 2

            # Find the minimum X in the roughing boundary (including face)
            min_roughing_x = min(bx for bx, bz in roughing_bnd)
            # Find the maximum X in the roughing boundary (peaks)
            max_roughing_x = max(bx for bx, bz in roughing_bnd)

            # Detect peaks/valleys: profile has peaks if max boundary X > stock
            # or if the profile X is non-monotonic (goes up then down).
            # A peak means at some X levels, the tool would pass through zones
            # where the profile sticks out past the cutting diameter.
            has_peaks = False

            # --- Arc geometry awareness: detect valleys that linearization
            # obscures (Change 1 of arc-valley-roughing-fix) ---
            # For each ARC segment in finish_moves, compute the arc center
            # and check if the arc's minimum X is below both endpoints.
            # This catches vertical/near-vertical arc valleys where the
            # linearized X deltas are too small for the 0.001" threshold.
            _ARC_VALLEY_EPS = 0.0001
            prev_pt = (x_start_d, z_start)
            for mv in finish_moves:
                if mv[0] == "ARC":
                    arc_x1 = prev_pt[0]  # start X (diameter)
                    arc_z1 = prev_pt[1]  # start Z
                    arc_x2 = mv[1]       # end X (diameter)
                    arc_z2 = mv[2]       # end Z
                    arc_radius = mv[3]   # signed radius

                    R_abs = abs(arc_radius)
                    adx = arc_x2 - arc_x1
                    adz = arc_z2 - arc_z1
                    arc_chord = math.sqrt(adx * adx + adz * adz)

                    # Skip degenerate arcs (same fallback as _linearize_arc)
                    if R_abs >= 1e-9 and arc_chord >= 1e-9 and arc_chord <= 2.0 * R_abs + 1e-6:
                        ar = max(R_abs, arc_chord / 2 + 0.0001)
                        h = math.sqrt(max(0, ar * ar - (arc_chord / 2) ** 2))
                        amx = (arc_x1 + arc_x2) / 2.0
                        amz = (arc_z1 + arc_z2) / 2.0
                        apx = -adz / arc_chord
                        apz = adx / arc_chord

                        # Center selection — same logic as _linearize_arc
                        cw = arc_radius > 0
                        if arc_radius > 0:
                            ccx, ccz = amx - h * apx, amz - h * apz
                        else:
                            ccx, ccz = amx - h * apx, amz - h * apz

                        # Compute start/end angles (same convention as _linearize_arc)
                        sa = math.atan2(arc_x1 - ccx, arc_z1 - ccz)
                        ea = math.atan2(arc_x2 - ccx, arc_z2 - ccz)

                        if cw:
                            if ea >= sa:
                                ea -= 2 * math.pi
                            if abs(ea - sa) > math.pi and arc_radius > 0:
                                ccx, ccz = 2 * amx - ccx, 2 * amz - ccz
                                sa = math.atan2(arc_x1 - ccx, arc_z1 - ccz)
                                ea = math.atan2(arc_x2 - ccx, arc_z2 - ccz)
                                if ea >= sa:
                                    ea -= 2 * math.pi
                        else:
                            if ea <= sa:
                                ea += 2 * math.pi
                            if abs(ea - sa) > math.pi and arc_radius > 0:
                                ccx, ccz = 2 * amx - ccx, 2 * amz - ccz
                                sa = math.atan2(arc_x1 - ccx, arc_z1 - ccz)
                                ea = math.atan2(arc_x2 - ccx, arc_z2 - ccz)
                                if ea <= sa:
                                    ea += 2 * math.pi

                        # The minimum X on the circle occurs at angle -pi/2
                        # (since x = cx + ar * sin(t), min when sin(t) = -1)
                        min_x_angle = -math.pi / 2.0

                        # Check if min_x_angle is within the arc's sweep
                        arc_passes_through_min_x = False
                        if cw:
                            # CW: sweep from sa down to ea (sa > ea)
                            # Normalize min_x_angle into range
                            a = min_x_angle
                            # Bring a into the range (ea, ea + 2*pi]
                            while a > sa + _ARC_VALLEY_EPS:
                                a -= 2 * math.pi
                            while a < ea - _ARC_VALLEY_EPS:
                                a += 2 * math.pi
                            if ea - _ARC_VALLEY_EPS <= a <= sa + _ARC_VALLEY_EPS:
                                arc_passes_through_min_x = True
                        else:
                            # CCW: sweep from sa up to ea (ea > sa)
                            a = min_x_angle
                            # Bring a into the range [sa, sa + 2*pi)
                            while a < sa - _ARC_VALLEY_EPS:
                                a += 2 * math.pi
                            while a > ea + _ARC_VALLEY_EPS:
                                a -= 2 * math.pi
                            if sa - _ARC_VALLEY_EPS <= a <= ea + _ARC_VALLEY_EPS:
                                arc_passes_through_min_x = True

                        if arc_passes_through_min_x:
                            # Arc's true minimum X (already in diameter space
                            # since all X coords in this system are diameter)
                            arc_min_x_d = ccx - ar
                            # Check if this is below both endpoints
                            endpoints_min_x_d = min(arc_x1, arc_x2)
                            if arc_min_x_d < endpoints_min_x_d - _ARC_VALLEY_EPS:
                                has_peaks = True

                    # Update prev_pt to arc endpoint
                    prev_pt = (mv[1], mv[2])
                elif mv[0] == "LINE":
                    prev_pt = (mv[1], mv[2])

                if has_peaks:
                    break

            # Fallback: existing roughing_bnd loop for non-arc peaks/valleys
            if not has_peaks:
                for i in range(1, len(roughing_bnd) - 1):
                    x_prev = roughing_bnd[i - 1][0]
                    x_curr = roughing_bnd[i][0]
                    x_next = roughing_bnd[i + 1][0]
                    # Peak: X increases then decreases (local maximum)
                    if x_curr > x_prev + 0.001 and x_curr > x_next + 0.001:
                        has_peaks = True
                        break
                    # Valley: X decreases then increases (local minimum) — also
                    # creates non-monotonic behavior that needs intervals
                    if x_curr < x_prev - 0.001 and x_curr < x_next - 0.001:
                        has_peaks = True
                        break

            # Pre-compute all roughing X levels
            x_levels = []
            cd = current_d - doc * 2
            while cd > min_roughing_x:
                x_levels.append(cd)
                cd -= doc * 2

            if has_peaks:
                # Profile has peaks/valleys — use interval-based logic
                # to avoid plunging through zones where profile sticks out
                z_interval_chart = build_z_interval_chart(finish_moves, x_start_d, z_start,
                                                          x_levels, fin_allowance, "OD")

                # Print point chart as G-code comment for verification
                lines.append(f"; --- Point Chart (Z intervals at each roughing X) ---")
                for xl in sorted(z_interval_chart.keys(), reverse=True):
                    intervals = z_interval_chart[xl]
                    interval_strs = [f"Z{zb:.4f} to Z{ze:.4f}" for zb, ze in intervals]
                    lines.append(f";   X{xl:.4f} -> [{', '.join(interval_strs)}]")
                lines.append(f"")

                while current_d - doc * 2 > min_roughing_x:
                    current_d -= doc * 2
                    pass_clear = current_d + retract_d
                    prev_pass_d = current_d + doc * 2  # previous pass cleared to here

                    intervals = z_interval_chart.get(current_d, [])
                    if not intervals:
                        continue

                    num_intervals = len(intervals)
                    for iv_idx, (z_begin, z_end) in enumerate(intervals):
                        iv_label = f"Pass {pass_num}" if num_intervals == 1 else f"Pass {pass_num}.{iv_idx+1}"
                        is_last_interval = (iv_idx == num_intervals - 1)

                        if iv_idx == 0:
                            # First interval approach: normal retraction is safe
                            # because z_begin is at or above z_start (part face).
                            lines.append(f"G00 X{pass_clear:.4f} Z{z_clear:.4f}  ({iv_label}  chart: X{current_d:.4f} [{z_begin:.4f} to {z_end:.4f}])")
                            lines.append(f"G00 X{prev_pass_d:.4f}")
                            lines.append(f"G01 X{current_d:.4f} F{feed_r}")
                        else:
                            # Subsequent intervals: must retract to x_clear
                            # to safely traverse past peak zones in Z.
                            lines.append(f"G00 X{x_clear:.4f}  ({iv_label}  chart: X{current_d:.4f} [{z_begin:.4f} to {z_end:.4f}])")
                            lines.append(f"G00 Z{z_begin:.4f}")
                            lines.append(f"G00 X{prev_pass_d:.4f}")
                            lines.append(f"G01 X{current_d:.4f} F{feed_r}")

                        # --- Cut ---
                        if peck_enabled and peck_depth > 0:
                            z_pos = z_begin
                            peck_num = 1
                            while z_pos - peck_depth > z_end + 0.0001:
                                z_pos -= peck_depth
                                lines.append(f"G01 Z{z_pos:.4f} F{feed_r}  (Peck {peck_num})")
                                lines.append(f"G04 P{peck_dwell:.3f}  (Chip break — 5 revs)")
                                peck_num += 1
                            lines.append(f"G01 Z{z_end:.4f} F{feed_r}  (Peck {peck_num} — final)")
                            lines.append(f"G04 P{peck_dwell:.3f}  (Chip break — 5 revs)")
                        else:
                            lines.append(f"G01 Z{z_end:.4f} F{feed_r}")

                        # --- Retract ---
                        if num_intervals == 1:
                            # Single interval (no peaks at this X level):
                            # Diagonal retract to pass_clear X, lifting 0.020" in Z.
                            pullaway_z = z_end + z_lift
                            lines.append(f"G00 X{pass_clear:.4f} Z{pullaway_z:.4f}  (Diagonal retract)")
                            lines.append(f"G00 Z{z_clear:.4f}")
                        elif is_last_interval:
                            # Last interval of a multi-interval pass:
                            # must retract to x_clear before Z travel
                            # because pass_clear may be inside peak zone.
                            pullaway_z = z_end + z_lift
                            lines.append(f"G00 X{x_clear:.4f} Z{pullaway_z:.4f}  (Diagonal retract)")
                            lines.append(f"G00 Z{z_clear:.4f}")
                        else:
                            # More intervals follow — diagonal retract to x_clear
                            # to safely cross peak zone to next interval.
                            pullaway_z = z_end + z_lift
                            lines.append(f"G00 X{x_clear:.4f} Z{pullaway_z:.4f}  (Diagonal retract)")
                        lines.append(f"")
                    pass_num += 1

            else:
                # Simple monotonic profile — use original single Z limit logic
                z_chart = build_z_limit_chart(finish_moves, x_start_d, z_start,
                                              x_levels, fin_allowance, "OD")

                # Print point chart as G-code comment for verification
                lines.append(f"; --- Point Chart (cleanup arc Z at each roughing X) ---")
                for xl in sorted(z_chart.keys(), reverse=True):
                    lines.append(f";   X{xl:.4f} -> Z{z_chart[xl]:.4f}")
                lines.append(f"")

                while current_d - doc * 2 > min_roughing_x:
                    current_d -= doc * 2
                    pass_clear = current_d + retract_d

                    z_limit = z_chart.get(current_d)
                    if z_limit is None:
                        continue

                    lines.append(f"G00 X{pass_clear:.4f} Z{z_clear:.4f}  (Pass {pass_num}  chart: X{current_d:.4f}->Z{z_limit:.4f})")
                    lines.append(f"G00 X{current_d:.4f} Z{z_start:.4f}")
                    if peck_enabled and peck_depth > 0:
                        # Peck roughing: feed in Z increments with chip-break dwells
                        total_z = z_start - z_limit
                        z_pos = z_start
                        peck_num = 1
                        while z_pos - peck_depth > z_limit + 0.0001:
                            z_pos -= peck_depth
                            lines.append(f"G01 Z{z_pos:.4f} F{feed_r}  (Peck {peck_num})")
                            lines.append(f"G04 P{peck_dwell:.3f}  (Chip break — 5 revs)")
                            peck_num += 1
                        # Final peck to z_limit
                        lines.append(f"G01 Z{z_limit:.4f} F{feed_r}  (Peck {peck_num} — final)")
                        lines.append(f"G04 P{peck_dwell:.3f}  (Chip break — 5 revs)")
                    else:
                        lines.append(f"G01 Z{z_limit:.4f} F{feed_r}")
                    # Diagonal pullaway: retract to pass_clear X while lifting
                    # 0.020" in Z to clear insert-angle ridges on the shoulder.
                    pullaway_z = z_limit + z_lift
                    lines.append(f"G00 X{pass_clear:.4f} Z{pullaway_z:.4f}  (Diagonal retract)")
                    lines.append(f"G00 Z{z_clear:.4f}")
                    lines.append(f"")
                    pass_num += 1

            # Cleanup pass: trace the roughing boundary contour
            # (part boundary offset outward by fin_allowance * 2 in X,
            #  fin_allowance in Z for LINE segments only)
            lines.append(f"; --- Cleanup pass (roughing boundary contour) ---")
            lines.append(f"G00 X{x_clear:.4f} Z{z_clear:.4f}")
            lines.append(f"G00 X{x_start_d + fin_allowance * 2:.4f} Z{z_start:.4f}")
            for mi, mv in enumerate(finish_moves):
                comment = f"  ({finish_comments[mi]})" if mi in finish_comments else ""
                if mv[0] == "LINE":
                    _, mx, mz = mv
                    ox = mx + fin_allowance * 2
                    oz = mz + fin_allowance
                    lines.append(f"G01 X{ox:.4f} Z{oz:.4f} F{feed_r}{comment}")
                elif mv[0] == "ARC":
                    _, mx, mz, mr = mv
                    ox = mx + fin_allowance * 2
                    oz = mz + fin_allowance
                    g = "G02" if mr > 0 else "G03"
                    lines.append(f"{g} X{ox:.4f} Z{oz:.4f} R{abs(mr):.4f} F{feed_r}{comment}")
            # Diagonal retract after cleanup pass: lift 0.020" in Z while
            # retracting to x_clear to avoid stock shoulder ridges.
            last_cleanup_z = None
            for mv in reversed(finish_moves):
                if mv[0] == "LINE":
                    last_cleanup_z = mv[2] + fin_allowance
                    break
                elif mv[0] == "ARC":
                    last_cleanup_z = mv[2] + fin_allowance
                    break
            if last_cleanup_z is not None:
                pullaway_z = last_cleanup_z + z_lift
                lines.append(f"G00 X{x_clear:.4f} Z{pullaway_z:.4f}  (Diagonal retract)")
                lines.append(f"G00 Z{z_clear:.4f}")
            else:
                lines.append(f"G00 X{x_clear:.4f}")
                lines.append(f"G00 Z{z_clear:.4f}")
            lines.append(f"")

        lines.append(f"G00 X{safe_x:.4f} Z{safe_z:.4f}  (Roughing complete — safe position)")
        lines.append(f"")

        # --- Tool change if needed ---
        if separate_tools and fin_p > 0:
            lines.append(f"M0  (PAUSE — Change to finish tool T{_lib_tool_num(f_tool)})")
            lines.append(f"T{_lib_tool_num(f_tool)} M6")
            lines.append(f"G43")
            lines.append(f"")

        # --- Finish pass: trace the full profile with chamfers and arcs ---
        if fin_p > 0:
            lines.append(f"; --- Finish pass (T{_lib_tool_num(f_tool)}) ---")
            lines.append(f"G00 X{safe_x:.4f} Z{safe_z:.4f}")
            lines.append(f"G00 X{x_start_d:.4f} Z{z_start:.4f}")

            for mi, mv in enumerate(finish_moves):
                comment = f"  ({finish_comments[mi]})" if mi in finish_comments else ""
                if mv[0] == "LINE":
                    _, mx, mz = mv
                    lines.append(f"G01 X{mx:.4f} Z{mz:.4f} F{feed_f}{comment}")
                elif mv[0] == "ARC":
                    _, mx, mz, mr = mv
                    g = "G02" if mr > 0 else "G03"
                    lines.append(f"{g} X{mx:.4f} Z{mz:.4f} R{abs(mr):.4f} F{feed_f}{comment}")

            if mode == "ID":
                # Diagonal retract: lift 0.020" in Z while retracting X
                # to avoid shoulder ridges at end of profile.
                last_finish_x = finish_moves[-1][1] if finish_moves else x_start_d
                last_finish_z = None
                for mv in reversed(finish_moves):
                    if mv[0] in ("LINE", "ARC"):
                        last_finish_z = mv[2]
                        break
                if last_finish_z is not None:
                    pullaway_z = last_finish_z + z_lift
                    if last_finish_x > x_start_d:
                        # Widening bore: retract toward center to x_clear
                        lines.append(f"G00 X{x_clear:.4f} Z{pullaway_z:.4f}  (Diagonal retract)")
                        lines.append(f"G00 Z{z_clear:.4f}")
                    else:
                        # Narrowing bore: retract toward center from current X
                        retract_x = last_finish_x - retract_d
                        lines.append(f"G00 X{retract_x:.4f} Z{pullaway_z:.4f}  (Diagonal retract)")
                        lines.append(f"G00 Z{z_clear:.4f}")
                        lines.append(f"G00 X{x_clear:.4f}")
                else:
                    if last_finish_x > x_start_d:
                        lines.append(f"G00 X{x_clear:.4f}")
                        lines.append(f"G00 Z{z_clear:.4f}")
                    else:
                        lines.append(f"G00 Z{z_clear:.4f}")
                        lines.append(f"G00 X{x_clear:.4f}")
            else:
                # OD finish pass: diagonal retract to x_clear, lifting 0.020" in Z
                last_finish_z = None
                for mv in reversed(finish_moves):
                    if mv[0] in ("LINE", "ARC"):
                        last_finish_z = mv[2]
                        break
                if last_finish_z is not None:
                    pullaway_z = last_finish_z + z_lift
                    lines.append(f"G00 X{x_clear:.4f} Z{pullaway_z:.4f}  (Diagonal retract)")
                    lines.append(f"G00 Z{z_clear:.4f}")
                else:
                    lines.append(f"G00 X{x_clear:.4f}")
            lines.append(f"")

        lines.append(f"G00 X{safe_x:.4f} Z{safe_z:.4f}  (Return to safe position)")
        lines.append(f"M2")
        lines.append(f"")


        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Threading Block
# ---------------------------------------------------------------------------
class ThreadingBlock(QFrame):
    """Parent block for threading operations — generates G76 cycle G-code."""

    def __init__(self, block_num=1, parent=None):
        super().__init__(parent)
        self.block_num = block_num
        self._expanded = True
        self._current_entry = None

        self.setStyleSheet(
            f"QFrame#threadingBlock {{ background-color: {COLORS['bg_dark']}; "
            f"border: 1px solid {COLORS['accent_orange']}; border-radius: 10px; "
            f"margin: 2px 0; }}"
        )
        self.setObjectName("threadingBlock")

        main = QVBoxLayout(self)
        main.setSpacing(4)
        main.setContentsMargins(8, 8, 8, 8)

        # --- Header (mirrors ProfileBlock) ---
        hdr = QHBoxLayout()
        self.title_edit = QLineEdit(f"Threading {block_num}")
        self.title_edit.setFont(ui_font(14, QFont.Bold))
        self.title_edit.setStyleSheet(
            f"color: {COLORS['accent_orange']}; background: transparent; "
            f"border: none; border-bottom: 1px solid transparent; padding: 2px 4px;")
        self.title_edit.setToolTip("Click to rename this threading block")
        self.title_edit.setMaximumWidth(250)
        hdr.addWidget(self.title_edit)
        hdr.addStretch()

        _hdr_btn = "border: none; border-radius: 8px; min-height: 0px; max-height: 36px; padding: 0px;"

        self.btn_collapse = QPushButton("▼")
        self.btn_collapse.setFixedSize(36, 36)
        self.btn_collapse.setFont(ui_font(14))
        self.btn_collapse.setStyleSheet(
            f"QPushButton {{ {_hdr_btn} background: {COLORS['bg_light']}; color: {COLORS['text']}; }}")
        self.btn_collapse.clicked.connect(self._toggle)
        hdr.addWidget(self.btn_collapse)

        self.btn_dup = QPushButton("x2")
        self.btn_dup.setFixedSize(36, 36)
        self.btn_dup.setFont(ui_font(13, QFont.Bold))
        self.btn_dup.setToolTip("Duplicate this threading block")
        self.btn_dup.setStyleSheet(
            f"QPushButton {{ {_hdr_btn} background: {COLORS['accent_orange']}; color: white; }}")
        hdr.addWidget(self.btn_dup)

        self.btn_up = QPushButton("↑")
        self.btn_up.setFixedSize(36, 36)
        self.btn_up.setFont(ui_font(16))
        self.btn_up.setToolTip("Move up")
        self.btn_up.setStyleSheet(
            f"QPushButton {{ {_hdr_btn} background: {COLORS['bg_light']}; color: {COLORS['text']}; }}")
        hdr.addWidget(self.btn_up)

        self.btn_down = QPushButton("↓")
        self.btn_down.setFixedSize(36, 36)
        self.btn_down.setFont(ui_font(16))
        self.btn_down.setToolTip("Move down")
        self.btn_down.setStyleSheet(
            f"QPushButton {{ {_hdr_btn} background: {COLORS['bg_light']}; color: {COLORS['text']}; }}")
        hdr.addWidget(self.btn_down)

        self.btn_remove = QPushButton("✕")
        self.btn_remove.setFixedSize(36, 36)
        self.btn_remove.setFont(ui_font(14, QFont.Bold))
        self.btn_remove.setStyleSheet(
            f"QPushButton {{ {_hdr_btn} background: {COLORS['accent']}; color: white; }}")
        hdr.addWidget(self.btn_remove)

        hdr.setContentsMargins(0, 0, 0, 0)
        main.addLayout(hdr)

        # --- Collapsible body ---
        self.body = QWidget()
        body_layout = QVBoxLayout(self.body)
        body_layout.setSpacing(4)
        body_layout.setContentsMargins(0, 0, 0, 0)

        # Row 1: Preset selector + Thread type
        row1 = QHBoxLayout()
        row1.setSpacing(8)
        lbl_preset = QLabel("Preset:")
        lbl_preset.setStyleSheet(LBL)
        lbl_preset.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        row1.addWidget(lbl_preset)
        self.cmb_preset = QComboBox()
        self.cmb_preset.setFixedWidth(200)
        self._populate_preset_combo()
        row1.addWidget(self.cmb_preset)

        lbl_type = QLabel("Type:")
        lbl_type.setStyleSheet(LBL)
        lbl_type.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        row1.addWidget(lbl_type)
        self.cmb_thread_type = QComboBox()
        self.cmb_thread_type.addItems(["External", "Internal"])
        self.cmb_thread_type.setFixedWidth(150)
        row1.addWidget(self.cmb_thread_type)
        row1.addStretch()
        body_layout.addLayout(row1)

        # Row 2: Fit class + Tolerance target
        row2 = QHBoxLayout()
        row2.setSpacing(8)
        lbl_fit = QLabel("Fit Class:")
        lbl_fit.setStyleSheet(LBL)
        lbl_fit.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        row2.addWidget(lbl_fit)
        self.cmb_fit_class = QComboBox()
        self.cmb_fit_class.setFixedWidth(100)
        row2.addWidget(self.cmb_fit_class)

        lbl_tol = QLabel("Tol Target:")
        lbl_tol.setStyleSheet(LBL)
        lbl_tol.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        row2.addWidget(lbl_tol)
        self.cmb_tol_target = QComboBox()
        self.cmb_tol_target.addItems(["MMC", "LMC", "Mid"])
        self.cmb_tol_target.setCurrentIndex(2)  # Default to Mid tolerance
        self.cmb_tol_target.setFixedWidth(80)
        row2.addWidget(self.cmb_tol_target)
        row2.addStretch()
        body_layout.addLayout(row2)

        # Row 3: Dimension fields with tolerance labels
        row3 = QHBoxLayout()
        row3.setSpacing(8)
        l, self.inp_major_d = _f("Major Dia:", "", "Major diameter (inches)", 80)
        row3.addWidget(l); row3.addWidget(self.inp_major_d)
        self.lbl_major_tol = QLabel("")
        self.lbl_major_tol.setStyleSheet(
            f"color: {COLORS['text_dim']}; font-size: 12px; background: transparent;")
        self.lbl_major_tol.setVisible(False)
        row3.addWidget(self.lbl_major_tol)

        l, self.inp_minor_d = _f("Minor Dia:", "", "Minor diameter (inches)", 80)
        row3.addWidget(l); row3.addWidget(self.inp_minor_d)
        self.lbl_minor_tol = QLabel("")
        self.lbl_minor_tol.setStyleSheet(
            f"color: {COLORS['text_dim']}; font-size: 12px; background: transparent;")
        self.lbl_minor_tol.setVisible(False)
        row3.addWidget(self.lbl_minor_tol)

        l, self.inp_pitch_d = _f("Pitch Dia:", "", "Pitch diameter (inches)", 80)
        row3.addWidget(l); row3.addWidget(self.inp_pitch_d)
        self.lbl_pitch_tol = QLabel("")
        self.lbl_pitch_tol.setStyleSheet(
            f"color: {COLORS['text_dim']}; font-size: 12px; background: transparent;")
        self.lbl_pitch_tol.setVisible(False)
        row3.addWidget(self.lbl_pitch_tol)
        row3.addStretch()
        body_layout.addLayout(row3)

        # Row 4: Thread params — pitch/TPI, length, lead-in, lead-out
        row4 = QHBoxLayout()
        row4.setSpacing(8)
        l, self.inp_pitch_tpi = _f("Pitch/TPI:", "", "TPI for UN, mm for Metric", 70)
        row4.addWidget(l); row4.addWidget(self.inp_pitch_tpi)

        l, self.inp_z_start = _f("Z Start:", "0.100", "Z position where threading cycle begins (inches)", 70)
        row4.addWidget(l); row4.addWidget(self.inp_z_start)

        l, self.inp_z_end = _f("Z End:", "-1.050", "Z position where threading cycle ends (inches)", 70)
        row4.addWidget(l); row4.addWidget(self.inp_z_end)
        row4.addStretch()
        body_layout.addLayout(row4)

        # Row 5: Cutting params
        row5 = QHBoxLayout()
        row5.setSpacing(8)
        l, self.inp_first_doc = _f("1st DOC:", "0.010", "First depth of cut (on diameter)", 60)
        row5.addWidget(l); row5.addWidget(self.inp_first_doc)

        l, self.inp_min_doc = _f("Min DOC:", "0.002", "Minimum depth of cut", 60)
        row5.addWidget(l); row5.addWidget(self.inp_min_doc)

        l, self.inp_spring_passes = _f("Spring:", "2", "Spring passes at final depth", 40)
        row5.addWidget(l); row5.addWidget(self.inp_spring_passes)

        l, self.inp_compound_angle = _f("Compound:", "29.5", "Compound infeed angle (degrees)", 50)
        row5.addWidget(l); row5.addWidget(self.inp_compound_angle)

        l, self.inp_degression = _f("Degress:", "1.0", "Degression factor (1.0 = constant chip area)", 50)
        row5.addWidget(l); row5.addWidget(self.inp_degression)
        row5.addStretch()
        body_layout.addLayout(row5)

        # Row 6: Multi-start
        row6 = QHBoxLayout()
        row6.setSpacing(8)
        l, self.inp_num_starts = _f("Starts:", "1", "Number of thread starts", 40)
        row6.addWidget(l); row6.addWidget(self.inp_num_starts)
        row6.addStretch()
        body_layout.addLayout(row6)

        # Row 7: Tool / RPM
        row7 = QHBoxLayout()
        row7.setSpacing(8)
        l, self.inp_tool_num = _f("Tool #:", "4", "Tool number for threading", 40)
        row7.addWidget(l); row7.addWidget(self.inp_tool_num)

        l, self.inp_rpm = _f("RPM:", "400", "Spindle RPM (comment only — manual spindle)", 60)
        row7.addWidget(l); row7.addWidget(self.inp_rpm)
        row7.addStretch()
        body_layout.addLayout(row7)

        main.addWidget(self.body)

        # --- Connect signals ---
        self.cmb_preset.currentIndexChanged.connect(self._on_preset_changed)
        self.cmb_thread_type.currentIndexChanged.connect(self._on_thread_type_changed)
        self.cmb_fit_class.currentIndexChanged.connect(self._on_fit_class_changed)
        self.cmb_tol_target.currentIndexChanged.connect(self._on_tolerance_target_changed)

    def _populate_preset_combo(self):
        """Fill preset combo with Custom + thread entries grouped by family."""
        self.cmb_preset.addItem("Custom")
        for family in thread_data.get_families():
            entries = thread_data.get_threads_for_family(family)
            if entries:
                self.cmb_preset.addItem(f"── {family} ──")
                # Make the separator non-selectable
                idx = self.cmb_preset.count() - 1
                self.cmb_preset.model().item(idx).setEnabled(False)
                for entry in entries:
                    self.cmb_preset.addItem(entry["key"])

    def _toggle(self):
        self._expanded = not self._expanded
        self.body.setVisible(self._expanded)
        self.btn_collapse.setText("▼" if self._expanded else "▶")

    def set_metric_display(self, metric: bool):
        """Convert distance fields between inch and metric display.

        Distance fields: major_d, minor_d, pitch_d, z_start, z_end,
        first_doc, min_doc. NOT converted: pitch/TPI, angles, RPM, tool#,
        spring passes, degression, num_starts.
        """
        self._metric_display = metric
        for field in (self.inp_major_d, self.inp_minor_d, self.inp_pitch_d,
                      self.inp_z_start, self.inp_z_end,
                      self.inp_first_doc, self.inp_min_doc):
            _conv_field_to_metric(field, metric)

    def set_num(self, n):
        old_default = f"Threading {self.block_num}"
        self.block_num = n
        if self.title_edit.text() == old_default:
            self.title_edit.setText(f"Threading {n}")

    # ------------------------------------------------------------------
    # Preset / tolerance signal handlers
    # ------------------------------------------------------------------

    def _on_preset_changed(self, index):
        """Handle preset combo selection change."""
        text = self.cmb_preset.currentText()

        # Check for Custom or separator
        if text == "Custom" or text.startswith("──"):
            self._current_entry = None
            self.inp_major_d.setText("")
            self.inp_minor_d.setText("")
            self.inp_pitch_d.setText("")
            self.inp_pitch_tpi.setText("")
            self.inp_compound_angle.setText("")
            self.cmb_fit_class.clear()
            self.cmb_tol_target.setVisible(False)
            self.lbl_major_tol.setVisible(False)
            self.lbl_minor_tol.setVisible(False)
            self.lbl_pitch_tol.setVisible(False)
            return

        entry = thread_data.get_thread_by_key(text)
        if entry is None:
            # Fallback to Custom mode
            self._current_entry = None
            return

        self._current_entry = entry

        # Auto-fill dimension fields (4 decimal places)
        self.inp_major_d.setText(f"{entry['major_d_basic']:.4f}")
        self.inp_minor_d.setText(f"{entry['minor_d_basic']:.4f}")
        self.inp_pitch_d.setText(f"{entry['pitch_d_basic']:.4f}")

        # Pitch/TPI
        if entry["tpi"] is not None:
            self.inp_pitch_tpi.setText(str(entry["tpi"]))
        elif entry["pitch_mm"] is not None:
            self.inp_pitch_tpi.setText(f"{entry['pitch_mm']:.4f}")

        # Compound angle
        self.inp_compound_angle.setText(f"{entry['compound_angle']:.1f}")

        # Update fit class options for current thread type
        self._update_fit_class_options()

        # Show tolerance target and apply
        self.cmb_tol_target.setVisible(True)
        self._apply_tolerance_target()

    def _on_thread_type_changed(self, index):
        """Handle thread type (External/Internal) change."""
        if self._current_entry is None:
            return
        self._update_fit_class_options()
        self._apply_tolerance_target()

    def _on_fit_class_changed(self, index):
        """Handle fit class selection change."""
        if self._current_entry is None:
            return
        self._update_tolerance_labels()
        self._apply_tolerance_target()

    def _on_tolerance_target_changed(self, index):
        """Handle tolerance target (MMC/LMC/Mid) change."""
        if self._current_entry is None:
            return
        self._apply_tolerance_target()

    def _update_fit_class_options(self):
        """Update fit class combo based on current entry family and thread type."""
        if self._current_entry is None:
            return
        family = self._current_entry["family"]
        thread_type = self.cmb_thread_type.currentText()
        fit_classes = thread_data.FAMILY_FIT_CLASSES.get(family, {}).get(thread_type, [])

        # Block signals to avoid recursion during update
        self.cmb_fit_class.blockSignals(True)
        self.cmb_fit_class.clear()
        self.cmb_fit_class.addItems(fit_classes)
        self.cmb_fit_class.blockSignals(False)

        # Trigger fit class changed to update labels
        self._on_fit_class_changed(self.cmb_fit_class.currentIndex())

    def _apply_tolerance_target(self):
        """Recalculate dimensions from tolerance target and update fields."""
        if self._current_entry is None:
            return
        fit_class = self.cmb_fit_class.currentText()
        if not fit_class:
            return
        target = self.cmb_tol_target.currentText()
        thread_type = self.cmb_thread_type.currentText()

        dims = thread_data.compute_tolerance_target(
            self._current_entry, fit_class, target, thread_type
        )
        self.inp_major_d.setText(f"{dims['major_d']:.4f}")
        self.inp_minor_d.setText(f"{dims['minor_d']:.4f}")
        self.inp_pitch_d.setText(f"{dims['pitch_d']:.4f}")

        self._update_tolerance_labels()

    def _update_tolerance_labels(self):
        """Show 'min — max' tolerance range next to each dimension field."""
        if self._current_entry is None or not self.cmb_fit_class.currentText():
            self.lbl_major_tol.setVisible(False)
            self.lbl_minor_tol.setVisible(False)
            self.lbl_pitch_tol.setVisible(False)
            return

        fit_class = self.cmb_fit_class.currentText()
        tol = self._current_entry["tolerances"].get(fit_class, {})

        for dim_key, label in [("major_d", self.lbl_major_tol),
                               ("minor_d", self.lbl_minor_tol),
                               ("pitch_d", self.lbl_pitch_tol)]:
            band = tol.get(dim_key, (None, None))
            lo, hi = band
            if lo is not None and hi is not None:
                label.setText(f"{lo:.4f} — {hi:.4f}")
                label.setVisible(True)
            else:
                label.setVisible(False)

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def export_data(self):
        """Export all field values as a dict for duplication."""
        return {
            "title": self.title_edit.text(),
            "preset_key": self.cmb_preset.currentText(),
            "thread_type": self.cmb_thread_type.currentText(),
            "fit_class": self.cmb_fit_class.currentText(),
            "tolerance_target": self.cmb_tol_target.currentText(),
            "major_d": self.inp_major_d.text(),
            "minor_d": self.inp_minor_d.text(),
            "pitch_d": self.inp_pitch_d.text(),
            "pitch_tpi": self.inp_pitch_tpi.text(),
            "z_start": self.inp_z_start.text(),
            "z_end": self.inp_z_end.text(),
            "first_doc": self.inp_first_doc.text(),
            "min_doc": self.inp_min_doc.text(),
            "spring_passes": self.inp_spring_passes.text(),
            "compound_angle": self.inp_compound_angle.text(),
            "degression": self.inp_degression.text(),
            "num_starts": self.inp_num_starts.text(),
            "tool_num": self.inp_tool_num.text(),
            "rpm": self.inp_rpm.text(),
        }

    def import_data(self, data):
        """Restore all fields from a dict with safe defaults."""
        if "title" in data:
            self.title_edit.setText(data["title"] + " (copy)")

        # Restore preset selection (triggers auto-fill cascade)
        preset_key = data.get("preset_key", "Custom")
        idx = self.cmb_preset.findText(preset_key)
        if idx >= 0:
            self.cmb_preset.setCurrentIndex(idx)

        # Thread type
        tt_idx = self.cmb_thread_type.findText(data.get("thread_type", "External"))
        if tt_idx >= 0:
            self.cmb_thread_type.setCurrentIndex(tt_idx)

        # Fit class (after preset + type are set so options are populated)
        fc_idx = self.cmb_fit_class.findText(data.get("fit_class", ""))
        if fc_idx >= 0:
            self.cmb_fit_class.setCurrentIndex(fc_idx)

        # Tolerance target
        tol_idx = self.cmb_tol_target.findText(data.get("tolerance_target", "MMC"))
        if tol_idx >= 0:
            self.cmb_tol_target.setCurrentIndex(tol_idx)

        # Override dimension fields with saved values (operator may have edited)
        for key, widget in [
            ("major_d", self.inp_major_d),
            ("minor_d", self.inp_minor_d),
            ("pitch_d", self.inp_pitch_d),
            ("pitch_tpi", self.inp_pitch_tpi),
            ("z_start", self.inp_z_start),
            ("z_end", self.inp_z_end),
            ("first_doc", self.inp_first_doc),
            ("min_doc", self.inp_min_doc),
            ("spring_passes", self.inp_spring_passes),
            ("compound_angle", self.inp_compound_angle),
            ("degression", self.inp_degression),
            ("num_starts", self.inp_num_starts),
            ("tool_num", self.inp_tool_num),
            ("rpm", self.inp_rpm),
        ]:
            if key in data:
                widget.setText(str(data[key]))

    # ------------------------------------------------------------------
    # G-code generation
    # ------------------------------------------------------------------

    def generate_gcode(self):
        """Generate G76 threading cycle G-code."""
        metric = getattr(self, '_metric_display', False)
        # --- Parse all numeric fields ---
        # Distance fields need conversion back to inches
        _dist_fields = {"major_d", "minor_d", "pitch_d", "z_start", "z_end", "first_doc", "min_doc"}
        fields = {}
        for name, widget in [
            ("major_d", self.inp_major_d),
            ("minor_d", self.inp_minor_d),
            ("pitch_d", self.inp_pitch_d),
            ("pitch_tpi", self.inp_pitch_tpi),
            ("z_start", self.inp_z_start),
            ("z_end", self.inp_z_end),
            ("first_doc", self.inp_first_doc),
            ("min_doc", self.inp_min_doc),
            ("spring_passes", self.inp_spring_passes),
            ("compound_angle", self.inp_compound_angle),
            ("degression", self.inp_degression),
            ("num_starts", self.inp_num_starts),
            ("tool_num", self.inp_tool_num),
            ("rpm", self.inp_rpm),
        ]:
            try:
                val = float(widget.text())
                if metric and name in _dist_fields:
                    val /= _IN_TO_MM
                fields[name] = val
            except ValueError:
                return f"; ERROR: Invalid input — {name}"

        major_d = fields["major_d"]
        minor_d = fields["minor_d"]
        pitch_tpi_val = fields["pitch_tpi"]
        z_start = fields["z_start"]
        z_end = fields["z_end"]
        first_doc = fields["first_doc"]
        spring_passes = int(fields["spring_passes"])
        compound_angle = fields["compound_angle"]
        degression = fields["degression"]
        num_starts = max(1, int(fields["num_starts"]))
        tool_num = int(fields["tool_num"])
        rpm = int(fields["rpm"])

        thread_type = self.cmb_thread_type.currentText()
        is_external = thread_type == "External"

        # --- Determine pitch distance (inches/rev) ---
        entry = self._current_entry
        if entry is not None and entry.get("pitch_mm") is not None and entry.get("tpi") is None:
            # Metric thread — pitch_tpi_val is mm
            pitch_dist = pitch_tpi_val / 25.4
        else:
            # UN/Acme or Custom — pitch_tpi_val is TPI
            if pitch_tpi_val <= 0:
                return "; ERROR: Invalid pitch value"
            pitch_dist = 1.0 / pitch_tpi_val

        # --- Validate ---
        if z_end >= z_start:
            return "; ERROR: Z End must be less than Z Start (threading moves in -Z)"

        thread_depth = (major_d - minor_d) / 2.0
        if thread_depth <= 0:
            return "; ERROR: Thread depth is zero or negative — check major/minor diameters"

        # --- Positioning ---
        clearance = 0.100
        if is_external:
            x_start = major_d + clearance
            i_param = -clearance
        else:
            x_start = minor_d - clearance
            i_param = clearance

        # G76 parameters
        j_param = first_doc / 2.0   # initial cut depth (on radius)
        k_param = thread_depth       # full thread depth (on radius)

        # --- Build G-code ---
        # Determine thread spec for comments
        preset_text = self.cmb_preset.currentText()
        if preset_text == "Custom":
            spec_str = "Custom Thread"
        else:
            spec_str = preset_text

        fit_class = self.cmb_fit_class.currentText()

        lines = []
        lines.append(f"; Threading — {thread_type} — {spec_str}")
        if entry and entry.get("tpi"):
            lines.append(f"; {entry['tpi']} TPI, {entry['thread_angle']}° thread form, Class {fit_class}")
        elif entry and entry.get("pitch_mm"):
            lines.append(f"; {entry['pitch_mm']}mm pitch, {entry['thread_angle']}° thread form, Class {fit_class}")
        else:
            lines.append(f"; Pitch: {pitch_dist:.6f} in/rev, Class {fit_class}")
        lines.append(f"; Major: {major_d:.4f}  Minor: {minor_d:.4f}  Pitch: {fields['pitch_d']:.4f}")
        lines.append(f"; Thread depth: {thread_depth:.4f} (on radius)")
        lines.append(f"; Z start: {z_start:.4f}  Z end: {z_end:.4f}  Spring passes: {spring_passes}")
        lines.append(f"; Suggested RPM: {rpm} (manual spindle — not emitted as S-word)")
        lines.append("")
        lines.append("G20 G18 G40 G49 G80")
        lines.append("G90")
        lines.append(f"T{_lib_tool_num(tool_num)} M6")
        lines.append("G43")

        for start_num in range(num_starts):
            z_offset = (pitch_dist / num_starts) * start_num
            z_start_pos = z_start - z_offset
            z_end_pos = z_end - z_offset

            lines.append("")
            lines.append(f"; Position to start")
            lines.append(f"G00 X{x_start:.4f} Z{z_start_pos:.4f}")
            lines.append("")
            lines.append(f"; G76 Threading Cycle — Start {start_num + 1} of {num_starts}")
            lines.append(f"; P=pitch, Z=end, I=peak offset, J=first cut, K=depth")
            lines.append(f"; Q=compound angle, H=spring passes, R=degression")
            lines.append(
                f"G76 P{pitch_dist:.6f} Z{z_end_pos:.4f} I{i_param:.4f} "
                f"J{j_param:.4f} K{k_param:.4f} Q{compound_angle} "
                f"H{spring_passes} R{degression}"
            )
            lines.append("")
            lines.append(f"; Return to safe position")
            lines.append(f"G00 X{x_start:.4f} Z{z_start_pos:.4f}")

        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Cutoff / Groove Block
# ---------------------------------------------------------------------------
class CutoffBlock(QFrame):
    """Parent block for cutoff/grooving operations.

    If Z Start == Z End → classic cutoff plunge.
    If Z Start ≠ Z End → grooving mode:
      - Peck depth controls X step-down per level
      - At each X level, traverse Z in blade-width steps to clear the groove width
      - Repeat until full X depth is reached
    """

    def __init__(self, block_num=1, parent=None):
        super().__init__(parent)
        self.block_num = block_num
        self._expanded = True

        self.setStyleSheet(
            f"QFrame#cutoffBlock {{ background-color: {COLORS['bg_dark']}; "
            f"border: 1px solid {COLORS['accent']}; border-radius: 10px; "
            f"margin: 2px 0; }}"
        )
        self.setObjectName("cutoffBlock")

        main = QVBoxLayout(self)
        main.setSpacing(4)
        main.setContentsMargins(8, 8, 8, 8)

        # --- Header ---
        hdr = QHBoxLayout()
        self.title_edit = QLineEdit(f"Grooving {block_num}")
        self.title_edit.setFont(ui_font(14, QFont.Bold))
        self.title_edit.setStyleSheet(
            f"color: {COLORS['accent']}; background: transparent; "
            f"border: none; border-bottom: 1px solid transparent; padding: 2px 4px;")
        self.title_edit.setToolTip("Click to rename this grooving/cutoff block")
        self.title_edit.setMaximumWidth(250)
        hdr.addWidget(self.title_edit)

        # Mode indicator label
        self.mode_indicator = QLabel("CUTOFF")
        self.mode_indicator.setFont(ui_font(11, QFont.Bold))
        self.mode_indicator.setStyleSheet(
            f"color: {COLORS['accent']}; background: {COLORS['bg_light']}; "
            f"border-radius: 4px; border: none; padding: 2px 8px;")
        self.mode_indicator.setFixedHeight(22)
        hdr.addWidget(self.mode_indicator)

        hdr.addStretch()

        self.btn_collapse = QPushButton("▼")
        _hdr_btn = "border: none; border-radius: 8px; min-height: 0px; max-height: 36px; padding: 0px;"

        self.btn_collapse.setFixedSize(36, 36)
        self.btn_collapse.setFont(ui_font(14))
        self.btn_collapse.setStyleSheet(
            f"QPushButton {{ {_hdr_btn} background: {COLORS['bg_light']}; color: {COLORS['text']}; }}")
        self.btn_collapse.clicked.connect(self._toggle)
        hdr.addWidget(self.btn_collapse)

        self.btn_dup = QPushButton("x2")
        self.btn_dup.setFixedSize(36, 36)
        self.btn_dup.setFont(ui_font(13, QFont.Bold))
        self.btn_dup.setToolTip("Duplicate this cutoff/groove block")
        self.btn_dup.setStyleSheet(
            f"QPushButton {{ {_hdr_btn} background: {COLORS['accent']}; color: white; }}")
        hdr.addWidget(self.btn_dup)

        self.btn_up = QPushButton("↑")
        self.btn_up.setFixedSize(36, 36)
        self.btn_up.setFont(ui_font(16))
        self.btn_up.setToolTip("Move up")
        self.btn_up.setStyleSheet(
            f"QPushButton {{ {_hdr_btn} background: {COLORS['bg_light']}; color: {COLORS['text']}; }}")
        hdr.addWidget(self.btn_up)

        self.btn_down = QPushButton("↓")
        self.btn_down.setFixedSize(36, 36)
        self.btn_down.setFont(ui_font(16))
        self.btn_down.setToolTip("Move down")
        self.btn_down.setStyleSheet(
            f"QPushButton {{ {_hdr_btn} background: {COLORS['bg_light']}; color: {COLORS['text']}; }}")
        hdr.addWidget(self.btn_down)

        self.btn_remove = QPushButton("✕")
        self.btn_remove.setFixedSize(36, 36)
        self.btn_remove.setFont(ui_font(14, QFont.Bold))
        self.btn_remove.setStyleSheet(
            f"QPushButton {{ {_hdr_btn} background: {COLORS['accent']}; color: white; }}")
        hdr.addWidget(self.btn_remove)

        hdr.setContentsMargins(0, 0, 0, 0)
        main.addLayout(hdr)

        # --- Collapsible body ---
        self.body = QWidget()
        body_layout = QVBoxLayout(self.body)
        body_layout.setSpacing(4)
        body_layout.setContentsMargins(0, 0, 0, 0)

        # Row 1: Dimensions — X Start, X End
        row1 = QHBoxLayout()
        row1.setSpacing(8)
        l, self.inp_x_start = _f("X Start:", "2.000", "X start position (diameter) — OD of workpiece", 80)
        row1.addWidget(l); row1.addWidget(self.inp_x_start)
        l, self.inp_x_end = _f("X End:", "-0.010", "X end position (diameter) — cut-through depth", 80)
        row1.addWidget(l); row1.addWidget(self.inp_x_end)
        row1.addStretch()
        body_layout.addLayout(row1)

        # Row 2: Z positions — Z Start, Z End
        row2 = QHBoxLayout()
        row2.setSpacing(8)
        l, self.inp_z_start = _f("Z Start:", "-2.000", "Z start of groove/cutoff (right side)", 80)
        row2.addWidget(l); row2.addWidget(self.inp_z_start)
        l, self.inp_z_end = _f("Z End:", "-2.000", "Z end of groove (left side). Same as Z Start = cutoff mode.", 80)
        row2.addWidget(l); row2.addWidget(self.inp_z_end)
        row2.addStretch()
        body_layout.addLayout(row2)

        # Row 3: Cutting — Feed Rate, RPM
        row3 = QHBoxLayout()
        row3.setSpacing(8)
        l, self.inp_feed = _f("Feed:", "0.002", "Feed rate (in/rev)", 80)
        row3.addWidget(l); row3.addWidget(self.inp_feed)
        l, self.inp_rpm = _f("RPM:", "300", "Spindle RPM (comment only — manual spindle)", 80)
        row3.addWidget(l); row3.addWidget(self.inp_rpm)
        row3.addStretch()
        body_layout.addLayout(row3)

        # Row 4: Peck — Peck Depth, Peck Retract
        row4 = QHBoxLayout()
        row4.setSpacing(8)
        l, self.inp_peck_depth = _f("Peck Depth:", "0.050",
            "X peck depth on diameter per level (cutoff: 0 = straight plunge; groove: required)", 80)
        row4.addWidget(l); row4.addWidget(self.inp_peck_depth)
        l, self.inp_peck_retract = _f("Peck Retract:", "0.010", "Peck retract distance on diameter", 80)
        row4.addWidget(l); row4.addWidget(self.inp_peck_retract)
        row4.addStretch()
        body_layout.addLayout(row4)

        # Row 5: Tool — Tool Number
        row5 = QHBoxLayout()
        row5.setSpacing(8)
        l, self.inp_tool_num = _f("Tool #:", "5", "Tool number for cutoff/grooving", 40)
        row5.addWidget(l); row5.addWidget(self.inp_tool_num)
        row5.addStretch()
        body_layout.addLayout(row5)

        main.addWidget(self.body)

        # --- Connect Z fields to update mode indicator ---
        self.inp_z_start.textChanged.connect(self._update_mode_indicator)
        self.inp_z_end.textChanged.connect(self._update_mode_indicator)

    def _toggle(self):
        self._expanded = not self._expanded
        self.body.setVisible(self._expanded)
        self.btn_collapse.setText("▼" if self._expanded else "▶")

    def set_metric_display(self, metric: bool):
        """Convert distance fields between inch and metric display.

        Distance fields: x_start, x_end, z_start, z_end, feed, peck_depth,
        peck_retract. NOT converted: RPM, tool#.
        """
        self._metric_display = metric
        for field in (self.inp_x_start, self.inp_x_end, self.inp_z_start,
                      self.inp_z_end, self.inp_feed, self.inp_peck_depth,
                      self.inp_peck_retract):
            _conv_field_to_metric(field, metric)

    def _update_mode_indicator(self):
        """Update the mode label based on Z Start vs Z End."""
        try:
            z_start = float(self.inp_z_start.text())
            z_end = float(self.inp_z_end.text())
        except ValueError:
            self.mode_indicator.setText("—")
            return
        if abs(z_start - z_end) < 0.0005:
            self.mode_indicator.setText("CUTOFF")
            self.mode_indicator.setStyleSheet(
                f"color: {COLORS['accent']}; background: {COLORS['bg_light']}; "
                f"border-radius: 4px; border: none; padding: 2px 8px;")
        else:
            self.mode_indicator.setText("GROOVE")
            self.mode_indicator.setStyleSheet(
                f"color: {COLORS['accent_orange']}; background: {COLORS['bg_light']}; "
                f"border-radius: 4px; border: none; padding: 2px 8px;")

    def set_num(self, n):
        old_default = f"Grooving {self.block_num}"
        old_legacy = f"Cutoff {self.block_num}"
        self.block_num = n
        if self.title_edit.text() in (old_default, old_legacy):
            self.title_edit.setText(f"Grooving {n}")

    def export_data(self):
        """Export all field values as a dict for duplication."""
        return {
            "title": self.title_edit.text(),
            "x_start": self.inp_x_start.text(),
            "x_end": self.inp_x_end.text(),
            "z_start": self.inp_z_start.text(),
            "z_end": self.inp_z_end.text(),
            "feed": self.inp_feed.text(),
            "rpm": self.inp_rpm.text(),
            "peck_depth": self.inp_peck_depth.text(),
            "peck_retract": self.inp_peck_retract.text(),
            "tool_num": self.inp_tool_num.text(),
        }

    def import_data(self, data):
        """Restore all fields from a dict with safe defaults."""
        if "title" in data:
            self.title_edit.setText(data["title"] + " (copy)")
        for key, widget in [
            ("x_start", self.inp_x_start),
            ("x_end", self.inp_x_end),
            ("z_start", self.inp_z_start),
            ("z_end", self.inp_z_end),
            ("feed", self.inp_feed),
            ("rpm", self.inp_rpm),
            ("peck_depth", self.inp_peck_depth),
            ("peck_retract", self.inp_peck_retract),
            ("tool_num", self.inp_tool_num),
        ]:
            if key in data:
                widget.setText(str(data[key]))
        # Backward compat: old "z_pos" field maps to both z_start and z_end
        if "z_pos" in data and "z_start" not in data:
            self.inp_z_start.setText(str(data["z_pos"]))
            self.inp_z_end.setText(str(data["z_pos"]))

    def generate_gcode(self):
        """Generate G-code for cutoff or grooving operation.

        Cutoff mode (Z Start == Z End):
          Plunge straight down (or peck) at a single Z position.

        Groove mode (Z Start != Z End):
          Step down in X by peck_depth, then traverse Z in blade-width
          steps to clear the full groove width at that X level.  Repeat
          until full X depth is reached.  The tool's right edge is
          referenced to Z Start (right side of groove) and steps toward
          Z End (left / negative Z).
        """
        metric = getattr(self, '_metric_display', False)
        # --- Input validation ---
        try:
            x_start = _inch_val(self.inp_x_start, metric)
            x_end = _inch_val(self.inp_x_end, metric)
            z_start = _inch_val(self.inp_z_start, metric)
            z_end = _inch_val(self.inp_z_end, metric)
            feed = _inch_val(self.inp_feed, metric)
            rpm = self.inp_rpm.text()
            tool = self.inp_tool_num.text()
            peck_depth = _inch_val(self.inp_peck_depth, metric)
            peck_retract = _inch_val(self.inp_peck_retract, metric)
        except ValueError as e:
            return f"; ERROR: Invalid input -- {e}\n"

        # Look up blade width from tool tab
        conv_tab = getattr(self, '_conv_tab', None)
        if conv_tab:
            blade_w = conv_tab.get_blade_width(tool)
        else:
            blade_w = 0.125  # fallback default

        if x_start <= x_end:
            return "; ERROR: X start must be greater than X end\n"
        if feed <= 0:
            return "; ERROR: Feed rate must be positive\n"
        if blade_w <= 0:
            return "; ERROR: Blade width must be positive\n"

        # Ensure z_start >= z_end (z_start is the right/positive side)
        if z_start < z_end:
            z_start, z_end = z_end, z_start

        groove_width = abs(z_start - z_end)
        is_groove = groove_width > 0.0005

        # --- Constants ---
        clearance = 0.100  # on diameter above X start
        x_clearance = x_start + clearance

        if is_groove:
            return self._gen_groove(
                x_start, x_end, z_start, z_end, blade_w,
                feed, rpm, tool, peck_depth, peck_retract,
                groove_width, x_clearance)
        else:
            return self._gen_cutoff(
                x_start, x_end, z_start, blade_w,
                feed, rpm, tool, peck_depth, peck_retract,
                x_clearance)

    # -- Groove G-code generation ------------------------------------------

    def _gen_groove(self, x_start, x_end, z_start, z_end, blade_w,
                    feed, rpm, tool, peck_depth, peck_retract,
                    groove_width, x_clearance):
        if peck_depth <= 0:
            return "; ERROR: Peck depth must be positive for grooving\n"
        if peck_retract <= 0:
            return "; ERROR: Peck retract must be positive for grooving\n"
        if blade_w > groove_width + 0.0001:
            return (f"; ERROR: Blade width ({blade_w:.4f}) exceeds "
                    f"groove width ({groove_width:.4f})\n")

        lines = [
            f"; Grooving — Conversational",
            f"; X Start: {x_start:.4f}  X End: {x_end:.4f}",
            f"; Z Start: {z_start:.4f}  Z End: {z_end:.4f}  "
            f"(Width: {groove_width:.4f})",
            f"; Blade width: {blade_w:.4f}",
            f"; Peck depth: {peck_depth:.4f} (on diameter)  "
            f"Retract: {peck_retract:.4f}",
            f"; Feed: {feed}  Suggested RPM: {rpm}",
            f"",
            f"G20 G18 G40 G49 G80",
            f"G90",
            f"T{_lib_tool_num(tool)} M6",
            f"G43",
            f"",
            f"G00 X{x_clearance:.4f} Z{z_start:.4f}  (Rapid to clearance)",
            f"",
        ]

        # Build the list of Z plunge positions across the groove width.
        # Each position is where the tool's RIGHT edge sits.
        # First plunge: right edge at z_start (cuts z_start to z_start - blade_w)
        # Last plunge:  right edge at z_end   (cuts z_end   to z_end   + blade_w)
        #
        # If groove width <= blade width, one plunge covers it.
        # If groove width <= 2× blade width, first + last plunges overlap.
        # If groove width > 2× blade width, intermediate plunges fill the gap.
        z_positions = [z_start]
        z_last = z_end  # right edge of final plunge
        gap = z_start - z_last  # total groove width (positive)
        if gap > 2.0 * blade_w + 0.0001:
            # First and last plunges can't cover the width — add intermediates
            z_pos = z_start - blade_w
            while z_pos > z_last + blade_w + 0.0001:
                z_positions.append(z_pos)
                z_pos -= blade_w
            z_positions.append(z_last)
        elif gap > blade_w + 0.0001:
            # Two plunges with overlap cover it
            z_positions.append(z_last)

        # Step down in X levels
        z_stepover_margin = 0.050  # clearance past previous X level
        current_x = x_start
        level = 0
        while current_x > x_end + 0.0001:
            level += 1
            next_x = max(current_x - peck_depth, x_end)

            # Retract height for Z repositioning: previous pass start X
            # plus safety margin so blade clears uncut material.
            stepover_retract_x = min(current_x + z_stepover_margin,
                                     x_clearance)

            lines.append(f"; --- Level {level}: X = {next_x:.4f} ---")

            for zi, z_pos in enumerate(z_positions):
                if zi == 0 and level == 1:
                    # Very first plunge — rapid from full clearance
                    lines.append(
                        f"G00 X{x_clearance:.4f} Z{z_pos:.4f}  "
                        f"(Position for level {level})")
                elif zi == 0:
                    # First Z position of a new level — retract to
                    # stepover height, reposition to Z start
                    lines.append(
                        f"G00 X{stepover_retract_x:.4f}  "
                        f"(Retract past previous pass)")
                    lines.append(
                        f"G00 Z{z_pos:.4f}  (Back to Z start)")
                else:
                    # Subsequent Z positions within a level
                    lines.append(
                        f"G00 X{stepover_retract_x:.4f}  "
                        f"(Retract past previous pass)")
                    lines.append(
                        f"G00 Z{z_pos:.4f}  (Step over)")

                lines.append(
                    f"G01 X{next_x:.4f} F{feed}  (Plunge)")

            lines.append(f"")
            current_x = next_x

        lines.append(f"G00 X{x_clearance:.4f}  (Retract to clearance)")
        lines.append(f"M2")
        lines.append(f"")

        return "\n".join(lines)

    # -- Cutoff G-code generation ------------------------------------------

    def _gen_cutoff(self, x_start, x_end, z_pos, blade_w,
                    feed, rpm, tool, peck_depth, peck_retract,
                    x_clearance):
        mode_str = "Pecking" if peck_depth > 0 else "Straight Plunge"

        if peck_depth > 0 and peck_retract <= 0:
            return "; ERROR: Peck retract must be positive when pecking\n"

        lines = [
            f"; Cutoff / Parting — Conversational",
            f"; X Start: {x_start:.4f}  X End: {x_end:.4f}",
            f"; Z position: {z_pos:.4f}  Blade width: {blade_w:.4f}",
            f"; Mode: {mode_str}",
            f"; Suggested RPM: {rpm}",
            f"",
            f"G20 G18 G40 G49 G80",
            f"G90",
            f"T{_lib_tool_num(tool)} M6",
            f"G43",
            f"",
            f"G00 X{x_clearance:.4f} Z{z_pos:.4f}  (Rapid to clearance)",
            f"",
        ]

        if peck_depth > 0:
            lines.append(f"; --- Peck parting ---")
            current_x = x_start
            peck_num = 0
            while current_x > x_end:
                peck_num += 1
                next_x = max(current_x - peck_depth, x_end)
                lines.append(f"G01 X{next_x:.4f} F{feed}  (Peck {peck_num})")
                if next_x > x_end:
                    retract_x = min(next_x + peck_retract, x_clearance)
                    lines.append(f"G00 X{retract_x:.4f}  (Retract)")
                current_x = next_x
            lines.append(f"")
        else:
            lines.append(f"G01 X{x_end:.4f} F{feed}  (Cutoff plunge)")
            lines.append(f"")

        lines.append(f"G00 X{x_clearance:.4f}  (Retract to clearance)")
        lines.append(f"M2")
        lines.append(f"")

        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main Profile Conversational Tab
# ---------------------------------------------------------------------------
class ProfileConvTab(QWidget):
    """Profile-based conversational programming.
    Parent blocks define stock + cutting params.
    Child segments define the finish profile.
    Supports threading and cutoff as separate block types."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._graph = None
        self._tool_tab = None
        layout = QHBoxLayout(self)
        layout.setSpacing(8)

        # ===== LEFT: Profile blocks =====
        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setSpacing(4)
        left_layout.setContentsMargins(0, 0, 0, 0)

        hdr = QHBoxLayout()
        title = QLabel("Process List")
        title.setFont(ui_font(14, QFont.Bold))
        title.setStyleSheet(f"color: {COLORS['text']}; background: transparent;")
        hdr.addWidget(title)
        hdr.addStretch()

        _proc_btn_base = (
            "QPushButton {{ "
            "  background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 {hi}, stop:1 {lo}); "
            "  color: white; border: 1px solid {lo}; border-bottom: 2px solid {shadow}; "
            "  border-radius: 10px; min-height: 40px; min-width: 100px; "
            "  padding: 6px 16px; font-weight: 700; font-size: 14px; }} "
            "QPushButton:hover {{ "
            "  background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 {hover}, stop:1 {hi}); "
            "  border: 1px solid {hi}; }} "
            "QPushButton:pressed {{ "
            "  background: {lo}; border: 1px solid {shadow}; "
            "  border-top: 2px solid {shadow}; border-bottom: 1px solid {lo}; "
            "  padding-top: 7px; padding-bottom: 5px; }}"
        )

        self.btn_add_profile = QPushButton("＋ Profile")
        self.btn_add_profile.setStyleSheet(_proc_btn_base.format(
            hi="#4a9eff", lo=COLORS['accent_blue'], shadow="#1750AC", hover="#6cb3ff"))
        self.btn_add_profile.clicked.connect(self.add_profile)
        hdr.addWidget(self.btn_add_profile)

        self.btn_add_threading = QPushButton("＋ Threading")
        self.btn_add_threading.setStyleSheet(_proc_btn_base.format(
            hi="#f5a040", lo=COLORS['accent_orange'], shadow="#b85c10", hover="#ffbe6a"))
        self.btn_add_threading.clicked.connect(self.add_threading)
        hdr.addWidget(self.btn_add_threading)

        self.btn_add_cutoff = QPushButton("＋ Grooving")
        self.btn_add_cutoff.setStyleSheet(_proc_btn_base.format(
            hi="#e05545", lo=COLORS['accent'], shadow="#8b1a10", hover="#f07060"))
        self.btn_add_cutoff.clicked.connect(self.add_cutoff)
        hdr.addWidget(self.btn_add_cutoff)

        left_layout.addLayout(hdr)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet(f"QScrollArea {{ border: none; background: {COLORS['bg_dark']}; }}")
        self.block_container = QWidget()
        self.block_layout = QVBoxLayout(self.block_container)
        self.block_layout.setSpacing(6)
        self.block_layout.setContentsMargins(2, 2, 2, 2)
        self.block_layout.addStretch()
        scroll.setWidget(self.block_container)
        left_layout.addWidget(scroll, stretch=1)

        self.blocks = []
        self.add_profile()  # Default first block

        layout.addWidget(left, stretch=1)

        # ===== RIGHT: Generate + playback + G-code preview =====
        right = QWidget()
        self._right_panel = right
        right_layout = QVBoxLayout(right)
        right_layout.setSpacing(6)
        right_layout.setContentsMargins(0, 0, 0, 0)

        self.btn_generate = QPushButton("⚙  Generate All")
        self.btn_generate.setStyleSheet(
            f"QPushButton {{ "
            f"  background: qlineargradient(x1:0,y1:0,x2:0,y2:1, "
            f"    stop:0 #4a9eff, stop:0.5 {COLORS['accent_blue']}, stop:1 #1750AC); "
            f"  color: white; font-size: 15px; min-height: 48px; font-weight: 700; "
            f"  border-radius: 12px; border: 1px solid #1750AC; "
            f"  border-bottom: 3px solid #0f3a7a; letter-spacing: 0.5px; }}"
            f"QPushButton:hover {{ "
            f"  background: qlineargradient(x1:0,y1:0,x2:0,y2:1, "
            f"    stop:0 #6cb3ff, stop:0.5 #4a9eff, stop:1 {COLORS['accent_blue']}); "
            f"  border: 1px solid #4a9eff; }}"
            f"QPushButton:pressed {{ "
            f"  background: qlineargradient(x1:0,y1:0,x2:0,y2:1, "
            f"    stop:0 #1750AC, stop:1 {COLORS['accent_blue']}); "
            f"  border-top: 3px solid #0f3a7a; border-bottom: 1px solid {COLORS['accent_blue']}; "
            f"  padding-top: 2px; }}")
        self.btn_generate.clicked.connect(self.generate)
        right_layout.addWidget(self.btn_generate)

        # Playback controls
        ctrl = QHBoxLayout()
        ctrl.setSpacing(6)

        _play_style = (
            f"QPushButton {{ "
            f"  background: qlineargradient(x1:0,y1:0,x2:0,y2:1, "
            f"    stop:0 {COLORS['accent_green_lt']}, stop:1 {COLORS['accent_green']}); "
            f"  color: {COLORS['bg_dark']}; font-weight: 700; "
            f"  border: 1px solid {COLORS['accent_green_dk']}; "
            f"  border-bottom: 2px solid {COLORS['accent_green_dk']}; "
            f"  border-radius: 8px; min-height: 38px; min-width: 70px; padding: 4px 14px; }}"
            f"QPushButton:hover {{ "
            f"  background: qlineargradient(x1:0,y1:0,x2:0,y2:1, "
            f"    stop:0 #d8e8b8, stop:1 {COLORS['accent_green_lt']}); }}"
            f"QPushButton:pressed {{ "
            f"  background: {COLORS['accent_green_dk']}; color: white; "
            f"  border-top: 2px solid {COLORS['accent_green_dk']}; border-bottom: 1px solid {COLORS['accent_green']}; }}"
        )
        _ctrl_style = (
            f"QPushButton {{ "
            f"  background: qlineargradient(x1:0,y1:0,x2:0,y2:1, "
            f"    stop:0 {COLORS['bg_elevated']}, stop:1 {COLORS['bg_light']}); "
            f"  color: {COLORS['text']}; border: 1px solid {COLORS['border']}; "
            f"  border-bottom: 2px solid {COLORS['bg_mid']}; "
            f"  border-radius: 8px; min-height: 38px; min-width: 60px; "
            f"  padding: 4px 12px; font-weight: 600; font-size: 13px; }}"
            f"QPushButton:hover {{ "
            f"  background: qlineargradient(x1:0,y1:0,x2:0,y2:1, "
            f"    stop:0 {COLORS['separator']}, stop:1 {COLORS['bg_elevated']}); "
            f"  border: 1px solid {COLORS['accent_blue_lt']}; }}"
            f"QPushButton:pressed {{ "
            f"  background: {COLORS['bg_mid']}; "
            f"  border-top: 2px solid {COLORS['bg_dark']}; border-bottom: 1px solid {COLORS['bg_light']}; }}"
        )

        self.btn_play = QPushButton("▶ Play")
        self.btn_play.setStyleSheet(_play_style)
        self.btn_play.clicked.connect(self._play_pause)
        ctrl.addWidget(self.btn_play)

        for text, slot in [("Step ▶|", "_step"), ("⟲ Reset", "_reset"), ("Show All", "_show_all")]:
            b = QPushButton(text)
            b.setStyleSheet(_ctrl_style)
            b.clicked.connect(getattr(self, slot))
            ctrl.addWidget(b)

        ctrl.addWidget(QLabel("Speed:"))
        self.speed_combo = QComboBox()
        self.speed_combo.addItems(["Slow", "Normal", "Fast", "Instant", "Real Time"])
        self.speed_combo.setCurrentIndex(1)
        self.speed_combo.currentIndexChanged.connect(self._set_speed)
        ctrl.addWidget(self.speed_combo)
        ctrl.addStretch()
        right_layout.addLayout(ctrl)

        # G-code preview
        grp = QGroupBox("G-code Preview")
        gl = QVBoxLayout(grp)
        self.gcode_preview = QTextEdit()
        self.gcode_preview.setFont(mono_font(18))
        self.gcode_preview.setPlaceholderText("Click 'Generate All' to build program...")
        self.gcode_preview.setStyleSheet(
            f"QTextEdit {{ background: {COLORS['dro_bg']}; color: {COLORS['dro_text']}; "
            f"border: 1px solid {COLORS['border']}; border-radius: 8px; padding: 8px; "
            f"font-size: 18px; }}")
        gl.addWidget(self.gcode_preview)
        right_layout.addWidget(grp, stretch=1)

        # Actions
        _act_btn_base = (
            "QPushButton {{ "
            "  background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 {hi}, stop:1 {lo}); "
            "  color: {fg}; border: 1px solid {lo}; border-bottom: 2px solid {shadow}; "
            "  border-radius: 10px; min-height: 42px; min-width: 90px; "
            "  padding: 6px 14px; font-weight: 700; font-size: 13px; }} "
            "QPushButton:hover {{ "
            "  background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 {hover}, stop:1 {hi}); "
            "  border: 1px solid {hi}; }} "
            "QPushButton:pressed {{ "
            "  background: {lo}; border-top: 2px solid {shadow}; border-bottom: 1px solid {lo}; "
            "  padding-top: 7px; padding-bottom: 5px; }}"
        )
        acts = QHBoxLayout()
        acts.setSpacing(8)
        for text, style_args, slot in [
            ("💾 Save Program", dict(
                hi=COLORS['accent_green_lt'], lo=COLORS['accent_green'],
                shadow=COLORS['accent_green_dk'], hover="#d8e8b8", fg="#111113"), self.save_program),
            ("📂 Open Program", dict(
                hi="#4a9eff", lo=COLORS['accent_blue'],
                shadow="#1750AC", hover="#6cb3ff", fg="white"), self.load_program),
            ("Save .ngc Only", dict(
                hi=COLORS['bg_elevated'], lo=COLORS['bg_light'],
                shadow=COLORS['bg_mid'], hover=COLORS['separator'], fg=COLORS['text']), self.save_file),
            ("📋 Copy", dict(
                hi=COLORS['bg_elevated'], lo=COLORS['bg_light'],
                shadow=COLORS['bg_mid'], hover=COLORS['separator'], fg=COLORS['text']), self.copy_clip),
        ]:
            b = QPushButton(text)
            b.setStyleSheet(_act_btn_base.format(**style_args))
            b.clicked.connect(slot)
            acts.addWidget(b)
        acts.addStretch()
        right_layout.addLayout(acts)

        layout.addWidget(right, stretch=1)

    def set_position_graph(self, graph):
        self._graph = graph
        if self._graph:
            self._graph.sim_line_changed.connect(self._on_sim_line_changed)

    def set_tool_tab(self, tool_tab):
        self._tool_tab = tool_tab

    def set_metric_display(self, metric: bool):
        """Propagate metric display mode to all blocks.

        Converts distance-based input fields in-place. G-code generation
        converts back to inches internally — no G20/G21 modal codes are affected.
        """
        self._metric_display = metric
        # Propagate to all blocks in the program
        for blk in self.blocks:
            if hasattr(blk, 'set_metric_display'):
                blk.set_metric_display(metric)

    def get_blade_width(self, tool_num_str):
        """Look up blade width from the tool tab for a given tool number.

        Returns the blade width as a float, or 0.125 as a fallback default.
        """
        default = 0.125
        if not self._tool_tab:
            return default
        try:
            t_num = int(tool_num_str)
        except (ValueError, TypeError):
            return default
        for row in self._tool_tab.tool_rows:
            if row.tool_num == t_num:
                data = row.get_data()
                try:
                    return float(data.get("blade_width", default))
                except (ValueError, TypeError):
                    return default
        return default

    def add_profile(self, import_data=None):
        n = len(self.blocks) + 1
        blk = ProfileBlock(n)
        blk.btn_remove.clicked.connect(lambda _, b=blk: self.remove_block(b))
        blk.btn_duplicate.clicked.connect(lambda _, b=blk: self.duplicate_block(b))
        blk.btn_move_up.clicked.connect(lambda _, b=blk: self.move_block(b, -1))
        blk.btn_move_down.clicked.connect(lambda _, b=blk: self.move_block(b, 1))
        if import_data:
            blk.import_data(import_data)
        # Apply current metric display state to new block
        if getattr(self, '_metric_display', False):
            blk.set_metric_display(True)
        self.blocks.append(blk)
        self.block_layout.insertWidget(self.block_layout.count() - 1, blk)

    def add_threading(self, import_data=None):
        n = len(self.blocks) + 1
        blk = ThreadingBlock(n)
        blk.btn_remove.clicked.connect(lambda _, b=blk: self.remove_block(b))
        blk.btn_dup.clicked.connect(lambda _, b=blk: self.duplicate_block(b))
        blk.btn_up.clicked.connect(lambda _, b=blk: self.move_block(b, -1))
        blk.btn_down.clicked.connect(lambda _, b=blk: self.move_block(b, 1))
        if import_data:
            blk.import_data(import_data)
        if getattr(self, '_metric_display', False):
            blk.set_metric_display(True)
        self.blocks.append(blk)
        self.block_layout.insertWidget(self.block_layout.count() - 1, blk)

    def add_cutoff(self, data=None):
        n = len(self.blocks) + 1
        blk = CutoffBlock(n)
        blk._conv_tab = self  # reference for blade width lookup
        blk.btn_remove.clicked.connect(lambda _, b=blk: self.remove_block(b))
        blk.btn_dup.clicked.connect(lambda _, b=blk: self.duplicate_block(b))
        blk.btn_up.clicked.connect(lambda _, b=blk: self.move_block(b, -1))
        blk.btn_down.clicked.connect(lambda _, b=blk: self.move_block(b, 1))
        if data:
            blk.import_data(data)
        if getattr(self, '_metric_display', False):
            blk.set_metric_display(True)
        self.blocks.append(blk)
        self.block_layout.insertWidget(self.block_layout.count() - 1, blk)

    def duplicate_block(self, blk):
        data = blk.export_data()
        if isinstance(blk, ThreadingBlock):
            self.add_threading(import_data=data)
        elif isinstance(blk, CutoffBlock):
            self.add_cutoff(data=data)
        else:
            self.add_profile(import_data=data)

    def move_block(self, blk, direction):
        if blk not in self.blocks:
            return
        idx = self.blocks.index(blk)
        new_idx = idx + direction
        if 0 <= new_idx < len(self.blocks):
            self.blocks[idx], self.blocks[new_idx] = self.blocks[new_idx], self.blocks[idx]
            for b in self.blocks:
                self.block_layout.removeWidget(b)
            for b in self.blocks:
                self.block_layout.insertWidget(self.block_layout.count() - 1, b)
            for i, b in enumerate(self.blocks):
                b.set_num(i + 1)

    def remove_block(self, blk):
        if blk in self.blocks:
            self.blocks.remove(blk)
            self.block_layout.removeWidget(blk)
            blk.deleteLater()
            for i, b in enumerate(self.blocks):
                b.set_num(i + 1)

    def generate(self):
        if not self.blocks:
            return


        try:
            lines = [
                f"; Profile Conversational Program — {len(self.blocks)} block(s)",
                f"; Generated by My-Lathe GUI",
                f"",
                f"G20 G18 G40 G49 G80",
                f"G90",
                f"",
            ]
            for i, blk in enumerate(self.blocks):
                block_type = "Threading" if isinstance(blk, ThreadingBlock) else "Grooving" if isinstance(blk, CutoffBlock) else "Profile"
                lines.append(f"; {'='*50}")
                lines.append(f"; BLOCK {i+1}: {block_type}")
                lines.append(f"; {'='*50}")
                gc = blk.generate_gcode()
                for gl in gc.splitlines():
                    s = gl.strip()
                    if s.startswith("G20") or s == "G90" or s in ("M2", "M2  (Program end)"):
                        continue
                    lines.append(gl)
                lines.append("")
                if i < len(self.blocks) - 1:
                    lines.append(f"M0  (PAUSE — Block {i+1} complete)")
                    lines.append("")

            lines.append("M2  (Program end)")
            lines.append("")

            full = "\n".join(lines)
            full = add_line_numbers(full)
            self.gcode_preview.setText(full)
            if self._graph:
                self._graph.sim_load(full)

        except Exception as e:
            self.gcode_preview.setText(f"; ERROR generating G-code:\n; {e}\n")

    # Sim controls
    def _play_pause(self):
        if not self._graph: return
        if self._graph._sim_playing:
            self._graph.sim_pause(); self.btn_play.setText("▶ Play")
        else:
            self._graph.sim_play(); self.btn_play.setText("⏸ Pause")

    def _step(self):
        if self._graph: self._graph.sim_step_forward()

    def _reset(self):
        if self._graph: self._graph.sim_reset(); self.btn_play.setText("▶ Play")

    def _show_all(self):
        if self._graph: self._graph.sim_show_all()

    def _set_speed(self, idx):
        if self._graph:
            # idx: 0=Slow, 1=Normal, 2=Fast, 3=Instant, 4=Real Time
            if idx == 4:
                self._graph.sim_set_speed(-1)  # real-time mode
            else:
                self._graph.sim_set_speed({0:160, 1:60, 2:20, 3:1}.get(idx, 60))

    def _on_sim_line_changed(self, line_idx):
        """Highlight the G-code line corresponding to the current sim step."""
        if line_idx < 0:
            # Clear highlight
            cursor = self.gcode_preview.textCursor()
            cursor.select(QTextCursor.Document)
            fmt = QTextCharFormat()
            fmt.setBackground(QColor("transparent"))
            cursor.setCharFormat(fmt)
            cursor.clearSelection()
            self.gcode_preview.setTextCursor(cursor)
            return

        doc = self.gcode_preview.document()
        if line_idx >= doc.blockCount():
            return

        # Clear previous highlight
        cursor = self.gcode_preview.textCursor()
        cursor.select(QTextCursor.Document)
        fmt = QTextCharFormat()
        fmt.setBackground(QColor("transparent"))
        cursor.setCharFormat(fmt)
        cursor.clearSelection()

        # Highlight the target line
        block = doc.findBlockByNumber(line_idx)
        cursor = QTextCursor(block)
        cursor.movePosition(QTextCursor.EndOfBlock, QTextCursor.KeepAnchor)
        highlight_fmt = QTextCharFormat()
        highlight_color = QColor(COLORS['accent_blue'])
        highlight_color.setAlpha(80)
        highlight_fmt.setBackground(highlight_color)
        cursor.setCharFormat(highlight_fmt)

        # Scroll to keep the highlighted line visible
        scroll_cursor = QTextCursor(block)
        self.gcode_preview.setTextCursor(scroll_cursor)
        self.gcode_preview.ensureCursorVisible()

    def export_program(self):
        """Export the entire program (all blocks) as a serializable dict."""
        block_list = []
        for blk in self.blocks:
            if isinstance(blk, ThreadingBlock):
                block_type = "threading"
            elif isinstance(blk, CutoffBlock):
                block_type = "cutoff"
            else:
                block_type = "profile"
            block_list.append({
                "type": block_type,
                "data": blk.export_data(),
            })
        return {
            "version": 1,
            "created": datetime.now().isoformat(),
            "generator": "My-Lathe ProfileConvTab",
            "block_count": len(block_list),
            "blocks": block_list,
        }

    def import_program(self, program):
        """Clear current blocks and rebuild from a program dict."""
        # Remove all existing blocks
        for blk in list(self.blocks):
            self.remove_block(blk)

        # Rebuild from saved data
        for entry in program.get("blocks", []):
            btype = entry.get("type", "profile")
            data = entry.get("data", {})
            # Strip " (copy)" suffix that import_data adds for duplicates
            if "title" in data and data["title"].endswith(" (copy)"):
                data["title"] = data["title"][:-7]
            if "title_edit" in data and isinstance(data.get("title_edit"), str) and data["title_edit"].endswith(" (copy)"):
                data["title_edit"] = data["title_edit"][:-7]
            if btype == "threading":
                self.add_threading(import_data=data)
            elif btype == "cutoff":
                self.add_cutoff(data=data)
            else:
                self.add_profile(import_data=data)

        # Fix block numbering and strip " (copy)" from titles
        for i, blk in enumerate(self.blocks):
            blk.set_num(i + 1)
            # Clean up the " (copy)" that import_data appends
            if isinstance(blk, ProfileBlock):
                t = blk.title.text()
                if t.endswith(" (copy)"):
                    blk.title.setText(t[:-7])
            elif isinstance(blk, ThreadingBlock):
                t = blk.title_edit.text()
                if t.endswith(" (copy)"):
                    blk.title_edit.setText(t[:-7])
            elif isinstance(blk, CutoffBlock):
                t = blk.title_edit.text()
                if t.endswith(" (copy)"):
                    blk.title_edit.setText(t[:-7])

    def save_program(self):
        """Save both .conv.json and .ngc via a standard Save dialog."""
        # Generate G-code first so it's current
        self.generate()
        gc = self.gcode_preview.toPlainText()
        if not gc.strip():
            QMessageBox.warning(self, "Nothing to Save",
                                "Generate a program first before saving.")
            return

        # Standard save dialog — user picks location and filename
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Conversational Program", "",
            "Conv Programs (*.conv.json)")
        if not path:
            return

        # Ensure .conv.json extension
        if not path.endswith(".conv.json"):
            path += ".conv.json"

        # Derive names from the chosen path
        dir_path = os.path.dirname(path)
        base = os.path.basename(path)
        # Strip .conv.json to get the program name
        if base.endswith(".conv.json"):
            safe_name = base[:-len(".conv.json")]
        else:
            safe_name = os.path.splitext(base)[0]

        if not safe_name:
            QMessageBox.warning(self, "Invalid Name",
                                "Please enter a valid program name.")
            return

        # Write .conv.json
        program_data = self.export_program()
        program_data["name"] = safe_name
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(program_data, f, indent=2)
        except Exception as e:
            QMessageBox.warning(self, "Save Error",
                                f"Failed to save .conv.json:\n{e}")
            return

        # Write .ngc alongside it
        ngc_path = os.path.join(dir_path, safe_name + ".ngc")
        try:
            with open(ngc_path, "w", encoding="utf-8") as f:
                f.write(gc)
        except Exception as e:
            QMessageBox.warning(self, "Save Error",
                                f"Failed to save .ngc:\n{e}")
            return

        QMessageBox.information(
            self, "Program Saved",
            f"Saved to:\n{dir_path}\n\n"
            f"• {safe_name}.conv.json (editable program)\n"
            f"• {safe_name}.ngc (G-code)")

    def load_program(self):
        """Open a .conv.json file and restore all blocks."""
        path, _ = QFileDialog.getOpenFileName(
            self, "Open Conversational Program", "",
            "Conv Programs (*.conv.json);;All Files (*)")
        if not path:
            return

        try:
            with open(path, "r", encoding="utf-8") as f:
                program = json.load(f)
        except json.JSONDecodeError as e:
            QMessageBox.warning(self, "Load Error",
                                f"Invalid JSON:\n{e}")
            return
        except Exception as e:
            QMessageBox.warning(self, "Load Error", str(e))
            return

        # Basic validation
        if "blocks" not in program:
            QMessageBox.warning(self, "Load Error",
                                "File does not contain a valid conversational program.")
            return

        self.import_program(program)

        # Auto-generate G-code from loaded blocks
        self.generate()

    def save_file(self):
        gc = self.gcode_preview.toPlainText()
        if not gc.strip(): return
        f, _ = QFileDialog.getSaveFileName(self, "Save", "", "G-code (*.ngc *.nc);;All (*)")
        if f:
            try:
                with open(f, "w", encoding="utf-8") as fh: fh.write(gc)
            except Exception as e:
                QMessageBox.warning(self, "Error", str(e))

    def copy_clip(self):
        from PyQt5.QtWidgets import QApplication
        gc = self.gcode_preview.toPlainText()
        if gc.strip(): QApplication.clipboard().setText(gc)
