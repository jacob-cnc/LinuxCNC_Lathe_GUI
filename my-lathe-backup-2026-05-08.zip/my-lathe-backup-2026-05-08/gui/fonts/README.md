# Fonts

Place font files (.ttf or .otf) in this directory. The GUI loads them
automatically at startup.

## Recommended fonts (free, open-source)

**Inter** — UI font (matches Apple SF Pro metrics)
  Download: https://github.com/rsms/inter/releases
  Files needed: Inter-Regular.ttf, Inter-SemiBold.ttf, Inter-Bold.ttf

**JetBrains Mono** — Monospace font for DRO digits and code
  Download: https://github.com/JetBrains/JetBrainsMono/releases
  Files needed: JetBrainsMono-Regular.ttf, JetBrainsMono-Bold.ttf

## Fallbacks

If no fonts are placed here, the GUI falls back to:
  - Segoe UI (Windows) or system sans-serif for UI text
  - Consolas (Windows) or system monospace for numeric readouts
