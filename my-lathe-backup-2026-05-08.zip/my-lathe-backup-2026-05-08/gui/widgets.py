"""
Shared Widgets — DRO, StatusIndicator, SpindlePanel, OverridePanel
====================================================================
Reusable UI components used by the main window and tabs.
"""

from PyQt5.QtWidgets import (
    QFrame, QHBoxLayout, QVBoxLayout, QGridLayout,
    QLabel, QGroupBox
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

from theme import COLORS, FONT_SIZES, TOUCH_SIZES, mono_font, ui_font


# ---------------------------------------------------------------------------
# DRO (Digital Readout) Widget
# ---------------------------------------------------------------------------
class DROWidget(QFrame):
    """Compact DRO showing work coordinates (large) and machine coordinates (small)."""

    def __init__(self, axis_name, color=COLORS["dro_text"], parent=None):
        super().__init__(parent)
        self.axis_name = axis_name
        self.color = color
        self.value = 0.0
        self.machine_value = 0.0
        self.diameter_mode = False

        layout = QHBoxLayout(self)
        layout.setContentsMargins(6, 4, 6, 4)
        layout.setSpacing(6)

        self.label = QLabel(axis_name)
        self.label.setFont(mono_font(FONT_SIZES['dro_axis_label'], QFont.Bold))
        self.label.setStyleSheet(f"color: {COLORS['accent_blue_lt']}; background: transparent;")
        self.label.setFixedWidth(30)
        self.label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.label)

        self.display = QLabel("+0.0000")
        self.display.setFont(mono_font(FONT_SIZES['dro_primary'], QFont.Bold))
        self.display.setStyleSheet(
            f"color: {self.color}; "
            f"background-color: {COLORS['dro_bg']}; "
            f"border: 1px solid {COLORS['bg_mid']}; "
            f"border-radius: 8px; padding: 2px 10px;"
        )
        self.display.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.display.setMinimumWidth(200)
        layout.addWidget(self.display)

        mach_col = QVBoxLayout()
        mach_col.setSpacing(0)
        mach_lbl = QLabel("G53")
        mach_lbl.setFont(mono_font(9))
        mach_lbl.setStyleSheet(f"color: {COLORS['text_dim']}; background: transparent;")
        mach_lbl.setAlignment(Qt.AlignCenter)
        mach_col.addWidget(mach_lbl)

        self.mach_display = QLabel("+0.0000")
        self.mach_display.setFont(mono_font(FONT_SIZES['dro_machine']))
        self.mach_display.setStyleSheet(
            f"color: {COLORS['text_secondary']}; "
            f"background-color: {COLORS['dro_bg']}; "
            f"border: 1px solid {COLORS['bg_mid']}; "
            f"border-radius: 6px; padding: 1px 6px;"
        )
        self.mach_display.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        mach_col.addWidget(self.mach_display)
        layout.addLayout(mach_col)

        self.setStyleSheet(
            f"background-color: {COLORS['bg_mid']}; border-radius: 10px;"
        )

    def update_value(self, value):
        self.value = value
        display_val = value * 2.0 if self.diameter_mode else value
        sign = "+" if display_val >= 0 else ""
        self.display.setText(f"{sign}{display_val:.4f}")

    def update_machine_value(self, value):
        self.machine_value = value
        display_val = value * 2.0 if self.diameter_mode else value
        sign = "+" if display_val >= 0 else ""
        self.mach_display.setText(f"{sign}{display_val:.4f}")

    def set_diameter_mode(self, enabled):
        self.diameter_mode = enabled
        self.update_value(self.value)
        self.update_machine_value(self.machine_value)


# ---------------------------------------------------------------------------
# Status indicator widget
# ---------------------------------------------------------------------------
class StatusIndicator(QFrame):
    """Small colored indicator with label — iOS-style pill."""

    def __init__(self, label_text, parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(6, 3, 8, 3)
        layout.setSpacing(4)

        self.indicator = QLabel("●")
        self.indicator.setFont(QFont("Arial", TOUCH_SIZES['indicator_dot_size']))
        self.indicator.setFixedWidth(TOUCH_SIZES['indicator_dot_size'] + 2)
        self.indicator.setStyleSheet("background: transparent; border: none;")
        layout.addWidget(self.indicator)

        self.label = QLabel(label_text)
        self.label.setFont(ui_font(FONT_SIZES['state_bar_label'], QFont.DemiBold))
        self.label.setStyleSheet(f"color: {COLORS['text_secondary']}; background: transparent; border: none;")
        layout.addWidget(self.label)

        self.setStyleSheet(
            f"StatusIndicator {{ "
            f"background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, "
            f"stop:0 {COLORS['bg_elevated']}, stop:1 {COLORS['bg_light']}); "
            f"border-radius: 10px; border: 1px solid {COLORS['border']};"
            f"}} "
            f"StatusIndicator QLabel {{ border: none; }}"
        )
        self.set_state("off")

    def set_state(self, state):
        colors = {
            "on":    COLORS["accent_green"],
            "off":   COLORS["text_dim"],
            "warn":  COLORS["accent_yellow"],
            "error": COLORS["accent"],
        }
        self.indicator.setStyleSheet(
            f"color: {colors.get(state, COLORS['text_dim'])}; background: transparent; border: none;"
        )


# ---------------------------------------------------------------------------
# Spindle Info Panel (sidebar widget)
# ---------------------------------------------------------------------------
class SpindlePanel(QGroupBox):
    """Spindle RPM display — read-only since spindle is manually controlled."""

    def __init__(self, parent=None):
        super().__init__("Spindle RPM", parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 14, 8, 6)

        self.rpm_label = QLabel("0")
        self.rpm_label.setFont(mono_font(FONT_SIZES['sidebar_rpm'], QFont.Bold))
        self.rpm_label.setAlignment(Qt.AlignCenter)
        self.rpm_label.setStyleSheet(
            f"color: {COLORS['accent_yellow']}; "
            f"background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, "
            f"stop:0 #0d1418, stop:0.1 {COLORS['dro_bg']}, stop:1 #0d1418); "
            f"border: 2px solid {COLORS['bg_mid']}; "
            f"border-top: 3px solid {COLORS['bg_dark']}; "
            f"border-radius: 10px; padding: 8px;"
        )
        layout.addWidget(self.rpm_label)

    def update_rpm(self, rpm, direction=0):
        self.rpm_label.setText(f"{abs(int(rpm))}")

# ---------------------------------------------------------------------------
# Feed & Override Panel (sidebar widget)
# ---------------------------------------------------------------------------
class OverridePanel(QGroupBox):
    """Feed rate and spindle override display."""

    def __init__(self, parent=None):
        super().__init__("Overrides", parent)
        layout = QGridLayout(self)

        layout.addWidget(QLabel("Feed:"), 0, 0)
        self.feed_label = QLabel("100%")
        self.feed_label.setFont(mono_font(17, QFont.Bold))
        self.feed_label.setStyleSheet(f"color: {COLORS['accent_green']};")
        self.feed_label.setAlignment(Qt.AlignRight)
        layout.addWidget(self.feed_label, 0, 1)

        layout.addWidget(QLabel("Rapid:"), 1, 0)
        self.rapid_label = QLabel("100%")
        self.rapid_label.setFont(mono_font(17, QFont.Bold))
        self.rapid_label.setStyleSheet(f"color: {COLORS['accent_blue']};")
        self.rapid_label.setAlignment(Qt.AlignRight)
        layout.addWidget(self.rapid_label, 1, 1)

    def update_overrides(self, feed_pct, rapid_pct):
        self.feed_label.setText(f"{int(feed_pct)}%")
        self.rapid_label.setText(f"{int(rapid_pct)}%")
