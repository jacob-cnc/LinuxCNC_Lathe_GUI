"""
Position Graph — Real-time 2D X/Z coordinate plot with G-code simulation.
==========================================================================
Supports mouse wheel zoom, click-drag pan, double-click to reset view.
Displays active work coordinate system and simulates G-code toolpaths
for the conversational programming tabs.
"""

import math
import re

from PyQt5.QtWidgets import QFrame
from PyQt5.QtCore import Qt, QTimer, pyqtSignal
from PyQt5.QtGui import QFont, QColor

from theme import COLORS, FONT_SIZES, mono_font


class PositionGraph(QFrame):
    """2D coordinate graph showing real-time tool position in X/Z plane."""

    # Emitted during simulation with the 0-based G-code line index
    sim_line_changed = pyqtSignal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(200)
        self.setStyleSheet(
            f"background-color: {COLORS['dro_bg']}; "
            f"border: 2px solid #2a3a3a; border-radius: 8px;"
        )
        self.setMouseTracking(True)

        self.current_x = 0.0
        self.current_z = 0.0
        self.current_tool = 0
        self.current_tool_desc = ""
        self.trail = []
        self.max_trail = 500
        self.work_offset = "G54"

        # Machine coordinates (G53) for secondary DRO display
        self.machine_x = 0.0
        self.machine_z = 0.0

        self._auto_scale = True
        self._view_cx = 0.0
        self._view_cz = 0.0
        self._view_span = 8.0

        self._dragging = False
        self._drag_start = None
        self._drag_view_cx = 0.0
        self._drag_view_cz = 0.0

        self._sim_mode = False
        self._sim_moves = []
        self._sim_line_map = []   # maps sim_move index → G-code line number (0-based)
        self._sim_feed_rates = []  # feed rate (in/min) per move for real-time mode
        self._sim_gcode_lines = []  # raw G-code lines for N-number display
        self._sim_step = 0
        self._sim_playing = False
        self._sim_speed = 30
        self._sim_realtime = False  # True = use feed rates for timing
        self._sim_rapid_rate = 200.0  # rapid traverse rate in/min (machine max)
        self._sim_timer = QTimer()
        self._sim_timer.timeout.connect(self._sim_advance)
        self._sim_stock = None

        # Go-To fence state
        self._fence_x_enabled = False
        self._fence_z_enabled = False
        self._fence_x_value = 0.0  # radius
        self._fence_z_value = 0.0

        # Collision zone highlights (from interference check)
        self._collision_zones = []

        # Display-only metric conversion flag
        self._metric_display = False

        # Per-tool Z-axis soft limit lines (machine coordinates, inches)
        self._tool_limit_z_minus = None
        self._tool_limit_z_plus = None

    def update_position(self, x, z):
        self.current_x = x
        self.current_z = z
        self.trail.append((x, z))
        if len(self.trail) > self.max_trail:
            self.trail.pop(0)
        if self._auto_scale:
            self._fit_view()
        self.update()

    def set_work_offset(self, offset_name):
        self.work_offset = offset_name
        self.update()

    def set_current_tool(self, tool_num, description=""):
        """Update the current tool number displayed on the graph."""
        self.current_tool = tool_num
        self.current_tool_desc = description
        self.update()

    def set_machine_position(self, x, z):
        """Update the machine coordinate (G53) values for secondary DRO display."""
        self.machine_x = x
        self.machine_z = z
        self.update()

    def set_metric_display(self, metric: bool):
        """Toggle display-only metric conversion (does not affect internal values)."""
        self._metric_display = metric
        self.update()

    def clear_trail(self):
        self.trail.clear()
        self.update()

    def set_fence(self, axis, enabled, value):
        """Update fence display state.

        Args:
            axis: 'x' or 'z'
            enabled: bool
            value: float (radius for X, position for Z)
        """
        if axis == 'x':
            self._fence_x_enabled = enabled
            self._fence_x_value = value
        elif axis == 'z':
            self._fence_z_enabled = enabled
            self._fence_z_value = value
        self.update()

    def set_collision_zones(self, collisions):
        """Store collision points for highlighting on the graph.

        Args:
            collisions: list of CollisionPoint objects with x_position and z_position
        """
        self._collision_zones = list(collisions) if collisions else []
        self.update()

    def clear_collision_zones(self):
        """Remove all collision zone highlights from the graph."""
        self._collision_zones = []
        self.update()

    def set_tool_limits(self, z_minus, z_plus):
        """Set the active tool's Z limit lines for display.

        Pass None for either to hide that limit line.
        Values are in machine coordinates (inches).
        """
        self._tool_limit_z_minus = z_minus
        self._tool_limit_z_plus = z_plus
        self.update()

    def clear_tool_limits(self):
        """Hide all tool limit lines."""
        self._tool_limit_z_minus = None
        self._tool_limit_z_plus = None
        self.update()

    def _fit_view(self):
        all_points = self.trail + [(self.current_x, self.current_z)]
        if not all_points:
            return
        xs = [p[0] for p in all_points]
        zs = [p[1] for p in all_points]
        x_min, x_max = min(xs), max(xs)
        z_min, z_max = min(zs), max(zs)
        self._view_cx = (x_min + x_max) / 2
        self._view_cz = (z_min + z_max) / 2
        self._view_span = max(x_max - x_min, z_max - z_min, 2.0) * 1.4

    # --- Mouse events ---
    def wheelEvent(self, event):
        self._auto_scale = False
        delta = event.angleDelta().y()
        factor = 0.85 if delta > 0 else 1.18
        self._view_span = max(0.005, min(100.0, self._view_span * factor))
        self.update()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._auto_scale = False
            self._dragging = True
            self._drag_start = event.pos()
            self._drag_view_cx = self._view_cx
            self._drag_view_cz = self._view_cz
            self.setCursor(Qt.ClosedHandCursor)

    def mouseMoveEvent(self, event):
        if self._dragging and self._drag_start:
            dx = event.pos().x() - self._drag_start.x()
            dy = event.pos().y() - self._drag_start.y()
            w = self.width()
            h = self.height()
            scale_z = 2.0 * self._view_span / max(w, 1)
            scale_x = 2.0 * self._view_span / max(h, 1)
            self._view_cz = self._drag_view_cz - dx * scale_z
            self._view_cx = self._drag_view_cx - dy * scale_x
            self.update()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._dragging = False
            self.setCursor(Qt.ArrowCursor)

    def mouseDoubleClickEvent(self, event):
        self._auto_scale = True
        self._fit_view()
        self.update()

    # --- Simulation methods ---
    def sim_load(self, gcode_text):
        self._sim_moves = []
        self._sim_line_map = []
        self._sim_feed_rates = []  # feed rate (in/min) for each move
        self._sim_gcode_lines = gcode_text.splitlines()
        self._sim_step = 0
        self._sim_playing = False
        self._sim_timer.stop()
        self._sim_mode = True
        self._collision_zones = []
        self.trail.clear()

        x, z = 0.0, 0.0
        absolute = True
        move_type = "rapid"
        current_feed = 10.0  # default feed rate in/min

        lines = gcode_text.splitlines()
        for line_idx, raw_line in enumerate(lines):
            line = raw_line.split(";")[0].split("(")[0].strip().upper()
            if not line:
                continue
            if "G90" in line: absolute = True
            if "G91" in line: absolute = False

            # Parse F word for feed rate
            f_m = re.search(r'F([+\-]?[\d.]+)', line)
            if f_m:
                current_feed = float(f_m.group(1))

            if line.strip() in ("M0", "M00") or re.match(r'^M0\b', line):
                self._sim_moves.append(("pause", x, z))
                self._sim_line_map.append(line_idx)
                self._sim_feed_rates.append(current_feed)
                continue
            if re.match(r'^M0*2\b', line) or re.match(r'^M30\b', line):
                continue

            if re.search(r'G76', line):
                p_m = re.search(r'P([+\-]?[\d.]+)', line)
                z_m = re.search(r'Z([+\-]?[\d.]+)', line)
                k_m = re.search(r'K([+\-]?[\d.]+)', line)
                j_m = re.search(r'J([+\-]?[\d.]+)', line)
                if p_m and z_m and k_m:
                    z_end = float(z_m.group(1))
                    full_depth = float(k_m.group(1))
                    first_cut = float(j_m.group(1)) if j_m else full_depth / 5
                    start_x, start_z = x, z
                    cut_depth, pn = 0.0, 0
                    pd = first_cut
                    while cut_depth < full_depth:
                        cut_depth = min(cut_depth + pd, full_depth)
                        cx = start_x - cut_depth
                        self._sim_moves.append(("rapid", cx, start_z))
                        self._sim_line_map.append(line_idx)
                        self._sim_feed_rates.append(current_feed)
                        self._sim_moves.append(("feed", cx, z_end))
                        self._sim_line_map.append(line_idx)
                        self._sim_feed_rates.append(current_feed)
                        self._sim_moves.append(("rapid", start_x, z_end))
                        self._sim_line_map.append(line_idx)
                        self._sim_feed_rates.append(current_feed)
                        self._sim_moves.append(("rapid", start_x, start_z))
                        self._sim_line_map.append(line_idx)
                        self._sim_feed_rates.append(current_feed)
                        pn += 1
                        if pn > 1: pd = max(first_cut / math.sqrt(pn), 0.002)
                    x, z = start_x, start_z
                continue

            if re.search(r'\bG0*0\b', line): move_type = "rapid"
            elif re.search(r'\bG0*1\b', line): move_type = "feed"
            elif re.search(r'\bG0*2\b', line): move_type = "arc_cw"
            elif re.search(r'\bG0*3\b', line): move_type = "arc_ccw"

            new_x, new_z = x, z
            x_m = re.search(r'X([+\-]?[\d.]+)', line)
            z_m = re.search(r'Z([+\-]?[\d.]+)', line)
            r_m = re.search(r'R([+\-]?[\d.]+)', line)
            if x_m:
                val = float(x_m.group(1))
                new_x = val / 2.0 if absolute else x + val / 2.0
            if z_m:
                val = float(z_m.group(1))
                new_z = val if absolute else z + val
            if new_x != x or new_z != z:
                if move_type in ("arc_cw", "arc_ccw") and r_m:
                    arc_r = float(r_m.group(1))
                    sx, sz, ex, ez = x, z, new_x, new_z
                    dx, dz = ex - sx, ez - sz
                    chord = math.sqrt(dx*dx + dz*dz)
                    if chord > 0 and abs(arc_r) >= chord / 2 - 0.001:
                        ar = max(abs(arc_r), chord / 2 + 0.0001)
                        h = math.sqrt(max(0, ar*ar - (chord/2)**2))
                        mx, mz = (sx+ex)/2, (sz+ez)/2
                        px, pz = -dz/chord, dx/chord
                        if arc_r > 0:
                            if move_type == "arc_cw":
                                ccx, ccz = mx - h*px, mz - h*pz
                            else:
                                ccx, ccz = mx + h*px, mz + h*pz
                        else:
                            if move_type == "arc_cw":
                                ccx, ccz = mx + h*px, mz + h*pz
                            else:
                                ccx, ccz = mx - h*px, mz - h*pz
                        sa = math.atan2(sx - ccx, sz - ccz)
                        ea = math.atan2(ex - ccx, ez - ccz)
                        if move_type == "arc_cw":
                            if ea >= sa: ea -= 2*math.pi
                            if abs(ea - sa) > math.pi and arc_r > 0:
                                ccx, ccz = 2*mx - ccx, 2*mz - ccz
                                sa = math.atan2(sx - ccx, sz - ccz)
                                ea = math.atan2(ex - ccx, ez - ccz)
                                if ea >= sa: ea -= 2*math.pi
                        else:
                            if ea <= sa: ea += 2*math.pi
                            if abs(ea - sa) > math.pi and arc_r > 0:
                                ccx, ccz = 2*mx - ccx, 2*mz - ccz
                                sa = math.atan2(sx - ccx, sz - ccz)
                                ea = math.atan2(ex - ccx, ez - ccz)
                                if ea <= sa: ea += 2*math.pi
                        steps = max(8, int(abs(ea - sa) / 0.15))
                        for i in range(1, steps + 1):
                            t = sa + (ea - sa) * i / steps
                            ax = ccx + ar * math.sin(t)
                            az = ccz + ar * math.cos(t)
                            self._sim_moves.append(("feed", ax, az))
                            self._sim_line_map.append(line_idx)
                            self._sim_feed_rates.append(current_feed)
                    else:
                        self._sim_moves.append(("feed", new_x, new_z))
                        self._sim_line_map.append(line_idx)
                        self._sim_feed_rates.append(current_feed)
                else:
                    mt = "rapid" if move_type == "rapid" else "feed"
                    self._sim_moves.append((mt, new_x, new_z))
                    self._sim_line_map.append(line_idx)
                    self._sim_feed_rates.append(current_feed)
                x, z = new_x, new_z

        self._auto_scale = True
        self._parse_stock_from_comments(gcode_text)

        for mt, mx, mz in self._sim_moves:
            self.trail.append((mx, mz))
            if self._sim_stock:
                r = self._sim_stock[0] / 2.0
                self.trail.append((r, self._sim_stock[1]))
                self.trail.append((0, self._sim_stock[2]))
        self._fit_view()
        self.trail.clear()
        self.update()

    def _parse_stock_from_comments(self, gcode_text):
        self._sim_stock = None
        max_od = 0
        for raw_line in gcode_text.splitlines():
            if "Stock:" in raw_line and "dia" in raw_line.lower():
                m = re.search(r'Stock:\s*([\d.]+)', raw_line)
                if m:
                    od = float(m.group(1))
                    if od > max_od:
                        max_od = od
                        for l2 in gcode_text.splitlines():
                            zm = re.search(r'Z range:\s*([+\-]?[\d.]+)\s*to\s*([+\-]?[\d.]+)', l2)
                            if zm:
                                z_s = float(zm.group(1))
                                z_e = float(zm.group(2))
                                if self._sim_stock:
                                    z_s = max(z_s, self._sim_stock[1])
                                    z_e = min(z_e, self._sim_stock[2])
                                self._sim_stock = (od, z_s, z_e)
                                break
                        if not self._sim_stock:
                            self._sim_stock = (od, 0.1, -3.0)
            elif "Bore:" in raw_line:
                m = re.search(r'Bore:\s*([\d.]+).*?→\s*([\d.]+)', raw_line)
                if m:
                    od = float(m.group(2))
                    if od * 1.5 > max_od:
                        max_od = od * 1.5
                        for l2 in gcode_text.splitlines():
                            zm = re.search(r'Z range:\s*([+\-]?[\d.]+)\s*to\s*([+\-]?[\d.]+)', l2)
                            if zm:
                                self._sim_stock = (od * 1.5, float(zm.group(1)), float(zm.group(2)))
                                break
            elif "OD:" in raw_line and "Cutoff" in gcode_text[:500]:
                m = re.search(r'OD:\s*([\d.]+)', raw_line)
                if m:
                    od = float(m.group(1))
                    if od > max_od:
                        max_od = od
                        zm = re.search(r'Z position:\s*([+\-]?[\d.]+)', gcode_text)
                        z_pos = float(zm.group(1)) if zm else -2.0
                        self._sim_stock = (od, 0.1, z_pos - 0.5)
            elif "Major:" in raw_line:
                m = re.search(r'Major:\s*([\d.]+)', raw_line)
                if m:
                    od = float(m.group(1))
                    if od > max_od:
                        max_od = od
                        for l2 in gcode_text.splitlines():
                            if "Length:" in l2:
                                lm = re.search(r'Length:\s*([\d.]+)', l2)
                                if lm:
                                    self._sim_stock = (od, 0.15, -(float(lm.group(1)) + 0.2))
                                    break

    def sim_clear(self):
        self._sim_mode = False
        self._sim_moves = []
        self._sim_line_map = []
        self._sim_feed_rates = []
        self._sim_gcode_lines = []
        self._sim_step = 0
        self._sim_playing = False
        self._sim_timer.stop()
        self._sim_stock = None
        self._collision_zones = []
        self.trail.clear()
        self.update()

    def sim_play(self):
        while (self._sim_step < len(self._sim_moves) and
               self._sim_moves[self._sim_step][0] == "pause"):
            self._sim_step += 1
        self._sim_playing = True
        if self._sim_realtime:
            self._sim_timer.start(self._calc_realtime_interval())
        else:
            self._sim_timer.start(self._sim_speed)
        self._emit_line()

    def sim_pause(self):
        self._sim_playing = False
        self._sim_timer.stop()

    def sim_reset(self):
        self._sim_step = 0
        self._sim_playing = False
        self._sim_timer.stop()
        self.sim_line_changed.emit(-1)
        self.update()

    def sim_step_forward(self):
        if self._sim_step < len(self._sim_moves):
            if self._sim_moves[self._sim_step][0] == "pause":
                self._sim_step += 1
            if self._sim_step < len(self._sim_moves):
                self._sim_step += 1
            self._emit_line()
            self.update()

    def sim_show_all(self):
        self._sim_step = len(self._sim_moves)
        self._sim_playing = False
        self._sim_timer.stop()
        self._emit_line()
        self.update()

    def sim_set_speed(self, ms):
        """Set simulation playback speed.

        Args:
            ms: Timer interval in milliseconds, or -1 for real-time mode
                (uses actual feed rates and distances to calculate timing).
        """
        if ms == -1:
            self._sim_realtime = True
            self._sim_speed = 30  # base interval, adjusted per-move
        else:
            self._sim_realtime = False
            self._sim_speed = max(5, ms)
        if self._sim_playing:
            if self._sim_realtime:
                self._sim_timer.setInterval(self._calc_realtime_interval())
            else:
                self._sim_timer.setInterval(self._sim_speed)

    def _calc_realtime_interval(self):
        """Calculate the timer interval for the current move in real-time mode.

        Uses the distance between the previous position and the current move's
        target, divided by the feed rate (or rapid rate for G0 moves), to get
        the actual time the move would take on the machine. Returns milliseconds.
        """
        if self._sim_step >= len(self._sim_moves):
            return 30

        move = self._sim_moves[self._sim_step]
        mt, target_x, target_z = move[0], move[1], move[2]

        if mt == "pause":
            return 500  # pause moves get a half-second delay

        # Get previous position
        if self._sim_step > 0:
            prev = self._sim_moves[self._sim_step - 1]
            prev_x, prev_z = prev[1], prev[2]
        else:
            prev_x, prev_z = 0.0, 0.0

        # Calculate distance (X is radius internally)
        dx = target_x - prev_x
        dz = target_z - prev_z
        dist = math.sqrt(dx * dx + dz * dz)

        if dist < 1e-6:
            return 10  # negligible move

        # Get rate: rapid uses machine max, feed uses programmed rate
        if mt == "rapid":
            rate = self._sim_rapid_rate  # in/min
        else:
            feed = self._sim_feed_rates[self._sim_step] if self._sim_step < len(self._sim_feed_rates) else 10.0
            rate = max(feed, 0.1)  # in/min

        # time = distance / rate, convert min to ms
        time_min = dist / rate
        time_ms = time_min * 60000.0

        # Clamp to reasonable range (10ms to 2000ms per step)
        return max(10, min(2000, int(time_ms)))

    def _emit_line(self):
        """Emit the G-code line number corresponding to the current sim step."""
        if self._sim_step > 0 and self._sim_line_map:
            idx = min(self._sim_step - 1, len(self._sim_line_map) - 1)
            self.sim_line_changed.emit(self._sim_line_map[idx])
        else:
            self.sim_line_changed.emit(-1)

    def _sim_advance(self):
        if self._sim_step < len(self._sim_moves):
            mt = self._sim_moves[self._sim_step][0]
            self._sim_step += 1
            if mt == "pause":
                self.sim_pause()
            self._emit_line()
            self.update()
            # In real-time mode, adjust interval for the next move
            if self._sim_realtime and self._sim_playing:
                self._sim_timer.setInterval(self._calc_realtime_interval())
        else:
            self.sim_pause()

    def paintEvent(self, event):
        from PyQt5.QtGui import QPainter, QPen, QBrush, QPolygonF, QPainterPath
        from PyQt5.QtCore import QPointF, QRectF

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # Clip to rounded rect so painted content respects border-radius
        path = QPainterPath()
        path.addRoundedRect(QRectF(self.rect()), 8, 8)
        painter.setClipPath(path)

        w = self.width()
        h = self.height()
        margin_left = 52
        margin = 36
        plot_w = w - margin_left - margin
        plot_h = h - 2 * margin

        if plot_w <= 0 or plot_h <= 0:
            painter.end()
            return

        aspect = plot_w / max(plot_h, 1)
        half_x = self._view_span / 2
        half_z = half_x * aspect
        vx_min = self._view_cx - half_x
        vx_max = self._view_cx + half_x
        vz_min = self._view_cz - half_z
        vz_max = self._view_cz + half_z
        vx_range = vx_max - vx_min
        vz_range = vz_max - vz_min

        def to_screen(x, z):
            sx = margin_left + (z - vz_min) / vz_range * plot_w
            sy = margin + (x - vx_min) / vx_range * plot_h
            return QPointF(sx, sy)

        painter.fillRect(self.rect(), QColor(COLORS["dro_bg"]))

        # Grid
        grid_pen = QPen(QColor("#2a4a6a"), 1, Qt.DotLine)

        def nice_step(range_val):
            raw = range_val / 8.0
            mag = 10 ** math.floor(math.log10(max(raw, 1e-6)))
            norm = raw / mag
            if norm < 1.5: return mag
            elif norm < 3.5: return 2 * mag
            elif norm < 7.5: return 5 * mag
            else: return 10 * mag

        z_step = nice_step(vz_range)
        x_step = nice_step(vx_range)

        # Dynamic decimal places based on grid step size
        z_decimals = max(2, -math.floor(math.log10(max(z_step, 1e-9))) + 1)
        x_decimals = max(2, -math.floor(math.log10(max(x_step, 1e-9))) + 1)
        z_fmt = f"{{:.{z_decimals}f}}"
        x_fmt = f"{{:.{x_decimals}f}}"

        z_val = math.ceil(vz_min / z_step) * z_step
        while z_val <= vz_max:
            pt = to_screen(0, z_val)
            painter.setPen(grid_pen)
            painter.drawLine(QPointF(pt.x(), margin), QPointF(pt.x(), h - margin))
            painter.setPen(QColor(COLORS["text_dim"]))
            painter.setFont(mono_font(10))
            z_label_val = z_val * 25.4 if self._metric_display else z_val
            painter.drawText(QRectF(pt.x() - 40, h - margin + 2, 80, 16), Qt.AlignCenter, z_fmt.format(z_label_val))
            z_val += z_step

        x_val = math.ceil(vx_min / x_step) * x_step
        while x_val <= vx_max:
            pt = to_screen(x_val, 0)
            painter.setPen(grid_pen)
            painter.drawLine(QPointF(margin_left, pt.y()), QPointF(w - margin, pt.y()))
            painter.setPen(QColor(COLORS["text_dim"]))
            painter.setFont(mono_font(10))
            x_label_val = x_val * 2 * 25.4 if self._metric_display else x_val * 2
            painter.drawText(QRectF(2, pt.y() - 8, margin_left - 4, 16), Qt.AlignRight | Qt.AlignVCenter, x_fmt.format(x_label_val))
            x_val += x_step

        # Origin crosshair
        origin = to_screen(0, 0)
        if margin_left <= origin.x() <= w - margin and margin <= origin.y() <= h - margin:
            painter.setPen(QPen(QColor(COLORS["accent_blue"]), 1, Qt.DashLine))
            painter.drawLine(QPointF(origin.x(), margin), QPointF(origin.x(), h - margin))
            painter.drawLine(QPointF(margin_left, origin.y()), QPointF(w - margin, origin.y()))

        # Trail
        if len(self.trail) > 1:
            for i in range(1, len(self.trail)):
                p1 = to_screen(*self.trail[i - 1])
                p2 = to_screen(*self.trail[i])
                alpha = int(80 + 175 * (i / len(self.trail)))
                c = QColor(COLORS["accent_green"])
                if self._sim_mode:
                    c = QColor("#ffffff")
                    c.setAlpha(min(200, alpha))
                else:
                    c.setAlpha(alpha)
                painter.setPen(QPen(c, 2 if self._sim_mode else 1.5))
                painter.drawLine(p1, p2)

        # Stock outline
        if self._sim_mode and self._sim_stock:
            od = self._sim_stock[0]
            r = od / 2.0
            sz_start = self._sim_stock[1]
            sz_end = self._sim_stock[2]
            painter.setPen(QPen(QColor(COLORS["accent_yellow"]), 1.5, Qt.DashLine))
            painter.setBrush(Qt.NoBrush)
            p1 = to_screen(r, sz_start)
            p2 = to_screen(r, sz_end)
            p3 = to_screen(0, sz_end)
            p4 = to_screen(0, sz_start)
            painter.drawPolygon(QPolygonF([p1, p2, p3, p4]))
            painter.setPen(QPen(QColor(COLORS["text_dim"]), 1, Qt.DashDotLine))
            cl_y = to_screen(0, 0).y()
            painter.drawLine(QPointF(margin_left, cl_y), QPointF(w - margin, cl_y))

        # Sim toolpath
        if self._sim_mode and self._sim_moves:
            prev_x, prev_z = 0.0, 0.0
            for i in range(min(self._sim_step, len(self._sim_moves))):
                mt, mx, mz = self._sim_moves[i]
                if mt == "pause":
                    prev_x, prev_z = mx, mz
                    continue
                p1 = to_screen(prev_x, prev_z)
                p2 = to_screen(mx, mz)
                if mt == "rapid":
                    painter.setPen(QPen(QColor(COLORS["accent"]), 1, Qt.DashLine))
                else:
                    painter.setPen(QPen(QColor(COLORS["accent_green"]), 2))
                painter.drawLine(p1, p2)
                prev_x, prev_z = mx, mz

        # Collision zone highlights (interference check)
        if self._collision_zones:
            collision_color = QColor(COLORS["accent"])
            collision_color.setAlpha(180)
            painter.setPen(QPen(collision_color, 2))
            painter.setBrush(QBrush(collision_color))
            for cz in self._collision_zones:
                cx = getattr(cz, 'x_position', None)
                cz_val = getattr(cz, 'z_position', None)
                if cx is not None and cz_val is not None:
                    pt = to_screen(cx, cz_val)
                    # Draw filled circle marker
                    painter.drawEllipse(pt, 5, 5)
                    # Draw X mark for extra visibility
                    painter.drawLine(QPointF(pt.x() - 4, pt.y() - 4),
                                     QPointF(pt.x() + 4, pt.y() + 4))
                    painter.drawLine(QPointF(pt.x() - 4, pt.y() + 4),
                                     QPointF(pt.x() + 4, pt.y() - 4))

        # Go-To fence lines
        if self._fence_x_enabled or self._fence_z_enabled:
            fence_pen = QPen(QColor(COLORS["fence"]), 2, Qt.DashDotLine)
            painter.setPen(fence_pen)
            if self._fence_x_enabled:
                pt = to_screen(self._fence_x_value, 0)
                painter.drawLine(QPointF(margin_left, pt.y()), QPointF(w - margin, pt.y()))
                # Label
                painter.setFont(mono_font(8, QFont.Bold))
                painter.setPen(QColor(COLORS["fence"]))
                fence_x_disp = self._fence_x_value * 2 * (25.4 if self._metric_display else 1.0)
                lbl_x = f"X={fence_x_disp:.4f}"
                painter.drawText(QRectF(w - margin - 100, pt.y() - 14, 98, 12),
                                 Qt.AlignRight, lbl_x)
                painter.setPen(fence_pen)
            if self._fence_z_enabled:
                pt = to_screen(0, self._fence_z_value)
                painter.drawLine(QPointF(pt.x(), margin), QPointF(pt.x(), h - margin))
                # Label
                painter.setFont(mono_font(8, QFont.Bold))
                painter.setPen(QColor(COLORS["fence"]))
                fence_z_disp = self._fence_z_value * (25.4 if self._metric_display else 1.0)
                lbl_z = f"Z={fence_z_disp:.4f}"
                painter.drawText(QRectF(pt.x() + 4, margin + 2, 80, 12),
                                 Qt.AlignLeft, lbl_z)

        # Per-tool Z-axis soft limit lines
        tool_limit_pen = QPen(QColor("#E67E22"), 2, Qt.DashLine)
        if self._tool_limit_z_minus is not None:
            pt = to_screen(0, self._tool_limit_z_minus)
            painter.setPen(tool_limit_pen)
            painter.drawLine(QPointF(pt.x(), margin), QPointF(pt.x(), h - margin))
            # Label
            painter.setFont(mono_font(8, QFont.Bold))
            painter.setPen(QColor("#E67E22"))
            limit_z_disp = self._tool_limit_z_minus * (25.4 if self._metric_display else 1.0)
            lbl = f"Z−={limit_z_disp:.4f}"
            painter.drawText(QRectF(pt.x() + 4, margin + 14, 90, 12),
                             Qt.AlignLeft, lbl)
        if self._tool_limit_z_plus is not None:
            pt = to_screen(0, self._tool_limit_z_plus)
            painter.setPen(tool_limit_pen)
            painter.drawLine(QPointF(pt.x(), margin), QPointF(pt.x(), h - margin))
            # Label
            painter.setFont(mono_font(8, QFont.Bold))
            painter.setPen(QColor("#E67E22"))
            limit_z_disp = self._tool_limit_z_plus * (25.4 if self._metric_display else 1.0)
            lbl = f"Z+={limit_z_disp:.4f}"
            painter.drawText(QRectF(pt.x() + 4, margin + 14, 90, 12),
                             Qt.AlignLeft, lbl)

        # Current position marker
        if self._sim_mode and self._sim_step > 0 and self._sim_step <= len(self._sim_moves):
            _, sx, sz = self._sim_moves[self._sim_step - 1]
            pos = to_screen(sx, sz)
        else:
            pos = to_screen(self.current_x, self.current_z)
        painter.setPen(QPen(QColor(COLORS["accent"]), 2))
        painter.drawLine(QPointF(pos.x() - 10, pos.y()), QPointF(pos.x() + 10, pos.y()))
        painter.drawLine(QPointF(pos.x(), pos.y() - 10), QPointF(pos.x(), pos.y() + 10))
        painter.setBrush(QBrush(QColor(COLORS["accent"])))
        painter.drawEllipse(pos, 4, 4)

        # Labels
        painter.setPen(QColor(COLORS["text_dim"]))
        painter.setFont(mono_font(10, QFont.Bold))
        painter.drawText(QRectF(w / 2 - 10, h - 16, 20, 14), Qt.AlignCenter, "Z")
        painter.save()
        painter.translate(12, h / 2 + 6)
        painter.rotate(-90)
        painter.drawText(0, 0, "X")
        painter.restore()

        painter.setPen(QColor(COLORS["dro_text"]))
        painter.setFont(mono_font(FONT_SIZES['dro_primary'], QFont.Bold))
        dro_x_val = self.current_x * 2
        dro_z_val = self.current_z

        # Apply metric conversion for display only
        _conv = 25.4 if self._metric_display else 1.0
        dro_x_display = dro_x_val * _conv
        dro_z_display = dro_z_val * _conv
        _unit_label = "mm" if self._metric_display else "in"
        _dro_fmt = "{:+.3f}" if self._metric_display else "{:+.4f}"

        # DRO area top-right: axis labels + work coordinate values
        dro_top = margin
        dro_right = w - margin - 10

        # X axis row
        painter.setPen(QColor(COLORS["text_secondary"]))
        painter.setFont(mono_font(FONT_SIZES['dro_axis_label'], QFont.Bold))
        painter.drawText(QRectF(dro_right - 340, dro_top, 40, 36), Qt.AlignLeft | Qt.AlignVCenter, "X")
        color = COLORS['dro_text_red'] if dro_x_display < 0 else COLORS['dro_text']
        painter.setPen(QColor(color))
        painter.setFont(mono_font(FONT_SIZES['dro_primary'], QFont.Bold))
        painter.drawText(QRectF(dro_right - 295, dro_top, 295, 36), Qt.AlignRight | Qt.AlignVCenter,
                         _dro_fmt.format(dro_x_display))

        # Z axis row
        dro_z_top = dro_top + 38
        painter.setPen(QColor(COLORS["text_secondary"]))
        painter.setFont(mono_font(FONT_SIZES['dro_axis_label'], QFont.Bold))
        painter.drawText(QRectF(dro_right - 340, dro_z_top, 40, 36), Qt.AlignLeft | Qt.AlignVCenter, "Z")
        color = COLORS['dro_text_red'] if dro_z_display < 0 else COLORS['dro_text']
        painter.setPen(QColor(color))
        painter.setFont(mono_font(FONT_SIZES['dro_primary'], QFont.Bold))
        painter.drawText(QRectF(dro_right - 295, dro_z_top, 295, 36), Qt.AlignRight | Qt.AlignVCenter,
                         _dro_fmt.format(dro_z_display))



        # Sim overlay info
        if self._sim_mode and self._sim_moves:
            lx = margin_left + 4
            ly = margin + 22
            painter.setPen(QPen(QColor(COLORS["accent"]), 1, Qt.DashLine))
            painter.drawLine(QPointF(lx, ly + 5), QPointF(lx + 18, ly + 5))
            painter.setPen(QColor(COLORS["text_dim"]))
            painter.setFont(mono_font(8))
            painter.drawText(QRectF(lx + 22, ly, 40, 12), Qt.AlignLeft, "Rapid")
            ly += 14
            painter.setPen(QPen(QColor(COLORS["accent_green"]), 2))
            painter.drawLine(QPointF(lx, ly + 5), QPointF(lx + 18, ly + 5))
            painter.setPen(QColor(COLORS["text_dim"]))
            painter.drawText(QRectF(lx + 22, ly, 40, 12), Qt.AlignLeft, "Feed")

            painter.setPen(QColor(COLORS["text_secondary"]))
            painter.setFont(mono_font(9))
            # Show N-number of current G-code line instead of step count
            n_label = ""
            if self._sim_step > 0 and self._sim_line_map:
                li = min(self._sim_step - 1, len(self._sim_line_map) - 1)
                gline_idx = self._sim_line_map[li]
                if gline_idx < len(self._sim_gcode_lines):
                    raw = self._sim_gcode_lines[gline_idx].strip()
                    n_match = re.match(r'N(\d+)', raw)
                    if n_match:
                        n_label = f"N{n_match.group(1)}"
            if not n_label:
                n_label = f"Step {self._sim_step}/{len(self._sim_moves)}"
            painter.drawText(QRectF(w - margin - 90, margin + 98, 90, 14), Qt.AlignRight,
                             n_label)

            if self._sim_step > 0:
                sm = self._sim_moves[self._sim_step - 1]
                mt, sx, sz = sm
                tc = QColor(COLORS["accent"]) if mt == "rapid" else QColor(COLORS["accent_green"]) if mt == "feed" else QColor(COLORS["accent_yellow"])
                painter.setPen(tc)
                painter.setFont(mono_font(9, QFont.Bold))
                tl = "RAPID" if mt == "rapid" else "FEED" if mt == "feed" else "PAUSE"
                sim_x_disp = sx * 2 * (25.4 if self._metric_display else 1.0)
                sim_z_disp = sz * (25.4 if self._metric_display else 1.0)
                _sim_fmt = "{:+.3f}" if self._metric_display else "{:+.4f}"
                painter.drawText(QRectF(w - margin - 180, margin + 114, 180, 14), Qt.AlignRight,
                                 f"{tl}  X{_sim_fmt.format(sim_x_disp)}  Z{_sim_fmt.format(sim_z_disp)}")

        if not self._auto_scale:
            painter.setPen(QColor(COLORS["text_dim"]))
            painter.setFont(mono_font(8))
            painter.drawText(QRectF(w - margin - 140, h - margin + 2, 140, 14), Qt.AlignRight,
                             "Scroll=zoom  Drag=pan  DblClick=reset")

        # Subtle inset shadow vignette around edges
        from PyQt5.QtGui import QLinearGradient
        shadow_color = QColor(0, 0, 0, 60)
        transparent = QColor(0, 0, 0, 0)
        shadow_size = 12

        # Top edge
        grad_t = QLinearGradient(0, 0, 0, shadow_size)
        grad_t.setColorAt(0, shadow_color)
        grad_t.setColorAt(1, transparent)
        painter.fillRect(QRectF(0, 0, w, shadow_size), grad_t)

        # Bottom edge
        grad_b = QLinearGradient(0, h - shadow_size, 0, h)
        grad_b.setColorAt(0, transparent)
        grad_b.setColorAt(1, shadow_color)
        painter.fillRect(QRectF(0, h - shadow_size, w, shadow_size), grad_b)

        # Left edge
        grad_l = QLinearGradient(0, 0, shadow_size, 0)
        grad_l.setColorAt(0, shadow_color)
        grad_l.setColorAt(1, transparent)
        painter.fillRect(QRectF(0, 0, shadow_size, h), grad_l)

        # Right edge
        grad_r = QLinearGradient(w - shadow_size, 0, w, 0)
        grad_r.setColorAt(0, transparent)
        grad_r.setColorAt(1, shadow_color)
        painter.fillRect(QRectF(w - shadow_size, 0, shadow_size, h), grad_r)

        painter.end()


# ---------------------------------------------------------------------------
# Module-level helper for interference check integration
# ---------------------------------------------------------------------------
def highlight_collisions_on_graph(collisions, graph_widget):
    """Mark interfering segments on the PositionGraph.

    Args:
        collisions: list of CollisionPoint objects with x_position and z_position
        graph_widget: PositionGraph instance (or None)
    """
    if graph_widget and hasattr(graph_widget, 'set_collision_zones'):
        graph_widget.set_collision_zones(collisions)
