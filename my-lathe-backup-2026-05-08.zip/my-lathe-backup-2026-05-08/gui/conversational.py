"""
Conversational Programming Module for My-Lathe GUI
====================================================
Generates G-code from simple form-based inputs.
Operations: OD Turning, Boring, Threading, Cutoff

Each operation is a panel with labeled input fields.
The user fills in dimensions, feeds, speeds, and depths of cut.
The module generates clean, commented G-code ready to run.
"""

import math
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel,
    QPushButton, QComboBox, QGroupBox, QLineEdit, QTextEdit,
    QStackedWidget, QFrame, QScrollArea, QMessageBox, QFileDialog
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont, QColor

# Import from main GUI module
import os
import sys
sys.path.insert(0, os.path.dirname(__file__))
from theme import COLORS, mono_font, ui_font


def _lib_tool_num(prog_tool):
    """Convert program tool number to library tool number.

    Convention: T1 in program = T101 in library, T2 = T102, etc.
    """
    try:
        t = int(prog_tool)
        return str(100 + t)
    except (ValueError, TypeError):
        return str(prog_tool)


# ---------------------------------------------------------------------------
# Styles shared across operation panels
# ---------------------------------------------------------------------------
LBL_STYLE = f"color: {COLORS['text_secondary']}; font-size: 12px; background: transparent;"
VAL_STYLE = (
    f"background-color: {COLORS['bg_light']}; color: {COLORS['text']}; "
    f"border: 1px solid {COLORS['border']}; border-radius: 6px; "
    f"padding: 5px 8px; font-size: 13px;"
)
SECTION_STYLE = (
    f"color: {COLORS['accent_blue']}; font-size: 13px; "
    f"font-weight: bold; background: transparent;"
)


# ---------------------------------------------------------------------------
# Helper: labeled input field
# ---------------------------------------------------------------------------
def make_field(label_text, default="", tooltip="", width=100):
    """Create a label + line edit pair, returns (label, field)."""
    lbl = QLabel(label_text)
    lbl.setStyleSheet(LBL_STYLE)
    lbl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
    field = QLineEdit(default)
    field.setStyleSheet(VAL_STYLE)
    field.setFixedWidth(width)
    if tooltip:
        field.setToolTip(tooltip)
        lbl.setToolTip(tooltip)
    return lbl, field


# ---------------------------------------------------------------------------
# OD Turning Operation
# ---------------------------------------------------------------------------
class ODTurningPanel(QWidget):
    """Conversational OD turning — straight, taper, or shoulder."""

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setSpacing(8)

        # --- Stock dimensions ---
        stock_group = QGroupBox("Stock")
        sg = QGridLayout(stock_group)
        row = 0

        lbl, self.stock_dia = make_field("Stock Diameter:", "2.000",
            "Starting OD of the workpiece (inches, diameter)")
        sg.addWidget(lbl, row, 0); sg.addWidget(self.stock_dia, row, 1)

        lbl, self.finish_dia = make_field("Finish Diameter:", "1.500",
            "Target OD after turning (inches, diameter)")
        sg.addWidget(lbl, row, 2); sg.addWidget(self.finish_dia, row, 3)
        row += 1

        lbl, self.z_start = make_field("Z Start:", "0.000",
            "Z position where cut begins (usually 0 or small positive for clearance)")
        sg.addWidget(lbl, row, 0); sg.addWidget(self.z_start, row, 1)

        lbl, self.z_end = make_field("Z End:", "-3.000",
            "Z position where cut ends (negative = toward chuck)")
        sg.addWidget(lbl, row, 2); sg.addWidget(self.z_end, row, 3)
        row += 1

        lbl, self.retract_x = make_field("X Retract:", "0.100",
            "Clearance above stock OD for rapid moves (inches, on diameter)")
        sg.addWidget(lbl, row, 0); sg.addWidget(self.retract_x, row, 1)

        lbl, self.retract_z = make_field("Z Retract:", "0.050",
            "Clearance past Z start for rapid positioning (inches)")
        sg.addWidget(lbl, row, 2); sg.addWidget(self.retract_z, row, 3)

        layout.addWidget(stock_group)

        # --- Cutting parameters ---
        cut_group = QGroupBox("Cutting Parameters")
        cg = QGridLayout(cut_group)
        row = 0

        lbl, self.doc = make_field("Depth of Cut:", "0.050",
            "Radial depth per pass (inches, on the radius)")
        cg.addWidget(lbl, row, 0); cg.addWidget(self.doc, row, 1)

        lbl, self.finish_passes = make_field("Finish Passes:", "1",
            "Number of light finish passes")
        cg.addWidget(lbl, row, 2); cg.addWidget(self.finish_passes, row, 3)
        row += 1

        lbl, self.finish_doc = make_field("Finish DOC:", "0.005",
            "Depth of cut for finish passes (inches, on radius)")
        cg.addWidget(lbl, row, 0); cg.addWidget(self.finish_doc, row, 1)
        row += 1

        lbl, self.feed_rough = make_field("Rough Feed:", "0.010",
            "Feed rate for roughing (in/rev or in/min)")
        cg.addWidget(lbl, row, 0); cg.addWidget(self.feed_rough, row, 1)

        lbl, self.feed_finish = make_field("Finish Feed:", "0.005",
            "Feed rate for finish passes")
        cg.addWidget(lbl, row, 2); cg.addWidget(self.feed_finish, row, 3)
        row += 1

        lbl, self.spindle_rpm = make_field("Spindle RPM:", "1200",
            "Spindle speed (informational — spindle is manual)")
        cg.addWidget(lbl, row, 0); cg.addWidget(self.spindle_rpm, row, 1)

        layout.addWidget(cut_group)

        # --- Tools (separate rough and finish) ---
        tool_group = QGroupBox("Tools")
        tg = QGridLayout(tool_group)

        lbl, self.rough_tool = make_field("Roughing Tool #:", "1", width=60,
            tooltip="Tool number for roughing passes")
        tg.addWidget(lbl, 0, 0); tg.addWidget(self.rough_tool, 0, 1)

        lbl, self.finish_tool = make_field("Finishing Tool #:", "1", width=60,
            tooltip="Tool number for finish passes (same as rough = no tool change)")
        tg.addWidget(lbl, 0, 2); tg.addWidget(self.finish_tool, 0, 3)

        layout.addWidget(tool_group)

        layout.addStretch()

    def generate_gcode(self):
        """Generate G-code for OD turning."""
        try:
            stock_d = float(self.stock_dia.text())
            finish_d = float(self.finish_dia.text())
            z_start = float(self.z_start.text())
            z_end = float(self.z_end.text())
            retract_x = float(self.retract_x.text())
            retract_z = float(self.retract_z.text())
            doc = float(self.doc.text())
            fin_passes = int(self.finish_passes.text())
            fin_doc = float(self.finish_doc.text())
            feed_r = float(self.feed_rough.text())
            feed_f = float(self.feed_finish.text())
            rpm = self.spindle_rpm.text()
            r_tool = self.rough_tool.text()
            f_tool = self.finish_tool.text()
        except ValueError as e:
            return f"; ERROR: Invalid input — {e}\n"

        separate_tools = r_tool.strip() != f_tool.strip()
        x_clear = stock_d + retract_x
        z_clear = z_start + retract_z

        lines = [
            f"; OD Turning — Conversational",
            f"; Stock: {stock_d:.4f} dia → {finish_d:.4f} dia",
            f"; Z range: {z_start:.4f} to {z_end:.4f}",
            f"; Retract: X {retract_x:.3f} above stock, Z {retract_z:.3f} past start",
            f"; Rough DOC: {doc:.4f}  Feed: {feed_r}  Tool: T{_lib_tool_num(r_tool)}",
            f"; Finish DOC: {fin_doc:.4f}  Feed: {feed_f}  Passes: {fin_passes}  Tool: T{_lib_tool_num(f_tool)}",
            f"; Suggested RPM: {rpm}",
            f"",
            f"G20 G18 G40 G49 G80  (Inch, XZ plane, cancel comp)",
            f"G90                   (Absolute mode)",
            f"",
            f"; --- Load roughing tool ---",
            f"T{_lib_tool_num(r_tool)} M6",
            f"G43",
            f"",
        ]

        # Calculate passes
        stock_r = stock_d / 2.0
        finish_r = finish_d / 2.0

        # Roughing passes
        current_r = stock_r
        pass_num = 1
        lines.append(f"; --- Roughing passes ---")

        while current_r - doc > finish_r + (fin_passes * fin_doc):
            current_r -= doc
            current_d = current_r * 2.0
            lines.append(f"G00 X{x_clear:.4f} Z{z_clear:.4f}  (Rapid to start, pass {pass_num})")
            lines.append(f"G00 X{current_d:.4f}")
            lines.append(f"G01 Z{z_end:.4f} F{feed_r}  (Rough cut)")
            lines.append(f"G00 X{x_clear:.4f}          (Retract X)")
            lines.append(f"")
            pass_num += 1

        # Cleanup remaining rough material
        remaining = current_r - finish_r - (fin_passes * fin_doc)
        if remaining > 0.001:
            current_r = finish_r + (fin_passes * fin_doc)
            current_d = current_r * 2.0
            lines.append(f"G00 X{x_clear:.4f} Z{z_clear:.4f}  (Cleanup pass)")
            lines.append(f"G00 X{current_d:.4f}")
            lines.append(f"G01 Z{z_end:.4f} F{feed_r}")
            lines.append(f"G00 X{x_clear:.4f}")
            lines.append(f"")

        # Retract to safe position after roughing
        lines.append(f"G00 X{x_clear:.4f} Z{z_clear:.4f}  (Roughing complete — retract)")
        lines.append(f"")

        # Tool change for finishing if different tool
        if separate_tools and fin_passes > 0:
            lines.append(f"; --- Tool change: roughing → finishing ---")
            lines.append(f"M0  (PAUSE — Change to finishing tool T{_lib_tool_num(f_tool)}, then Cycle Start)")
            lines.append(f"T{_lib_tool_num(f_tool)} M6")
            lines.append(f"G43")
            lines.append(f"")

        # Finish passes
        if fin_passes > 0:
            lines.append(f"; --- Finish passes (T{_lib_tool_num(f_tool)}) ---")
            for i in range(fin_passes):
                remaining_fin = fin_passes - i
                fin_r = finish_r + (remaining_fin - 1) * fin_doc
                fin_d = fin_r * 2.0
                lines.append(f"G00 X{x_clear:.4f} Z{z_clear:.4f}  (Finish pass {i+1})")
                lines.append(f"G00 X{fin_d:.4f}")
                lines.append(f"G01 Z{z_end:.4f} F{feed_f}  (Finish cut)")
                lines.append(f"G00 X{x_clear:.4f}")
                lines.append(f"")

        lines.append(f"G00 X{x_clear:.4f} Z{z_clear:.4f}  (Return to safe position)")
        lines.append(f"M2  (Program end)")
        lines.append(f"")

        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Boring Operation
# ---------------------------------------------------------------------------
class BoringPanel(QWidget):
    """Conversational boring — enlarge an existing hole."""

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setSpacing(8)

        stock_group = QGroupBox("Bore Dimensions")
        sg = QGridLayout(stock_group)
        row = 0

        lbl, self.start_dia = make_field("Starting Bore:", "0.500",
            "Current bore diameter (inches)")
        sg.addWidget(lbl, row, 0); sg.addWidget(self.start_dia, row, 1)

        lbl, self.finish_dia = make_field("Finish Bore:", "1.000",
            "Target bore diameter (inches)")
        sg.addWidget(lbl, row, 2); sg.addWidget(self.finish_dia, row, 3)
        row += 1

        lbl, self.z_start = make_field("Z Start:", "0.000",
            "Z position at bore entry (face of part)")
        sg.addWidget(lbl, row, 0); sg.addWidget(self.z_start, row, 1)

        lbl, self.z_end = make_field("Z Depth:", "-1.500",
            "Z depth of bore (negative = into part)")
        sg.addWidget(lbl, row, 2); sg.addWidget(self.z_end, row, 3)
        row += 1

        lbl, self.retract_x = make_field("X Retract:", "0.050",
            "Clearance inside bore for retract moves (inches, on diameter)")
        sg.addWidget(lbl, row, 0); sg.addWidget(self.retract_x, row, 1)

        lbl, self.retract_z = make_field("Z Retract:", "0.050",
            "Clearance past Z start for rapid positioning (inches)")
        sg.addWidget(lbl, row, 2); sg.addWidget(self.retract_z, row, 3)

        layout.addWidget(stock_group)

        cut_group = QGroupBox("Cutting Parameters")
        cg = QGridLayout(cut_group)
        row = 0

        lbl, self.doc = make_field("Depth of Cut:", "0.025",
            "Radial depth per pass (inches, on radius)")
        cg.addWidget(lbl, row, 0); cg.addWidget(self.doc, row, 1)

        lbl, self.finish_passes = make_field("Finish Passes:", "1")
        cg.addWidget(lbl, row, 2); cg.addWidget(self.finish_passes, row, 3)
        row += 1

        lbl, self.finish_doc = make_field("Finish DOC:", "0.005")
        cg.addWidget(lbl, row, 0); cg.addWidget(self.finish_doc, row, 1)
        row += 1

        lbl, self.feed_rough = make_field("Rough Feed:", "0.005")
        cg.addWidget(lbl, row, 0); cg.addWidget(self.feed_rough, row, 1)

        lbl, self.feed_finish = make_field("Finish Feed:", "0.003")
        cg.addWidget(lbl, row, 2); cg.addWidget(self.feed_finish, row, 3)
        row += 1

        lbl, self.spindle_rpm = make_field("Spindle RPM:", "800")
        cg.addWidget(lbl, row, 0); cg.addWidget(self.spindle_rpm, row, 1)

        layout.addWidget(cut_group)

        tool_group = QGroupBox("Tools")
        tg = QGridLayout(tool_group)

        lbl, self.rough_tool = make_field("Roughing Tool #:", "2", width=60,
            tooltip="Tool number for roughing passes")
        tg.addWidget(lbl, 0, 0); tg.addWidget(self.rough_tool, 0, 1)

        lbl, self.finish_tool = make_field("Finishing Tool #:", "2", width=60,
            tooltip="Tool number for finish passes (same as rough = no tool change)")
        tg.addWidget(lbl, 0, 2); tg.addWidget(self.finish_tool, 0, 3)

        layout.addWidget(tool_group)

        layout.addStretch()

    def generate_gcode(self):
        try:
            start_d = float(self.start_dia.text())
            finish_d = float(self.finish_dia.text())
            z_start = float(self.z_start.text())
            z_end = float(self.z_end.text())
            retract_x = float(self.retract_x.text())
            retract_z = float(self.retract_z.text())
            doc = float(self.doc.text())
            fin_passes = int(self.finish_passes.text())
            fin_doc = float(self.finish_doc.text())
            feed_r = float(self.feed_rough.text())
            feed_f = float(self.feed_finish.text())
            rpm = self.spindle_rpm.text()
            r_tool = self.rough_tool.text()
            f_tool = self.finish_tool.text()
        except ValueError as e:
            return f"; ERROR: Invalid input — {e}\n"

        separate_tools = r_tool.strip() != f_tool.strip()
        x_clear = start_d - retract_x  # Retract toward center inside bore
        z_clear = z_start + retract_z

        lines = [
            f"; Boring — Conversational",
            f"; Bore: {start_d:.4f} dia → {finish_d:.4f} dia",
            f"; Z range: {z_start:.4f} to {z_end:.4f}",
            f"; Retract: X {retract_x:.3f} inside bore, Z {retract_z:.3f} past start",
            f"; Rough DOC: {doc:.4f}  Feed: {feed_r}  Tool: T{_lib_tool_num(r_tool)}",
            f"; Finish DOC: {fin_doc:.4f}  Feed: {feed_f}  Passes: {fin_passes}  Tool: T{_lib_tool_num(f_tool)}",
            f"; Suggested RPM: {rpm}",
            f"",
            f"G20 G18 G40 G49 G80",
            f"G90",
            f"",
            f"; --- Load roughing tool ---",
            f"T{_lib_tool_num(r_tool)} M6",
            f"G43",
            f"",
        ]

        start_r = start_d / 2.0
        finish_r = finish_d / 2.0

        current_r = start_r
        pass_num = 1
        lines.append(f"; --- Roughing passes ---")

        while current_r + doc < finish_r - (fin_passes * fin_doc):
            current_r += doc
            current_d = current_r * 2.0
            lines.append(f"G00 X{x_clear:.4f} Z{z_clear:.4f}  (Rapid, pass {pass_num})")
            lines.append(f"G00 X{current_d:.4f}")
            lines.append(f"G01 Z{z_end:.4f} F{feed_r}  (Bore cut)")
            lines.append(f"G00 X{x_clear:.4f}          (Retract to center)")
            lines.append(f"G00 Z{z_clear:.4f}")
            lines.append(f"")
            pass_num += 1

        # Cleanup remaining rough material
        remaining = finish_r - (fin_passes * fin_doc) - current_r
        if remaining > 0.001:
            current_r = finish_r - (fin_passes * fin_doc)
            current_d = current_r * 2.0
            lines.append(f"G00 X{x_clear:.4f} Z{z_clear:.4f}  (Cleanup)")
            lines.append(f"G00 X{current_d:.4f}")
            lines.append(f"G01 Z{z_end:.4f} F{feed_r}")
            lines.append(f"G00 X{x_clear:.4f}")
            lines.append(f"G00 Z{z_clear:.4f}")
            lines.append(f"")

        # Retract after roughing
        lines.append(f"G00 X{x_clear:.4f} Z{z_clear:.4f}  (Roughing complete — retract)")
        lines.append(f"")

        # Tool change for finishing if different tool
        if separate_tools and fin_passes > 0:
            lines.append(f"; --- Tool change: roughing → finishing ---")
            lines.append(f"M0  (PAUSE — Change to finishing tool T{_lib_tool_num(f_tool)}, then Cycle Start)")
            lines.append(f"T{_lib_tool_num(f_tool)} M6")
            lines.append(f"G43")
            lines.append(f"")

        # Finish passes
        if fin_passes > 0:
            lines.append(f"; --- Finish passes (T{_lib_tool_num(f_tool)}) ---")
            for i in range(fin_passes):
                remaining_fin = fin_passes - i
                fin_r = finish_r - (remaining_fin - 1) * fin_doc
                fin_d = fin_r * 2.0
                lines.append(f"G00 X{x_clear:.4f} Z{z_clear:.4f}  (Finish {i+1})")
                lines.append(f"G00 X{fin_d:.4f}")
                lines.append(f"G01 Z{z_end:.4f} F{feed_f}")
                lines.append(f"G00 X{x_clear:.4f}")
                lines.append(f"G00 Z{z_clear:.4f}")
                lines.append(f"")

        lines.append(f"G00 X0.0000 Z{z_clear:.4f}  (Return)")
        lines.append(f"M2")
        lines.append(f"")

        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Threading Operation (uses G76 cycle)
# ---------------------------------------------------------------------------
class ThreadingPanel(QWidget):
    """Conversational threading — external or internal using G76."""

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setSpacing(8)

        # --- Thread type ---
        type_group = QGroupBox("Thread Type")
        tg = QGridLayout(type_group)

        tg.addWidget(QLabel("Type:"), 0, 0)
        self.thread_type = QComboBox()
        self.thread_type.addItems(["External (OD)", "Internal (Bore)"])
        tg.addWidget(self.thread_type, 0, 1)

        tg.addWidget(QLabel("Thread Form:"), 0, 2)
        self.thread_form = QComboBox()
        self.thread_form.addItems(["UN/UNF (60°)", "Metric (60°)", "Acme (29°)", "Whitworth (55°)"])
        tg.addWidget(self.thread_form, 0, 3)

        layout.addWidget(type_group)

        # --- Thread dimensions ---
        dim_group = QGroupBox("Thread Dimensions")
        dg = QGridLayout(dim_group)
        row = 0

        lbl, self.major_dia = make_field("Major Diameter:", "1.000",
            "Major (outer) diameter of thread")
        dg.addWidget(lbl, row, 0); dg.addWidget(self.major_dia, row, 1)

        lbl, self.minor_dia = make_field("Minor Diameter:", "0.8376",
            "Minor (root) diameter — look up in thread chart")
        dg.addWidget(lbl, row, 2); dg.addWidget(self.minor_dia, row, 3)
        row += 1

        lbl, self.pitch = make_field("Pitch (TPI or mm):", "20",
            "Threads per inch (UN) or pitch in mm (Metric)")
        dg.addWidget(lbl, row, 0); dg.addWidget(self.pitch, row, 1)

        lbl, self.thread_length = make_field("Thread Length:", "1.000",
            "Length of threaded section (inches)")
        dg.addWidget(lbl, row, 2); dg.addWidget(self.thread_length, row, 3)
        row += 1

        lbl, self.lead_in = make_field("Lead-in:", "0.100",
            "Distance before thread starts for spindle sync")
        dg.addWidget(lbl, row, 0); dg.addWidget(self.lead_in, row, 1)

        lbl, self.lead_out = make_field("Lead-out:", "0.050",
            "Overrun past thread end")
        dg.addWidget(lbl, row, 2); dg.addWidget(self.lead_out, row, 3)

        layout.addWidget(dim_group)

        # --- Cutting parameters ---
        cut_group = QGroupBox("Cutting Parameters")
        cg = QGridLayout(cut_group)
        row = 0

        lbl, self.first_doc = make_field("First DOC:", "0.020",
            "Depth of first threading pass (on diameter)")
        cg.addWidget(lbl, row, 0); cg.addWidget(self.first_doc, row, 1)

        lbl, self.min_doc = make_field("Min DOC:", "0.002",
            "Minimum depth of cut (last passes)")
        cg.addWidget(lbl, row, 2); cg.addWidget(self.min_doc, row, 3)
        row += 1

        lbl, self.spring_passes = make_field("Spring Passes:", "2",
            "Passes at final depth to clean up thread")
        cg.addWidget(lbl, row, 0); cg.addWidget(self.spring_passes, row, 1)

        lbl, self.spindle_rpm = make_field("Spindle RPM:", "400",
            "Suggested RPM — set manually on headstock")
        cg.addWidget(lbl, row, 2); cg.addWidget(self.spindle_rpm, row, 3)

        layout.addWidget(cut_group)

        tool_group = QGroupBox("Tool")
        tlg = QHBoxLayout(tool_group)
        lbl, self.tool_num = make_field("Tool #:", "4", width=60)
        tlg.addWidget(lbl); tlg.addWidget(self.tool_num)
        tlg.addStretch()
        layout.addWidget(tool_group)

        layout.addStretch()

    def generate_gcode(self):
        try:
            is_external = self.thread_type.currentIndex() == 0
            form_idx = self.thread_form.currentIndex()
            major_d = float(self.major_dia.text())
            minor_d = float(self.minor_dia.text())
            pitch_val = float(self.pitch.text())
            t_length = float(self.thread_length.text())
            lead_in = float(self.lead_in.text())
            lead_out = float(self.lead_out.text())
            first_doc = float(self.first_doc.text())
            min_doc = float(self.min_doc.text())
            spring = int(self.spring_passes.text())
            rpm = self.spindle_rpm.text()
            tool = self.tool_num.text()
        except ValueError as e:
            return f"; ERROR: Invalid input — {e}\n"

        # Thread angle based on form
        angles = {0: 60, 1: 60, 2: 29, 3: 55}
        thread_angle = angles.get(form_idx, 60)

        # Pitch: for UN threads, convert TPI to pitch distance
        if form_idx in (0,):  # UN/UNF — input is TPI
            pitch_dist = 1.0 / pitch_val
            pitch_label = f"{pitch_val:.0f} TPI"
        else:
            pitch_dist = pitch_val / 25.4  # mm to inches
            pitch_label = f"{pitch_val}mm pitch"

        # Thread depth (on radius)
        thread_depth = (major_d - minor_d) / 2.0

        # G76 parameters
        # P: pitch (distance per rev)
        # Z: end of thread
        # I: thread taper (0 for straight)
        # J: initial cut depth (on radius)
        # K: full thread depth (on radius)
        # R: degression (1.0 = constant area)
        # Q: compound infeed angle (29.5° for 60° thread)
        # L: spring passes
        # E: taper distance at end (0)
        # H: first pass depth (on diameter for G76)

        z_start = lead_in
        z_end = -(t_length + lead_out)

        if is_external:
            x_start = major_d + 0.100  # clearance
            x_thread = minor_d
            type_str = "External"
        else:
            x_start = minor_d - 0.100
            x_thread = major_d
            type_str = "Internal"

        compound_angle = thread_angle / 2.0  # Compound infeed angle

        lines = [
            f"; Threading — {type_str} — Conversational",
            f"; {pitch_label}, {thread_angle}° thread form",
            f"; Major: {major_d:.4f}  Minor: {minor_d:.4f}",
            f"; Thread depth: {thread_depth:.4f} (on radius)",
            f"; Length: {t_length:.4f}  Spring passes: {spring}",
            f"; Suggested RPM: {rpm}",
            f"",
            f"G20 G18 G40 G49 G80",
            f"G90",
            f"T{_lib_tool_num(tool)} M6",
            f"G43",
            f"",
            f"; Position to start",
            f"G00 X{x_start:.4f} Z{z_start:.4f}",
            f"",
            f"; G76 Threading Cycle",
            f"; P = pitch, Z = end, K = thread depth (radius)",
            f"; I = taper (0), J = first cut depth, L = spring passes",
            f"G76 P{pitch_dist:.6f} Z{z_end:.4f} I0 J{first_doc / 2:.4f} K{thread_depth:.4f} R1.0 Q{compound_angle:.1f} L{spring} E0",
            f"",
            f"; Return to safe position",
            f"G00 X{x_start:.4f} Z{z_start:.4f}",
            f"M2",
            f"",
        ]

        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Cutoff / Parting Operation
# ---------------------------------------------------------------------------
class CutoffPanel(QWidget):
    """Conversational cutoff/parting."""

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setSpacing(8)

        dim_group = QGroupBox("Dimensions")
        dg = QGridLayout(dim_group)
        row = 0

        lbl, self.od = make_field("OD:", "2.000",
            "Outside diameter of the workpiece")
        dg.addWidget(lbl, row, 0); dg.addWidget(self.od, row, 1)

        lbl, self.id_bore = make_field("ID (if hollow):", "0.000",
            "Inside diameter if part is hollow (0 for solid)")
        dg.addWidget(lbl, row, 2); dg.addWidget(self.id_bore, row, 3)
        row += 1

        lbl, self.z_pos = make_field("Z Position:", "-2.000",
            "Z position of the cutoff (where the blade enters)")
        dg.addWidget(lbl, row, 0); dg.addWidget(self.z_pos, row, 1)

        lbl, self.blade_width = make_field("Blade Width:", "0.125",
            "Width of the parting blade (inches)")
        dg.addWidget(lbl, row, 2); dg.addWidget(self.blade_width, row, 3)

        layout.addWidget(dim_group)

        cut_group = QGroupBox("Cutting Parameters")
        cg = QGridLayout(cut_group)
        row = 0

        lbl, self.feed = make_field("Feed:", "0.002",
            "Feed rate for parting (in/rev — keep low)")
        cg.addWidget(lbl, row, 0); cg.addWidget(self.feed, row, 1)

        lbl, self.spindle_rpm = make_field("Spindle RPM:", "300",
            "Suggested RPM — low speed for parting")
        cg.addWidget(lbl, row, 2); cg.addWidget(self.spindle_rpm, row, 3)
        row += 1

        lbl, self.peck_depth = make_field("Peck Depth:", "0.000",
            "Peck depth per plunge (0 = no pecking, straight plunge)")
        cg.addWidget(lbl, row, 0); cg.addWidget(self.peck_depth, row, 1)

        lbl, self.retract = make_field("Peck Retract:", "0.010",
            "Retract distance between pecks")
        cg.addWidget(lbl, row, 2); cg.addWidget(self.retract, row, 3)

        layout.addWidget(cut_group)

        tool_group = QGroupBox("Tool")
        tlg = QHBoxLayout(tool_group)
        lbl, self.tool_num = make_field("Tool #:", "5", width=60)
        tlg.addWidget(lbl); tlg.addWidget(self.tool_num)
        tlg.addStretch()
        layout.addWidget(tool_group)

        layout.addStretch()

    def generate_gcode(self):
        try:
            od = float(self.od.text())
            id_bore = float(self.id_bore.text())
            z_pos = float(self.z_pos.text())
            blade_w = float(self.blade_width.text())
            feed = float(self.feed.text())
            rpm = self.spindle_rpm.text()
            tool = self.tool_num.text()
            peck = float(self.peck_depth.text())
            retract = float(self.retract.text())
        except ValueError as e:
            return f"; ERROR: Invalid input — {e}\n"

        clearance = 0.100
        x_start = od + clearance * 2
        x_end = id_bore - 0.010 if id_bore > 0 else -0.010  # Cut past center or to bore

        lines = [
            f"; Cutoff / Parting — Conversational",
            f"; OD: {od:.4f}  ID: {id_bore:.4f}",
            f"; Z position: {z_pos:.4f}  Blade: {blade_w:.4f} wide",
            f"; Suggested RPM: {rpm}",
            f"",
            f"G20 G18 G40 G49 G80",
            f"G90",
            f"T{_lib_tool_num(tool)} M6",
            f"G43",
            f"",
            f"G00 X{x_start:.4f} Z{z_pos:.4f}  (Position parting tool)",
            f"",
        ]

        if peck > 0.001:
            # Pecking cutoff
            lines.append(f"; --- Peck parting ---")
            current_x = od
            while current_x > x_end:
                next_x = max(current_x - peck * 2, x_end)  # peck is on diameter
                lines.append(f"G01 X{next_x:.4f} F{feed}  (Peck)")
                if next_x > x_end:
                    lines.append(f"G00 X{next_x + retract * 2:.4f}  (Retract)")
                current_x = next_x
            lines.append(f"")
        else:
            # Straight plunge
            lines.append(f"G01 X{x_end:.4f} F{feed}  (Cutoff plunge)")
            lines.append(f"")

        lines.append(f"G00 X{x_start:.4f}  (Retract)")
        lines.append(f"M2")
        lines.append(f"")

        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Toolpath Simulation Widget
# ---------------------------------------------------------------------------
class ToolpathSimulator(QFrame):
    """Parses generated G-code and draws an animated 2D toolpath preview.
    Shows rapid moves (dashed red), feed moves (solid green), and
    the stock outline. Supports play/pause/reset with step-through."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(280)
        self.setStyleSheet(
            f"background-color: {COLORS['dro_bg']}; "
            f"border: 1px solid {COLORS['border']}; border-radius: 10px;"
        )

        # Parsed moves: list of (type, x, z) where type is 'rapid', 'feed', or 'pause'
        self.moves = []
        self.current_step = 0
        self.playing = False
        self.stock_profile = None  # (od, z_start, z_end) or (id, od, z_start, z_end)

        # Animation timer
        from PyQt5.QtCore import QTimer
        self.anim_timer = QTimer()
        self.anim_timer.timeout.connect(self._advance_step)
        self.anim_speed = 30  # ms per step

    def load_gcode(self, gcode_text):
        """Parse G-code text into a list of moves for simulation.
        X values in G-code are diameter — converted to radius for display."""
        self.moves = []
        self.current_step = 0
        self.playing = False
        self.anim_timer.stop()
        self.stock_profile = None

        import re

        x, z = 0.0, 0.0  # Track position in RADIUS (display coords)
        absolute = True
        move_type = "rapid"

        for raw_line in gcode_text.splitlines():
            line = raw_line.split(";")[0].split("(")[0].strip().upper()
            if not line:
                continue

            # Track modal state
            if "G90" in line:
                absolute = True
            if "G91" in line:
                absolute = False
            if line.strip() in ("M0", "M00") or re.match(r'^M0\b', line):
                self.moves.append(("pause", x, z))
                continue
            if "M2" in line or "M30" in line:
                break

            # --- G76 threading cycle expansion ---
            g76_match = re.search(r'G76', line)
            if g76_match:
                # Parse G76 parameters: P (pitch), Z (end), K (depth on radius),
                # J (first cut on radius), I (taper)
                p_m = re.search(r'P([+\-]?[\d.]+)', line)
                z_m = re.search(r'Z([+\-]?[\d.]+)', line)
                k_m = re.search(r'K([+\-]?[\d.]+)', line)
                j_m = re.search(r'J([+\-]?[\d.]+)', line)

                if p_m and z_m and k_m:
                    pitch = float(p_m.group(1))
                    z_end = float(z_m.group(1))
                    full_depth = float(k_m.group(1))  # on radius
                    first_cut = float(j_m.group(1)) if j_m else full_depth / 5.0

                    # Simulate threading passes (compound infeed)
                    start_x_r = x  # Current X in radius
                    start_z = z
                    cut_depth = 0.0
                    pass_depth = first_cut
                    pass_num = 0

                    while cut_depth < full_depth:
                        cut_depth = min(cut_depth + pass_depth, full_depth)
                        cut_x_r = start_x_r - cut_depth  # Cutting into the part

                        # Rapid to start X
                        self.moves.append(("rapid", cut_x_r, start_z))
                        # Feed along Z (threading pass)
                        self.moves.append(("feed", cut_x_r, z_end))
                        # Retract X
                        self.moves.append(("rapid", start_x_r, z_end))
                        # Rapid back to Z start
                        self.moves.append(("rapid", start_x_r, start_z))

                        # Reduce depth per pass (degression)
                        pass_num += 1
                        if pass_num > 1:
                            pass_depth = max(first_cut / math.sqrt(pass_num), 0.002)

                    x, z = start_x_r, start_z
                continue

            # Determine move type from G codes
            if re.search(r'\bG0*0\b', line):
                move_type = "rapid"
            elif re.search(r'\bG0*1\b', line):
                move_type = "feed"

            # Parse X and Z values — X is diameter in G-code, convert to radius
            new_x, new_z = x, z
            x_match = re.search(r'X([+\-]?[\d.]+)', line)
            z_match = re.search(r'Z([+\-]?[\d.]+)', line)

            if x_match:
                val = float(x_match.group(1))
                if absolute:
                    new_x = val / 2.0  # Diameter to radius
                else:
                    new_x = x + val / 2.0
            if z_match:
                val = float(z_match.group(1))
                new_z = val if absolute else z + val

            if new_x != x or new_z != z:
                self.moves.append((move_type, new_x, new_z))
                x, z = new_x, new_z

        # --- Detect stock profile from comments ---
        for raw_line in gcode_text.splitlines():
            # OD turning: "Stock: 2.0000 dia"
            if "Stock:" in raw_line and "dia" in raw_line.lower():
                m = re.search(r'Stock:\s*([\d.]+)', raw_line)
                if m:
                    od = float(m.group(1))
                    for l2 in gcode_text.splitlines():
                        zm = re.search(r'Z range:\s*([+\-]?[\d.]+)\s*to\s*([+\-]?[\d.]+)', l2)
                        if zm:
                            self.stock_profile = (od, float(zm.group(1)), float(zm.group(2)))
                            break
                    if not self.stock_profile:
                        self.stock_profile = (od, 0.1, -3.0)
                break
            # Boring: "Bore: 0.5000 dia → 1.0000 dia"
            if "Bore:" in raw_line:
                m = re.search(r'Bore:\s*([\d.]+).*?→\s*([\d.]+)', raw_line)
                if m:
                    od = float(m.group(2))  # Use finish bore as outer reference
                    for l2 in gcode_text.splitlines():
                        zm = re.search(r'Z range:\s*([+\-]?[\d.]+)\s*to\s*([+\-]?[\d.]+)', l2)
                        if zm:
                            self.stock_profile = (od * 1.5, float(zm.group(1)), float(zm.group(2)))
                            break
                break
            # Cutoff: "OD: 2.0000"
            if "OD:" in raw_line and "Cutoff" in gcode_text[:200]:
                m = re.search(r'OD:\s*([\d.]+)', raw_line)
                if m:
                    od = float(m.group(1))
                    zm = re.search(r'Z position:\s*([+\-]?[\d.]+)', gcode_text)
                    z_pos = float(zm.group(1)) if zm else -2.0
                    self.stock_profile = (od, 0.1, z_pos - 0.5)
                break
            # Threading: "Major: 1.0000"
            if "Major:" in raw_line:
                m = re.search(r'Major:\s*([\d.]+)', raw_line)
                if m:
                    od = float(m.group(1))
                    for l2 in gcode_text.splitlines():
                        if "Length:" in l2:
                            lm = re.search(r'Length:\s*([\d.]+)', l2)
                            if lm:
                                length = float(lm.group(1))
                                self.stock_profile = (od, 0.15, -(length + 0.2))
                                break
                break

        self.update()

    def play(self):
        self.playing = True
        self.anim_timer.start(self.anim_speed)

    def pause(self):
        self.playing = False
        self.anim_timer.stop()

    def reset(self):
        self.current_step = 0
        self.playing = False
        self.anim_timer.stop()
        self.update()

    def step_forward(self):
        if self.current_step < len(self.moves):
            self.current_step += 1
            self.update()

    def set_speed(self, ms_per_step):
        self.anim_speed = max(5, ms_per_step)
        if self.playing:
            self.anim_timer.setInterval(self.anim_speed)

    def show_all(self):
        """Jump to end — show complete toolpath."""
        self.current_step = len(self.moves)
        self.playing = False
        self.anim_timer.stop()
        self.update()

    def _advance_step(self):
        if self.current_step < len(self.moves):
            move_type = self.moves[self.current_step][0]
            self.current_step += 1
            if move_type == "pause":
                self.pause()  # Stop at M0 pauses
            self.update()
        else:
            self.pause()

    def paintEvent(self, event):
        from PyQt5.QtGui import QPainter, QPen, QBrush
        from PyQt5.QtCore import QPointF, QRectF

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        w = self.width()
        h = self.height()
        margin = 36
        readout_h = 48  # Reserved strip at bottom for coordinate readout

        plot_w = w - 2 * margin
        plot_h = h - 2 * margin - readout_h

        if plot_w <= 0 or plot_h <= 0 or not self.moves:
            # Empty state
            painter.fillRect(self.rect(), QColor(COLORS["dro_bg"]))
            painter.setPen(QColor(COLORS["text_dim"]))
            painter.setFont(mono_font(12))
            painter.drawText(self.rect(), Qt.AlignCenter, "Generate G-code, then click Simulate")
            painter.end()
            return

        painter.fillRect(self.rect(), QColor(COLORS["dro_bg"]))

        # Compute bounds from all moves
        all_x = [0.0] + [m[1] for m in self.moves]
        all_z = [0.0] + [m[2] for m in self.moves]
        x_min, x_max = min(all_x), max(all_x)
        z_min, z_max = min(all_z), max(all_z)

        # Include stock profile in bounds
        if self.stock_profile:
            od = self.stock_profile[0]
            x_max = max(x_max, od / 2.0 + 0.1)
            if len(self.stock_profile) >= 3:
                z_min = min(z_min, self.stock_profile[2] - 0.1)
                z_max = max(z_max, self.stock_profile[1] + 0.1)

        # Padding
        x_range = max(x_max - x_min, 0.5)
        z_range = max(z_max - z_min, 0.5)
        pad = 0.15
        x_min -= x_range * pad
        x_max += x_range * pad
        z_min -= z_range * pad
        z_max += z_range * pad
        x_range = x_max - x_min
        z_range = z_max - z_min

        def to_screen(x, z):
            """Lathe view: Z horizontal, X vertical (positive up)."""
            sx = margin + (z - z_min) / z_range * plot_w
            sy = margin + (x_max - x) / x_range * plot_h
            return QPointF(sx, sy)

        # --- Stock outline ---
        if self.stock_profile:
            od = self.stock_profile[0]
            r = od / 2.0
            sz_start = self.stock_profile[1] if len(self.stock_profile) >= 3 else 0.0
            sz_end = self.stock_profile[2] if len(self.stock_profile) >= 3 else z_min

            stock_pen = QPen(QColor(COLORS["accent_yellow"]), 1.5, Qt.DashLine)
            painter.setPen(stock_pen)
            painter.setBrush(Qt.NoBrush)

            # Draw stock rectangle (top half — lathe is symmetric about centerline)
            p1 = to_screen(r, sz_start)
            p2 = to_screen(r, sz_end)
            p3 = to_screen(0, sz_end)
            p4 = to_screen(0, sz_start)
            from PyQt5.QtGui import QPolygonF
            painter.drawPolygon(QPolygonF([p1, p2, p3, p4]))

            # Centerline
            cl_pen = QPen(QColor(COLORS["text_dim"]), 1, Qt.DashDotLine)
            painter.setPen(cl_pen)
            cl_y = to_screen(0, 0).y()
            painter.drawLine(QPointF(margin, cl_y), QPointF(w - margin, cl_y))

        # --- Draw toolpath ---
        prev_x, prev_z = 0.0, 0.0
        for i in range(min(self.current_step, len(self.moves))):
            move_type, mx, mz = self.moves[i]

            if move_type == "pause":
                prev_x, prev_z = mx, mz
                continue

            p1 = to_screen(prev_x, prev_z)
            p2 = to_screen(mx, mz)

            if move_type == "rapid":
                pen = QPen(QColor(COLORS["accent"]), 1, Qt.DashLine)
            else:
                pen = QPen(QColor(COLORS["accent_green"]), 2, Qt.SolidLine)

            painter.setPen(pen)
            painter.drawLine(p1, p2)
            prev_x, prev_z = mx, mz

        # --- Current tool position ---
        if self.current_step > 0:
            last_idx = min(self.current_step, len(self.moves)) - 1
            _, cx, cz = self.moves[last_idx]
            cp = to_screen(cx, cz)

            # Tool marker
            painter.setPen(QPen(QColor("#ffffff"), 2))
            painter.setBrush(QBrush(QColor("#ffffff")))
            painter.drawEllipse(cp, 4, 4)
            ch = 8
            painter.drawLine(QPointF(cp.x() - ch, cp.y()), QPointF(cp.x() + ch, cp.y()))
            painter.drawLine(QPointF(cp.x(), cp.y() - ch), QPointF(cp.x(), cp.y() + ch))

        # --- Axis labels ---
        painter.setPen(QColor(COLORS["text_dim"]))
        painter.setFont(mono_font(9))
        painter.drawText(QRectF(w / 2 - 10, h - 14, 20, 14), Qt.AlignCenter, "Z")
        painter.drawText(QRectF(2, h / 2 - 7, 14, 14), Qt.AlignCenter, "X")

        # --- Legend ---
        painter.setFont(mono_font(9))
        lx = margin + 4
        ly = margin + 4
        painter.setPen(QPen(QColor(COLORS["accent"]), 1, Qt.DashLine))
        painter.drawLine(QPointF(lx, ly + 6), QPointF(lx + 20, ly + 6))
        painter.setPen(QColor(COLORS["text_dim"]))
        painter.drawText(QRectF(lx + 24, ly, 50, 14), Qt.AlignLeft, "Rapid")

        ly += 16
        painter.setPen(QPen(QColor(COLORS["accent_green"]), 2))
        painter.drawLine(QPointF(lx, ly + 6), QPointF(lx + 20, ly + 6))
        painter.setPen(QColor(COLORS["text_dim"]))
        painter.drawText(QRectF(lx + 24, ly, 50, 14), Qt.AlignLeft, "Feed")

        # --- Step counter ---
        painter.setPen(QColor(COLORS["text_secondary"]))
        painter.setFont(mono_font(10))
        step_text = f"Step {self.current_step}/{len(self.moves)}"
        painter.drawText(QRectF(w - margin - 100, margin + 4, 100, 16), Qt.AlignRight, step_text)

        # --- Coordinate readout bar (below plot area) ---
        readout_y = h - readout_h
        # Background bar
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(QColor(COLORS["bg_mid"])))
        painter.drawRoundedRect(QRectF(margin, readout_y, plot_w, readout_h), 6, 6)

        # Divider line
        painter.setPen(QPen(QColor(COLORS["border"]), 1))
        painter.drawLine(QPointF(margin, readout_y), QPointF(margin + plot_w, readout_y))

        if self.current_step > 0 and self.current_step <= len(self.moves):
            last_move = self.moves[self.current_step - 1]
            mv_type, mv_x, mv_z = last_move
            mv_x_dia = mv_x * 2.0

            # Move type badge
            if mv_type == "rapid":
                type_color = QColor(COLORS["accent"])
                type_text = "RAPID"
            elif mv_type == "feed":
                type_color = QColor(COLORS["accent_green"])
                type_text = "FEED"
            elif mv_type == "pause":
                type_color = QColor(COLORS["accent_yellow"])
                type_text = "PAUSE"
            else:
                type_color = QColor(COLORS["text_dim"])
                type_text = "—"

            # Badge background
            badge_w = 60
            painter.setPen(Qt.NoPen)
            painter.setBrush(QBrush(type_color))
            painter.drawRoundedRect(QRectF(margin + 8, readout_y + 12, badge_w, 24), 4, 4)
            painter.setPen(QColor("#111113"))
            painter.setFont(mono_font(11, QFont.Bold))
            painter.drawText(QRectF(margin + 8, readout_y + 12, badge_w, 24), Qt.AlignCenter, type_text)

            # X value
            col2_x = margin + 80
            painter.setPen(QColor(COLORS["accent_blue"]))
            painter.setFont(mono_font(13, QFont.Bold))
            painter.drawText(QRectF(col2_x, readout_y + 6, 30, 18), Qt.AlignRight | Qt.AlignVCenter, "X")
            painter.setPen(QColor(COLORS["dro_text"]))
            painter.setFont(mono_font(15, QFont.Bold))
            painter.drawText(QRectF(col2_x + 34, readout_y + 4, 140, 20), Qt.AlignLeft | Qt.AlignVCenter,
                             f"{mv_x_dia:+.4f}")
            painter.setPen(QColor(COLORS["text_dim"]))
            painter.setFont(mono_font(10))
            painter.drawText(QRectF(col2_x + 34, readout_y + 26, 140, 16), Qt.AlignLeft | Qt.AlignVCenter,
                             f"R {mv_x:+.4f}")

            # Z value
            col3_x = margin + 270
            painter.setPen(QColor(COLORS["accent_blue"]))
            painter.setFont(mono_font(13, QFont.Bold))
            painter.drawText(QRectF(col3_x, readout_y + 6, 30, 18), Qt.AlignRight | Qt.AlignVCenter, "Z")
            painter.setPen(QColor(COLORS["dro_text"]))
            painter.setFont(mono_font(15, QFont.Bold))
            painter.drawText(QRectF(col3_x + 34, readout_y + 4, 140, 20), Qt.AlignLeft | Qt.AlignVCenter,
                             f"{mv_z:+.4f}")

            # Step counter
            painter.setPen(QColor(COLORS["text_secondary"]))
            painter.setFont(mono_font(10))
            step_text = f"Step {self.current_step}/{len(self.moves)}"
            painter.drawText(QRectF(w - margin - 90, readout_y + 14, 82, 18), Qt.AlignRight | Qt.AlignVCenter, step_text)
        else:
            # Starting position
            col2_x = margin + 80
            painter.setPen(QColor(COLORS["accent_blue"]))
            painter.setFont(mono_font(13, QFont.Bold))
            painter.drawText(QRectF(col2_x, readout_y + 14, 30, 18), Qt.AlignRight | Qt.AlignVCenter, "X")
            painter.setPen(QColor(COLORS["text_dim"]))
            painter.setFont(mono_font(15, QFont.Bold))
            painter.drawText(QRectF(col2_x + 34, readout_y + 14, 140, 18), Qt.AlignLeft | Qt.AlignVCenter,
                             "+0.0000")

            col3_x = margin + 270
            painter.setPen(QColor(COLORS["accent_blue"]))
            painter.setFont(mono_font(13, QFont.Bold))
            painter.drawText(QRectF(col3_x, readout_y + 14, 30, 18), Qt.AlignRight | Qt.AlignVCenter, "Z")
            painter.setPen(QColor(COLORS["text_dim"]))
            painter.setFont(mono_font(15, QFont.Bold))
            painter.drawText(QRectF(col3_x + 34, readout_y + 14, 140, 18), Qt.AlignLeft | Qt.AlignVCenter,
                             "+0.0000")

            painter.setPen(QColor(COLORS["text_dim"]))
            painter.setFont(mono_font(10))
            painter.drawText(QRectF(margin + 8, readout_y + 14, 60, 18), Qt.AlignCenter, "Ready")

        painter.end()


# ---------------------------------------------------------------------------
# Process Step Row — one operation in the Mazatrol-style process list
# ---------------------------------------------------------------------------
OP_TYPES = ["OD Turning", "Boring", "Threading", "Cutoff"]

class ProcessStepRow(QFrame):
    """A single row in the process list — shows step number, operation type,
    key parameters summary, and expand/collapse for full editing."""

    removed = None  # Signal placeholder

    def __init__(self, step_num=1, parent=None):
        super().__init__(parent)
        self.step_num = step_num
        self._expanded = False
        self._panel = None

        self.setStyleSheet(
            f"QFrame {{ background-color: {COLORS['bg_mid']}; "
            f"border: 1px solid {COLORS['border']}; border-radius: 10px; "
            f"margin: 1px 0px; }}"
        )

        self.main_layout = QVBoxLayout(self)
        self.main_layout.setSpacing(4)
        self.main_layout.setContentsMargins(8, 6, 8, 6)

        # --- Header row (always visible) ---
        header = QHBoxLayout()
        header.setSpacing(8)

        self.step_label = QLabel(f"#{step_num}")
        self.step_label.setFont(mono_font(16, QFont.Bold))
        self.step_label.setStyleSheet(f"color: {COLORS['accent_yellow']}; background: transparent; border: none;")
        self.step_label.setFixedWidth(36)
        header.addWidget(self.step_label)

        self.op_combo = QComboBox()
        self.op_combo.addItems(OP_TYPES)
        self.op_combo.setFixedWidth(140)
        self.op_combo.currentIndexChanged.connect(self._on_op_changed)
        header.addWidget(self.op_combo)

        self.summary_label = QLabel("— click to configure —")
        self.summary_label.setStyleSheet(f"color: {COLORS['text_dim']}; background: transparent; border: none; font-size: 12px;")
        header.addWidget(self.summary_label, stretch=1)

        self.btn_expand = QPushButton("Edit")
        self.btn_expand.setFixedWidth(60)
        self.btn_expand.setStyleSheet(
            f"QPushButton {{ min-height: 28px; font-size: 12px; border: none; "
            f"background: {COLORS['bg_light']}; border-radius: 6px; }}"
        )
        self.btn_expand.clicked.connect(self.toggle_expand)
        header.addWidget(self.btn_expand)

        self.btn_move_up = QPushButton("▲")
        self.btn_move_up.setFixedSize(28, 28)
        self.btn_move_up.setStyleSheet(f"QPushButton {{ border: none; border-radius: 6px; font-size: 12px; background: {COLORS['bg_light']}; }}")
        header.addWidget(self.btn_move_up)

        self.btn_move_down = QPushButton("▼")
        self.btn_move_down.setFixedSize(28, 28)
        self.btn_move_down.setStyleSheet(f"QPushButton {{ border: none; border-radius: 6px; font-size: 12px; background: {COLORS['bg_light']}; }}")
        header.addWidget(self.btn_move_down)

        self.btn_remove = QPushButton("✕")
        self.btn_remove.setFixedSize(28, 28)
        self.btn_remove.setStyleSheet(
            f"QPushButton {{ border: none; border-radius: 6px; font-size: 12px; "
            f"background: {COLORS['accent']}; color: white; }}"
        )
        header.addWidget(self.btn_remove)

        self.main_layout.addLayout(header)

        # --- Detail panel (hidden by default) ---
        self.detail_container = QWidget()
        self.detail_layout = QVBoxLayout(self.detail_container)
        self.detail_layout.setContentsMargins(36, 4, 0, 4)
        self.detail_container.setVisible(False)
        self.main_layout.addWidget(self.detail_container)

        # Create initial panel
        self._on_op_changed(0)

    def _on_op_changed(self, idx):
        """Swap the detail panel when operation type changes."""
        # Clear old panel
        if self._panel:
            self.detail_layout.removeWidget(self._panel)
            self._panel.deleteLater()
            self._panel = None

        creators = [ODTurningPanel, BoringPanel, ThreadingPanel, CutoffPanel]
        if 0 <= idx < len(creators):
            self._panel = creators[idx]()
            self.detail_layout.addWidget(self._panel)

        self._update_summary()

    def toggle_expand(self):
        self._expanded = not self._expanded
        self.detail_container.setVisible(self._expanded)
        self.btn_expand.setText("Close" if self._expanded else "Edit")

    def set_step_num(self, num):
        self.step_num = num
        self.step_label.setText(f"#{num}")

    def _update_summary(self):
        """Build a short summary string from the panel's current values."""
        if not self._panel:
            self.summary_label.setText("—")
            return

        op = self.op_combo.currentText()
        try:
            if isinstance(self._panel, ODTurningPanel):
                s = (f"{self._panel.stock_dia.text()}→{self._panel.finish_dia.text()} dia, "
                     f"Z {self._panel.z_start.text()} to {self._panel.z_end.text()}, "
                     f"DOC {self._panel.doc.text()}")
            elif isinstance(self._panel, BoringPanel):
                s = (f"Bore {self._panel.start_dia.text()}→{self._panel.finish_dia.text()} dia, "
                     f"Z {self._panel.z_start.text()} to {self._panel.z_end.text()}")
            elif isinstance(self._panel, ThreadingPanel):
                s = (f"{self._panel.major_dia.text()} dia, "
                     f"{self._panel.pitch.text()} TPI, "
                     f"L={self._panel.thread_length.text()}")
            elif isinstance(self._panel, CutoffPanel):
                s = (f"OD {self._panel.od.text()}, "
                     f"Z {self._panel.z_pos.text()}, "
                     f"blade {self._panel.blade_width.text()}")
            else:
                s = "—"
        except Exception:
            s = "—"
        self.summary_label.setText(s)

    def generate_gcode(self):
        """Generate G-code for this step."""
        if self._panel:
            self._update_summary()
            return self._panel.generate_gcode()
        return ""


# ---------------------------------------------------------------------------
# Main Conversational Tab — Mazatrol-style process list
# ---------------------------------------------------------------------------
class ConversationalTab(QWidget):
    """Mazatrol-style conversational programming with a sequential process list.
    Uses the main PositionGraph for toolpath simulation instead of a separate widget.
    Call set_position_graph() after construction to connect to the main graph."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._graph = None  # Set via set_position_graph()
        layout = QHBoxLayout(self)
        layout.setSpacing(8)

        # ===== LEFT: Process list =====
        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setSpacing(6)
        left_layout.setContentsMargins(0, 0, 0, 0)

        hdr = QHBoxLayout()
        title = QLabel("Process List")
        title.setFont(ui_font(15, QFont.Bold))
        title.setStyleSheet(f"color: {COLORS['text']}; background: transparent;")
        hdr.addWidget(title)
        hdr.addStretch()

        self.btn_add = QPushButton("+ Add Step")
        self.btn_add.setStyleSheet(
            f"QPushButton {{ background-color: {COLORS['accent_blue']}; color: #ffffff; "
            f"font-weight: 700; border: none; border-radius: 8px; "
            f"min-height: 32px; padding: 0 16px; }}"
        )
        self.btn_add.clicked.connect(self.add_step)
        hdr.addWidget(self.btn_add)
        left_layout.addLayout(hdr)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet(f"QScrollArea {{ border: none; background: {COLORS['bg_dark']}; }}")
        self.step_container = QWidget()
        self.step_list_layout = QVBoxLayout(self.step_container)
        self.step_list_layout.setSpacing(4)
        self.step_list_layout.setContentsMargins(2, 2, 2, 2)
        self.step_list_layout.addStretch()
        scroll.setWidget(self.step_container)
        left_layout.addWidget(scroll, stretch=1)

        self.steps = []
        self.add_step()
        layout.addWidget(left, stretch=1)

        # ===== RIGHT: Generate + playback controls + G-code preview (expanded) =====
        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setSpacing(6)
        right_layout.setContentsMargins(0, 0, 0, 0)

        # Generate button
        self.btn_generate = QPushButton("Generate All")
        self.btn_generate.setStyleSheet(
            f"QPushButton {{ background-color: {COLORS['accent_blue']}; color: #ffffff; "
            f"font-size: 15px; min-height: 44px; font-weight: 700; "
            f"border-radius: 10px; border: none; }}"
            f"QPushButton:hover {{ background-color: #3a9bff; }}"
        )
        self.btn_generate.clicked.connect(self.generate)
        right_layout.addWidget(self.btn_generate)

        # Playback controls (drive the main graph's sim mode)
        ctrl_bar = QHBoxLayout()
        ctrl_bar.setSpacing(4)

        self.btn_sim_play = QPushButton("▶ Play")
        self.btn_sim_play.setStyleSheet(
            f"QPushButton {{ background-color: {COLORS['accent_green']}; color: #111113; "
            f"font-weight: 700; border: none; border-radius: 6px; min-height: 30px; padding: 0 12px; }}"
        )
        self.btn_sim_play.clicked.connect(self._sim_play_pause)
        ctrl_bar.addWidget(self.btn_sim_play)

        self.btn_sim_step = QPushButton("Step ▶|")
        self.btn_sim_step.setStyleSheet(f"QPushButton {{ min-height: 30px; padding: 0 10px; }}")
        self.btn_sim_step.clicked.connect(self._sim_step)
        ctrl_bar.addWidget(self.btn_sim_step)

        self.btn_sim_reset = QPushButton("⟲ Reset")
        self.btn_sim_reset.setStyleSheet(f"QPushButton {{ min-height: 30px; padding: 0 10px; }}")
        self.btn_sim_reset.clicked.connect(self._sim_reset)
        ctrl_bar.addWidget(self.btn_sim_reset)

        self.btn_sim_all = QPushButton("Show All")
        self.btn_sim_all.setStyleSheet(f"QPushButton {{ min-height: 30px; padding: 0 10px; }}")
        self.btn_sim_all.clicked.connect(self._sim_show_all)
        ctrl_bar.addWidget(self.btn_sim_all)

        ctrl_bar.addWidget(QLabel("Speed:"))
        self.speed_combo = QComboBox()
        self.speed_combo.addItems(["Slow", "Normal", "Fast", "Instant"])
        self.speed_combo.setCurrentIndex(1)
        self.speed_combo.currentIndexChanged.connect(self._set_sim_speed)
        ctrl_bar.addWidget(self.speed_combo)
        ctrl_bar.addStretch()
        right_layout.addLayout(ctrl_bar)

        # G-code preview (now gets all the space formerly used by sim widget)
        preview_group = QGroupBox("G-code Preview")
        pg = QVBoxLayout(preview_group)
        self.gcode_preview = QTextEdit()
        self.gcode_preview.setFont(mono_font(12))
        self.gcode_preview.setPlaceholderText("Click 'Generate All' to build program from process list...")
        self.gcode_preview.setStyleSheet(
            f"background-color: {COLORS['dro_bg']}; color: {COLORS['dro_text']}; "
            f"border: 1px solid {COLORS['border']}; border-radius: 8px; padding: 8px;"
        )
        pg.addWidget(self.gcode_preview)
        right_layout.addWidget(preview_group, stretch=1)

        # Action buttons
        action_bar = QHBoxLayout()
        self.btn_save = QPushButton("Save .ngc")
        self.btn_save.setStyleSheet(
            f"QPushButton {{ background-color: {COLORS['accent_green']}; color: #111113; "
            f"font-weight: 700; border: none; border-radius: 8px; min-height: 38px; }}"
        )
        self.btn_save.clicked.connect(self.save_file)
        action_bar.addWidget(self.btn_save)

        self.btn_send = QPushButton("Send to Program Tab")
        self.btn_send.setStyleSheet(
            f"QPushButton {{ background-color: {COLORS['accent_orange']}; color: #111113; "
            f"font-weight: 700; border: none; border-radius: 8px; min-height: 38px; }}"
        )
        action_bar.addWidget(self.btn_send)

        self.btn_copy = QPushButton("Copy to Clipboard")
        action_bar.addWidget(self.btn_copy)
        self.btn_copy.clicked.connect(self.copy_to_clipboard)
        right_layout.addLayout(action_bar)

        layout.addWidget(right, stretch=1)

    def set_position_graph(self, graph):
        """Connect to the main PositionGraph for simulation display."""
        self._graph = graph

    # --- Process list management ---
    def add_step(self):
        step_num = len(self.steps) + 1
        row = ProcessStepRow(step_num)
        row.btn_remove.clicked.connect(lambda checked, r=row: self.remove_step(r))
        row.btn_move_up.clicked.connect(lambda checked, r=row: self.move_step(r, -1))
        row.btn_move_down.clicked.connect(lambda checked, r=row: self.move_step(r, 1))
        self.steps.append(row)
        self.step_list_layout.insertWidget(self.step_list_layout.count() - 1, row)

    def remove_step(self, row):
        if row in self.steps:
            self.steps.remove(row)
            self.step_list_layout.removeWidget(row)
            row.deleteLater()
            self._renumber()

    def move_step(self, row, direction):
        if row not in self.steps:
            return
        idx = self.steps.index(row)
        new_idx = idx + direction
        if 0 <= new_idx < len(self.steps):
            self.steps[idx], self.steps[new_idx] = self.steps[new_idx], self.steps[idx]
            for s in self.steps:
                self.step_list_layout.removeWidget(s)
            for s in self.steps:
                self.step_list_layout.insertWidget(self.step_list_layout.count() - 1, s)
            self._renumber()

    def _renumber(self):
        for i, step in enumerate(self.steps):
            step.set_step_num(i + 1)

    # --- G-code generation ---
    def generate(self):
        if not self.steps:
            return

        lines = [
            f"; Conversational Program — {len(self.steps)} operation(s)",
            f"; Generated by My-Lathe GUI",
            f"",
            f"G20 G18 G40 G49 G80  (Inch, XZ plane, cancel comp)",
            f"G90                   (Absolute mode)",
            f"",
        ]

        for i, step in enumerate(self.steps):
            op_name = step.op_combo.currentText()
            lines.append(f"; {'='*60}")
            lines.append(f"; STEP {i+1}: {op_name}")
            lines.append(f"; {'='*60}")

            step_gcode = step.generate_gcode()
            filtered = []
            skip_preamble = True
            for gl in step_gcode.splitlines():
                stripped = gl.strip()
                if skip_preamble:
                    if stripped.startswith("G20") or stripped.startswith("G90"):
                        continue
                    if stripped == "":
                        continue
                    if stripped.startswith(";") and i > 0:
                        if any(kw in stripped for kw in ["Conversational", "Stock:", "Bore:", "Rough DOC",
                                                          "Finish DOC", "Suggested RPM", "Retract"]):
                            filtered.append(gl)
                            continue
                    skip_preamble = False
                if stripped in ("M2", "M2  (Program end)"):
                    continue
                filtered.append(gl)

            lines.extend(filtered)
            lines.append(f"")

            if i < len(self.steps) - 1:
                next_op = self.steps[i + 1].op_combo.currentText()
                lines.append(f"M0  (PAUSE — Step {i+1} complete. Next: Step {i+2} {next_op}. Cycle Start to continue.)")
                lines.append(f"")

        lines.append(f"M2  (Program end)")
        lines.append(f"")

        full_gcode = "\n".join(lines)
        self.gcode_preview.setText(full_gcode)

        # Send to main position graph for simulation
        if self._graph:
            self._graph.sim_load(full_gcode)

    # --- Simulation controls (delegate to main graph) ---
    def _sim_play_pause(self):
        if not self._graph:
            return
        if self._graph._sim_playing:
            self._graph.sim_pause()
            self.btn_sim_play.setText("▶ Play")
        else:
            self._graph.sim_play()
            self.btn_sim_play.setText("⏸ Pause")

    def _sim_step(self):
        if self._graph:
            self._graph.sim_step_forward()

    def _sim_reset(self):
        if self._graph:
            self._graph.sim_reset()
            self.btn_sim_play.setText("▶ Play")

    def _sim_show_all(self):
        if self._graph:
            self._graph.sim_show_all()

    def _set_sim_speed(self, idx):
        if self._graph:
            speeds = {0: 80, 1: 30, 2: 10, 3: 1}
            self._graph.sim_set_speed(speeds.get(idx, 30))

    # --- File actions ---
    def save_file(self):
        gcode = self.gcode_preview.toPlainText()
        if not gcode.strip():
            return
        fname, _ = QFileDialog.getSaveFileName(
            self, "Save G-code", "",
            "G-code Files (*.ngc *.nc);;All Files (*)"
        )
        if fname:
            try:
                with open(fname, "w") as f:
                    f.write(gcode)
            except Exception as e:
                QMessageBox.warning(self, "Save Error", str(e))

    def copy_to_clipboard(self):
        from PyQt5.QtWidgets import QApplication
        gcode = self.gcode_preview.toPlainText()
        if gcode.strip():
            QApplication.clipboard().setText(gcode)
