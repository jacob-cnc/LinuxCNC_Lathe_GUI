#!/usr/bin/env python3
"""
My-Lathe Custom GUI for LinuxCNC
=================================
Main window and entry point. All widgets, tabs, and theme are
imported from their respective modules.

Usage:
  Set DISPLAY = lathe_gui.py in the INI file, or run standalone
  for development/testing.
"""

import sys
import os

# Ensure the gui/ directory is on sys.path so bare imports (theme, widgets,
# tabs, etc.) resolve correctly regardless of the working directory.
# LinuxCNC launches DISPLAY scripts from the config directory, not gui/.
_GUI_DIR = os.path.dirname(os.path.abspath(__file__))
if _GUI_DIR not in sys.path:
    sys.path.insert(0, _GUI_DIR)
os.chdir(_GUI_DIR)

# LinuxCNC modules — graceful fallback for offline/Windows development
try:
    import linuxcnc
    import hal
    HAS_LINUXCNC = True
except ImportError:
    HAS_LINUXCNC = False
    print("LinuxCNC modules not found — running in offline preview mode")

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QTabWidget, QFrame, QComboBox, QLineEdit,
    QGroupBox, QFileDialog, QStatusBar, QMessageBox, QGraphicsDropShadowEffect
)
from PyQt5.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve
from PyQt5.QtGui import QFont, QPainter, QColor

from theme import COLORS, STYLESHEET, TOUCH_SIZES, FONT_SIZES, LAYOUT, load_bundled_fonts, mono_font, ui_font
from widgets import DROWidget, StatusIndicator
from widgets_fence import GoToFenceWidget
from position_graph import PositionGraph
from tabs import ManualTab, ProgramTab, MDITab, ToolTab, OffsetsTab, TuningTab, EditTab, HALMonitorTab, GCodeRefTab
from conv_profile import ProfileConvTab
from line_numbers import resolve_n_word
from limit_manager import LimitManager
from limit_enforcer import LimitEnforcer
from limits_view import LimitsView


class ToolChangeOverlay(QWidget):
    """Semi-transparent overlay shown during M6 tool change pauses.

    Displays the tool number and description prominently over the main
    window. Disappears automatically when cycle start resumes the program.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, False)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.hide()

        # Main layout
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)

        # Container frame for the prompt content
        self._frame = QFrame()
        self._frame.setStyleSheet(
            f"QFrame {{ "
            f"background-color: rgba(26, 32, 40, 230); "
            f"border: 3px solid {COLORS['accent_yellow']}; "
            f"border-radius: 20px; "
            f"padding: 30px; }}"
        )
        frame_layout = QVBoxLayout(self._frame)
        frame_layout.setSpacing(16)
        frame_layout.setContentsMargins(50, 30, 50, 30)

        # "TOOL CHANGE" header
        self._header = QLabel("TOOL CHANGE")
        self._header.setFont(ui_font(20, QFont.Bold))
        self._header.setAlignment(Qt.AlignCenter)
        self._header.setStyleSheet(
            f"color: {COLORS['accent_yellow']}; background: transparent;"
        )
        frame_layout.addWidget(self._header)

        # Tool number (large)
        self._tool_label = QLabel("T1")
        self._tool_label.setFont(mono_font(48, QFont.Bold))
        self._tool_label.setAlignment(Qt.AlignCenter)
        self._tool_label.setStyleSheet(
            f"color: {COLORS['text']}; background: transparent;"
        )
        frame_layout.addWidget(self._tool_label)

        # Tool description
        self._desc_label = QLabel("")
        self._desc_label.setFont(ui_font(16, QFont.Normal))
        self._desc_label.setAlignment(Qt.AlignCenter)
        self._desc_label.setWordWrap(True)
        self._desc_label.setStyleSheet(
            f"color: {COLORS['text_secondary']}; background: transparent;"
        )
        frame_layout.addWidget(self._desc_label)

        # Instruction
        self._instruction = QLabel("Press CYCLE START to continue")
        self._instruction.setFont(ui_font(14, QFont.Normal))
        self._instruction.setAlignment(Qt.AlignCenter)
        self._instruction.setStyleSheet(
            f"color: {COLORS['accent_green_lt']}; background: transparent;"
        )
        frame_layout.addWidget(self._instruction)

        layout.addWidget(self._frame, alignment=Qt.AlignCenter)

        # Drop shadow for the frame
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(40)
        shadow.setColor(QColor(0, 0, 0, 180))
        shadow.setOffset(0, 4)
        self._frame.setGraphicsEffect(shadow)

    def show_tool_change(self, tool_number, tool_description=""):
        """Display the overlay with the given tool info."""
        self._tool_label.setText(f"T{tool_number}")
        if tool_description:
            self._desc_label.setText(tool_description)
            self._desc_label.show()
        else:
            self._desc_label.hide()
        self.show()
        self.raise_()

    def dismiss(self):
        """Hide the overlay."""
        self.hide()

    def paintEvent(self, event):
        """Draw semi-transparent background over the entire overlay area."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.fillRect(self.rect(), QColor(0, 0, 0, 140))
        super().paintEvent(event)


class LatheGUI(QMainWindow):
    """Main application window for the lathe GUI."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("My Lathe — LinuxCNC")
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setFixedSize(LAYOUT['window_width'], LAYOUT['window_height'])

        self.lcnc_stat = None
        self.lcnc_cmd = None
        self.lcnc_err = None
        self.connected = False
        self._connect_linuxcnc()
        self._setup_compound_hal()

        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QHBoxLayout(central)
        main_layout.setSpacing(LAYOUT['panel_spacing'])
        main_layout.setContentsMargins(LAYOUT['main_margin'], LAYOUT['main_margin'], LAYOUT['main_margin'], LAYOUT['main_margin'])

        # ===== LEFT SIDE =====
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setSpacing(6)
        left_layout.setContentsMargins(0, 0, 0, 0)

        # --- Machine state bar ---
        state_bar = QFrame()
        state_bar.setMinimumHeight(TOUCH_SIZES['state_bar_height'])
        state_layout = QHBoxLayout(state_bar)
        state_layout.setContentsMargins(8, 3, 8, 3)
        state_bar.setStyleSheet(
            f"background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, "
            f"stop:0 {COLORS['bg_light']}, stop:1 {COLORS['bg_mid']}); "
            f"border: 1px solid {COLORS['border']}; border-radius: 10px;"
        )

        self.ind_estop = StatusIndicator("E-Stop")
        self.ind_power = StatusIndicator("Power")
        self.ind_homed = StatusIndicator("Homed")
        self.ind_program = StatusIndicator("Program")

        self.state_label = QLabel("NOT CONNECTED")
        self.state_label.setFont(ui_font(FONT_SIZES['state_bar_mode'], QFont.Bold))
        self.state_label.setStyleSheet(f"color: {COLORS['accent']}; background: transparent;")

        self.mode_label = QLabel("[MANUAL]")
        self.mode_label.setFont(mono_font(FONT_SIZES['state_bar_mode'], QFont.Bold))
        self.mode_label.setStyleSheet(f"color: {COLORS['accent_blue_lt']}; background: transparent;")


        # Shutdown button (far left)
        self.btn_shutdown = QPushButton("✕ EXIT")
        self.btn_shutdown.setStyleSheet(
            f"QPushButton {{ "
            f"background-color: #6B2D2D; "
            f"border-radius: 10px; border: 1px solid #4A1F1F; "
            f"color: #D4A0A0; "
            f"padding: 4px 10px; font-size: {FONT_SIZES['state_bar_label']}px; "
            f"font-weight: 700; }}"
            f"QPushButton:hover {{ background-color: {COLORS['accent']}; color: #ffffff; }}"
            f"QPushButton:pressed {{ background-color: #8B1A1A; color: #ffffff; }}"
        )
        self.btn_shutdown.clicked.connect(self._confirm_shutdown)
        state_layout.addWidget(self.btn_shutdown)

        state_layout.addSpacing(6)

        state_layout.addWidget(self.ind_estop)
        state_layout.addWidget(self.ind_power)
        state_layout.addWidget(self.ind_homed)
        state_layout.addWidget(self.ind_program)

        # Inch/Metric toggle — prominent pill button
        self.btn_units_toggle = QPushButton("INCH")
        self.btn_units_toggle.setToolTip("Toggle display units (Inch / Metric)")
        self.btn_units_toggle.setFont(ui_font(12, QFont.Bold))
        self.btn_units_toggle.setStyleSheet(
            f"QPushButton {{ "
            f"background-color: qlineargradient(x1:0,y1:0,x2:0,y2:1, "
            f"  stop:0 {COLORS['accent_green_lt']}, stop:1 {COLORS['accent_green']}); "
            f"border-radius: 12px; border: 1px solid {COLORS['accent_green_dk']}; "
            f"border-bottom: 2px solid {COLORS['accent_green_dk']}; "
            f"color: {COLORS['bg_dark']}; "
            f"padding: 5px 14px; min-width: 52px; min-height: 0px; max-height: 32px; }}"
            f"QPushButton:hover {{ "
            f"  background-color: qlineargradient(x1:0,y1:0,x2:0,y2:1, "
            f"  stop:0 #d8e8b8, stop:1 {COLORS['accent_green_lt']}); }}"
            f"QPushButton:pressed {{ background-color: {COLORS['accent_green_dk']}; color: white; }}"
        )
        self.btn_units_toggle.clicked.connect(self._toggle_units_display)
        state_layout.addWidget(self.btn_units_toggle)

        state_layout.addStretch()

        # --- Status readouts (larger, right-aligned) ---
        self.gcodes_label = QLabel("G20 G54 G90 G94 G97")
        self.gcodes_label.setFont(mono_font(12, QFont.Bold))
        self.gcodes_label.setStyleSheet(f"color: {COLORS['accent_blue_lt']}; background: transparent;")
        state_layout.addWidget(self.gcodes_label)

        state_layout.addSpacing(10)

        self.override_feed_lbl = QLabel("Feed:100%")
        self.override_feed_lbl.setFont(mono_font(13, QFont.Bold))
        self.override_feed_lbl.setStyleSheet(f"color: {COLORS['text']}; background: transparent;")
        state_layout.addWidget(self.override_feed_lbl)

        self.override_rapid_lbl = QLabel("Rapid:100%")
        self.override_rapid_lbl.setFont(mono_font(13, QFont.Bold))
        self.override_rapid_lbl.setStyleSheet(f"color: {COLORS['text']}; background: transparent;")
        state_layout.addWidget(self.override_rapid_lbl)

        state_layout.addSpacing(10)

        self.spindle_rpm_lbl = QLabel("S:0")
        self.spindle_rpm_lbl.setFont(mono_font(13, QFont.Bold))
        self.spindle_rpm_lbl.setStyleSheet(f"color: {COLORS['accent_green']}; background: transparent;")
        state_layout.addWidget(self.spindle_rpm_lbl)

        self.feed_display = QLabel("0.0 in/min")
        self.feed_display.setFont(mono_font(13, QFont.Bold))
        self.feed_display.setStyleSheet(f"color: {COLORS['text']}; background: transparent;")
        state_layout.addWidget(self.feed_display)
        left_layout.addWidget(state_bar)

        # --- Position graph ---
        self.position_graph = PositionGraph()
        self.position_graph.setMinimumHeight(LAYOUT['graph_min_other'])
        left_layout.addWidget(self.position_graph, stretch=5)

        # --- Tabs ---
        self.tabs = QTabWidget()
        self.tabs.tabBar().setExpanding(True)
        self.tabs.tabBar().setUsesScrollButtons(False)
        self.tabs.tabBar().setDocumentMode(True)
        self.manual_tab = ManualTab()
        self.program_tab = ProgramTab()
        self.mdi_tab = MDITab()
        self.tool_tab = ToolTab(stat=self.lcnc_stat, cmd=self.lcnc_cmd)
        self.offsets_tab = OffsetsTab(
            stat=self.lcnc_stat, cmd=self.lcnc_cmd,
            var_file_path=os.path.join(os.path.dirname(_GUI_DIR), "my-lathe.var")
        )
        self.tuning_tab = TuningTab()
        self.conv_tab = ProfileConvTab()
        self.conv_tab.set_position_graph(self.position_graph)
        self.conv_tab.set_tool_tab(self.tool_tab)
        self.edit_tab = EditTab()

        self.tabs.addTab(self.manual_tab, "Manual")
        self.tabs.addTab(self.program_tab, "Program")
        self.tabs.addTab(self.conv_tab, "Conv")
        self.tabs.addTab(self.edit_tab, "Edit")
        self.tabs.addTab(self.mdi_tab, "MDI")
        self.tabs.addTab(self.tool_tab, "Tools")
        self.tabs.addTab(self.offsets_tab, "WCS")
        self.tabs.addTab(self.tuning_tab, "Tuning")

        self.hal_monitor_tab = HALMonitorTab(has_linuxcnc=HAS_LINUXCNC)
        self.tabs.addTab(self.hal_monitor_tab, "HAL")

        self.gcode_ref_tab = GCodeRefTab()
        self.tabs.addTab(self.gcode_ref_tab, "Codes")


        left_layout.addWidget(self.tabs, stretch=0)

        self._left_layout = left_layout
        self.tabs.currentChanged.connect(self._on_tab_changed)
        main_layout.addWidget(left_panel, stretch=LAYOUT['left_stretch'])

        # ===== RIGHT SIDE (2-column grid) =====
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setSpacing(6)
        right_layout.setContentsMargins(0, 0, 0, 0)

        # Grid for the 2-column layout
        grid = QGridLayout()
        grid.setSpacing(6)

        # --- C1R1: Tool Number ---
        tool_frame = QFrame()
        tool_frame.setStyleSheet(
            f"background-color: {COLORS['bg_mid']}; border-radius: 10px;"
        )
        tool_inner = QVBoxLayout(tool_frame)
        tool_inner.setContentsMargins(8, 6, 8, 6)
        tool_inner.setSpacing(2)
        tool_lbl = QLabel("Tool:")
        tool_lbl.setFont(mono_font(FONT_SIZES['secondary']))
        tool_lbl.setStyleSheet(f"color: {COLORS['text_dim']}; background: transparent;")
        tool_inner.addWidget(tool_lbl)

        self.sidebar_tool_combo = QComboBox()
        self.sidebar_tool_combo.setFont(mono_font(FONT_SIZES['sidebar_tool'], QFont.Bold))
        self.sidebar_tool_combo.setStyleSheet(
            f"QComboBox {{ color: {COLORS['accent_yellow']}; background: {COLORS['bg_light']}; "
            f"border: 1px solid {COLORS['border']}; border-radius: 4px; padding: 4px 6px; "
            f"min-height: {TOUCH_SIZES['target_min']}px; }}"
            f"QComboBox QAbstractItemView {{ background: {COLORS['bg_light']}; "
            f"color: {COLORS['text']}; selection-background-color: {COLORS['accent_blue']}; }}"
            f"QComboBox QAbstractItemView::item {{ min-height: {TOUCH_SIZES['target_min']}px; padding: 8px 12px; }}"
        )
        self.sidebar_tool_combo.currentIndexChanged.connect(self._on_sidebar_tool_changed)
        tool_inner.addWidget(self.sidebar_tool_combo)

        self.sidebar_tool_desc = QLabel("")
        self.sidebar_tool_desc.setFont(mono_font(FONT_SIZES['secondary']))
        self.sidebar_tool_desc.setStyleSheet(f"color: {COLORS['text_secondary']}; background: transparent;")
        self.sidebar_tool_desc.setWordWrap(True)
        tool_inner.addWidget(self.sidebar_tool_desc)

        grid.addWidget(tool_frame, 0, 0)

        # --- C2R1: WCS ---
        wcs_frame = QFrame()
        wcs_frame.setStyleSheet(
            f"background-color: {COLORS['bg_mid']}; border-radius: 10px;"
        )
        wcs_inner = QVBoxLayout(wcs_frame)
        wcs_inner.setContentsMargins(8, 6, 8, 6)
        wcs_inner.setSpacing(2)
        wcs_lbl = QLabel("WCS:")
        wcs_lbl.setFont(mono_font(FONT_SIZES['secondary']))
        wcs_lbl.setStyleSheet(f"color: {COLORS['text_dim']}; background: transparent;")
        wcs_inner.addWidget(wcs_lbl)

        self.wcs_combo = QComboBox()
        self.wcs_combo.addItems(["G53", "G54", "G55", "G56", "G57", "G58", "G59"])
        self.wcs_combo.setCurrentIndex(1)  # Default G54
        self.wcs_combo.setFont(mono_font(FONT_SIZES['sidebar_wcs'], QFont.Bold))
        self.wcs_combo.setStyleSheet(
            f"QComboBox {{ color: {COLORS['accent_blue_lt']}; background: {COLORS['bg_light']}; "
            f"border: 1px solid {COLORS['border']}; border-radius: 4px; padding: 4px 8px; "
            f"min-height: {TOUCH_SIZES['target_min']}px; }}"
            f"QComboBox QAbstractItemView {{ background: {COLORS['bg_light']}; "
            f"color: {COLORS['text']}; selection-background-color: {COLORS['accent_blue']}; }}"
            f"QComboBox QAbstractItemView::item {{ min-height: {TOUCH_SIZES['target_min']}px; padding: 8px 12px; }}"
        )
        wcs_inner.addWidget(self.wcs_combo)
        wcs_inner.addStretch()

        grid.addWidget(wcs_frame, 0, 1)

        # DRO state tracking (position still displayed on graph)
        self._dro_x_value = 0.0
        self._dro_z_value = 0.0
        self._dro_diameter_mode = True  # X defaults to diameter
        self._metric_display = False  # Display-only inch/mm toggle



        # --- Row 4: Go-To Fence (left) + Position (right) ---
        self.fence_widget = GoToFenceWidget()
        grid.addWidget(self.fence_widget, 1, 0)

        pos_group = QGroupBox("Position")
        pos_layout = QVBoxLayout(pos_group)
        pos_layout.setSpacing(8)
        pos_layout.setContentsMargins(8, 6, 8, 18)

        pos_btn_s = (
            f"QPushButton {{ min-height: 44px; font-size: {FONT_SIZES['body']}px; "
            f"font-weight: 600; border-radius: 6px; padding: 4px 8px; }}"
        )

        self.sidebar_btn_goto_toolchange = QPushButton("Tool Change")
        self.sidebar_btn_goto_toolchange.setStyleSheet(pos_btn_s)
        self.sidebar_btn_goto_toolchange.setToolTip("Go To Tool Change Position")
        pos_layout.addWidget(self.sidebar_btn_goto_toolchange)

        self.sidebar_btn_home_all = QPushButton("Home All")
        self.sidebar_btn_home_all.setStyleSheet(pos_btn_s)
        self.sidebar_btn_home_all.setToolTip("Home All Axes")
        self.sidebar_btn_home_all.clicked.connect(self.home_all)
        pos_layout.addWidget(self.sidebar_btn_home_all)

        grid.addWidget(pos_group, 1, 1)

        # Make columns equal width
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 1)

        # Set minimum row heights so grid widgets don't get squished
        grid.setRowMinimumHeight(0, 70)
        grid.setRowMinimumHeight(1, 55)

        right_layout.addLayout(grid, 0)

        # Compound Slide / Arc Jog — full row width (scrollable to avoid squishing)
        from PyQt5.QtWidgets import QSizePolicy, QScrollArea
        from compound_slide_widget import CompoundSlideWidget
        self.compound_widget = CompoundSlideWidget()
        compound_scroll = QScrollArea()
        compound_scroll.setWidget(self.compound_widget)
        compound_scroll.setWidgetResizable(True)
        compound_scroll.setFrameShape(QFrame.NoFrame)
        compound_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        compound_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        compound_scroll.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        right_layout.addWidget(compound_scroll, stretch=2)

        # E-Stop and Power at bottom — E-Stop expands to fill remaining space
        self.btn_estop = QPushButton("E-STOP")
        self.btn_estop.setStyleSheet(
            f"QPushButton {{ background-color: {COLORS['accent']}; color: #ffffff; "
            f"font-size: 18px; font-weight: 700; "
            f"min-width: {TOUCH_SIZES['estop_width']}px; "
            f"min-height: {TOUCH_SIZES['estop_height']}px; "
            f"border: none; border-radius: 10px; }}"
            f"QPushButton:hover {{ background-color: #d44637; }}"
            f"QPushButton:pressed {{ background-color: #962d22; }}"
        )
        self.btn_estop.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.btn_estop.clicked.connect(self.toggle_estop)
        right_layout.addWidget(self.btn_estop, stretch=0)

        self.btn_power = QPushButton("POWER ON")
        self.btn_power.setStyleSheet(
            f"QPushButton {{ background-color: {COLORS['accent_green']}; color: {COLORS['bg_dark']}; "
            f"font-size: {FONT_SIZES['state_bar_mode']}px; font-weight: 700; min-height: {TOUCH_SIZES['target_min']}px; "
            f"border: none; border-radius: 10px; }}"
            f"QPushButton:hover {{ background-color: {COLORS['accent_green_lt']}; }}"
            f"QPushButton:pressed {{ background-color: {COLORS['accent_green_dk']}; }}"
        )
        self.btn_power.clicked.connect(self.toggle_power)
        right_layout.addWidget(self.btn_power, stretch=0)

        main_layout.addWidget(right_panel, stretch=LAYOUT['right_stretch'])

        # --- Status bar ---
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Ready")

        # --- Tool change overlay ---
        self._tool_change_overlay = ToolChangeOverlay(self)
        self._tool_change_active = False

        self._connect_signals()

        # Set initial run-from-line button state based on connection
        if self.connected:
            self.program_tab.btn_run_from.setEnabled(True)
            self.program_tab.btn_run_from.setToolTip("")
        else:
            self.program_tab.btn_run_from.setEnabled(False)
            self.program_tab.btn_run_from.setToolTip("Requires LinuxCNC connection")

        # --- Per-tool soft limits ---
        # Limits directory is the my-lathe/ directory (one level up from gui/)
        limits_dir = os.path.dirname(_GUI_DIR)
        self.limit_manager = LimitManager(limits_dir)
        self.limit_manager.load()
        # In offline mode (HAS_LINUXCNC=False), lcnc_cmd is None — LimitEnforcer skips enforcement
        self.limit_enforcer = LimitEnforcer(self.limit_manager, self.lcnc_cmd)
        self._last_tool_in_spindle = 0  # Track tool changes for limit activation

        # --- LimitsView panel (Task 8.5) ---
        self.limits_view = LimitsView(self.limit_manager, self.tool_tab)
        self.limits_view.setVisible(False)
        # Insert LimitsView into the tool tab layout (after the scroll area)
        self.tool_tab.layout().addWidget(self.limits_view, stretch=1)
        # Wire the Limits toggle button
        self.tool_tab.btn_limits.clicked.connect(self._toggle_limits_view)
        # Wire limits_changed signal to update enforcer and graph
        self.limits_view.limits_changed.connect(self._on_limits_changed)
        # Wire tool_deleted signal to clean up limits for removed tools
        self.tool_tab.tool_deleted.connect(self._on_tool_deleted)

        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.periodic_update)
        self.update_timer.start(100)

        self._on_tab_changed(0)

    # --- LinuxCNC connection ---
    def _connect_linuxcnc(self):
        if not HAS_LINUXCNC:
            self.connected = False
            print("Offline preview mode — no LinuxCNC connection")
            return
        try:
            self.lcnc_stat = linuxcnc.stat()
            self.lcnc_cmd = linuxcnc.command()
            self.lcnc_err = linuxcnc.error_channel()
            self.lcnc_stat.poll()
            self.connected = True
        except Exception as e:
            self.connected = False
            print(f"LinuxCNC not running — GUI in offline mode: {e}")

    # --- Compound slide HAL component ---
    def _setup_compound_hal(self):
        """Create the compound-slide userspace HAL component and pins.

        The component provides HAL pins for compound slide integration:
          - compound-enable (bit IN): activation state from GUI
          - compound-angle (float IN): angle in degrees from GUI
          - mpg-x-in (s32 IN): raw X MPG encoder count
          - mpg-z-in (s32 IN): raw Z MPG encoder count
          - jog-scale (float IN): current jog increment from mux4
          - x-jog-counts (s32 OUT): decomposed X jog counts
          - z-jog-counts (s32 OUT): decomposed Z jog counts
        """
        if not HAS_LINUXCNC:
            self.compound_hal = None
            return
        self.compound_hal = hal.component("compound-slide")
        self.compound_hal.newpin("compound-enable", hal.HAL_BIT, hal.HAL_IN)
        self.compound_hal.newpin("compound-angle", hal.HAL_FLOAT, hal.HAL_IN)
        self.compound_hal.newpin("mpg-x-in", hal.HAL_S32, hal.HAL_IN)
        self.compound_hal.newpin("mpg-z-in", hal.HAL_S32, hal.HAL_IN)
        self.compound_hal.newpin("jog-scale", hal.HAL_FLOAT, hal.HAL_IN)
        self.compound_hal.newpin("x-jog-counts", hal.HAL_S32, hal.HAL_OUT)
        self.compound_hal.newpin("z-jog-counts", hal.HAL_S32, hal.HAL_OUT)
        self.compound_hal.ready()

    def _connect_signals(self):
        self.program_tab.btn_open.clicked.connect(self.open_file)
        self.program_tab.btn_run.clicked.connect(self.cycle_start)
        self.program_tab.btn_pause.clicked.connect(self.cycle_pause)
        self.program_tab.btn_stop.clicked.connect(self.cycle_stop)
        self.program_tab.btn_run_from.clicked.connect(self.run_from_line)
        self.mdi_tab.btn_execute.clicked.connect(self.execute_mdi)
        self.mdi_tab.cmd_input.returnPressed.connect(self.execute_mdi)

        # Edit tab — preview sends editor text to PositionGraph (Req 15.2)
        self.edit_tab.preview_requested.connect(self._preview_show_all)

        # Edit tab — load into Program tab (Req 16.1, 16.2, 16.3)
        self.edit_tab.load_program_requested.connect(self._load_into_program)

        # Manual tab — Go-To fence
        self.fence_widget.fence_changed.connect(self._on_fence_changed)

        # Compound slide signals
        self.compound_widget.compound_activated.connect(self._on_compound_activated)
        self.compound_widget.limit_warning.connect(self._on_compound_warning)

        # Tool tab — touch-off requests
        self.tool_tab.touchoff_requested.connect(self._on_tool_touchoff)

        # Sidebar WCS combo — sync with offsets tab and issue G-code
        self.wcs_combo.currentTextChanged.connect(self._on_sidebar_wcs_changed)

    def _on_compound_activated(self, active):
        """Handle compound slide activation/deactivation."""
        if self.compound_hal is not None:
            self.compound_hal["compound-enable"] = active
        if active:
            self.status_bar.showMessage("Compound slide mode ACTIVE")
        else:
            self.status_bar.showMessage("Compound slide mode OFF", 3000)

    def _on_compound_warning(self, message):
        """Display compound slide warning in status bar."""
        self.status_bar.showMessage(message, 5000)

    def _on_tab_changed(self, index):
        is_manual = (index == 0)
        is_conv = (self.tabs.widget(index) == self.conv_tab)
        is_program = (self.tabs.widget(index) == self.program_tab)
        is_hal = (self.tabs.widget(index) == self.hal_monitor_tab)

        # Activate/deactivate HAL monitor polling
        self.hal_monitor_tab.set_active(is_hal)

        if not is_conv and not is_program and self.position_graph._sim_mode:
            self.position_graph.sim_clear()

        if is_manual:
            self._left_layout.setStretchFactor(self.position_graph, 5)
            self._left_layout.setStretchFactor(self.tabs, 0)
            self.tabs.setMaximumHeight(80)
            self.position_graph.setMinimumHeight(LAYOUT['graph_min_manual'])
        elif is_program:
            self._left_layout.setStretchFactor(self.position_graph, 3)
            self._left_layout.setStretchFactor(self.tabs, 4)
            self.position_graph.setMinimumHeight(LAYOUT['graph_min_program'])
            self.tabs.setMaximumHeight(16777215)
        elif is_conv:
            self._left_layout.setStretchFactor(self.position_graph, 3)
            self._left_layout.setStretchFactor(self.tabs, 2)
            self.tabs.setMaximumHeight(16777215)
            self.position_graph.setMinimumHeight(LAYOUT['graph_min_other'])
        else:
            self._left_layout.setStretchFactor(self.position_graph, 1)
            self._left_layout.setStretchFactor(self.tabs, 2)
            self.tabs.setMaximumHeight(16777215)
            self.position_graph.setMinimumHeight(LAYOUT['graph_min_other'])

    # --- Load into Program (Req 16.1, 16.2, 16.3) ---
    def _load_into_program(self, text: str, file_label: str) -> None:
        """Set the Program tab's gcode_display and file_label from the Edit tab."""
        self.program_tab.gcode_display.setPlainText(text)
        self.program_tab.file_label.setText(file_label)

    # --- Preview show-all (Edit tab and Program tab) ---
    def _preview_show_all(self, gcode_text: str) -> None:
        """Load G-code into the position graph and show the complete toolpath."""
        if gcode_text.strip():
            self.position_graph.sim_load(gcode_text)
            self.position_graph.sim_show_all()

    # --- Periodic update ---
    def periodic_update(self):
        if not self.connected:
            self._offline_demo()
            return
        try:
            self.lcnc_stat.poll()
            s = self.lcnc_stat
            pos = s.actual_position
            self._update_dro(pos[0], pos[2])
            try:
                g5x = s.g5x_offset
                # Machine position = work position + g5x offset
                self.position_graph.set_machine_position(
                    pos[0] + g5x[0], pos[2] + g5x[2])
            except (AttributeError, IndexError):
                pass

            self.position_graph.update_position(pos[0], pos[2])

            # --- Distance to Go ---
            try:
                dtg = s.dtg
                self.program_tab.update_dtg(dtg[0], dtg[2], self._metric_display)
            except (AttributeError, IndexError, TypeError):
                self.program_tab.update_dtg(0.0, 0.0, self._metric_display)

            g5x_index = s.g5x_index
            wcs_map = {0: "G53", 1: "G54", 2: "G55", 3: "G56", 4: "G57", 5: "G58", 6: "G59"}
            active_wcs = wcs_map.get(g5x_index, "G54")
            self.position_graph.set_work_offset(active_wcs)

            # Sync sidebar WCS combo if LinuxCNC changed it (e.g., from G-code)
            if active_wcs != "G53":
                idx = self.wcs_combo.findText(active_wcs)
                if idx >= 0 and self.wcs_combo.currentIndex() != idx:
                    self.wcs_combo.blockSignals(True)
                    self.wcs_combo.setCurrentIndex(idx)
                    self.wcs_combo.blockSignals(False)
                    self.offsets_tab.set_active_wcs(active_wcs)

            # Current tool number
            try:
                tool_num = s.tool_in_spindle
                if tool_num > 0:
                    self.position_graph.set_current_tool(tool_num)
                    # Determine pocket number from library tool number
                    pocket_num = tool_num - 100 if tool_num > 100 else tool_num
                    # Program running: show Txx (program tool number)
                    # Manual/MDI: show T1xx (library tool number)
                    program_active = (
                        s.task_mode == linuxcnc.MODE_AUTO
                        and s.interp_state != linuxcnc.INTERP_IDLE
                    )
                    if program_active:
                        self.tool_tab.current_tool_label.setText(f"T{pocket_num}")
                    else:
                        lib_tool = 100 + pocket_num
                        self.tool_tab.current_tool_label.setText(f"T{lib_tool}")
                    # Update sidebar combo to match (combo uses T1xx format)
                    lib_tool = 100 + pocket_num
                    idx = self.sidebar_tool_combo.findText(f"T{lib_tool}")
                    if idx >= 0:
                        self.sidebar_tool_combo.blockSignals(True)
                        self.sidebar_tool_combo.setCurrentIndex(idx)
                        self.sidebar_tool_combo.blockSignals(False)
                    # Pull description from tool table
                    for row in self.tool_tab.tool_rows:
                        if row.tool_num == pocket_num:
                            tool_type_text = row.tool_type.currentText()
                            self.sidebar_tool_desc.setText(tool_type_text)
                            desc_text = row.description.text().strip() if hasattr(row, 'description') else ""
                            if desc_text:
                                self.tool_tab.current_tool_desc.setText(f"{tool_type_text} — {desc_text}")
                            else:
                                self.tool_tab.current_tool_desc.setText(tool_type_text)
                            break
            except (AttributeError, TypeError):
                pass

            # --- Per-tool soft limit enforcement (Tasks 8.2, 8.3, 8.4) ---
            z_machine = pos[2]
            is_homed = all(s.homed[:2])
            is_program_running = (
                s.task_mode == linuxcnc.MODE_AUTO
                and s.interp_state != linuxcnc.INTERP_IDLE
            )
            tool_in_spindle = s.tool_in_spindle

            # Task 8.3: Homing interlock — disable enforcement while not homed
            if is_homed:
                self.limit_enforcer.set_enabled(True)
            else:
                self.limit_enforcer.set_enabled(False)

            # Task 8.2: Check limits and display violation in status bar
            violation_msg = self.limit_enforcer.check(
                z_machine, tool_in_spindle, is_homed, is_program_running
            )
            if violation_msg is not None:
                self.status_bar.showMessage(violation_msg, 5000)

            # Task 8.4: Tool change detection — update graph limit lines
            if tool_in_spindle != self._last_tool_in_spindle:
                self._last_tool_in_spindle = tool_in_spindle
                limits = self.limit_manager.get_limits(tool_in_spindle)
                if limits is not None:
                    z_minus, z_plus = limits
                    self.position_graph.set_tool_limits(z_minus, z_plus)
                else:
                    self.position_graph.clear_tool_limits()

            # Task 8.6: Feed live data to LimitsView each cycle
            self.limits_view.set_machine_z(z_machine)
            self.limits_view.set_homed(is_homed)

            if s.estop:
                self.state_label.setText("E-STOP")
                self.state_label.setStyleSheet(f"color: {COLORS['accent']};")
                self.ind_estop.set_state("error")
            elif not s.enabled:
                self.state_label.setText("POWER OFF")
                self.state_label.setStyleSheet(f"color: {COLORS['accent_yellow']};")
                self.ind_estop.set_state("on")
                self.ind_power.set_state("off")
            else:
                self.state_label.setText("READY")
                self.state_label.setStyleSheet(f"color: {COLORS['accent_green']};")
                self.ind_estop.set_state("on")
                self.ind_power.set_state("on")

            mode_map = {
                linuxcnc.MODE_MANUAL: "[MANUAL]",
                linuxcnc.MODE_AUTO: "[AUTO]",
                linuxcnc.MODE_MDI: "[MDI]",
            }
            self.mode_label.setText(mode_map.get(s.task_mode, "[???]"))
            self.ind_homed.set_state("on" if all(s.homed[:2]) else "warn")

            if s.task_mode == linuxcnc.MODE_AUTO:
                state_map = {
                    linuxcnc.INTERP_IDLE: "off",
                    linuxcnc.INTERP_READING: "on",
                    linuxcnc.INTERP_PAUSED: "warn",
                    linuxcnc.INTERP_WAITING: "on",
                }
                self.ind_program.set_state(state_map.get(s.interp_state, "off"))
                if s.interp_state in (linuxcnc.INTERP_READING, linuxcnc.INTERP_WAITING):
                    if not self.position_graph._sim_mode and hasattr(s, 'file') and s.file:
                        try:
                            with open(s.file, 'r') as f:
                                gcode = f.read()
                            if gcode.strip():
                                self.position_graph.sim_load(gcode)
                                self.position_graph.sim_show_all()
                        except Exception:
                            pass
            else:
                self.ind_program.set_state("off")
                if self.position_graph._sim_mode and self.tabs.currentWidget() != self.conv_tab:
                    self.position_graph.sim_clear()

            try:
                spindle_speed = s.spindle[0]["speed"]
                spindle_dir = s.spindle[0]["direction"]
            except (TypeError, KeyError, IndexError):
                spindle_speed = 0
                spindle_dir = 0
            self.spindle_rpm_lbl.setText(f"S:{int(spindle_speed)}")

            feed_pct = int(s.feedrate * 100)
            rapid_pct = int(getattr(s, "rapidrate", 1.0) * 100)
            self.override_feed_lbl.setText(f"Feed:{feed_pct}%")
            self.override_rapid_lbl.setText(f"Rapid:{rapid_pct}%")

            current_vel = s.current_vel * 60.0
            if self._metric_display:
                self.feed_display.setText(f"{current_vel * 25.4:.1f} mm/min")
            else:
                self.feed_display.setText(f"{current_vel:.1f} in/min")

            active = " ".join(f"G{c/10:.0f}" if c > 0 else "" for c in s.gcodes[:16])
            self.gcodes_label.setText(active.strip())

            self.tuning_tab.update_live_status({
                "x_ferror": s.joint[0]["ferror"] if hasattr(s, "joint") else 0.0,
                "z_ferror": s.joint[1]["ferror"] if hasattr(s, "joint") else 0.0,
                "x_cmd_pos": pos[0], "z_cmd_pos": pos[2],
                "x_enc_pos": s.actual_position[0], "z_enc_pos": s.actual_position[2],
                "spindle_rpm": spindle_speed,
            })

            self.tool_tab.refresh_wear_from_stat()
            self.offsets_tab.periodic_refresh()

            # --- Compound slide interlock update ---
            if hasattr(self, 'compound_widget'):
                self.compound_widget.set_interlock_state(
                    estop=s.estop,
                    homed=all(s.homed[:2]),
                    manual_mode=(s.task_mode == linuxcnc.MODE_MANUAL),
                    program_idle=(s.interp_state == linuxcnc.INTERP_IDLE),
                    machine_enabled=s.enabled,
                )
                # Force deactivate if any interlock is violated while active
                if self.compound_widget.is_active():
                    ok, reason = self.compound_widget.check_interlocks()
                    if not ok:
                        self.compound_widget.force_deactivate(reason)
                        if self.compound_hal is not None:
                            self.compound_hal["compound-enable"] = False

            # --- Compound slide processing ---
            if hasattr(self, 'compound_widget') and self.compound_widget.is_active():
                current_x = pos[0]  # radius
                current_z = pos[2]
                mpg_x = self.compound_hal["mpg-x-in"]
                mpg_z = self.compound_hal["mpg-z-in"]
                jog_scale = self.compound_hal["jog-scale"]

                x_out, z_out = self.compound_widget.update_compound(
                    current_x, current_z, mpg_x, mpg_z, jog_scale
                )

                self.compound_hal["x-jog-counts"] = x_out
                self.compound_hal["z-jog-counts"] = z_out

            # Update HAL pins from widget state (always, even when inactive)
            if hasattr(self, 'compound_widget') and self.compound_hal is not None:
                self.compound_hal["compound-enable"] = self.compound_widget.is_active()
                self.compound_hal["compound-angle"] = self.compound_widget.get_angle()

            error = self.lcnc_err.poll()
            if error:
                kind, text = error
                self.status_bar.showMessage(
                    f"{'ERROR' if kind == linuxcnc.OPERATOR_ERROR else 'MSG'}: {text}")

            # --- Tool change overlay detection ---
            # M6 causes the interpreter to pause waiting for cycle start.
            # Detect: AUTO mode + paused + a tool prepped (pocket_prepped != -1)
            try:
                tool_change_waiting = (
                    s.task_mode == linuxcnc.MODE_AUTO
                    and s.paused
                    and s.pocket_prepped != -1
                    and s.pocket_prepped != s.tool_in_spindle
                )
            except AttributeError:
                tool_change_waiting = False

            if tool_change_waiting and not self._tool_change_active:
                # Show the overlay with the tool being called
                called_tool = s.pocket_prepped
                # Look up description from tool table
                tool_desc = ""
                pocket_num = called_tool - 100 if called_tool > 100 else called_tool
                for row in self.tool_tab.tool_rows:
                    if row.tool_num == pocket_num:
                        tool_type_text = row.tool_type.currentText()
                        desc_text = row.description.text().strip() if hasattr(row, 'description') else ""
                        if desc_text:
                            tool_desc = f"{tool_type_text} — {desc_text}"
                        else:
                            tool_desc = tool_type_text
                        break
                self._tool_change_overlay.show_tool_change(called_tool, tool_desc)
                self._tool_change_overlay.setGeometry(self.centralWidget().rect())
                self._tool_change_active = True
            elif not tool_change_waiting and self._tool_change_active:
                # Program resumed (cycle start pressed) — dismiss overlay
                self._tool_change_overlay.dismiss()
                self._tool_change_active = False

            # Disable interactive buttons while a program is running
            program_running = (
                s.task_mode == linuxcnc.MODE_AUTO
                and s.interp_state != linuxcnc.INTERP_IDLE
            )
            self.sidebar_btn_goto_toolchange.setEnabled(not program_running)
            self.sidebar_btn_home_all.setEnabled(not program_running)
            self.sidebar_tool_combo.setEnabled(not program_running)
        except Exception as e:
            self.status_bar.showMessage(f"Update error: {e}")

    def _refresh_sidebar_tool_combo(self):
        """Populate the sidebar tool combo from the tool table.

        Always displays library tool numbers (T1xx) — the operator selects
        tools by their library ID in manual mode.
        """
        self.sidebar_tool_combo.blockSignals(True)
        self.sidebar_tool_combo.clear()
        for row in self.tool_tab.tool_rows:
            lib_tool = 100 + row.tool_num
            self.sidebar_tool_combo.addItem(f"T{lib_tool}", row.tool_num)
        self.sidebar_tool_combo.blockSignals(False)

    def _on_sidebar_tool_changed(self, index):
        """Handle tool selection from sidebar — activate tool offset via MDI."""
        if index < 0:
            return
        tool_num = self.sidebar_tool_combo.currentData()
        if tool_num is None:
            return

        # Update description
        for row in self.tool_tab.tool_rows:
            if row.tool_num == tool_num:
                tool_type_text = row.tool_type.currentText()
                self.sidebar_tool_desc.setText(tool_type_text)
                # Build description for the Tools tab current tool display
                desc_text = row.description.text().strip() if hasattr(row, 'description') else ""
                if desc_text:
                    self.tool_tab.current_tool_desc.setText(f"{tool_type_text} — {desc_text}")
                else:
                    self.tool_tab.current_tool_desc.setText(tool_type_text)
                break

        # Issue tool change command if connected
        if self.connected:
            try:
                lib_tool = 100 + tool_num
                self.ensure_mode(linuxcnc.MODE_MDI)
                self.lcnc_cmd.mdi(f"T{lib_tool} M6 G43")
                self.lcnc_cmd.wait_complete()
                self.tool_tab.current_tool_label.setText(f"T{lib_tool}")
            except Exception as e:
                self.status_bar.showMessage(f"Tool change error: {e}")
        else:
            # Offline — just update display
            lib_tool = 100 + tool_num
            self.tool_tab.current_tool_label.setText(f"T{lib_tool}")
            self.position_graph.set_current_tool(tool_num)

    def _on_sidebar_wcs_changed(self, wcs_name):
        """Handle WCS selection from sidebar — sync offsets tab and issue G-code."""
        # Update offsets tab (skip G53 — that's machine coords, not settable)
        self.offsets_tab.set_active_wcs(wcs_name)

        # Issue WCS change command if connected (G53 is per-line only, skip it)
        if wcs_name == "G53":
            self.status_bar.showMessage("G53 — Machine coordinates (view only)")
            return
        if self.connected:
            try:
                self.ensure_mode(linuxcnc.MODE_MDI)
                self.lcnc_cmd.mdi(wcs_name)
                self.lcnc_cmd.wait_complete()
                self.status_bar.showMessage(f"Active WCS: {wcs_name}")
            except Exception as e:
                self.status_bar.showMessage(f"WCS change error: {e}")

    def _update_dro(self, x_value, z_value):
        """Update position tracking (displayed on graph only)."""
        self._dro_x_value = x_value
        self._dro_z_value = z_value

    def _toggle_units_display(self):
        """Toggle between inch and metric display mode (display-only)."""
        self._metric_display = not self._metric_display
        if self._metric_display:
            self.btn_units_toggle.setText("MM")
            self.btn_units_toggle.setStyleSheet(
                f"QPushButton {{ "
                f"background-color: qlineargradient(x1:0,y1:0,x2:0,y2:1, "
                f"  stop:0 {COLORS['accent_blue_lt']}, stop:1 {COLORS['accent_blue']}); "
                f"border-radius: 12px; border: 1px solid {COLORS['accent_blue_dk']}; "
                f"border-bottom: 2px solid {COLORS['accent_blue_dk']}; "
                f"color: #ffffff; "
                f"padding: 5px 14px; min-width: 52px; min-height: 0px; max-height: 32px; }}"
                f"QPushButton:hover {{ "
                f"  background-color: qlineargradient(x1:0,y1:0,x2:0,y2:1, "
                f"  stop:0 #b0d8ff, stop:1 {COLORS['accent_blue_lt']}); color: {COLORS['bg_dark']}; }}"
                f"QPushButton:pressed {{ background-color: {COLORS['accent_blue_dk']}; color: #ffffff; }}"
            )
        else:
            self.btn_units_toggle.setText("INCH")
            self.btn_units_toggle.setStyleSheet(
                f"QPushButton {{ "
                f"background-color: qlineargradient(x1:0,y1:0,x2:0,y2:1, "
                f"  stop:0 {COLORS['accent_green_lt']}, stop:1 {COLORS['accent_green']}); "
                f"border-radius: 12px; border: 1px solid {COLORS['accent_green_dk']}; "
                f"border-bottom: 2px solid {COLORS['accent_green_dk']}; "
                f"color: {COLORS['bg_dark']}; "
                f"padding: 5px 14px; min-width: 52px; min-height: 0px; max-height: 32px; }}"
                f"QPushButton:hover {{ "
                f"  background-color: qlineargradient(x1:0,y1:0,x2:0,y2:1, "
                f"  stop:0 #d8e8b8, stop:1 {COLORS['accent_green_lt']}); }}"
                f"QPushButton:pressed {{ background-color: {COLORS['accent_green_dk']}; color: white; }}"
            )
        # Propagate to all widgets that display inch-based values
        self.position_graph.set_metric_display(self._metric_display)
        self.tool_tab.set_metric_display(self._metric_display)
        self.offsets_tab.set_metric_display(self._metric_display)
        self.tuning_tab.set_metric_display(self._metric_display)
        self.limits_view.set_metric_display(self._metric_display)
        self.fence_widget.set_metric_display(self._metric_display)
        self.conv_tab.set_metric_display(self._metric_display)
        # Force immediate repaint
        self.position_graph.update()

    def _on_fence_changed(self, axis, enabled, value):
        """Relay fence state to the position graph for display."""
        self.position_graph.set_fence(axis, enabled, value)

    def _sim_mpg_counts(self):
        """Provide simulated MPG encoder pulses for offline UI testing.

        Returns:
            (mpg_x_counts, mpg_z_counts, jog_scale) tuple with simulated values.
        """
        if not hasattr(self, '_sim_mpg_counter'):
            self._sim_mpg_counter = 0
        # Only generate pulses if compound mode is active (for visual feedback)
        if hasattr(self, 'compound_widget') and self.compound_widget.is_active():
            self._sim_mpg_counter += 1
        return (self._sim_mpg_counter, 0, 0.001)

    def _offline_demo(self):
        if not hasattr(self, '_offline_initialized'):
            # First call — set up demo state
            self._offline_initialized = True
            self._update_dro(-1.2345, -3.8750)
            self.position_graph.set_work_offset("G54")
            self.position_graph.update_position(-1.2345, -3.8750)
            # Demo machine coordinates (G53) — work pos + simulated G54 offset
            self.position_graph.set_machine_position(-1.2345 + 0.0, -3.8750 + 5.0)
            # Populate tool combo from tool table
            self._refresh_sidebar_tool_combo()
            if self.sidebar_tool_combo.count() > 0:
                self.sidebar_tool_combo.setCurrentIndex(0)
                self._on_sidebar_tool_changed(0)
            self.state_label.setText("OFFLINE PREVIEW")
            self.state_label.setStyleSheet(f"color: {COLORS['accent_yellow']};")
            self.mode_label.setText("[MANUAL]")
            self.ind_estop.set_state("on")
            self.ind_power.set_state("on")
            self.ind_homed.set_state("on")
            self.ind_program.set_state("off")
            self.spindle_rpm_lbl.setText("S:1200")
            self.override_feed_lbl.setText("Feed:100%")
            self.override_rapid_lbl.setText("Rapid:100%")
            if self._metric_display:
                self.feed_display.setText(f"{8.5 * 25.4:.1f} mm/min")
            else:
                self.feed_display.setText("8.5 in/min")
            self.gcodes_label.setText("G20 G54 G90 G94 G97 G40")
            self.program_tab.update_dtg(0.125, 1.375, self._metric_display)
            # Set current tool from loaded table (first tool)
            if self.tool_tab.tool_rows:
                first_row = self.tool_tab.tool_rows[0]
                tool_num = first_row.tool_num
                lib_tool = 100 + tool_num
                self.tool_tab.current_tool_label.setText(f"T{lib_tool}")
                tool_type_text = first_row.tool_type.currentText()
                desc_text = first_row.description.text().strip()
                if desc_text:
                    self.tool_tab.current_tool_desc.setText(f"{tool_type_text} — {desc_text}")
                else:
                    self.tool_tab.current_tool_desc.setText(tool_type_text)
                self.position_graph.set_current_tool(tool_num, f"{tool_type_text} — {desc_text}" if desc_text else tool_type_text)
                # Task 8.8: Display tool limit lines in offline mode
                limits = self.limit_manager.get_limits(tool_num)
                if limits is not None:
                    z_minus, z_plus = limits
                    self.position_graph.set_tool_limits(z_minus, z_plus)
                else:
                    self.position_graph.clear_tool_limits()
            else:
                self.tool_tab.current_tool_label.setText("T101")
                self.tool_tab.current_tool_desc.setText("No tool loaded")
                self.position_graph.set_current_tool(1)
                self.position_graph.clear_tool_limits()
            self.status_bar.showMessage("Offline preview — connect to LinuxCNC for live data")
            self.tuning_tab.update_live_status({
                "x_ferror": 0.000042, "z_ferror": 0.000018,
                "x_cmd_pos": 0.0, "z_cmd_pos": 0.0,
                "x_enc_pos": 0.000042, "z_enc_pos": 0.000018,
                "spindle_rpm": 1200,
            })

        # Update display-unit-sensitive labels every tick (responds to unit toggle)
        if self._metric_display:
            self.feed_display.setText(f"{8.5 * 25.4:.1f} mm/min")
        else:
            self.feed_display.setText("8.5 in/min")
        self.program_tab.update_dtg(0.125, 1.375, self._metric_display)

        # Task 8.6: Feed simulated data to LimitsView in offline mode
        # Use the demo machine Z position (work Z + simulated G54 offset)
        offline_z_machine = self._dro_z_value + 5.0 if hasattr(self, '_dro_z_value') else 1.25
        self.limits_view.set_machine_z(offline_z_machine)
        self.limits_view.set_homed(True)  # Simulate homed state in offline mode

        # Process compound slide in offline mode
        if hasattr(self, 'compound_widget') and self.compound_widget.is_active():
            mpg_x, mpg_z, jog_scale = self._sim_mpg_counts()
            current_x = self._dro_x_value if hasattr(self, '_dro_x_value') else -1.2345
            current_z = self._dro_z_value if hasattr(self, '_dro_z_value') else -3.8750
            self.compound_widget.update_compound(
                current_x, current_z, mpg_x, mpg_z, jog_scale
            )

    # --- Actions ---
    def ensure_mode(self, mode):
        if not self.connected:
            return False
        self.lcnc_stat.poll()
        if self.lcnc_stat.task_mode != mode:
            self.lcnc_cmd.mode(mode)
            self.lcnc_cmd.wait_complete()
        return True

    def toggle_estop(self):
        if not self.connected: return
        self.lcnc_stat.poll()
        if self.lcnc_stat.estop:
            self.lcnc_cmd.state(linuxcnc.STATE_ESTOP_RESET)
        else:
            self.lcnc_cmd.state(linuxcnc.STATE_ESTOP)

    def toggle_power(self):
        if not self.connected: return
        self.lcnc_stat.poll()
        if self.lcnc_stat.enabled:
            self.lcnc_cmd.state(linuxcnc.STATE_OFF)
        else:
            self.lcnc_cmd.state(linuxcnc.STATE_ON)

    def home_all(self):
        if not self.connected: return
        self.ensure_mode(linuxcnc.MODE_MANUAL)
        self.lcnc_cmd.home(-1)

    def open_file(self):
        fname, _ = QFileDialog.getOpenFileName(
            self, "Open G-code File", "",
            "G-code Files (*.ngc *.nc *.gcode *.tap);;All Files (*)"
        )
        if fname:
            if self.connected:
                self.ensure_mode(linuxcnc.MODE_AUTO)
                self.lcnc_cmd.program_open(fname)
            self.program_tab.file_label.setText(os.path.basename(fname))
            try:
                try:
                    with open(fname, "r", encoding="utf-8") as f:
                        gcode = f.read()
                except UnicodeDecodeError:
                    with open(fname, "r", encoding="cp1252") as f:
                        gcode = f.read()
                self.program_tab.gcode_display.setPlainText(gcode)
                if hasattr(self, 'position_graph') and gcode.strip():
                    self.position_graph.sim_load(gcode)
                    self.position_graph.sim_show_all()
            except Exception as e:
                self.status_bar.showMessage(f"Error reading file: {e}")

    def cycle_start(self):
        if hasattr(self, 'compound_widget') and self.compound_widget.is_active():
            self.status_bar.showMessage("Cannot start program while compound slide is active", 5000)
            return
        if not self.connected: return
        self.ensure_mode(linuxcnc.MODE_AUTO)
        self.lcnc_cmd.auto(linuxcnc.AUTO_RUN, 0)
        # Dismiss tool change overlay immediately on cycle start
        if self._tool_change_active:
            self._tool_change_overlay.dismiss()
            self._tool_change_active = False

    def cycle_pause(self):
        if not self.connected: return
        self.lcnc_stat.poll()
        if self.lcnc_stat.paused:
            self.lcnc_cmd.auto(linuxcnc.AUTO_RESUME)
            # Dismiss tool change overlay on resume
            if self._tool_change_active:
                self._tool_change_overlay.dismiss()
                self._tool_change_active = False
        else:
            self.lcnc_cmd.auto(linuxcnc.AUTO_PAUSE)

    def cycle_stop(self):
        if not self.connected: return
        self.lcnc_cmd.abort()

    def run_from_line(self):
        if not self.connected:
            return
        n_value = self.program_tab.start_line_input.value()
        if n_value == 0:
            self.status_bar.showMessage("Enter a line number (N#) to start from")
            return
        gcode_text = self.program_tab.gcode_display.toPlainText()
        line_index = resolve_n_word(gcode_text, n_value)
        if line_index is not None:
            self.ensure_mode(linuxcnc.MODE_AUTO)
            self.lcnc_cmd.auto(linuxcnc.AUTO_RUN, line_index)
            self.status_bar.showMessage(f"Running from N{n_value} (line {line_index})")
        else:
            self.status_bar.showMessage(f"Line N{n_value} not found")

    def execute_mdi(self):
        if not self.connected: return
        cmd = self.mdi_tab.cmd_input.text().strip()
        if not cmd: return
        self.ensure_mode(linuxcnc.MODE_MDI)
        self.lcnc_cmd.mdi(cmd)
        self.mdi_tab.history.append(f"> {cmd}")
        self.mdi_tab.cmd_input.clear()
        self.status_bar.showMessage(f"MDI: {cmd}")

    def _on_tool_touchoff(self, axis, tool_num, value_str):
        """Handle tool touch-off request from ToolTab — uses G10 L10.

        G10 L10 calculates the tool offset so that the current position
        (in the active WCS) equals the specified value. This is the standard
        lathe touch-off workflow:
          1. Touch tool to a known surface
          2. Enter the known dimension (diameter for X, length for Z)
          3. LinuxCNC back-calculates the offset

        Args:
            axis: 'x' or 'z'
            tool_num: Tool number (1-based program tool number)
            value_str: Known dimension at current position (diameter for X)
        """
        if not self.connected:
            self.status_bar.showMessage(f"Offline — T{tool_num} {axis.upper()} touch-off not applied")
            return

        lib_tool = 100 + tool_num

        # Get current offset for display
        current_val = "unknown"
        try:
            self.lcnc_stat.poll()
            if axis == 'x':
                current_val = f"{self.lcnc_stat.tool_table[lib_tool].xoffset * 2:.4f}"
            else:
                current_val = f"{self.lcnc_stat.tool_table[lib_tool].zoffset:.4f}"
        except Exception:
            pass

        msg = QMessageBox(self)
        msg.setWindowTitle(f"Confirm {axis.upper()} Touch-Off")
        msg.setText(f"Touch off T{tool_num} {axis.upper()}?")
        msg.setInformativeText(
            f"Current {axis.upper()} offset: {current_val}\n"
            f"Known {axis.upper()} value at current position: {value_str}\n\n"
            f"LinuxCNC will calculate the new offset using G10 L10."
        )
        msg.setIcon(QMessageBox.Warning)
        msg.setStandardButtons(QMessageBox.Yes | QMessageBox.Cancel)
        msg.setDefaultButton(QMessageBox.Cancel)
        msg.setStyleSheet(
            f"QMessageBox {{ background-color: {COLORS['bg_dark']}; color: {COLORS['text']}; }}"
            f"QLabel {{ color: {COLORS['text']}; font-size: 14px; }}"
            f"QPushButton {{ min-width: 80px; min-height: 40px; font-size: 13px; }}"
        )

        if msg.exec_() != QMessageBox.Yes:
            return

        try:
            self.ensure_mode(linuxcnc.MODE_MDI)
            # G10 L10 P{tool} — calculate offset from current WCS position
            if axis == 'x':
                self.lcnc_cmd.mdi(f"G10 L10 P{lib_tool} X{value_str}")
            else:
                self.lcnc_cmd.mdi(f"G10 L10 P{lib_tool} Z{value_str}")
            self.lcnc_cmd.wait_complete()
            self.lcnc_cmd.mdi("G43")
            self.lcnc_cmd.wait_complete()
            self.status_bar.showMessage(
                f"T{tool_num} {axis.upper()} touched off at {value_str} (G10 L10)")
        except Exception as e:
            self.status_bar.showMessage(f"Touch-off error: {e}")

    def _confirm_shutdown(self):
        """Show confirmation dialog before shutting down."""
        msg = QMessageBox(self)
        msg.setWindowTitle("Confirm Exit")
        msg.setText("Exit LinuxCNC?")
        msg.setInformativeText(
            "This will save all state and close the GUI safely."
        )
        msg.setIcon(QMessageBox.Warning)
        msg.setStandardButtons(QMessageBox.Yes | QMessageBox.Cancel)
        msg.setDefaultButton(QMessageBox.Cancel)
        msg.setStyleSheet(
            f"QMessageBox {{ background-color: {COLORS['bg_dark']}; color: {COLORS['text']}; }}"
            f"QLabel {{ color: {COLORS['text']}; font-size: 14px; }}"
            f"QPushButton {{ min-width: 80px; min-height: 40px; font-size: 13px; }}"
        )

        if msg.exec_() == QMessageBox.Yes:
            self.close()  # triggers closeEvent for clean LinuxCNC shutdown

    # --- Limits View toggle (Task 8.5) ---
    def _toggle_limits_view(self):
        """Toggle between tool table scroll area and LimitsView panel."""
        showing_limits = self.tool_tab.btn_limits.isChecked()
        if showing_limits:
            # Show LimitsView, hide tool scroll
            self.limits_view.refresh()
            self.tool_tab.tool_scroll.setVisible(False)
            self.limits_view.setVisible(True)
        else:
            # Show tool scroll, hide LimitsView
            self.limits_view.setVisible(False)
            self.tool_tab.tool_scroll.setVisible(True)

    def _on_limits_changed(self):
        """Handle limits_changed signal — update enforcer and graph lines."""
        # Refresh the graph limit lines for the current tool
        tool_num = self._last_tool_in_spindle
        if tool_num > 0:
            limits = self.limit_manager.get_limits(tool_num)
            if limits is not None:
                z_minus, z_plus = limits
                self.position_graph.set_tool_limits(z_minus, z_plus)
            else:
                self.position_graph.clear_tool_limits()
        else:
            self.position_graph.clear_tool_limits()

    def _on_tool_deleted(self, tool_num: int):
        """Handle tool deletion — remove limits for the deleted tool."""
        self.limit_manager.remove_tool(tool_num)
        self.limit_manager.save()
        # Refresh LimitsView if it's currently visible
        if self.limits_view.isVisible():
            self.limits_view.refresh()

    def resizeEvent(self, event):
        """Keep tool change overlay sized to the central widget."""
        super().resizeEvent(event)
        if hasattr(self, '_tool_change_overlay') and self._tool_change_overlay.isVisible():
            self._tool_change_overlay.setGeometry(self.centralWidget().rect())

    def closeEvent(self, event):
        """Clean shutdown — ensure LinuxCNC saves state before exit."""
        self.update_timer.stop()

        if self.connected:
            try:
                # Ensure machine is in a safe state
                self.lcnc_stat.poll()

                # If running a program, stop it first
                if self.lcnc_stat.task_mode == linuxcnc.MODE_AUTO:
                    if self.lcnc_stat.interp_state != linuxcnc.INTERP_IDLE:
                        self.lcnc_cmd.abort()
                        self.lcnc_cmd.wait_complete()

                # Switch to manual mode (safe state)
                self.lcnc_cmd.mode(linuxcnc.MODE_MANUAL)
                self.lcnc_cmd.wait_complete()

                # Issue M2 (end program) via MDI to trigger parameter save
                self.lcnc_cmd.mode(linuxcnc.MODE_MDI)
                self.lcnc_cmd.wait_complete()
                self.lcnc_cmd.mdi("M2")
                self.lcnc_cmd.wait_complete()

                print("Clean shutdown: LinuxCNC state saved.")
            except Exception as e:
                print(f"Shutdown warning: {e}")

        # Save tool table if active
        if hasattr(self, 'tool_tab') and self.tool_tab._active_table_path:
            self.tool_tab._write_table_to_path(self.tool_tab._active_table_path)

        event.accept()


def main():
    app = QApplication(sys.argv)
    load_bundled_fonts()
    app.setStyleSheet(STYLESHEET)
    window = LatheGUI()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
