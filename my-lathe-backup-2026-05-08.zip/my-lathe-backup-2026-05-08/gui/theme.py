"""
Theme Module — Colors, Stylesheet, and Font Helpers
=====================================================
Central location for all visual styling used across the GUI.
"""

import os
from PyQt5.QtGui import QFont, QFontDatabase


# ---------------------------------------------------------------------------
# Font setup — Inter (UI) + JetBrains Mono (DRO/code)
# ---------------------------------------------------------------------------
FONT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts")
FONT_UI = "Inter"
FONT_MONO = "JetBrains Mono"


def load_bundled_fonts():
    """Load bundled font files from gui/fonts/ directory."""
    loaded = []
    if os.path.isdir(FONT_DIR):
        for fname in os.listdir(FONT_DIR):
            if fname.lower().endswith((".ttf", ".otf")):
                fpath = os.path.join(FONT_DIR, fname)
                fid = QFontDatabase.addApplicationFont(fpath)
                if fid >= 0:
                    families = QFontDatabase.applicationFontFamilies(fid)
                    loaded.extend(families)
    if loaded:
        print(f"Loaded fonts: {', '.join(set(loaded))}")
    return loaded


def ui_font(size=13, weight=QFont.Normal):
    """Return a UI font (Inter or fallback)."""
    f = QFont(FONT_UI, size, weight)
    f.setStyleStrategy(QFont.PreferAntialias)
    if FONT_UI not in QFontDatabase().families():
        f.setFamily("Segoe UI")
    return f


def mono_font(size=13, weight=QFont.Normal):
    """Return a monospace font (JetBrains Mono or fallback)."""
    f = QFont(FONT_MONO, size, weight)
    f.setStyleStrategy(QFont.PreferAntialias)
    if FONT_MONO not in QFontDatabase().families():
        f.setFamily("Consolas")
    return f


# ---------------------------------------------------------------------------
# Colour palette — Steel blue-gray base with blue accents, muted sage greens,
# and warm orange-crimson for alerts.
# ---------------------------------------------------------------------------
COLORS = {
    # Base surfaces (teal/sage backgrounds)
    "bg_dark":       "#334a50",
    "bg_mid":        "#446269",
    "bg_light":      "#557b83",
    "bg_elevated":   "#6B959E",
    # Group box surfaces (steel blue-gray)
    "groupbox_dark": "#2d343d",
    "groupbox_mid":  "#3d4f66",
    # Blue accent palette
    "accent_blue":   "#3373C4",
    "accent_blue_lt":"#86C6FA",
    "accent_blue_dk":"#1750AC",
    # Warm palette (warnings, errors, stops)
    "accent":        "#C0392B",
    "accent_orange": "#E67E22",
    "accent_warm":   "#F5A623",
    # Green palette (ready, ok, feed moves)
    "accent_green":  "#8FA87E",
    "accent_green_lt":"#C5D5A0",
    "accent_green_dk":"#6B7F5E",
    # Text
    "text":          "#E8ECF0",
    "text_secondary":"#B8C4CC",
    "text_dim":      "#7B9AAC",
    # DRO
    "dro_bg":        "#1a2028",
    "dro_text":      "#C5D5A0",
    "dro_text_red":  "#C0392B",
    # Borders & separators
    "border":        "#5A7A8C",
    "separator":     "#6B8FA0",
    # Spindle / RPM
    "accent_yellow": "#F5A623",
    # Go-To fence
    "fence":         "#E056A0",
}


# ---------------------------------------------------------------------------
# Touch target sizing — minimum dimensions for touchscreen usability
# ---------------------------------------------------------------------------
TOUCH_SIZES = {
    "target_min": 44,          # Minimum touch target size (px)
    "target_spacing": 8,       # Minimum gap between targets (px)
    "tab_height": 48,          # Tab header height (px)
    "tab_min_width": 70,       # Tab header minimum width (px)
    "estop_width": 120,        # E-Stop minimum width (px)
    "estop_height": 80,        # E-Stop minimum height (px)
    "input_height": 44,        # Input field minimum height (px)
    "touchoff_btn_width": 60,  # Touch-off button minimum width (px)
    "scrollbar_width": 12,     # Scrollbar width for touch dragging (px)
    "state_bar_height": 44,    # State bar minimum height (px)
    "indicator_dot_size": 12,  # Status indicator dot diameter (px)
}


# ---------------------------------------------------------------------------
# Font sizes — centralized point sizes for all text elements
# ---------------------------------------------------------------------------
FONT_SIZES = {
    "dro_primary": 30,         # DRO work coordinate values (pt)
    "dro_axis_label": 20,      # DRO axis labels X, Z (pt)
    "dro_machine": 14,         # DRO machine coordinate G53 (pt)
    "sidebar_rpm": 28,         # Spindle RPM display (pt)
    "sidebar_tool": 18,        # Tool number display (pt)
    "sidebar_wcs": 18,         # WCS identifier display (pt)
    "tab_label": 14,           # Tab header labels (pt)
    "state_bar_label": 12,     # State bar indicator labels (pt)
    "state_bar_mode": 14,      # State bar mode/state text (pt)
    "body": 13,                # Body text and labels (pt)
    "secondary": 11,           # Secondary/dim text (pt)
}


# ---------------------------------------------------------------------------
# Layout — window and panel sizing constants for 1920×1080 fullscreen
# ---------------------------------------------------------------------------
LAYOUT = {
    "window_width": 1920,      # Target display width (px)
    "window_height": 1080,     # Target display height (px)
    "main_margin": 4,          # Main layout margin all sides (px)
    "panel_spacing": 8,        # Spacing between panels (px)
    "left_stretch": 3,         # Left panel stretch factor (75%)
    "right_stretch": 1,        # Right panel stretch factor (25%)
    "graph_min_manual": 594,   # Position graph min-height, Manual tab (px)
    "graph_min_program": 378,  # Position graph min-height, Program tab (px)
    "graph_min_other": 350,    # Position graph min-height, other tabs (px)
}


# ---------------------------------------------------------------------------
# Global stylesheet
# ---------------------------------------------------------------------------
STYLESHEET = f"""
    * {{
        font-family: '{FONT_UI}', 'Segoe UI', 'Helvetica Neue', sans-serif;
    }}
    QMainWindow {{
        background-color: {COLORS['bg_dark']};
    }}
    QWidget {{
        background-color: {COLORS['bg_dark']};
        color: {COLORS['text']};
        font-size: 18px;
    }}
    QTabWidget::pane {{
        border: none;
        background-color: {COLORS['bg_mid']};
        border-radius: 8px;
    }}
    QTabBar {{
        qproperty-expanding: 1;
    }}
    QTabBar::tab {{
        background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
            stop:0 {COLORS['bg_elevated']}, stop:1 {COLORS['bg_light']});
        color: {COLORS['text_secondary']};
        padding: 8px 14px;
        margin: 2px 1px;
        border-radius: 8px;
        border: 1px solid {COLORS['border']};
        border-bottom: 1px solid {COLORS['bg_light']};
        font-size: {FONT_SIZES['tab_label']}pt;
        font-weight: bold;
        min-height: {TOUCH_SIZES['tab_height']}px;
    }}
    QTabBar::tab:selected {{
        background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
            stop:0 {COLORS['accent_blue_lt']}, stop:0.4 {COLORS['accent_blue']}, stop:1 {COLORS['accent_blue_dk']});
        color: #ffffff;
        border: 1px solid {COLORS['accent_blue_dk']};
        border-bottom: 1px solid {COLORS['accent_blue']};
    }}
    QTabBar::tab:hover:!selected {{
        background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
            stop:0 {COLORS['separator']}, stop:1 {COLORS['bg_elevated']});
        color: {COLORS['accent_blue_lt']};
    }}
    QPushButton {{
        background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
            stop:0 {COLORS['bg_elevated']}, stop:0.5 {COLORS['bg_light']}, stop:1 {COLORS['bg_mid']});
        color: {COLORS['text']};
        border: 1px solid {COLORS['border']};
        border-bottom: 2px solid {COLORS['bg_mid']};
        border-radius: 8px;
        padding: 8px 18px;
        font-size: 18px;
        font-weight: 600;
        min-height: {TOUCH_SIZES['target_min']}px;
    }}
    QPushButton:hover {{
        background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
            stop:0 {COLORS['separator']}, stop:0.5 {COLORS['bg_elevated']}, stop:1 {COLORS['bg_light']});
        border: 1px solid {COLORS['accent_blue_lt']};
        border-bottom: 2px solid {COLORS['bg_light']};
    }}
    QPushButton:pressed {{
        background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
            stop:0 {COLORS['bg_mid']}, stop:1 {COLORS['bg_light']});
        border: 1px solid {COLORS['accent_blue']};
        border-top: 2px solid {COLORS['bg_mid']};
        border-bottom: 1px solid {COLORS['bg_light']};
        padding-top: 9px;
        padding-bottom: 7px;
    }}
    QPushButton:disabled {{
        background-color: {COLORS['bg_mid']};
        color: {COLORS['text_dim']};
        border: 1px solid {COLORS['bg_light']};
    }}
    QGroupBox {{
        border: 1px solid {COLORS['border']};
        border-radius: 10px;
        margin-top: 14px;
        padding: 18px 10px 10px 10px;
        font-weight: 600;
        font-size: 16px;
        color: {COLORS['text_secondary']};
        background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
            stop:0 {COLORS['groupbox_mid']}, stop:1 {COLORS['groupbox_dark']});
    }}
    QGroupBox::title {{
        subcontrol-origin: margin;
        left: 14px;
        padding: 0 6px;
        color: {COLORS['accent_blue_lt']};
    }}
    QTextEdit {{
        background-color: {COLORS['dro_bg']};
        color: {COLORS['dro_text']};
        border: 2px solid {COLORS['bg_mid']};
        border-top: 2px solid {COLORS['bg_dark']};
        border-radius: 8px;
        padding: 6px;
        font-family: '{FONT_MONO}', 'Consolas', 'Courier New', monospace;
        font-size: 18px;
        selection-background-color: {COLORS['accent_blue']};
    }}
    QLineEdit {{
        background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
            stop:0 {COLORS['bg_mid']}, stop:0.3 {COLORS['bg_light']}, stop:1 {COLORS['bg_light']});
        color: {COLORS['text']};
        border: 1px solid {COLORS['border']};
        border-top: 2px solid {COLORS['bg_mid']};
        border-radius: 6px;
        padding: 6px 8px;
        font-family: '{FONT_MONO}', 'Consolas', 'Courier New', monospace;
        font-size: 18px;
        selection-background-color: {COLORS['accent_blue']};
        min-height: {TOUCH_SIZES['target_min']}px;
    }}
    QLineEdit:focus {{
        border: 1px solid {COLORS['accent_blue_lt']};
        border-top: 2px solid {COLORS['accent_blue']};
    }}
    QComboBox {{
        background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
            stop:0 {COLORS['bg_elevated']}, stop:1 {COLORS['bg_light']});
        color: {COLORS['text']};
        border: 1px solid {COLORS['border']};
        border-bottom: 2px solid {COLORS['bg_mid']};
        border-radius: 6px;
        padding: 6px 8px;
        font-size: 18px;
        min-height: {TOUCH_SIZES['target_min']}px;
    }}
    QComboBox:hover {{
        border: 1px solid {COLORS['accent_blue_lt']};
    }}
    QComboBox::drop-down {{
        border: none;
        width: {TOUCH_SIZES['target_min']}px;
    }}
    QComboBox QAbstractItemView {{
        background-color: {COLORS['bg_light']};
        color: {COLORS['text']};
        border: 1px solid {COLORS['border']};
        border-radius: 6px;
        selection-background-color: {COLORS['accent_blue']};
        selection-color: #ffffff;
        min-height: {TOUCH_SIZES['target_min']}px;
    }}
    QComboBox QAbstractItemView::item {{
        min-height: {TOUCH_SIZES['target_min']}px;
        padding: 8px 12px;
    }}
    QMenu {{
        background-color: {COLORS['bg_light']};
        color: {COLORS['text']};
        border: 1px solid {COLORS['border']};
        border-radius: 6px;
        padding: 4px;
    }}
    QMenu::item {{
        min-height: {TOUCH_SIZES['target_min']}px;
        padding: 10px 20px;
        border-radius: 4px;
    }}
    QMenu::item:selected {{
        background-color: {COLORS['accent_blue']};
        color: #ffffff;
    }}
    QScrollArea {{
        border: none;
        background: {COLORS['bg_dark']};
    }}
    QScrollBar:vertical {{
        background: {COLORS['bg_dark']};
        width: {TOUCH_SIZES['scrollbar_width']}px;
        border-radius: 4px;
    }}
    QScrollBar::handle:vertical {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
            stop:0 {COLORS['bg_elevated']}, stop:1 {COLORS['separator']});
        border-radius: 4px;
        min-height: {TOUCH_SIZES['target_min']}px;
    }}
    QScrollBar::handle:vertical:hover {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
            stop:0 {COLORS['separator']}, stop:1 {COLORS['accent_blue_lt']});
    }}
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
        height: 0px;
    }}
    QScrollBar:horizontal {{
        background: {COLORS['bg_dark']};
        height: {TOUCH_SIZES['scrollbar_width']}px;
        border-radius: 4px;
    }}
    QScrollBar::handle:horizontal {{
        background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
            stop:0 {COLORS['bg_elevated']}, stop:1 {COLORS['separator']});
        border-radius: 4px;
        min-width: {TOUCH_SIZES['target_min']}px;
    }}
    QStatusBar {{
        background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
            stop:0 {COLORS['bg_mid']}, stop:1 {COLORS['bg_dark']});
        color: {COLORS['text_dim']};
        border-top: 1px solid {COLORS['border']};
        font-size: 16px;
    }}
    QToolTip {{
        background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
            stop:0 {COLORS['bg_elevated']}, stop:1 {COLORS['bg_mid']});
        color: {COLORS['text']};
        border: 1px solid {COLORS['accent_blue']};
        border-radius: 6px;
        padding: 6px;
        font-size: 16px;
    }}
"""
