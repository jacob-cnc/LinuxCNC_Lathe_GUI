# My-Lathe GUI — Demo Preview

Custom PyQt5 GUI for a 2-axis CNC lathe. Runs in offline preview mode on Windows — no LinuxCNC required.

## Quick Start

```
pip install PyQt5
python lathe_gui.py
```

## Tabs

### Manual
Jog controls, spindle, coolant, and E-stop. Simulated in offline mode.

### Program
Load and run G-code files. Displays program listing with line highlighting.

### MDI
Manual Data Input — type and execute single G-code commands.

### Conv (Conversational)
Build multi-block programs with:
- **Profile blocks** — Define part geometry with segments (lines, tapers, arcs). Generates roughing passes with staircase clipping to the roughing boundary, a cleanup contour pass, and a finish pass.
- **Threading blocks** — External/internal threading with G76 cycle. Preset database for UN/UNC/UNF, Metric, and Acme threads with tolerance handling.
- **Cutoff blocks** — Parting operations.

Each block supports collapse/expand, duplicate, reorder, and remove. Click Generate to produce G-code and simulate the toolpath in the position graph.

**Profile segments** support:
- Straight lines, tapers, arcs (CW/CCW selector)
- Entry/exit chamfers and radii
- OD turning and ID boring modes

### Edit
G-code text editor with syntax highlighting, line numbers, and bracket matching. Preview button sends code to the position graph for simulation.

### Tools
Tool table management — view and edit tool offsets.

### Tool Wear
Apply wear offsets to compensate for tool wear during production runs.

### WCS
Work Coordinate System offsets (G54-G59). View and set work offsets.

### Tuning
PID tuning and axis configuration parameters.

### HAL
HAL pin monitor — view real-time HAL signal states for debugging.

## Position Graph
The graph widget (top of the window) shows:
- Live tool position tracking
- G-code simulation playback with rapid (dashed) and feed (solid) moves
- Stock outline
- Zoom (scroll wheel), pan (drag), reset (double-click)
- Grid lines down to 0.001" resolution at max zoom

## Notes
- All X coordinates are diameter in the GUI
- DOC and Finish DOC are entered as diameter values
- Offline mode uses demo data — no machine connection needed
- Fonts: Inter (UI) + JetBrains Mono (DRO/code) with system fallbacks
