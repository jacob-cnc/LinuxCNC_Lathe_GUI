"""G-code line numbering utilities.

Provides post-processing functions to add sequential N# line numbers
to executable G-code lines, and to resolve N# numbers back to their
0-based line indices. Designed to be called after G-code generation is
complete, keeping the numbering concern decoupled from block-level
code generation.
"""

import re

# Matches G-code word letters that indicate an executable line.
# Looks for letter+digit patterns (G0, M3, T1, F200, S1000, X1.0, etc.)
# in the non-comment portion of the line.
_EXECUTABLE_RE = re.compile(r'[GMTFSXZIKR]\d', re.IGNORECASE)

# Matches a line that is solely a parenthetical comment (with optional
# surrounding whitespace), e.g. "  (some comment)  "
_PAREN_COMMENT_RE = re.compile(r'^\s*\(.*\)\s*$')


def is_executable_line(line: str) -> bool:
    """Classify a single G-code line as executable or not.

    A line is executable if it contains G-code commands (G00, G01, G02,
    G03, G76, etc.), M-codes (M0, M2, M3, M4, M5, M6, M7, M8, M9, M30),
    T-words (tool changes), F-words (feed rate), S-words (spindle speed),
    or axis words (X, Z, I, K, R with numbers). Inline comments after
    executable content do not disqualify a line.

    A line is NOT executable if it is blank, whitespace-only, starts with
    ';', or consists solely of a parenthetical comment like '(some text)'.

    Returns:
        True if the line should receive an N#.
    """
    stripped = line.strip()

    # Blank / whitespace-only
    if not stripped:
        return False

    # Semicolon comment
    if stripped.startswith(';'):
        return False

    # Solely a parenthetical comment
    if _PAREN_COMMENT_RE.match(stripped):
        return False

    # Strip inline parenthetical comments before checking for G-code words,
    # so that e.g. "(G0 is rapid)" alone doesn't count, but we already
    # handled the pure-comment case above.  For mixed lines like
    # "G00 X1.0 (rapid)", the G00 X1.0 part will match.
    code_portion = re.sub(r'\(.*?\)', '', stripped)

    return bool(_EXECUTABLE_RE.search(code_portion))


def add_line_numbers(gcode_text: str, start: int = 10, increment: int = 10) -> str:
    """Prepend N# line numbers to executable lines in a G-code string.

    Args:
        gcode_text: Complete G-code program as a single string.
        start: First N# value (default 10).
        increment: Step between successive N# values (default 10).

    Returns:
        The G-code string with N# prefixes on executable lines.
        Comment-only lines, blank lines, and whitespace-only lines
        pass through unmodified. The output has the same number of
        lines as the input.
    """
    if not gcode_text:
        return gcode_text

    lines = gcode_text.split('\n')
    result = []
    n = start

    for line in lines:
        if is_executable_line(line):
            result.append(f'N{n} {line}')
            n += increment
        else:
            result.append(line)

    return '\n'.join(result)


def resolve_n_word(gcode_text: str, n_number: int) -> int | None:
    """Find the 0-based line index for a given N# number.

    Scans the G-code text for a line starting with N<n_number> followed
    by a space (case-insensitive match).

    Args:
        gcode_text: The numbered G-code program.
        n_number: The N# value to find (e.g. 30 for N30).

    Returns:
        0-based line index if found, None if not found.
    """
    prefix = f'N{n_number} '
    prefix_lower = prefix.lower()

    for idx, line in enumerate(gcode_text.split('\n')):
        if line.lower().startswith(prefix_lower):
            return idx

    return None
