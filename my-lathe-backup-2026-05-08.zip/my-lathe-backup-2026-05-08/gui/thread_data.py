"""
Thread Preset Database for LinuxCNC Lathe Threading Conversational Block.

Contains dimension and tolerance data for common thread families:
- UN/UNC (Unified National Coarse) per ASME B1.1
- UN/UNF (Unified National Fine) per ASME B1.1
- Metric Coarse per ISO 261
- Metric Fine per ISO 261
- Acme per ASME B1.5

All dimensions are in inches. Metric diameters are converted from mm.
Tolerance bands are (min, max) tuples; (None, None) means not controlled.
"""

# ---------------------------------------------------------------------------
# Family → Fit-class mapping
# ---------------------------------------------------------------------------
FAMILY_FIT_CLASSES = {
    "UN/UNC/UNF": {
        "External": ["1A", "2A", "3A"],
        "Internal": ["1B", "2B", "3B"],
    },
    "Metric": {
        "External": ["6g"],
        "Internal": ["6H"],
    },
    "Acme": {
        "External": ["2G", "3G", "4G"],
        "Internal": ["2G", "3G", "4G"],
    },
}

# ---------------------------------------------------------------------------
# THREAD_DATABASE  –  family name → list of thread entry dicts
# ---------------------------------------------------------------------------
THREAD_DATABASE = {}

# ============================= UN / UNC ====================================
_UNC_ENTRIES = [
    # --- Number sizes ---
    {
        "key": "#0-80 UNC", "family": "UN/UNC/UNF", "designation": "#0-80 UNC",
        "major_d_basic": 0.0600, "pitch_d_basic": 0.0519, "minor_d_basic": 0.0438,
        "tpi": 80, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.0578, 0.0600), "pitch_d": (0.0496, 0.0519), "minor_d": (None, None)},
            "2A": {"major_d": (0.0586, 0.0600), "pitch_d": (0.0502, 0.0519), "minor_d": (None, None)},
            "3A": {"major_d": (0.0590, 0.0600), "pitch_d": (0.0506, 0.0519), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.0519, 0.0542), "minor_d": (0.0438, 0.0514)},
            "2B": {"major_d": (None, None), "pitch_d": (0.0519, 0.0536), "minor_d": (0.0438, 0.0496)},
            "3B": {"major_d": (None, None), "pitch_d": (0.0519, 0.0532), "minor_d": (0.0438, 0.0482)},
        },
    },
    {
        "key": "#1-64 UNC", "family": "UN/UNC/UNF", "designation": "#1-64 UNC",
        "major_d_basic": 0.0730, "pitch_d_basic": 0.0629, "minor_d_basic": 0.0527,
        "tpi": 64, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.0704, 0.0730), "pitch_d": (0.0602, 0.0629), "minor_d": (None, None)},
            "2A": {"major_d": (0.0714, 0.0730), "pitch_d": (0.0610, 0.0629), "minor_d": (None, None)},
            "3A": {"major_d": (0.0719, 0.0730), "pitch_d": (0.0615, 0.0629), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.0629, 0.0656), "minor_d": (0.0527, 0.0613)},
            "2B": {"major_d": (None, None), "pitch_d": (0.0629, 0.0648), "minor_d": (0.0527, 0.0593)},
            "3B": {"major_d": (None, None), "pitch_d": (0.0629, 0.0643), "minor_d": (0.0527, 0.0578)},
        },
    },
    {
        "key": "#2-56 UNC", "family": "UN/UNC/UNF", "designation": "#2-56 UNC",
        "major_d_basic": 0.0860, "pitch_d_basic": 0.0744, "minor_d_basic": 0.0628,
        "tpi": 56, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.0832, 0.0860), "pitch_d": (0.0714, 0.0744), "minor_d": (None, None)},
            "2A": {"major_d": (0.0842, 0.0860), "pitch_d": (0.0722, 0.0744), "minor_d": (None, None)},
            "3A": {"major_d": (0.0848, 0.0860), "pitch_d": (0.0728, 0.0744), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.0744, 0.0774), "minor_d": (0.0628, 0.0720)},
            "2B": {"major_d": (None, None), "pitch_d": (0.0744, 0.0766), "minor_d": (0.0628, 0.0700)},
            "3B": {"major_d": (None, None), "pitch_d": (0.0744, 0.0759), "minor_d": (0.0628, 0.0685)},
        },
    },
    {
        "key": "#3-48 UNC", "family": "UN/UNC/UNF", "designation": "#3-48 UNC",
        "major_d_basic": 0.0990, "pitch_d_basic": 0.0855, "minor_d_basic": 0.0719,
        "tpi": 48, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.0958, 0.0990), "pitch_d": (0.0822, 0.0855), "minor_d": (None, None)},
            "2A": {"major_d": (0.0970, 0.0990), "pitch_d": (0.0831, 0.0855), "minor_d": (None, None)},
            "3A": {"major_d": (0.0977, 0.0990), "pitch_d": (0.0838, 0.0855), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.0855, 0.0888), "minor_d": (0.0719, 0.0820)},
            "2B": {"major_d": (None, None), "pitch_d": (0.0855, 0.0879), "minor_d": (0.0719, 0.0797)},
            "3B": {"major_d": (None, None), "pitch_d": (0.0855, 0.0871), "minor_d": (0.0719, 0.0780)},
        },
    },
    {
        "key": "#4-40 UNC", "family": "UN/UNC/UNF", "designation": "#4-40 UNC",
        "major_d_basic": 0.1120, "pitch_d_basic": 0.0958, "minor_d_basic": 0.0795,
        "tpi": 40, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.1084, 0.1120), "pitch_d": (0.0919, 0.0958), "minor_d": (None, None)},
            "2A": {"major_d": (0.1098, 0.1120), "pitch_d": (0.0930, 0.0958), "minor_d": (None, None)},
            "3A": {"major_d": (0.1106, 0.1120), "pitch_d": (0.0938, 0.0958), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.0958, 0.0997), "minor_d": (0.0795, 0.0907)},
            "2B": {"major_d": (None, None), "pitch_d": (0.0958, 0.0985), "minor_d": (0.0795, 0.0880)},
            "3B": {"major_d": (None, None), "pitch_d": (0.0958, 0.0977), "minor_d": (0.0795, 0.0860)},
        },
    },
    {
        "key": "#5-40 UNC", "family": "UN/UNC/UNF", "designation": "#5-40 UNC",
        "major_d_basic": 0.1250, "pitch_d_basic": 0.1088, "minor_d_basic": 0.0925,
        "tpi": 40, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.1214, 0.1250), "pitch_d": (0.1049, 0.1088), "minor_d": (None, None)},
            "2A": {"major_d": (0.1228, 0.1250), "pitch_d": (0.1060, 0.1088), "minor_d": (None, None)},
            "3A": {"major_d": (0.1236, 0.1250), "pitch_d": (0.1068, 0.1088), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.1088, 0.1127), "minor_d": (0.0925, 0.1037)},
            "2B": {"major_d": (None, None), "pitch_d": (0.1088, 0.1115), "minor_d": (0.0925, 0.1010)},
            "3B": {"major_d": (None, None), "pitch_d": (0.1088, 0.1107), "minor_d": (0.0925, 0.0990)},
        },
    },
    {
        "key": "#6-32 UNC", "family": "UN/UNC/UNF", "designation": "#6-32 UNC",
        "major_d_basic": 0.1380, "pitch_d_basic": 0.1177, "minor_d_basic": 0.0974,
        "tpi": 32, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.1338, 0.1380), "pitch_d": (0.1131, 0.1177), "minor_d": (None, None)},
            "2A": {"major_d": (0.1354, 0.1380), "pitch_d": (0.1145, 0.1177), "minor_d": (None, None)},
            "3A": {"major_d": (0.1364, 0.1380), "pitch_d": (0.1155, 0.1177), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.1177, 0.1223), "minor_d": (0.0974, 0.1106)},
            "2B": {"major_d": (None, None), "pitch_d": (0.1177, 0.1209), "minor_d": (0.0974, 0.1074)},
            "3B": {"major_d": (None, None), "pitch_d": (0.1177, 0.1199), "minor_d": (0.0974, 0.1050)},
        },
    },
    {
        "key": "#8-32 UNC", "family": "UN/UNC/UNF", "designation": "#8-32 UNC",
        "major_d_basic": 0.1640, "pitch_d_basic": 0.1437, "minor_d_basic": 0.1234,
        "tpi": 32, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.1596, 0.1640), "pitch_d": (0.1389, 0.1437), "minor_d": (None, None)},
            "2A": {"major_d": (0.1612, 0.1640), "pitch_d": (0.1404, 0.1437), "minor_d": (None, None)},
            "3A": {"major_d": (0.1622, 0.1640), "pitch_d": (0.1414, 0.1437), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.1437, 0.1485), "minor_d": (0.1234, 0.1370)},
            "2B": {"major_d": (None, None), "pitch_d": (0.1437, 0.1470), "minor_d": (0.1234, 0.1338)},
            "3B": {"major_d": (None, None), "pitch_d": (0.1437, 0.1460), "minor_d": (0.1234, 0.1314)},
        },
    },
    {
        "key": "#10-24 UNC", "family": "UN/UNC/UNF", "designation": "#10-24 UNC",
        "major_d_basic": 0.1900, "pitch_d_basic": 0.1629, "minor_d_basic": 0.1359,
        "tpi": 24, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.1848, 0.1900), "pitch_d": (0.1573, 0.1629), "minor_d": (None, None)},
            "2A": {"major_d": (0.1868, 0.1900), "pitch_d": (0.1590, 0.1629), "minor_d": (None, None)},
            "3A": {"major_d": (0.1880, 0.1900), "pitch_d": (0.1602, 0.1629), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.1629, 0.1685), "minor_d": (0.1359, 0.1517)},
            "2B": {"major_d": (None, None), "pitch_d": (0.1629, 0.1668), "minor_d": (0.1359, 0.1479)},
            "3B": {"major_d": (None, None), "pitch_d": (0.1629, 0.1656), "minor_d": (0.1359, 0.1449)},
        },
    },
    {
        "key": "#12-24 UNC", "family": "UN/UNC/UNF", "designation": "#12-24 UNC",
        "major_d_basic": 0.2160, "pitch_d_basic": 0.1889, "minor_d_basic": 0.1619,
        "tpi": 24, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.2108, 0.2160), "pitch_d": (0.1833, 0.1889), "minor_d": (None, None)},
            "2A": {"major_d": (0.2128, 0.2160), "pitch_d": (0.1850, 0.1889), "minor_d": (None, None)},
            "3A": {"major_d": (0.2140, 0.2160), "pitch_d": (0.1862, 0.1889), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.1889, 0.1945), "minor_d": (0.1619, 0.1777)},
            "2B": {"major_d": (None, None), "pitch_d": (0.1889, 0.1928), "minor_d": (0.1619, 0.1739)},
            "3B": {"major_d": (None, None), "pitch_d": (0.1889, 0.1916), "minor_d": (0.1619, 0.1709)},
        },
    },
    # --- Fractional sizes ---
    {
        "key": "1/4-20 UNC", "family": "UN/UNC/UNF", "designation": "1/4-20 UNC",
        "major_d_basic": 0.2500, "pitch_d_basic": 0.2175, "minor_d_basic": 0.1850,
        "tpi": 20, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.2442, 0.2500), "pitch_d": (0.2113, 0.2175), "minor_d": (None, None)},
            "2A": {"major_d": (0.2464, 0.2500), "pitch_d": (0.2132, 0.2175), "minor_d": (None, None)},
            "3A": {"major_d": (0.2478, 0.2500), "pitch_d": (0.2147, 0.2175), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.2175, 0.2237), "minor_d": (0.1850, 0.2030)},
            "2B": {"major_d": (None, None), "pitch_d": (0.2175, 0.2218), "minor_d": (0.1850, 0.1990)},
            "3B": {"major_d": (None, None), "pitch_d": (0.2175, 0.2203), "minor_d": (0.1850, 0.1959)},
        },
    },
    {
        "key": "5/16-18 UNC", "family": "UN/UNC/UNF", "designation": "5/16-18 UNC",
        "major_d_basic": 0.3125, "pitch_d_basic": 0.2764, "minor_d_basic": 0.2403,
        "tpi": 18, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.3063, 0.3125), "pitch_d": (0.2697, 0.2764), "minor_d": (None, None)},
            "2A": {"major_d": (0.3087, 0.3125), "pitch_d": (0.2718, 0.2764), "minor_d": (None, None)},
            "3A": {"major_d": (0.3102, 0.3125), "pitch_d": (0.2734, 0.2764), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.2764, 0.2831), "minor_d": (0.2403, 0.2600)},
            "2B": {"major_d": (None, None), "pitch_d": (0.2764, 0.2810), "minor_d": (0.2403, 0.2557)},
            "3B": {"major_d": (None, None), "pitch_d": (0.2764, 0.2794), "minor_d": (0.2403, 0.2524)},
        },
    },
    {
        "key": "3/8-16 UNC", "family": "UN/UNC/UNF", "designation": "3/8-16 UNC",
        "major_d_basic": 0.3750, "pitch_d_basic": 0.3344, "minor_d_basic": 0.2938,
        "tpi": 16, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.3682, 0.3750), "pitch_d": (0.3270, 0.3344), "minor_d": (None, None)},
            "2A": {"major_d": (0.3708, 0.3750), "pitch_d": (0.3293, 0.3344), "minor_d": (None, None)},
            "3A": {"major_d": (0.3724, 0.3750), "pitch_d": (0.3311, 0.3344), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.3344, 0.3418), "minor_d": (0.2938, 0.3151)},
            "2B": {"major_d": (None, None), "pitch_d": (0.3344, 0.3395), "minor_d": (0.2938, 0.3104)},
            "3B": {"major_d": (None, None), "pitch_d": (0.3344, 0.3377), "minor_d": (0.2938, 0.3067)},
        },
    },
    {
        "key": "7/16-14 UNC", "family": "UN/UNC/UNF", "designation": "7/16-14 UNC",
        "major_d_basic": 0.4375, "pitch_d_basic": 0.3911, "minor_d_basic": 0.3447,
        "tpi": 14, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.4299, 0.4375), "pitch_d": (0.3829, 0.3911), "minor_d": (None, None)},
            "2A": {"major_d": (0.4329, 0.4375), "pitch_d": (0.3854, 0.3911), "minor_d": (None, None)},
            "3A": {"major_d": (0.4347, 0.4375), "pitch_d": (0.3874, 0.3911), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.3911, 0.3993), "minor_d": (0.3447, 0.3680)},
            "2B": {"major_d": (None, None), "pitch_d": (0.3911, 0.3968), "minor_d": (0.3447, 0.3629)},
            "3B": {"major_d": (None, None), "pitch_d": (0.3911, 0.3948), "minor_d": (0.3447, 0.3589)},
        },
    },
    {
        "key": "1/2-13 UNC", "family": "UN/UNC/UNF", "designation": "1/2-13 UNC",
        "major_d_basic": 0.5000, "pitch_d_basic": 0.4500, "minor_d_basic": 0.4001,
        "tpi": 13, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.4919, 0.5000), "pitch_d": (0.4411, 0.4500), "minor_d": (None, None)},
            "2A": {"major_d": (0.4951, 0.5000), "pitch_d": (0.4439, 0.4500), "minor_d": (None, None)},
            "3A": {"major_d": (0.4970, 0.5000), "pitch_d": (0.4460, 0.4500), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.4500, 0.4589), "minor_d": (0.4001, 0.4251)},
            "2B": {"major_d": (None, None), "pitch_d": (0.4500, 0.4565), "minor_d": (0.4001, 0.4197)},
            "3B": {"major_d": (None, None), "pitch_d": (0.4500, 0.4543), "minor_d": (0.4001, 0.4153)},
        },
    },
    {
        "key": "9/16-12 UNC", "family": "UN/UNC/UNF", "designation": "9/16-12 UNC",
        "major_d_basic": 0.5625, "pitch_d_basic": 0.5084, "minor_d_basic": 0.4542,
        "tpi": 12, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.5538, 0.5625), "pitch_d": (0.4990, 0.5084), "minor_d": (None, None)},
            "2A": {"major_d": (0.5573, 0.5625), "pitch_d": (0.5019, 0.5084), "minor_d": (None, None)},
            "3A": {"major_d": (0.5594, 0.5625), "pitch_d": (0.5042, 0.5084), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.5084, 0.5178), "minor_d": (0.4542, 0.4808)},
            "2B": {"major_d": (None, None), "pitch_d": (0.5084, 0.5152), "minor_d": (0.4542, 0.4750)},
            "3B": {"major_d": (None, None), "pitch_d": (0.5084, 0.5130), "minor_d": (0.4542, 0.4703)},
        },
    },
    {
        "key": "5/8-11 UNC", "family": "UN/UNC/UNF", "designation": "5/8-11 UNC",
        "major_d_basic": 0.6250, "pitch_d_basic": 0.5660, "minor_d_basic": 0.5069,
        "tpi": 11, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.6155, 0.6250), "pitch_d": (0.5558, 0.5660), "minor_d": (None, None)},
            "2A": {"major_d": (0.6193, 0.6250), "pitch_d": (0.5589, 0.5660), "minor_d": (None, None)},
            "3A": {"major_d": (0.6216, 0.6250), "pitch_d": (0.5614, 0.5660), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.5660, 0.5762), "minor_d": (0.5069, 0.5354)},
            "2B": {"major_d": (None, None), "pitch_d": (0.5660, 0.5733), "minor_d": (0.5069, 0.5291)},
            "3B": {"major_d": (None, None), "pitch_d": (0.5660, 0.5710), "minor_d": (0.5069, 0.5240)},
        },
    },
    {
        "key": "3/4-10 UNC", "family": "UN/UNC/UNF", "designation": "3/4-10 UNC",
        "major_d_basic": 0.7500, "pitch_d_basic": 0.6850, "minor_d_basic": 0.6201,
        "tpi": 10, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.7396, 0.7500), "pitch_d": (0.6738, 0.6850), "minor_d": (None, None)},
            "2A": {"major_d": (0.7438, 0.7500), "pitch_d": (0.6773, 0.6850), "minor_d": (None, None)},
            "3A": {"major_d": (0.7463, 0.7500), "pitch_d": (0.6800, 0.6850), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.6850, 0.6962), "minor_d": (0.6201, 0.6510)},
            "2B": {"major_d": (None, None), "pitch_d": (0.6850, 0.6930), "minor_d": (0.6201, 0.6441)},
            "3B": {"major_d": (None, None), "pitch_d": (0.6850, 0.6905), "minor_d": (0.6201, 0.6386)},
        },
    },
    {
        "key": "7/8-9 UNC", "family": "UN/UNC/UNF", "designation": "7/8-9 UNC",
        "major_d_basic": 0.8750, "pitch_d_basic": 0.8028, "minor_d_basic": 0.7307,
        "tpi": 9, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.8636, 0.8750), "pitch_d": (0.7905, 0.8028), "minor_d": (None, None)},
            "2A": {"major_d": (0.8682, 0.8750), "pitch_d": (0.7943, 0.8028), "minor_d": (None, None)},
            "3A": {"major_d": (0.8709, 0.8750), "pitch_d": (0.7973, 0.8028), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.8028, 0.8151), "minor_d": (0.7307, 0.7645)},
            "2B": {"major_d": (None, None), "pitch_d": (0.8028, 0.8116), "minor_d": (0.7307, 0.7571)},
            "3B": {"major_d": (None, None), "pitch_d": (0.8028, 0.8088), "minor_d": (0.7307, 0.7511)},
        },
    },
    {
        "key": "1-8 UNC", "family": "UN/UNC/UNF", "designation": "1-8 UNC",
        "major_d_basic": 1.0000, "pitch_d_basic": 0.9188, "minor_d_basic": 0.8376,
        "tpi": 8, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.9876, 1.0000), "pitch_d": (0.9053, 0.9188), "minor_d": (None, None)},
            "2A": {"major_d": (0.9926, 1.0000), "pitch_d": (0.9096, 0.9188), "minor_d": (None, None)},
            "3A": {"major_d": (0.9956, 1.0000), "pitch_d": (0.9130, 0.9188), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.9188, 0.9323), "minor_d": (0.8376, 0.8745)},
            "2B": {"major_d": (None, None), "pitch_d": (0.9188, 0.9284), "minor_d": (0.8376, 0.8663)},
            "3B": {"major_d": (None, None), "pitch_d": (0.9188, 0.9254), "minor_d": (0.8376, 0.8598)},
        },
    },
    {
        "key": "1-1/8-7 UNC", "family": "UN/UNC/UNF", "designation": "1-1/8-7 UNC",
        "major_d_basic": 1.1250, "pitch_d_basic": 1.0322, "minor_d_basic": 0.9394,
        "tpi": 7, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (1.1113, 1.1250), "pitch_d": (1.0174, 1.0322), "minor_d": (None, None)},
            "2A": {"major_d": (1.1168, 1.1250), "pitch_d": (1.0222, 1.0322), "minor_d": (None, None)},
            "3A": {"major_d": (1.1201, 1.1250), "pitch_d": (1.0260, 1.0322), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (1.0322, 1.0470), "minor_d": (0.9394, 0.9800)},
            "2B": {"major_d": (None, None), "pitch_d": (1.0322, 1.0427), "minor_d": (0.9394, 0.9710)},
            "3B": {"major_d": (None, None), "pitch_d": (1.0322, 1.0393), "minor_d": (0.9394, 0.9639)},
        },
    },
    {
        "key": "1-1/4-7 UNC", "family": "UN/UNC/UNF", "designation": "1-1/4-7 UNC",
        "major_d_basic": 1.2500, "pitch_d_basic": 1.1572, "minor_d_basic": 1.0644,
        "tpi": 7, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (1.2363, 1.2500), "pitch_d": (1.1424, 1.1572), "minor_d": (None, None)},
            "2A": {"major_d": (1.2418, 1.2500), "pitch_d": (1.1472, 1.1572), "minor_d": (None, None)},
            "3A": {"major_d": (1.2451, 1.2500), "pitch_d": (1.1510, 1.1572), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (1.1572, 1.1720), "minor_d": (1.0644, 1.1050)},
            "2B": {"major_d": (None, None), "pitch_d": (1.1572, 1.1677), "minor_d": (1.0644, 1.0960)},
            "3B": {"major_d": (None, None), "pitch_d": (1.1572, 1.1643), "minor_d": (1.0644, 1.0889)},
        },
    },
    {
        "key": "1-3/8-6 UNC", "family": "UN/UNC/UNF", "designation": "1-3/8-6 UNC",
        "major_d_basic": 1.3750, "pitch_d_basic": 1.2667, "minor_d_basic": 1.1585,
        "tpi": 6, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (1.3596, 1.3750), "pitch_d": (1.2500, 1.2667), "minor_d": (None, None)},
            "2A": {"major_d": (1.3658, 1.3750), "pitch_d": (1.2553, 1.2667), "minor_d": (None, None)},
            "3A": {"major_d": (1.3695, 1.3750), "pitch_d": (1.2596, 1.2667), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (1.2667, 1.2834), "minor_d": (1.1585, 1.2030)},
            "2B": {"major_d": (None, None), "pitch_d": (1.2667, 1.2786), "minor_d": (1.1585, 1.1930)},
            "3B": {"major_d": (None, None), "pitch_d": (1.2667, 1.2748), "minor_d": (1.1585, 1.1850)},
        },
    },
    {
        "key": "1-1/2-6 UNC", "family": "UN/UNC/UNF", "designation": "1-1/2-6 UNC",
        "major_d_basic": 1.5000, "pitch_d_basic": 1.3917, "minor_d_basic": 1.2835,
        "tpi": 6, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (1.4846, 1.5000), "pitch_d": (1.3750, 1.3917), "minor_d": (None, None)},
            "2A": {"major_d": (1.4908, 1.5000), "pitch_d": (1.3803, 1.3917), "minor_d": (None, None)},
            "3A": {"major_d": (1.4945, 1.5000), "pitch_d": (1.3846, 1.3917), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (1.3917, 1.4084), "minor_d": (1.2835, 1.3280)},
            "2B": {"major_d": (None, None), "pitch_d": (1.3917, 1.4036), "minor_d": (1.2835, 1.3180)},
            "3B": {"major_d": (None, None), "pitch_d": (1.3917, 1.3998), "minor_d": (1.2835, 1.3100)},
        },
    },
]

# ============================= UN / UNF ====================================
_UNF_ENTRIES = [
    {
        "key": "#0-80 UNF", "family": "UN/UNC/UNF", "designation": "#0-80 UNF",
        "major_d_basic": 0.0600, "pitch_d_basic": 0.0519, "minor_d_basic": 0.0438,
        "tpi": 80, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.0578, 0.0600), "pitch_d": (0.0496, 0.0519), "minor_d": (None, None)},
            "2A": {"major_d": (0.0586, 0.0600), "pitch_d": (0.0502, 0.0519), "minor_d": (None, None)},
            "3A": {"major_d": (0.0590, 0.0600), "pitch_d": (0.0506, 0.0519), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.0519, 0.0542), "minor_d": (0.0438, 0.0514)},
            "2B": {"major_d": (None, None), "pitch_d": (0.0519, 0.0536), "minor_d": (0.0438, 0.0496)},
            "3B": {"major_d": (None, None), "pitch_d": (0.0519, 0.0532), "minor_d": (0.0438, 0.0482)},
        },
    },
    {
        "key": "#1-72 UNF", "family": "UN/UNC/UNF", "designation": "#1-72 UNF",
        "major_d_basic": 0.0730, "pitch_d_basic": 0.0640, "minor_d_basic": 0.0550,
        "tpi": 72, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.0706, 0.0730), "pitch_d": (0.0615, 0.0640), "minor_d": (None, None)},
            "2A": {"major_d": (0.0715, 0.0730), "pitch_d": (0.0622, 0.0640), "minor_d": (None, None)},
            "3A": {"major_d": (0.0720, 0.0730), "pitch_d": (0.0627, 0.0640), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.0640, 0.0665), "minor_d": (0.0550, 0.0630)},
            "2B": {"major_d": (None, None), "pitch_d": (0.0640, 0.0658), "minor_d": (0.0550, 0.0612)},
            "3B": {"major_d": (None, None), "pitch_d": (0.0640, 0.0653), "minor_d": (0.0550, 0.0598)},
        },
    },
    {
        "key": "#2-64 UNF", "family": "UN/UNC/UNF", "designation": "#2-64 UNF",
        "major_d_basic": 0.0860, "pitch_d_basic": 0.0759, "minor_d_basic": 0.0657,
        "tpi": 64, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.0834, 0.0860), "pitch_d": (0.0732, 0.0759), "minor_d": (None, None)},
            "2A": {"major_d": (0.0844, 0.0860), "pitch_d": (0.0740, 0.0759), "minor_d": (None, None)},
            "3A": {"major_d": (0.0849, 0.0860), "pitch_d": (0.0745, 0.0759), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.0759, 0.0786), "minor_d": (0.0657, 0.0743)},
            "2B": {"major_d": (None, None), "pitch_d": (0.0759, 0.0778), "minor_d": (0.0657, 0.0723)},
            "3B": {"major_d": (None, None), "pitch_d": (0.0759, 0.0773), "minor_d": (0.0657, 0.0708)},
        },
    },
    {
        "key": "#3-56 UNF", "family": "UN/UNC/UNF", "designation": "#3-56 UNF",
        "major_d_basic": 0.0990, "pitch_d_basic": 0.0874, "minor_d_basic": 0.0758,
        "tpi": 56, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.0962, 0.0990), "pitch_d": (0.0844, 0.0874), "minor_d": (None, None)},
            "2A": {"major_d": (0.0972, 0.0990), "pitch_d": (0.0852, 0.0874), "minor_d": (None, None)},
            "3A": {"major_d": (0.0978, 0.0990), "pitch_d": (0.0858, 0.0874), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.0874, 0.0904), "minor_d": (0.0758, 0.0850)},
            "2B": {"major_d": (None, None), "pitch_d": (0.0874, 0.0896), "minor_d": (0.0758, 0.0830)},
            "3B": {"major_d": (None, None), "pitch_d": (0.0874, 0.0889), "minor_d": (0.0758, 0.0815)},
        },
    },
    {
        "key": "#4-48 UNF", "family": "UN/UNC/UNF", "designation": "#4-48 UNF",
        "major_d_basic": 0.1120, "pitch_d_basic": 0.0985, "minor_d_basic": 0.0849,
        "tpi": 48, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.1088, 0.1120), "pitch_d": (0.0952, 0.0985), "minor_d": (None, None)},
            "2A": {"major_d": (0.1100, 0.1120), "pitch_d": (0.0961, 0.0985), "minor_d": (None, None)},
            "3A": {"major_d": (0.1107, 0.1120), "pitch_d": (0.0968, 0.0985), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.0985, 0.1018), "minor_d": (0.0849, 0.0950)},
            "2B": {"major_d": (None, None), "pitch_d": (0.0985, 0.1009), "minor_d": (0.0849, 0.0927)},
            "3B": {"major_d": (None, None), "pitch_d": (0.0985, 0.1001), "minor_d": (0.0849, 0.0910)},
        },
    },
    {
        "key": "#5-44 UNF", "family": "UN/UNC/UNF", "designation": "#5-44 UNF",
        "major_d_basic": 0.1250, "pitch_d_basic": 0.1102, "minor_d_basic": 0.0955,
        "tpi": 44, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.1216, 0.1250), "pitch_d": (0.1066, 0.1102), "minor_d": (None, None)},
            "2A": {"major_d": (0.1229, 0.1250), "pitch_d": (0.1076, 0.1102), "minor_d": (None, None)},
            "3A": {"major_d": (0.1237, 0.1250), "pitch_d": (0.1084, 0.1102), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.1102, 0.1138), "minor_d": (0.0955, 0.1062)},
            "2B": {"major_d": (None, None), "pitch_d": (0.1102, 0.1128), "minor_d": (0.0955, 0.1038)},
            "3B": {"major_d": (None, None), "pitch_d": (0.1102, 0.1120), "minor_d": (0.0955, 0.1019)},
        },
    },
    {
        "key": "#6-40 UNF", "family": "UN/UNC/UNF", "designation": "#6-40 UNF",
        "major_d_basic": 0.1380, "pitch_d_basic": 0.1218, "minor_d_basic": 0.1055,
        "tpi": 40, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.1344, 0.1380), "pitch_d": (0.1179, 0.1218), "minor_d": (None, None)},
            "2A": {"major_d": (0.1358, 0.1380), "pitch_d": (0.1190, 0.1218), "minor_d": (None, None)},
            "3A": {"major_d": (0.1366, 0.1380), "pitch_d": (0.1198, 0.1218), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.1218, 0.1257), "minor_d": (0.1055, 0.1167)},
            "2B": {"major_d": (None, None), "pitch_d": (0.1218, 0.1245), "minor_d": (0.1055, 0.1140)},
            "3B": {"major_d": (None, None), "pitch_d": (0.1218, 0.1237), "minor_d": (0.1055, 0.1120)},
        },
    },
    {
        "key": "#8-36 UNF", "family": "UN/UNC/UNF", "designation": "#8-36 UNF",
        "major_d_basic": 0.1640, "pitch_d_basic": 0.1460, "minor_d_basic": 0.1279,
        "tpi": 36, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.1600, 0.1640), "pitch_d": (0.1417, 0.1460), "minor_d": (None, None)},
            "2A": {"major_d": (0.1616, 0.1640), "pitch_d": (0.1430, 0.1460), "minor_d": (None, None)},
            "3A": {"major_d": (0.1625, 0.1640), "pitch_d": (0.1439, 0.1460), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.1460, 0.1503), "minor_d": (0.1279, 0.1400)},
            "2B": {"major_d": (None, None), "pitch_d": (0.1460, 0.1490), "minor_d": (0.1279, 0.1371)},
            "3B": {"major_d": (None, None), "pitch_d": (0.1460, 0.1480), "minor_d": (0.1279, 0.1349)},
        },
    },
    {
        "key": "#10-32 UNF", "family": "UN/UNC/UNF", "designation": "#10-32 UNF",
        "major_d_basic": 0.1900, "pitch_d_basic": 0.1697, "minor_d_basic": 0.1494,
        "tpi": 32, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.1858, 0.1900), "pitch_d": (0.1651, 0.1697), "minor_d": (None, None)},
            "2A": {"major_d": (0.1874, 0.1900), "pitch_d": (0.1665, 0.1697), "minor_d": (None, None)},
            "3A": {"major_d": (0.1884, 0.1900), "pitch_d": (0.1675, 0.1697), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.1697, 0.1743), "minor_d": (0.1494, 0.1626)},
            "2B": {"major_d": (None, None), "pitch_d": (0.1697, 0.1729), "minor_d": (0.1494, 0.1594)},
            "3B": {"major_d": (None, None), "pitch_d": (0.1697, 0.1719), "minor_d": (0.1494, 0.1570)},
        },
    },
    {
        "key": "#12-28 UNF", "family": "UN/UNC/UNF", "designation": "#12-28 UNF",
        "major_d_basic": 0.2160, "pitch_d_basic": 0.1928, "minor_d_basic": 0.1696,
        "tpi": 28, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.2114, 0.2160), "pitch_d": (0.1878, 0.1928), "minor_d": (None, None)},
            "2A": {"major_d": (0.2132, 0.2160), "pitch_d": (0.1894, 0.1928), "minor_d": (None, None)},
            "3A": {"major_d": (0.2143, 0.2160), "pitch_d": (0.1905, 0.1928), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.1928, 0.1978), "minor_d": (0.1696, 0.1840)},
            "2B": {"major_d": (None, None), "pitch_d": (0.1928, 0.1963), "minor_d": (0.1696, 0.1805)},
            "3B": {"major_d": (None, None), "pitch_d": (0.1928, 0.1951), "minor_d": (0.1696, 0.1778)},
        },
    },
    {
        "key": "1/4-28 UNF", "family": "UN/UNC/UNF", "designation": "1/4-28 UNF",
        "major_d_basic": 0.2500, "pitch_d_basic": 0.2268, "minor_d_basic": 0.2036,
        "tpi": 28, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.2454, 0.2500), "pitch_d": (0.2218, 0.2268), "minor_d": (None, None)},
            "2A": {"major_d": (0.2472, 0.2500), "pitch_d": (0.2234, 0.2268), "minor_d": (None, None)},
            "3A": {"major_d": (0.2483, 0.2500), "pitch_d": (0.2245, 0.2268), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.2268, 0.2318), "minor_d": (0.2036, 0.2180)},
            "2B": {"major_d": (None, None), "pitch_d": (0.2268, 0.2303), "minor_d": (0.2036, 0.2145)},
            "3B": {"major_d": (None, None), "pitch_d": (0.2268, 0.2291), "minor_d": (0.2036, 0.2118)},
        },
    },
    {
        "key": "5/16-24 UNF", "family": "UN/UNC/UNF", "designation": "5/16-24 UNF",
        "major_d_basic": 0.3125, "pitch_d_basic": 0.2854, "minor_d_basic": 0.2584,
        "tpi": 24, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.3073, 0.3125), "pitch_d": (0.2798, 0.2854), "minor_d": (None, None)},
            "2A": {"major_d": (0.3093, 0.3125), "pitch_d": (0.2815, 0.2854), "minor_d": (None, None)},
            "3A": {"major_d": (0.3105, 0.3125), "pitch_d": (0.2827, 0.2854), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.2854, 0.2910), "minor_d": (0.2584, 0.2742)},
            "2B": {"major_d": (None, None), "pitch_d": (0.2854, 0.2893), "minor_d": (0.2584, 0.2704)},
            "3B": {"major_d": (None, None), "pitch_d": (0.2854, 0.2881), "minor_d": (0.2584, 0.2674)},
        },
    },
    {
        "key": "3/8-24 UNF", "family": "UN/UNC/UNF", "designation": "3/8-24 UNF",
        "major_d_basic": 0.3750, "pitch_d_basic": 0.3479, "minor_d_basic": 0.3209,
        "tpi": 24, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.3698, 0.3750), "pitch_d": (0.3423, 0.3479), "minor_d": (None, None)},
            "2A": {"major_d": (0.3718, 0.3750), "pitch_d": (0.3440, 0.3479), "minor_d": (None, None)},
            "3A": {"major_d": (0.3730, 0.3750), "pitch_d": (0.3452, 0.3479), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.3479, 0.3535), "minor_d": (0.3209, 0.3367)},
            "2B": {"major_d": (None, None), "pitch_d": (0.3479, 0.3518), "minor_d": (0.3209, 0.3329)},
            "3B": {"major_d": (None, None), "pitch_d": (0.3479, 0.3506), "minor_d": (0.3209, 0.3299)},
        },
    },
    {
        "key": "7/16-20 UNF", "family": "UN/UNC/UNF", "designation": "7/16-20 UNF",
        "major_d_basic": 0.4375, "pitch_d_basic": 0.4050, "minor_d_basic": 0.3725,
        "tpi": 20, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.4317, 0.4375), "pitch_d": (0.3988, 0.4050), "minor_d": (None, None)},
            "2A": {"major_d": (0.4339, 0.4375), "pitch_d": (0.4007, 0.4050), "minor_d": (None, None)},
            "3A": {"major_d": (0.4353, 0.4375), "pitch_d": (0.4022, 0.4050), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.4050, 0.4112), "minor_d": (0.3725, 0.3905)},
            "2B": {"major_d": (None, None), "pitch_d": (0.4050, 0.4093), "minor_d": (0.3725, 0.3865)},
            "3B": {"major_d": (None, None), "pitch_d": (0.4050, 0.4078), "minor_d": (0.3725, 0.3834)},
        },
    },
    {
        "key": "1/2-20 UNF", "family": "UN/UNC/UNF", "designation": "1/2-20 UNF",
        "major_d_basic": 0.5000, "pitch_d_basic": 0.4675, "minor_d_basic": 0.4350,
        "tpi": 20, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.4942, 0.5000), "pitch_d": (0.4613, 0.4675), "minor_d": (None, None)},
            "2A": {"major_d": (0.4964, 0.5000), "pitch_d": (0.4632, 0.4675), "minor_d": (None, None)},
            "3A": {"major_d": (0.4978, 0.5000), "pitch_d": (0.4647, 0.4675), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.4675, 0.4737), "minor_d": (0.4350, 0.4530)},
            "2B": {"major_d": (None, None), "pitch_d": (0.4675, 0.4718), "minor_d": (0.4350, 0.4490)},
            "3B": {"major_d": (None, None), "pitch_d": (0.4675, 0.4703), "minor_d": (0.4350, 0.4459)},
        },
    },
    {
        "key": "9/16-18 UNF", "family": "UN/UNC/UNF", "designation": "9/16-18 UNF",
        "major_d_basic": 0.5625, "pitch_d_basic": 0.5264, "minor_d_basic": 0.4903,
        "tpi": 18, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.5563, 0.5625), "pitch_d": (0.5197, 0.5264), "minor_d": (None, None)},
            "2A": {"major_d": (0.5587, 0.5625), "pitch_d": (0.5218, 0.5264), "minor_d": (None, None)},
            "3A": {"major_d": (0.5602, 0.5625), "pitch_d": (0.5234, 0.5264), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.5264, 0.5331), "minor_d": (0.4903, 0.5100)},
            "2B": {"major_d": (None, None), "pitch_d": (0.5264, 0.5310), "minor_d": (0.4903, 0.5057)},
            "3B": {"major_d": (None, None), "pitch_d": (0.5264, 0.5294), "minor_d": (0.4903, 0.5024)},
        },
    },
    {
        "key": "5/8-18 UNF", "family": "UN/UNC/UNF", "designation": "5/8-18 UNF",
        "major_d_basic": 0.6250, "pitch_d_basic": 0.5889, "minor_d_basic": 0.5528,
        "tpi": 18, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.6188, 0.6250), "pitch_d": (0.5822, 0.5889), "minor_d": (None, None)},
            "2A": {"major_d": (0.6212, 0.6250), "pitch_d": (0.5843, 0.5889), "minor_d": (None, None)},
            "3A": {"major_d": (0.6227, 0.6250), "pitch_d": (0.5859, 0.5889), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.5889, 0.5956), "minor_d": (0.5528, 0.5725)},
            "2B": {"major_d": (None, None), "pitch_d": (0.5889, 0.5935), "minor_d": (0.5528, 0.5682)},
            "3B": {"major_d": (None, None), "pitch_d": (0.5889, 0.5919), "minor_d": (0.5528, 0.5649)},
        },
    },
    {
        "key": "3/4-16 UNF", "family": "UN/UNC/UNF", "designation": "3/4-16 UNF",
        "major_d_basic": 0.7500, "pitch_d_basic": 0.7094, "minor_d_basic": 0.6688,
        "tpi": 16, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.7432, 0.7500), "pitch_d": (0.7020, 0.7094), "minor_d": (None, None)},
            "2A": {"major_d": (0.7458, 0.7500), "pitch_d": (0.7043, 0.7094), "minor_d": (None, None)},
            "3A": {"major_d": (0.7474, 0.7500), "pitch_d": (0.7061, 0.7094), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.7094, 0.7168), "minor_d": (0.6688, 0.6901)},
            "2B": {"major_d": (None, None), "pitch_d": (0.7094, 0.7145), "minor_d": (0.6688, 0.6854)},
            "3B": {"major_d": (None, None), "pitch_d": (0.7094, 0.7127), "minor_d": (0.6688, 0.6817)},
        },
    },
    {
        "key": "7/8-14 UNF", "family": "UN/UNC/UNF", "designation": "7/8-14 UNF",
        "major_d_basic": 0.8750, "pitch_d_basic": 0.8286, "minor_d_basic": 0.7822,
        "tpi": 14, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.8674, 0.8750), "pitch_d": (0.8204, 0.8286), "minor_d": (None, None)},
            "2A": {"major_d": (0.8704, 0.8750), "pitch_d": (0.8229, 0.8286), "minor_d": (None, None)},
            "3A": {"major_d": (0.8722, 0.8750), "pitch_d": (0.8249, 0.8286), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.8286, 0.8368), "minor_d": (0.7822, 0.8055)},
            "2B": {"major_d": (None, None), "pitch_d": (0.8286, 0.8343), "minor_d": (0.7822, 0.8004)},
            "3B": {"major_d": (None, None), "pitch_d": (0.8286, 0.8323), "minor_d": (0.7822, 0.7964)},
        },
    },
    {
        "key": "1-12 UNF", "family": "UN/UNC/UNF", "designation": "1-12 UNF",
        "major_d_basic": 1.0000, "pitch_d_basic": 0.9459, "minor_d_basic": 0.8917,
        "tpi": 12, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (0.9913, 1.0000), "pitch_d": (0.9365, 0.9459), "minor_d": (None, None)},
            "2A": {"major_d": (0.9948, 1.0000), "pitch_d": (0.9393, 0.9459), "minor_d": (None, None)},
            "3A": {"major_d": (0.9969, 1.0000), "pitch_d": (0.9416, 0.9459), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (0.9459, 0.9553), "minor_d": (0.8917, 0.9183)},
            "2B": {"major_d": (None, None), "pitch_d": (0.9459, 0.9527), "minor_d": (0.8917, 0.9125)},
            "3B": {"major_d": (None, None), "pitch_d": (0.9459, 0.9505), "minor_d": (0.8917, 0.9078)},
        },
    },
    {
        "key": "1-1/8-12 UNF", "family": "UN/UNC/UNF", "designation": "1-1/8-12 UNF",
        "major_d_basic": 1.1250, "pitch_d_basic": 1.0709, "minor_d_basic": 1.0167,
        "tpi": 12, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (1.1163, 1.1250), "pitch_d": (1.0615, 1.0709), "minor_d": (None, None)},
            "2A": {"major_d": (1.1198, 1.1250), "pitch_d": (1.0643, 1.0709), "minor_d": (None, None)},
            "3A": {"major_d": (1.1219, 1.1250), "pitch_d": (1.0666, 1.0709), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (1.0709, 1.0803), "minor_d": (1.0167, 1.0433)},
            "2B": {"major_d": (None, None), "pitch_d": (1.0709, 1.0777), "minor_d": (1.0167, 1.0375)},
            "3B": {"major_d": (None, None), "pitch_d": (1.0709, 1.0755), "minor_d": (1.0167, 1.0328)},
        },
    },
    {
        "key": "1-1/4-12 UNF", "family": "UN/UNC/UNF", "designation": "1-1/4-12 UNF",
        "major_d_basic": 1.2500, "pitch_d_basic": 1.1959, "minor_d_basic": 1.1417,
        "tpi": 12, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (1.2413, 1.2500), "pitch_d": (1.1865, 1.1959), "minor_d": (None, None)},
            "2A": {"major_d": (1.2448, 1.2500), "pitch_d": (1.1893, 1.1959), "minor_d": (None, None)},
            "3A": {"major_d": (1.2469, 1.2500), "pitch_d": (1.1916, 1.1959), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (1.1959, 1.2053), "minor_d": (1.1417, 1.1683)},
            "2B": {"major_d": (None, None), "pitch_d": (1.1959, 1.2027), "minor_d": (1.1417, 1.1625)},
            "3B": {"major_d": (None, None), "pitch_d": (1.1959, 1.2005), "minor_d": (1.1417, 1.1578)},
        },
    },
    {
        "key": "1-3/8-12 UNF", "family": "UN/UNC/UNF", "designation": "1-3/8-12 UNF",
        "major_d_basic": 1.3750, "pitch_d_basic": 1.3209, "minor_d_basic": 1.2667,
        "tpi": 12, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (1.3663, 1.3750), "pitch_d": (1.3115, 1.3209), "minor_d": (None, None)},
            "2A": {"major_d": (1.3698, 1.3750), "pitch_d": (1.3143, 1.3209), "minor_d": (None, None)},
            "3A": {"major_d": (1.3719, 1.3750), "pitch_d": (1.3166, 1.3209), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (1.3209, 1.3303), "minor_d": (1.2667, 1.2933)},
            "2B": {"major_d": (None, None), "pitch_d": (1.3209, 1.3277), "minor_d": (1.2667, 1.2875)},
            "3B": {"major_d": (None, None), "pitch_d": (1.3209, 1.3255), "minor_d": (1.2667, 1.2828)},
        },
    },
    {
        "key": "1-1/2-12 UNF", "family": "UN/UNC/UNF", "designation": "1-1/2-12 UNF",
        "major_d_basic": 1.5000, "pitch_d_basic": 1.4459, "minor_d_basic": 1.3917,
        "tpi": 12, "pitch_mm": None, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "1A": {"major_d": (1.4913, 1.5000), "pitch_d": (1.4365, 1.4459), "minor_d": (None, None)},
            "2A": {"major_d": (1.4948, 1.5000), "pitch_d": (1.4393, 1.4459), "minor_d": (None, None)},
            "3A": {"major_d": (1.4969, 1.5000), "pitch_d": (1.4416, 1.4459), "minor_d": (None, None)},
            "1B": {"major_d": (None, None), "pitch_d": (1.4459, 1.4553), "minor_d": (1.3917, 1.4183)},
            "2B": {"major_d": (None, None), "pitch_d": (1.4459, 1.4527), "minor_d": (1.3917, 1.4125)},
            "3B": {"major_d": (None, None), "pitch_d": (1.4459, 1.4505), "minor_d": (1.3917, 1.4078)},
        },
    },
]

# ============================= Metric Coarse ===============================
# Dimensions converted from mm to inches (÷ 25.4).
# Tolerances per ISO 261 for 6g (external) and 6H (internal).
_METRIC_COARSE_ENTRIES = [
    {
        "key": "M3x0.5", "family": "Metric", "designation": "M3x0.5",
        "major_d_basic": 0.1181, "pitch_d_basic": 0.1043, "minor_d_basic": 0.0938,
        "tpi": None, "pitch_mm": 0.5, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.1150, 0.1173), "pitch_d": (0.1017, 0.1036), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.1043, 0.1063), "minor_d": (0.0938, 0.0984)},
        },
    },
    {
        "key": "M3.5x0.6", "family": "Metric", "designation": "M3.5x0.6",
        "major_d_basic": 0.1378, "pitch_d_basic": 0.1218, "minor_d_basic": 0.1096,
        "tpi": None, "pitch_mm": 0.6, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.1344, 0.1369), "pitch_d": (0.1189, 0.1210), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.1218, 0.1241), "minor_d": (0.1096, 0.1148)},
        },
    },
    {
        "key": "M4x0.7", "family": "Metric", "designation": "M4x0.7",
        "major_d_basic": 0.1575, "pitch_d_basic": 0.1394, "minor_d_basic": 0.1254,
        "tpi": None, "pitch_mm": 0.7, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.1538, 0.1565), "pitch_d": (0.1361, 0.1385), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.1394, 0.1419), "minor_d": (0.1254, 0.1311)},
        },
    },
    {
        "key": "M5x0.8", "family": "Metric", "designation": "M5x0.8",
        "major_d_basic": 0.1969, "pitch_d_basic": 0.1744, "minor_d_basic": 0.1571,
        "tpi": None, "pitch_mm": 0.8, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.1927, 0.1957), "pitch_d": (0.1708, 0.1734), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.1744, 0.1772), "minor_d": (0.1571, 0.1634)},
        },
    },
    {
        "key": "M6x1", "family": "Metric", "designation": "M6x1",
        "major_d_basic": 0.2362, "pitch_d_basic": 0.2096, "minor_d_basic": 0.1891,
        "tpi": None, "pitch_mm": 1.0, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.2314, 0.2348), "pitch_d": (0.2053, 0.2083), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.2096, 0.2128), "minor_d": (0.1891, 0.1963)},
        },
    },
    {
        "key": "M7x1", "family": "Metric", "designation": "M7x1",
        "major_d_basic": 0.2756, "pitch_d_basic": 0.2489, "minor_d_basic": 0.2284,
        "tpi": None, "pitch_mm": 1.0, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.2708, 0.2742), "pitch_d": (0.2446, 0.2476), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.2489, 0.2521), "minor_d": (0.2284, 0.2356)},
        },
    },
    {
        "key": "M8x1.25", "family": "Metric", "designation": "M8x1.25",
        "major_d_basic": 0.3150, "pitch_d_basic": 0.2818, "minor_d_basic": 0.2554,
        "tpi": None, "pitch_mm": 1.25, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.3095, 0.3134), "pitch_d": (0.2769, 0.2803), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.2818, 0.2854), "minor_d": (0.2554, 0.2636)},
        },
    },
    {
        "key": "M10x1.5", "family": "Metric", "designation": "M10x1.5",
        "major_d_basic": 0.3937, "pitch_d_basic": 0.3523, "minor_d_basic": 0.3189,
        "tpi": None, "pitch_mm": 1.5, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.3875, 0.3919), "pitch_d": (0.3467, 0.3505), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.3523, 0.3563), "minor_d": (0.3189, 0.3280)},
        },
    },
    {
        "key": "M12x1.75", "family": "Metric", "designation": "M12x1.75",
        "major_d_basic": 0.4724, "pitch_d_basic": 0.4228, "minor_d_basic": 0.3825,
        "tpi": None, "pitch_mm": 1.75, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.4654, 0.4703), "pitch_d": (0.4165, 0.4208), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.4228, 0.4273), "minor_d": (0.3825, 0.3925)},
        },
    },
    {
        "key": "M14x2", "family": "Metric", "designation": "M14x2",
        "major_d_basic": 0.5512, "pitch_d_basic": 0.4934, "minor_d_basic": 0.4461,
        "tpi": None, "pitch_mm": 2.0, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.5435, 0.5488), "pitch_d": (0.4864, 0.4911), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.4934, 0.4983), "minor_d": (0.4461, 0.4571)},
        },
    },
    {
        "key": "M16x2", "family": "Metric", "designation": "M16x2",
        "major_d_basic": 0.6299, "pitch_d_basic": 0.5721, "minor_d_basic": 0.5248,
        "tpi": None, "pitch_mm": 2.0, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.6222, 0.6275), "pitch_d": (0.5651, 0.5698), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.5721, 0.5770), "minor_d": (0.5248, 0.5358)},
        },
    },
    {
        "key": "M18x2.5", "family": "Metric", "designation": "M18x2.5",
        "major_d_basic": 0.7087, "pitch_d_basic": 0.6417, "minor_d_basic": 0.5866,
        "tpi": None, "pitch_mm": 2.5, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.7001, 0.7060), "pitch_d": (0.6339, 0.6391), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.6417, 0.6472), "minor_d": (0.5866, 0.5988)},
        },
    },
    {
        "key": "M20x2.5", "family": "Metric", "designation": "M20x2.5",
        "major_d_basic": 0.7874, "pitch_d_basic": 0.7204, "minor_d_basic": 0.6654,
        "tpi": None, "pitch_mm": 2.5, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.7788, 0.7847), "pitch_d": (0.7126, 0.7178), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.7204, 0.7259), "minor_d": (0.6654, 0.6776)},
        },
    },
    {
        "key": "M22x2.5", "family": "Metric", "designation": "M22x2.5",
        "major_d_basic": 0.8661, "pitch_d_basic": 0.7992, "minor_d_basic": 0.7441,
        "tpi": None, "pitch_mm": 2.5, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.8575, 0.8634), "pitch_d": (0.7914, 0.7966), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.7992, 0.8047), "minor_d": (0.7441, 0.7563)},
        },
    },
    {
        "key": "M24x3", "family": "Metric", "designation": "M24x3",
        "major_d_basic": 0.9449, "pitch_d_basic": 0.8688, "minor_d_basic": 0.8058,
        "tpi": None, "pitch_mm": 3.0, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.9353, 0.9419), "pitch_d": (0.8601, 0.8659), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.8688, 0.8749), "minor_d": (0.8058, 0.8194)},
        },
    },
    {
        "key": "M27x3", "family": "Metric", "designation": "M27x3",
        "major_d_basic": 1.0630, "pitch_d_basic": 0.9869, "minor_d_basic": 0.9239,
        "tpi": None, "pitch_mm": 3.0, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (1.0534, 1.0600), "pitch_d": (0.9782, 0.9840), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.9869, 0.9930), "minor_d": (0.9239, 0.9375)},
        },
    },
    {
        "key": "M30x3.5", "family": "Metric", "designation": "M30x3.5",
        "major_d_basic": 1.1811, "pitch_d_basic": 1.0960, "minor_d_basic": 1.0252,
        "tpi": None, "pitch_mm": 3.5, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (1.1706, 1.1778), "pitch_d": (1.0865, 1.0928), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (1.0960, 1.1026), "minor_d": (1.0252, 1.0401)},
        },
    },
    {
        "key": "M33x3.5", "family": "Metric", "designation": "M33x3.5",
        "major_d_basic": 1.2992, "pitch_d_basic": 1.2141, "minor_d_basic": 1.1433,
        "tpi": None, "pitch_mm": 3.5, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (1.2887, 1.2959), "pitch_d": (1.2046, 1.2109), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (1.2141, 1.2207), "minor_d": (1.1433, 1.1582)},
        },
    },
    {
        "key": "M36x4", "family": "Metric", "designation": "M36x4",
        "major_d_basic": 1.4173, "pitch_d_basic": 1.3228, "minor_d_basic": 1.2441,
        "tpi": None, "pitch_mm": 4.0, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (1.4059, 1.4137), "pitch_d": (1.3125, 1.3193), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (1.3228, 1.3300), "minor_d": (1.2441, 1.2604)},
        },
    },
]

# ============================= Metric Fine =================================
_METRIC_FINE_ENTRIES = [
    {
        "key": "M3x0.35", "family": "Metric", "designation": "M3x0.35",
        "major_d_basic": 0.1181, "pitch_d_basic": 0.1074, "minor_d_basic": 0.0993,
        "tpi": None, "pitch_mm": 0.35, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.1157, 0.1175), "pitch_d": (0.1053, 0.1069), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.1074, 0.1090), "minor_d": (0.0993, 0.1028)},
        },
    },
    {
        "key": "M4x0.5", "family": "Metric", "designation": "M4x0.5",
        "major_d_basic": 0.1575, "pitch_d_basic": 0.1437, "minor_d_basic": 0.1332,
        "tpi": None, "pitch_mm": 0.5, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.1547, 0.1567), "pitch_d": (0.1413, 0.1431), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.1437, 0.1456), "minor_d": (0.1332, 0.1372)},
        },
    },
    {
        "key": "M5x0.5", "family": "Metric", "designation": "M5x0.5",
        "major_d_basic": 0.1969, "pitch_d_basic": 0.1831, "minor_d_basic": 0.1726,
        "tpi": None, "pitch_mm": 0.5, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.1941, 0.1961), "pitch_d": (0.1807, 0.1825), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.1831, 0.1850), "minor_d": (0.1726, 0.1766)},
        },
    },
    {
        "key": "M6x0.75", "family": "Metric", "designation": "M6x0.75",
        "major_d_basic": 0.2362, "pitch_d_basic": 0.2165, "minor_d_basic": 0.2013,
        "tpi": None, "pitch_mm": 0.75, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.2327, 0.2351), "pitch_d": (0.2135, 0.2155), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.2165, 0.2187), "minor_d": (0.2013, 0.2063)},
        },
    },
    {
        "key": "M8x1", "family": "Metric", "designation": "M8x1",
        "major_d_basic": 0.3150, "pitch_d_basic": 0.2884, "minor_d_basic": 0.2678,
        "tpi": None, "pitch_mm": 1.0, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.3102, 0.3134), "pitch_d": (0.2843, 0.2871), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.2884, 0.2914), "minor_d": (0.2678, 0.2742)},
        },
    },
    {
        "key": "M10x1", "family": "Metric", "designation": "M10x1",
        "major_d_basic": 0.3937, "pitch_d_basic": 0.3671, "minor_d_basic": 0.3465,
        "tpi": None, "pitch_mm": 1.0, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.3889, 0.3921), "pitch_d": (0.3630, 0.3658), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.3671, 0.3701), "minor_d": (0.3465, 0.3529)},
        },
    },
    {
        "key": "M10x1.25", "family": "Metric", "designation": "M10x1.25",
        "major_d_basic": 0.3937, "pitch_d_basic": 0.3605, "minor_d_basic": 0.3341,
        "tpi": None, "pitch_mm": 1.25, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.3882, 0.3919), "pitch_d": (0.3558, 0.3590), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.3605, 0.3639), "minor_d": (0.3341, 0.3413)},
        },
    },
    {
        "key": "M12x1.25", "family": "Metric", "designation": "M12x1.25",
        "major_d_basic": 0.4724, "pitch_d_basic": 0.4392, "minor_d_basic": 0.4128,
        "tpi": None, "pitch_mm": 1.25, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.4669, 0.4706), "pitch_d": (0.4345, 0.4377), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.4392, 0.4426), "minor_d": (0.4128, 0.4200)},
        },
    },
    {
        "key": "M12x1.5", "family": "Metric", "designation": "M12x1.5",
        "major_d_basic": 0.4724, "pitch_d_basic": 0.4310, "minor_d_basic": 0.3976,
        "tpi": None, "pitch_mm": 1.5, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.4662, 0.4704), "pitch_d": (0.4256, 0.4293), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.4310, 0.4349), "minor_d": (0.3976, 0.4057)},
        },
    },
    {
        "key": "M14x1.5", "family": "Metric", "designation": "M14x1.5",
        "major_d_basic": 0.5512, "pitch_d_basic": 0.5098, "minor_d_basic": 0.4764,
        "tpi": None, "pitch_mm": 1.5, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.5450, 0.5492), "pitch_d": (0.5044, 0.5081), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.5098, 0.5137), "minor_d": (0.4764, 0.4845)},
        },
    },
    {
        "key": "M16x1.5", "family": "Metric", "designation": "M16x1.5",
        "major_d_basic": 0.6299, "pitch_d_basic": 0.5885, "minor_d_basic": 0.5551,
        "tpi": None, "pitch_mm": 1.5, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.6237, 0.6279), "pitch_d": (0.5831, 0.5868), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.5885, 0.5924), "minor_d": (0.5551, 0.5632)},
        },
    },
    {
        "key": "M18x1.5", "family": "Metric", "designation": "M18x1.5",
        "major_d_basic": 0.7087, "pitch_d_basic": 0.6673, "minor_d_basic": 0.6339,
        "tpi": None, "pitch_mm": 1.5, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.7025, 0.7067), "pitch_d": (0.6619, 0.6656), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.6673, 0.6712), "minor_d": (0.6339, 0.6420)},
        },
    },
    {
        "key": "M18x2", "family": "Metric", "designation": "M18x2",
        "major_d_basic": 0.7087, "pitch_d_basic": 0.6509, "minor_d_basic": 0.6036,
        "tpi": None, "pitch_mm": 2.0, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.7010, 0.7063), "pitch_d": (0.6439, 0.6486), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.6509, 0.6558), "minor_d": (0.6036, 0.6136)},
        },
    },
    {
        "key": "M20x1.5", "family": "Metric", "designation": "M20x1.5",
        "major_d_basic": 0.7874, "pitch_d_basic": 0.7460, "minor_d_basic": 0.7126,
        "tpi": None, "pitch_mm": 1.5, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.7812, 0.7854), "pitch_d": (0.7406, 0.7443), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.7460, 0.7499), "minor_d": (0.7126, 0.7207)},
        },
    },
    {
        "key": "M20x2", "family": "Metric", "designation": "M20x2",
        "major_d_basic": 0.7874, "pitch_d_basic": 0.7296, "minor_d_basic": 0.6823,
        "tpi": None, "pitch_mm": 2.0, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.7797, 0.7850), "pitch_d": (0.7226, 0.7273), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.7296, 0.7345), "minor_d": (0.6823, 0.6923)},
        },
    },
    {
        "key": "M24x2", "family": "Metric", "designation": "M24x2",
        "major_d_basic": 0.9449, "pitch_d_basic": 0.8871, "minor_d_basic": 0.8398,
        "tpi": None, "pitch_mm": 2.0, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (0.9372, 0.9425), "pitch_d": (0.8801, 0.8848), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (0.8871, 0.8920), "minor_d": (0.8398, 0.8498)},
        },
    },
    {
        "key": "M27x2", "family": "Metric", "designation": "M27x2",
        "major_d_basic": 1.0630, "pitch_d_basic": 1.0052, "minor_d_basic": 0.9579,
        "tpi": None, "pitch_mm": 2.0, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (1.0553, 1.0606), "pitch_d": (0.9982, 1.0029), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (1.0052, 1.0101), "minor_d": (0.9579, 0.9679)},
        },
    },
    {
        "key": "M30x2", "family": "Metric", "designation": "M30x2",
        "major_d_basic": 1.1811, "pitch_d_basic": 1.1233, "minor_d_basic": 1.0760,
        "tpi": None, "pitch_mm": 2.0, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (1.1734, 1.1787), "pitch_d": (1.1163, 1.1210), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (1.1233, 1.1282), "minor_d": (1.0760, 1.0860)},
        },
    },
    {
        "key": "M33x2", "family": "Metric", "designation": "M33x2",
        "major_d_basic": 1.2992, "pitch_d_basic": 1.2414, "minor_d_basic": 1.1941,
        "tpi": None, "pitch_mm": 2.0, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (1.2915, 1.2968), "pitch_d": (1.2344, 1.2391), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (1.2414, 1.2463), "minor_d": (1.1941, 1.2041)},
        },
    },
    {
        "key": "M36x3", "family": "Metric", "designation": "M36x3",
        "major_d_basic": 1.4173, "pitch_d_basic": 1.3412, "minor_d_basic": 1.2782,
        "tpi": None, "pitch_mm": 3.0, "thread_angle": 60, "compound_angle": 29.5,
        "tolerances": {
            "6g": {"major_d": (1.4077, 1.4143), "pitch_d": (1.3325, 1.3383), "minor_d": (None, None)},
            "6H": {"major_d": (None, None), "pitch_d": (1.3412, 1.3473), "minor_d": (1.2782, 1.2918)},
        },
    },
]

# ============================= Acme ========================================
# Per ASME B1.5.  29° thread angle, 14.5° compound.
# Fit classes 2G, 3G, 4G apply to both external and internal.
_ACME_ENTRIES = [
    {
        "key": "1/4-16 Acme", "family": "Acme", "designation": "1/4-16 Acme",
        "major_d_basic": 0.2500, "pitch_d_basic": 0.2188, "minor_d_basic": 0.1875,
        "tpi": 16, "pitch_mm": None, "thread_angle": 29, "compound_angle": 14.5,
        "tolerances": {
            "2G": {"major_d": (0.2450, 0.2500), "pitch_d": (0.2138, 0.2188), "minor_d": (0.1825, 0.1875)},
            "3G": {"major_d": (0.2463, 0.2500), "pitch_d": (0.2151, 0.2188), "minor_d": (0.1838, 0.1875)},
            "4G": {"major_d": (0.2475, 0.2500), "pitch_d": (0.2163, 0.2188), "minor_d": (0.1850, 0.1875)},
        },
    },
    {
        "key": "5/16-14 Acme", "family": "Acme", "designation": "5/16-14 Acme",
        "major_d_basic": 0.3125, "pitch_d_basic": 0.2768, "minor_d_basic": 0.2411,
        "tpi": 14, "pitch_mm": None, "thread_angle": 29, "compound_angle": 14.5,
        "tolerances": {
            "2G": {"major_d": (0.3069, 0.3125), "pitch_d": (0.2712, 0.2768), "minor_d": (0.2355, 0.2411)},
            "3G": {"major_d": (0.3084, 0.3125), "pitch_d": (0.2727, 0.2768), "minor_d": (0.2370, 0.2411)},
            "4G": {"major_d": (0.3097, 0.3125), "pitch_d": (0.2740, 0.2768), "minor_d": (0.2383, 0.2411)},
        },
    },
    {
        "key": "3/8-12 Acme", "family": "Acme", "designation": "3/8-12 Acme",
        "major_d_basic": 0.3750, "pitch_d_basic": 0.3333, "minor_d_basic": 0.2917,
        "tpi": 12, "pitch_mm": None, "thread_angle": 29, "compound_angle": 14.5,
        "tolerances": {
            "2G": {"major_d": (0.3686, 0.3750), "pitch_d": (0.3269, 0.3333), "minor_d": (0.2853, 0.2917)},
            "3G": {"major_d": (0.3703, 0.3750), "pitch_d": (0.3286, 0.3333), "minor_d": (0.2870, 0.2917)},
            "4G": {"major_d": (0.3718, 0.3750), "pitch_d": (0.3301, 0.3333), "minor_d": (0.2885, 0.2917)},
        },
    },
    {
        "key": "7/16-12 Acme", "family": "Acme", "designation": "7/16-12 Acme",
        "major_d_basic": 0.4375, "pitch_d_basic": 0.3958, "minor_d_basic": 0.3542,
        "tpi": 12, "pitch_mm": None, "thread_angle": 29, "compound_angle": 14.5,
        "tolerances": {
            "2G": {"major_d": (0.4311, 0.4375), "pitch_d": (0.3894, 0.3958), "minor_d": (0.3478, 0.3542)},
            "3G": {"major_d": (0.4328, 0.4375), "pitch_d": (0.3911, 0.3958), "minor_d": (0.3495, 0.3542)},
            "4G": {"major_d": (0.4343, 0.4375), "pitch_d": (0.3926, 0.3958), "minor_d": (0.3510, 0.3542)},
        },
    },
    {
        "key": "1/2-10 Acme", "family": "Acme", "designation": "1/2-10 Acme",
        "major_d_basic": 0.5000, "pitch_d_basic": 0.4500, "minor_d_basic": 0.4000,
        "tpi": 10, "pitch_mm": None, "thread_angle": 29, "compound_angle": 14.5,
        "tolerances": {
            "2G": {"major_d": (0.4926, 0.5000), "pitch_d": (0.4426, 0.4500), "minor_d": (0.3926, 0.4000)},
            "3G": {"major_d": (0.4946, 0.5000), "pitch_d": (0.4446, 0.4500), "minor_d": (0.3946, 0.4000)},
            "4G": {"major_d": (0.4963, 0.5000), "pitch_d": (0.4463, 0.4500), "minor_d": (0.3963, 0.4000)},
        },
    },
    {
        "key": "5/8-8 Acme", "family": "Acme", "designation": "5/8-8 Acme",
        "major_d_basic": 0.6250, "pitch_d_basic": 0.5625, "minor_d_basic": 0.5000,
        "tpi": 8, "pitch_mm": None, "thread_angle": 29, "compound_angle": 14.5,
        "tolerances": {
            "2G": {"major_d": (0.6163, 0.6250), "pitch_d": (0.5538, 0.5625), "minor_d": (0.4913, 0.5000)},
            "3G": {"major_d": (0.6186, 0.6250), "pitch_d": (0.5561, 0.5625), "minor_d": (0.4936, 0.5000)},
            "4G": {"major_d": (0.6207, 0.6250), "pitch_d": (0.5582, 0.5625), "minor_d": (0.4957, 0.5000)},
        },
    },
    {
        "key": "3/4-6 Acme", "family": "Acme", "designation": "3/4-6 Acme",
        "major_d_basic": 0.7500, "pitch_d_basic": 0.6667, "minor_d_basic": 0.5833,
        "tpi": 6, "pitch_mm": None, "thread_angle": 29, "compound_angle": 14.5,
        "tolerances": {
            "2G": {"major_d": (0.7396, 0.7500), "pitch_d": (0.6563, 0.6667), "minor_d": (0.5729, 0.5833)},
            "3G": {"major_d": (0.7424, 0.7500), "pitch_d": (0.6591, 0.6667), "minor_d": (0.5757, 0.5833)},
            "4G": {"major_d": (0.7448, 0.7500), "pitch_d": (0.6615, 0.6667), "minor_d": (0.5781, 0.5833)},
        },
    },
    {
        "key": "7/8-6 Acme", "family": "Acme", "designation": "7/8-6 Acme",
        "major_d_basic": 0.8750, "pitch_d_basic": 0.7917, "minor_d_basic": 0.7083,
        "tpi": 6, "pitch_mm": None, "thread_angle": 29, "compound_angle": 14.5,
        "tolerances": {
            "2G": {"major_d": (0.8640, 0.8750), "pitch_d": (0.7807, 0.7917), "minor_d": (0.6973, 0.7083)},
            "3G": {"major_d": (0.8670, 0.8750), "pitch_d": (0.7837, 0.7917), "minor_d": (0.7003, 0.7083)},
            "4G": {"major_d": (0.8696, 0.8750), "pitch_d": (0.7863, 0.7917), "minor_d": (0.7029, 0.7083)},
        },
    },
    {
        "key": "1-5 Acme", "family": "Acme", "designation": "1-5 Acme",
        "major_d_basic": 1.0000, "pitch_d_basic": 0.9000, "minor_d_basic": 0.8000,
        "tpi": 5, "pitch_mm": None, "thread_angle": 29, "compound_angle": 14.5,
        "tolerances": {
            "2G": {"major_d": (0.9876, 1.0000), "pitch_d": (0.8876, 0.9000), "minor_d": (0.7876, 0.8000)},
            "3G": {"major_d": (0.9910, 1.0000), "pitch_d": (0.8910, 0.9000), "minor_d": (0.7910, 0.8000)},
            "4G": {"major_d": (0.9938, 1.0000), "pitch_d": (0.8938, 0.9000), "minor_d": (0.7938, 0.8000)},
        },
    },
    {
        "key": "1-1/8-5 Acme", "family": "Acme", "designation": "1-1/8-5 Acme",
        "major_d_basic": 1.1250, "pitch_d_basic": 1.0250, "minor_d_basic": 0.9250,
        "tpi": 5, "pitch_mm": None, "thread_angle": 29, "compound_angle": 14.5,
        "tolerances": {
            "2G": {"major_d": (1.1120, 1.1250), "pitch_d": (1.0120, 1.0250), "minor_d": (0.9120, 0.9250)},
            "3G": {"major_d": (1.1156, 1.1250), "pitch_d": (1.0156, 1.0250), "minor_d": (0.9156, 0.9250)},
            "4G": {"major_d": (1.1186, 1.1250), "pitch_d": (1.0186, 1.0250), "minor_d": (0.9186, 0.9250)},
        },
    },
    {
        "key": "1-1/4-5 Acme", "family": "Acme", "designation": "1-1/4-5 Acme",
        "major_d_basic": 1.2500, "pitch_d_basic": 1.1500, "minor_d_basic": 1.0500,
        "tpi": 5, "pitch_mm": None, "thread_angle": 29, "compound_angle": 14.5,
        "tolerances": {
            "2G": {"major_d": (1.2370, 1.2500), "pitch_d": (1.1370, 1.1500), "minor_d": (1.0370, 1.0500)},
            "3G": {"major_d": (1.2406, 1.2500), "pitch_d": (1.1406, 1.1500), "minor_d": (1.0406, 1.0500)},
            "4G": {"major_d": (1.2436, 1.2500), "pitch_d": (1.1436, 1.1500), "minor_d": (1.0436, 1.0500)},
        },
    },
    {
        "key": "1-3/8-4 Acme", "family": "Acme", "designation": "1-3/8-4 Acme",
        "major_d_basic": 1.3750, "pitch_d_basic": 1.2500, "minor_d_basic": 1.1250,
        "tpi": 4, "pitch_mm": None, "thread_angle": 29, "compound_angle": 14.5,
        "tolerances": {
            "2G": {"major_d": (1.3600, 1.3750), "pitch_d": (1.2350, 1.2500), "minor_d": (1.1100, 1.1250)},
            "3G": {"major_d": (1.3641, 1.3750), "pitch_d": (1.2391, 1.2500), "minor_d": (1.1141, 1.1250)},
            "4G": {"major_d": (1.3675, 1.3750), "pitch_d": (1.2425, 1.2500), "minor_d": (1.1175, 1.1250)},
        },
    },
    {
        "key": "1-1/2-4 Acme", "family": "Acme", "designation": "1-1/2-4 Acme",
        "major_d_basic": 1.5000, "pitch_d_basic": 1.3750, "minor_d_basic": 1.2500,
        "tpi": 4, "pitch_mm": None, "thread_angle": 29, "compound_angle": 14.5,
        "tolerances": {
            "2G": {"major_d": (1.4850, 1.5000), "pitch_d": (1.3600, 1.3750), "minor_d": (1.2350, 1.2500)},
            "3G": {"major_d": (1.4891, 1.5000), "pitch_d": (1.3641, 1.3750), "minor_d": (1.2391, 1.2500)},
            "4G": {"major_d": (1.4925, 1.5000), "pitch_d": (1.3675, 1.3750), "minor_d": (1.2425, 1.2500)},
        },
    },
]

# ---------------------------------------------------------------------------
# Assemble THREAD_DATABASE
# ---------------------------------------------------------------------------
THREAD_DATABASE["UN/UNC/UNF"] = _UNC_ENTRIES + _UNF_ENTRIES
THREAD_DATABASE["Metric"] = _METRIC_COARSE_ENTRIES + _METRIC_FINE_ENTRIES
THREAD_DATABASE["Acme"] = _ACME_ENTRIES

# Build a flat lookup by key for fast access
_KEY_INDEX = {}
for _family, _entries in THREAD_DATABASE.items():
    for _entry in _entries:
        _KEY_INDEX[_entry["key"]] = _entry


# ---------------------------------------------------------------------------
# Public helper functions
# ---------------------------------------------------------------------------

def get_families():
    """Return family names in display order."""
    return ["UN/UNC/UNF", "Metric", "Acme"]


def get_threads_for_family(family):
    """Return list of thread entry dicts for the given family, or []."""
    return THREAD_DATABASE.get(family, [])


def get_thread_by_key(key):
    """Return a single thread entry dict by its unique key, or None."""
    return _KEY_INDEX.get(key)


def compute_tolerance_target(entry, fit_class, target, thread_type):
    """Compute concrete dimension values from tolerance band.

    Parameters
    ----------
    entry : dict
        Thread entry from THREAD_DATABASE.
    fit_class : str
        e.g. "2A", "6H", "3G".
    target : str
        "MMC", "LMC", or "Mid".
    thread_type : str
        "External" or "Internal".

    Returns
    -------
    dict
        {"major_d": float, "pitch_d": float, "minor_d": float}
    """
    tol = entry["tolerances"].get(fit_class, {})
    result = {}
    for dim in ("major_d", "pitch_d", "minor_d"):
        band = tol.get(dim, (None, None))
        lo, hi = band
        if lo is None or hi is None:
            # Use basic dimension when tolerance not controlled
            result[dim] = entry[f"{dim}_basic"]
        elif target == "MMC":
            # External: max material = largest diameter
            # Internal: max material = smallest diameter
            result[dim] = hi if thread_type == "External" else lo
        elif target == "LMC":
            result[dim] = lo if thread_type == "External" else hi
        else:  # Mid
            result[dim] = (lo + hi) / 2.0
    return result
