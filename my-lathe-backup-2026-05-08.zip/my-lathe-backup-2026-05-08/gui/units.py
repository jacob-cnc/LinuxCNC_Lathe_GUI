"""
Units Module — Display-only inch/metric conversion helpers.
=============================================================
All internal values remain in inches (radius for X, direct for Z).
These helpers convert for display purposes only.
"""

# Conversion factor: inches → millimeters
IN_TO_MM = 25.4


def display_value(inches_val: float, metric: bool) -> float:
    """Convert an internal inch value to display units."""
    return inches_val * IN_TO_MM if metric else inches_val


def internal_value(user_val: float, metric: bool) -> float:
    """Convert a user-entered value from display units back to inches."""
    return user_val / IN_TO_MM if metric else user_val


def fmt(value: float, metric: bool, decimals_in: int = 4, decimals_mm: int = 3) -> str:
    """Format a value with appropriate decimal places for the unit system."""
    d = decimals_mm if metric else decimals_in
    return f"{value:.{d}f}"


def fmt_signed(value: float, metric: bool, decimals_in: int = 4, decimals_mm: int = 3) -> str:
    """Format a value with sign and appropriate decimal places."""
    d = decimals_mm if metric else decimals_in
    return f"{value:+.{d}f}"


def unit_label(metric: bool) -> str:
    """Return the short unit label."""
    return "mm" if metric else "in"


def rate_label(metric: bool) -> str:
    """Return the feed rate unit label."""
    return "mm/min" if metric else "in/min"
