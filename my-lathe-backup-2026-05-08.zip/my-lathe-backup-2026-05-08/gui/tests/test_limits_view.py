"""Tests for LimitsView and LimitCard — Set Here button logic and homing state.

Validates Requirements 6.1, 6.2, 6.3, 6.4.
"""

import os
import sys
import tempfile

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from PyQt5.QtWidgets import QApplication

# Ensure a QApplication exists for widget tests
app = QApplication.instance() or QApplication([])

from limit_manager import LimitManager
from limits_view import LimitCard, LimitsView


class FakeToolTab:
    """Minimal fake ToolTab for testing."""
    pass


@pytest.fixture
def tmp_dir():
    """Create a temporary directory for limit files."""
    with tempfile.TemporaryDirectory() as d:
        yield d


@pytest.fixture
def limit_manager(tmp_dir):
    """Create a LimitManager with a temp directory."""
    lm = LimitManager(tmp_dir)
    lm.load()
    return lm


@pytest.fixture
def limits_view(limit_manager):
    """Create a LimitsView with a fake tool tab."""
    view = LimitsView(limit_manager, FakeToolTab())
    return view


@pytest.fixture
def limit_card(limits_view):
    """Create a LimitCard connected to the limits_view."""
    card = LimitCard(1, limits_view)
    limits_view._cards.append(card)
    return card


class TestSetHereButtons:
    """Test 'Set Here' button logic (Requirement 6.1, 6.2, 6.4)."""

    def test_set_here_z_minus_captures_machine_z(self, limit_card, limits_view):
        """Set Here Z- populates field with current machine Z position."""
        limits_view._machine_z = 1.2345
        limit_card._on_set_z_minus()
        assert limit_card.z_minus_field.text() == "1.2345"

    def test_set_here_z_plus_captures_machine_z(self, limit_card, limits_view):
        """Set Here Z+ populates field with current machine Z position."""
        limits_view._machine_z = 6.7890
        limit_card._on_set_z_plus()
        assert limit_card.z_plus_field.text() == "6.7890"

    def test_set_here_negative_position(self, limit_card, limits_view):
        """Set Here captures negative machine Z positions correctly."""
        limits_view._machine_z = -0.0500
        limit_card._on_set_z_minus()
        assert limit_card.z_minus_field.text() == "-0.0500"

    def test_set_here_z_minus_triggers_save(self, limit_card, limits_view, limit_manager):
        """Set Here Z- persists the value to LimitManager."""
        limits_view._machine_z = -0.1000
        limit_card._on_set_z_minus()
        result = limit_manager.get_limits(1)
        assert result is not None
        assert result[0] == -0.1

    def test_set_here_z_plus_triggers_save(self, limit_card, limits_view, limit_manager):
        """Set Here Z+ persists the value to LimitManager."""
        limits_view._machine_z = 5.5000
        limit_card._on_set_z_plus()
        result = limit_manager.get_limits(1)
        assert result is not None
        assert result[1] == 5.5

    def test_set_here_both_limits_persisted(self, limit_card, limits_view, limit_manager):
        """Setting both Z- and Z+ via Set Here persists both values."""
        limits_view._machine_z = -0.0500
        limit_card._on_set_z_minus()
        limits_view._machine_z = 6.5000
        limit_card._on_set_z_plus()
        result = limit_manager.get_limits(1)
        assert result == (-0.05, 6.5)

    def test_set_here_formats_to_4_decimal_places(self, limit_card, limits_view):
        """Set Here formats the value to 4 decimal places."""
        limits_view._machine_z = 1.0
        limit_card._on_set_z_minus()
        assert limit_card.z_minus_field.text() == "1.0000"

    def test_set_here_emits_limits_changed(self, limit_card, limits_view):
        """Set Here emits the limits_changed signal."""
        signal_received = []
        limits_view.limits_changed.connect(lambda: signal_received.append(True))
        limits_view._machine_z = 3.0
        limit_card._on_set_z_plus()
        assert len(signal_received) == 1


class TestHomingState:
    """Test homing state enables/disables buttons (Requirement 6.3)."""

    def test_buttons_disabled_when_not_homed(self, limit_card):
        """Set Here buttons are disabled when not homed."""
        limit_card.set_homed(False)
        assert not limit_card.z_minus_set_btn.isEnabled()
        assert not limit_card.z_plus_set_btn.isEnabled()

    def test_buttons_enabled_when_homed(self, limit_card):
        """Set Here buttons are enabled when homed."""
        limit_card.set_homed(True)
        assert limit_card.z_minus_set_btn.isEnabled()
        assert limit_card.z_plus_set_btn.isEnabled()

    def test_tooltip_shows_home_message_when_not_homed(self, limit_card):
        """Tooltip shows 'Home all axes first' when not homed."""
        limit_card.set_homed(False)
        assert limit_card.z_minus_set_btn.toolTip() == "Home all axes first"
        assert limit_card.z_plus_set_btn.toolTip() == "Home all axes first"

    def test_tooltip_restored_when_homed(self, limit_card):
        """Tooltip restored to capture message when homed."""
        limit_card.set_homed(False)
        limit_card.set_homed(True)
        assert "Capture" in limit_card.z_minus_set_btn.toolTip()
        assert "Capture" in limit_card.z_plus_set_btn.toolTip()

    def test_limits_view_set_homed_propagates_to_cards(self, limits_view, limit_card):
        """LimitsView.set_homed() propagates to all cards."""
        limits_view.set_homed(False)
        assert not limit_card.z_minus_set_btn.isEnabled()
        assert not limit_card.z_plus_set_btn.isEnabled()

        limits_view.set_homed(True)
        assert limit_card.z_minus_set_btn.isEnabled()
        assert limit_card.z_plus_set_btn.isEnabled()


class TestFieldValidation:
    """Test field editing validation logic (Requirement 5.6, 5.7)."""

    def test_valid_limits_no_error(self, limit_card, limits_view):
        """Valid z_minus < z_plus shows no error."""
        limit_card.z_minus_field.setText("-0.0500")
        limit_card.z_plus_field.setText("6.5000")
        limit_card._on_field_edited()
        assert not limit_card.error_label.isVisible()

    def test_invalid_limits_shows_error(self, limit_card, limits_view):
        """z_minus >= z_plus shows error label."""
        limit_card.z_minus_field.setText("6.5000")
        limit_card.z_plus_field.setText("-0.0500")
        limit_card._on_field_edited()
        # Use .isVisibleTo(limit_card) since the widget isn't shown on screen
        assert limit_card.error_label.isVisibleTo(limit_card)
        assert "Z\u2212 must be less than Z+" in limit_card.error_label.text()

    def test_invalid_limits_not_saved(self, limit_card, limits_view, limit_manager):
        """Invalid limits are not persisted to LimitManager."""
        limit_card.z_minus_field.setText("6.5000")
        limit_card.z_plus_field.setText("-0.0500")
        limit_card._on_field_edited()
        assert limit_manager.get_limits(1) is None

    def test_empty_fields_remove_tool(self, limit_card, limits_view, limit_manager):
        """Both fields empty removes the tool entry."""
        # First set a valid limit
        limit_manager.set_limit(1, z_minus=-0.05, z_plus=6.5)
        # Then clear both fields
        limit_card.z_minus_field.clear()
        limit_card.z_plus_field.clear()
        limit_card._on_field_edited()
        assert limit_manager.get_limits(1) is None

    def test_partial_z_minus_only_saved(self, limit_card, limits_view, limit_manager):
        """Only Z- set saves partial entry."""
        limit_card.z_minus_field.setText("-0.0500")
        limit_card.z_plus_field.clear()
        limit_card._on_field_edited()
        result = limit_manager.get_limits(1)
        assert result == (-0.05, None)

    def test_partial_z_plus_only_saved(self, limit_card, limits_view, limit_manager):
        """Only Z+ set saves partial entry."""
        limit_card.z_minus_field.clear()
        limit_card.z_plus_field.setText("6.5000")
        limit_card._on_field_edited()
        result = limit_manager.get_limits(1)
        assert result == (None, 6.5)
