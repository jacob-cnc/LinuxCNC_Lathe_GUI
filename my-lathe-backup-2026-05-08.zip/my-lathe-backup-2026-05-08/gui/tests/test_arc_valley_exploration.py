# Bugfix: arc-valley-roughing-fix, Property 1: Bug Condition Exploration
"""
Bug condition exploration tests for arc valley roughing pass generation.

These tests verify that the roughing system correctly handles arc valleys —
arcs that bulge toward the centerline (smaller X diameter). The three
interacting defects are:
  1. has_peaks detection fails for vertical arc valleys (linearized X deltas
     below 0.001" threshold)
  2. build_z_interval_chart skips vertical arcs (zero-width X range from
     endpoints)
  3. Z crossing candidates accepted without angular sweep validation
     (phantom crossings)

**Validates: Requirements 1.1, 1.2, 1.3, 1.4**

On UNFIXED code, these tests are EXPECTED TO FAIL — failure confirms the bug
exists (arc valleys not detected, intervals empty, phantoms accepted).
"""

import sys
import os
import math

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from hypothesis import given, settings, assume
from hypothesis.strategies import floats

from conv_profile import _linearize_arc, build_z_interval_chart


# ==================================================================
# Helper: Reproduce has_peaks detection logic from generate_gcode
# ==================================================================

def _detect_has_peaks(finish_moves, x_start_d, z_start, fin_passes, fin_doc, mode="OD"):
    """Reproduce the has_peaks detection logic from ProfileBlock.generate_gcode.

    This mirrors the exact logic at line ~1846 of conv_profile.py:
    1. Arc geometry awareness: detect valleys from arc center/radius
    2. Build rough_pts by linearizing arcs
    3. Build roughing_bnd by offsetting X by fin_allowance * 2
    4. Fallback: Check for peaks/valleys using the 0.001" threshold
    """
    fin_allowance = fin_passes * fin_doc  # on radius
    offset_d = fin_allowance * 2  # on diameter

    # Build rough_pts (linearized profile points)
    rough_pts = [(x_start_d, z_start)]
    for mv in finish_moves:
        if mv[0] == "LINE":
            rough_pts.append((mv[1], mv[2]))
        elif mv[0] == "ARC":
            prev_x, prev_z = rough_pts[-1]
            arc_pts = _linearize_arc(prev_x, prev_z, mv[1], mv[2], mv[3])
            rough_pts.extend(arc_pts)

    # Build roughing_bnd (offset by finish allowance)
    roughing_bnd = []
    for x, z in rough_pts:
        if mode == "OD":
            roughing_bnd.append((x + offset_d, z))
        else:
            roughing_bnd.append((x - offset_d, z))

    # --- Arc geometry awareness: detect valleys that linearization obscures ---
    has_peaks = False
    _ARC_VALLEY_EPS = 0.0001
    prev_pt = (x_start_d, z_start)
    for mv in finish_moves:
        if mv[0] == "ARC":
            arc_x1 = prev_pt[0]
            arc_z1 = prev_pt[1]
            arc_x2 = mv[1]
            arc_z2 = mv[2]
            arc_radius = mv[3]

            R_abs = abs(arc_radius)
            adx = arc_x2 - arc_x1
            adz = arc_z2 - arc_z1
            arc_chord = math.sqrt(adx * adx + adz * adz)

            if R_abs >= 1e-9 and arc_chord >= 1e-9 and arc_chord <= 2.0 * R_abs + 1e-6:
                ar = max(R_abs, arc_chord / 2 + 0.0001)
                h = math.sqrt(max(0, ar * ar - (arc_chord / 2) ** 2))
                amx = (arc_x1 + arc_x2) / 2.0
                amz = (arc_z1 + arc_z2) / 2.0
                apx = -adz / arc_chord
                apz = adx / arc_chord

                cw = arc_radius > 0
                if arc_radius > 0:
                    ccx, ccz = amx - h * apx, amz - h * apz
                else:
                    ccx, ccz = amx - h * apx, amz - h * apz

                sa = math.atan2(arc_x1 - ccx, arc_z1 - ccz)
                ea = math.atan2(arc_x2 - ccx, arc_z2 - ccz)

                if cw:
                    if ea >= sa:
                        ea -= 2 * math.pi
                    if abs(ea - sa) > math.pi and arc_radius > 0:
                        ccx, ccz = 2 * amx - ccx, 2 * amz - ccz
                        sa = math.atan2(arc_x1 - ccx, arc_z1 - ccz)
                        ea = math.atan2(arc_x2 - ccx, arc_z2 - ccz)
                        if ea >= sa:
                            ea -= 2 * math.pi
                else:
                    if ea <= sa:
                        ea += 2 * math.pi
                    if abs(ea - sa) > math.pi and arc_radius > 0:
                        ccx, ccz = 2 * amx - ccx, 2 * amz - ccz
                        sa = math.atan2(arc_x1 - ccx, arc_z1 - ccz)
                        ea = math.atan2(arc_x2 - ccx, arc_z2 - ccz)
                        if ea <= sa:
                            ea += 2 * math.pi

                min_x_angle = -math.pi / 2.0
                arc_passes_through_min_x = False
                if cw:
                    a = min_x_angle
                    while a > sa + _ARC_VALLEY_EPS:
                        a -= 2 * math.pi
                    while a < ea - _ARC_VALLEY_EPS:
                        a += 2 * math.pi
                    if ea - _ARC_VALLEY_EPS <= a <= sa + _ARC_VALLEY_EPS:
                        arc_passes_through_min_x = True
                else:
                    a = min_x_angle
                    while a < sa - _ARC_VALLEY_EPS:
                        a += 2 * math.pi
                    while a > ea + _ARC_VALLEY_EPS:
                        a -= 2 * math.pi
                    if sa - _ARC_VALLEY_EPS <= a <= ea + _ARC_VALLEY_EPS:
                        arc_passes_through_min_x = True

                if arc_passes_through_min_x:
                    arc_min_x_d = ccx - ar
                    endpoints_min_x_d = min(arc_x1, arc_x2)
                    if arc_min_x_d < endpoints_min_x_d - _ARC_VALLEY_EPS:
                        has_peaks = True

            prev_pt = (mv[1], mv[2])
        elif mv[0] == "LINE":
            prev_pt = (mv[1], mv[2])

        if has_peaks:
            break

    # Fallback: existing roughing_bnd loop for non-arc peaks/valleys
    if not has_peaks:
        for i in range(1, len(roughing_bnd) - 1):
            x_prev = roughing_bnd[i - 1][0]
            x_curr = roughing_bnd[i][0]
            x_next = roughing_bnd[i + 1][0]
            # Peak: X increases then decreases (local maximum)
            if x_curr > x_prev + 0.001 and x_curr > x_next + 0.001:
                has_peaks = True
                break
            # Valley: X decreases then increases (local minimum)
            if x_curr < x_prev - 0.001 and x_curr < x_next - 0.001:
                has_peaks = True
                break

    return has_peaks, roughing_bnd


# ==================================================================
# Test 1a: has_peaks detection for vertical arc valley
# ==================================================================

def test_has_peaks_detects_vertical_arc_valley():
    """Vertical arc valley: has_peaks must detect the valley.

    **Validates: Requirements 1.1, 1.2**

    Profile: X_start=1.500, Z_start=0.000
      LINE to X1.500 Z-0.500
      ARC (G02/CW, R=0.250) to X1.500 Z-1.000 (valley to ~X1.257 at midpoint)
      LINE to X1.500 Z-1.500

    The arc has both endpoints at X=1.500 and bulges inward to ~X1.257
    (diameter). When linearized with step=0.010", adjacent X deltas near
    the apex are ~0.0002" — well below the 0.001" threshold.

    Convention: positive R = G02/CW = inward valley in this system.

    Expected behavior: has_peaks returns True (valley detected).
    On UNFIXED code: has_peaks returns False (FAILS — confirms bug).
    """
    # Profile with vertical arc valley
    # G02/CW = positive radius = inward valley in this system
    # The arc goes from X1.500 Z-0.500 to X1.500 Z-1.000 with R=0.250
    # creating a valley that bulges inward to ~X=1.257 at the midpoint
    finish_moves = [
        ("LINE", 1.500, -0.500),
        ("ARC", 1.500, -1.000, 0.250),  # G02/CW = positive R = valley
        ("LINE", 1.500, -1.500),
    ]

    x_start_d = 1.500
    z_start = 0.000
    fin_passes = 1
    fin_doc = 0.002  # on radius

    has_peaks, roughing_bnd = _detect_has_peaks(
        finish_moves, x_start_d, z_start, fin_passes, fin_doc, mode="OD"
    )

    # Verify the arc actually creates a valley by checking linearized points
    # The arc should produce points with X < 1.500 (valley toward centerline)
    arc_pts = _linearize_arc(1.500, -0.500, 1.500, -1.000, 0.250)
    min_x_in_arc = min(x for x, z in arc_pts)

    # Sanity check: the arc does create a valley (min X should be near 1.257)
    assert min_x_in_arc < 1.400, (
        f"Arc should create valley to ~X1.257 but min X in linearized "
        f"points is {min_x_in_arc:.4f}"
    )

    # The critical assertion: has_peaks must be True for this valley profile
    assert has_peaks is True, (
        f"has_peaks returned False for a profile with a vertical arc valley "
        f"(arc min X = {min_x_in_arc:.4f}, endpoints X = 1.500). "
        f"The 0.001\" threshold fails to detect valleys in finely-linearized "
        f"arcs where adjacent X deltas are ~0.0002\"."
    )


# ==================================================================
# Test 1b: build_z_interval_chart X-range for vertical arc valley
# ==================================================================

def test_interval_chart_covers_vertical_arc_valley():
    """Vertical arc valley: intervals must be non-empty for X levels inside valley.

    **Validates: Requirements 1.3**

    Same profile as Test 1a. Call build_z_interval_chart with X levels
    between 1.257 and 1.500 (diameter). The arc valley extends from
    X=1.500 down to ~X=1.257 at the midpoint.

    Expected behavior: intervals are non-empty for X levels inside the valley
    (e.g., X=1.300, X=1.350, X=1.400).
    On UNFIXED code: intervals are empty because x_min_seg = x_max_seg = 1.500
    (zero-width range causes the arc to be skipped). FAILS — confirms bug.
    """
    finish_moves = [
        ("LINE", 1.500, -0.500),
        ("ARC", 1.500, -1.000, 0.250),  # G02/CW = positive R = valley
        ("LINE", 1.500, -1.500),
    ]

    x_start_d = 1.500
    z_start = 0.000
    fin_allowance = 0.002  # 1 pass * 0.002 radius

    # X levels inside the valley (between arc min X~1.257 and endpoint X=1.500)
    x_levels = [1.300, 1.350, 1.400]

    chart = build_z_interval_chart(
        finish_moves, x_start_d, z_start, x_levels, fin_allowance, mode="OD"
    )

    # For each X level inside the valley, intervals should be non-empty
    # Material exists between the tool path and the arc boundary
    missing_levels = []
    for xl in x_levels:
        intervals = chart.get(xl, [])
        if not intervals:
            missing_levels.append(xl)

    assert len(missing_levels) == 0, (
        f"build_z_interval_chart returned empty intervals for X levels "
        f"inside the arc valley: {[f'X{x:.3f}' for x in missing_levels]}. "
        f"The zero-width X range check (x_min_seg = x_max_seg = 1.500) "
        f"causes the arc to be skipped entirely."
    )


# ==================================================================
# Test 1c: Angular sweep validation — phantom crossing rejection
# ==================================================================

def test_angular_sweep_rejects_phantom_crossing():
    """Phantom crossing: Z candidates outside arc sweep must be rejected.

    **Validates: Requirements 1.4**

    Construct a quarter-circle arc (90 degree sweep) where the circle
    equation produces a Z candidate that is within the endpoint Z range
    but NOT on the actual arc sweep.

    Arc from X1.500 Z-0.500 to X1.250 Z-0.750 (R=0.250, G02/CW).
    This is a 90-degree arc. The circle center is at approximately
    (1.250, -0.500) in diameter space. The circle equation at X=1.300
    produces two Z solutions: one on the arc (valid) and one on the
    opposite side (phantom at ~Z=-0.250 which is ABOVE the arc start).

    For this test, we use the vertical arc and verify that the interval
    boundaries are geometrically consistent — no phantom crossings extend
    the interval beyond the arc's actual Z extent.

    Expected behavior: Only valid crossings (on the arc sweep) are used.
    On UNFIXED code: Phantom crossings may be accepted because only endpoint
    Z range filtering is applied. FAILS — confirms bug.
    """
    # Use a vertical arc where we can verify the geometry precisely.
    # Arc: X1.500 Z-0.500 to X1.500 Z-1.000, R=0.250, G02/CW (valley)
    # Center is at approximately (1.2478, -0.750) in diameter space
    # ar = 0.2501 (slightly > R due to chord/2 + 0.0001 adjustment)
    finish_moves = [
        ("LINE", 1.500, -0.500),
        ("ARC", 1.500, -1.000, 0.250),  # G02/CW = positive R = valley
        ("LINE", 1.500, -1.500),
    ]

    x_start_d = 1.500
    z_start = 0.000
    fin_allowance = 0.002

    # Test at X level near the bottom of the valley.
    # At X=1.300 (inside the valley), the circle equation produces two Z
    # solutions. Both should be on the arc for this symmetric (near-semicircle)
    # arc. But for the angular sweep validation test, we verify that the
    # intervals produced are geometrically correct.
    #
    # The arc center is at ~(1.2478, -0.750) with ar=0.2501.
    # At X=1.300 (diameter), the radius-space X is 0.650.
    # Circle: (0.650 - 0.6239)^2 + (z - (-0.750))^2 = 0.2501^2
    #         0.000681 + (z + 0.750)^2 = 0.06255
    #         (z + 0.750)^2 = 0.06187
    #         z = -0.750 ± 0.2487
    #         z1 = -0.5013 (near arc start)
    #         z2 = -0.9987 (near arc end)
    #
    # Both are valid for this near-semicircle. The phantom issue manifests
    # more clearly when we check that NO interval extends OUTSIDE the arc's
    # Z range (Z=-0.500 to Z=-1.000).

    x_test = 1.300
    chart = build_z_interval_chart(
        finish_moves, x_start_d, z_start, [x_test], fin_allowance, mode="OD"
    )

    intervals = chart.get(x_test, [])

    # First, the interval must exist (this also tests the X-range issue)
    assert len(intervals) > 0, (
        f"No intervals at X={x_test} — arc valley not detected "
        f"(zero-width X range causes arc to be skipped). "
        f"Cannot test phantom crossing rejection without intervals."
    )

    # Verify interval boundaries are within the arc's Z extent.
    # The arc spans Z=-0.500 to Z=-1.000. With fin_allowance offset,
    # the boundaries should be within Z=-0.498 to Z=-0.998 approximately.
    arc_z_start = -0.500 + fin_allowance  # offset
    arc_z_end = -1.000 + fin_allowance    # offset
    tolerance = 0.020  # tolerance for rounding and offset

    for z_begin, z_end in intervals:
        # No interval boundary should be ABOVE the arc start (phantom)
        assert z_begin <= arc_z_start + tolerance, (
            f"Interval start Z={z_begin:.4f} is above arc start "
            f"Z={arc_z_start:.4f} + tolerance — phantom crossing accepted"
        )
        # No interval boundary should be BELOW the arc end (phantom)
        assert z_end >= arc_z_end - tolerance, (
            f"Interval end Z={z_end:.4f} is below arc end "
            f"Z={arc_z_end:.4f} - tolerance — phantom crossing accepted"
        )


# ==================================================================
# Test 1d: Near-vertical arc — X range too narrow
# ==================================================================

def test_near_vertical_arc_x_range():
    """Near-vertical arc: X level inside valley must produce intervals.

    **Validates: Requirements 1.3**

    Arc endpoints at X=1.500 and X=1.502, R=0.250, G02/CW. The arc creates
    a valley to approximately X=1.257. The endpoint-based X range is only
    0.002" wide (1.500 to 1.502), so X levels between 1.257 and 1.498
    are missed.

    Expected behavior: X level 1.350 produces non-empty intervals (arc's
    true X extent used for range check).
    On UNFIXED code: X level 1.350 produces empty intervals because the
    X range check only sees 0.002" span. FAILS — confirms bug.
    """
    # Near-vertical arc: endpoints at X=1.500 and X=1.502
    # G02/CW = positive radius = inward valley
    finish_moves = [
        ("LINE", 1.500, -0.500),
        ("ARC", 1.502, -1.000, 0.250),  # G02/CW, near-vertical valley
        ("LINE", 1.502, -1.500),
    ]

    x_start_d = 1.502
    z_start = 0.000
    fin_allowance = 0.002

    # X level well inside the valley but outside the endpoint X range
    # The valley extends to ~X=1.257, so X=1.350 is clearly inside
    x_levels = [1.350]

    chart = build_z_interval_chart(
        finish_moves, x_start_d, z_start, x_levels, fin_allowance, mode="OD"
    )

    intervals = chart.get(1.350, [])

    assert len(intervals) > 0, (
        f"build_z_interval_chart returned empty intervals at X=1.350 for "
        f"a near-vertical arc (endpoints X=1.500/1.502, R=0.250). "
        f"The endpoint-based X range check sees only 0.002\" span and "
        f"skips the arc for X levels between 1.257 and 1.498."
    )
