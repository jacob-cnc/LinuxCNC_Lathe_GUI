# Bugfix: incremental-roughing-retract, Property 1: Bug Condition Exploration
"""
Bug condition exploration tests for ProfileBlock roughing pass retract/approach.

These tests verify that roughing pass approach and retract X positions use
incremental per-pass clearance (current_d ± retract_d) instead of the fixed
x_clear (stock_d ± retract_d).

**Validates: Requirements 1.1, 1.2, 1.3, 2.1, 2.2**

On UNFIXED code, these tests are EXPECTED TO FAIL — failure confirms the bug
exists (all roughing passes approach/retract to the fixed x_clear).
"""

import sys
import os
import re
import math

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from PyQt5.QtWidgets import QApplication
from hypothesis import given, settings, assume, HealthCheck
from hypothesis.strategies import floats

_app = None


def _get_app():
    global _app
    if _app is None:
        _app = QApplication.instance() or QApplication(sys.argv)
    return _app


def _make_profile_block():
    """Create a fresh ProfileBlock instance (requires QApplication)."""
    _get_app()
    from conv_profile import ProfileBlock
    return ProfileBlock(block_num=1)


def _set_profile_fields(blk, **kwargs):
    """Set ProfileBlock fields from keyword arguments."""
    field_map = {
        "stock_dia": blk.stock_dia,
        "x_start": blk.x_start,
        "z_start": blk.z_start,
        "doc": blk.doc,
        "fin_passes": blk.fin_passes,
        "fin_doc": blk.fin_doc,
        "feed_r": blk.feed_r,
        "feed_f": blk.feed_f,
        "retract": blk.retract,
        "rough_tool": blk.rough_tool,
        "finish_tool": blk.finish_tool,
        "rpm": blk.rpm,
        "safe_x": blk.safe_x,
        "safe_z": blk.safe_z,
    }
    for k, v in kwargs.items():
        if k == "mode":
            idx = blk.cmb_mode.findText(v)
            if idx >= 0:
                blk.cmb_mode.setCurrentIndex(idx)
        elif k in field_map:
            field_map[k].setText(str(v))


def _add_segments(blk, segments):
    """Add profile segments to a ProfileBlock.

    Each segment is a dict with keys: x_end, z_end, and optionally
    is_arc (bool), arc_r (str).
    The block starts with one default segment, so we remove it first.
    """
    for seg in list(blk.segments):
        blk.remove_segment(seg)

    for seg_data in segments:
        blk.add_segment()
        seg = blk.segments[-1]
        seg.x_end.setText(str(seg_data["x_end"]))
        seg.z_end.setText(str(seg_data["z_end"]))
        if seg_data.get("is_arc"):
            seg.arc_check.setChecked(True)
            seg.arc_r.setText(str(seg_data.get("arc_r", "")))


def _parse_roughing_passes(gcode):
    """Parse roughing pass approach X, current_d, and retract X from G-code.

    Returns a list of dicts, one per roughing pass:
      {
        "pass_num": int,
        "approach_x": float,   # X from the first G00 X... Z... line
        "current_d": float,    # X from the G00 X{current_d} positioning line
        "retract_x": float,    # X from the G00 X{retract} line after G01
      }

    Parsing logic for each pass pattern:
        G00 X{approach_x} Z{z_clear}  (Pass N ...)
        G00 X{current_d} Z{z_start}
        G01 Z{z_limit} F{feed}
        G00 X{retract_x}
    """
    lines = gcode.split("\n")
    passes = []
    in_roughing = False

    i = 0
    while i < len(lines):
        stripped = lines[i].strip()

        # Detect roughing section start
        if "; --- Roughing passes ---" in stripped:
            in_roughing = True
            i += 1
            continue

        # Detect end of roughing section
        if in_roughing and (
            "; --- Cleanup pass" in stripped
            or "; --- Finish pass" in stripped
            or "Roughing complete" in stripped
        ):
            break

        if not in_roughing:
            i += 1
            continue

        # Look for approach line: G00 X{approach_x} Z{z_clear}  (Pass N ...)
        approach_match = re.match(
            r'G00\s+X([+-]?\d+\.?\d*)\s+Z([+-]?\d+\.?\d*)\s+\(Pass\s+(\d+)',
            stripped
        )
        if approach_match:
            approach_x = float(approach_match.group(1))
            pass_num = int(approach_match.group(3))

            # Next line: G00 X{current_d} Z{z_start}
            i += 1
            if i < len(lines):
                pos_match = re.match(
                    r'\s*G00\s+X([+-]?\d+\.?\d*)\s+Z([+-]?\d+\.?\d*)',
                    lines[i]
                )
                if pos_match:
                    current_d = float(pos_match.group(1))

                    # Next line: G01 Z{z_limit} F{feed}
                    i += 1
                    if i < len(lines):
                        g01_match = re.match(
                            r'\s*G01\s+Z([+-]?\d+\.?\d*)',
                            lines[i]
                        )
                        if g01_match:
                            # Next line: G00 X{retract_x}
                            i += 1
                            if i < len(lines):
                                retract_match = re.match(
                                    r'\s*G00\s+X([+-]?\d+\.?\d*)',
                                    lines[i].strip()
                                )
                                if retract_match:
                                    retract_x = float(retract_match.group(1))
                                    passes.append({
                                        "pass_num": pass_num,
                                        "approach_x": approach_x,
                                        "current_d": current_d,
                                        "retract_x": retract_x,
                                    })
        i += 1

    return passes


# ------------------------------------------------------------------
# Test 1: OD multi-pass cylinder — approach/retract should be per-pass
# ------------------------------------------------------------------

def test_od_roughing_incremental_retract():
    """OD cylinder: roughing approach/retract X must be current_d + retract_d, not x_clear.

    **Validates: Requirements 1.1, 1.3, 2.1**

    Profile: stock_d=2.5, retract_d=0.050, doc=0.050
    Face from X2.5 to X1.0 Z0.0, then straight to X1.0 Z-2.0.
    This generates 14 roughing passes stepping from X2.4 down to X1.1.

    For each roughing pass, the approach and retract X should be
    current_d + retract_d (incremental clearance), NOT stock_d + retract_d
    (fixed x_clear = 2.550).

    On UNFIXED code, all approach/retract X values will be 2.5500 (x_clear)
    regardless of pass depth — this test will FAIL, confirming the bug.
    """
    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="OD",
        stock_dia="2.500",
        x_start="2.500",
        z_start="0.1",
        doc="0.050",
        fin_passes="1",
        fin_doc="0.002",
        feed_r="0.005",
        feed_f="0.003",
        retract="0.050",
        rough_tool="1",
        finish_tool="1",
        rpm="1200",
        safe_x="3.000",
        safe_z="1.000",
    )

    # Face from stock to X1.0, then straight bore to Z-2.0
    _add_segments(blk, [
        {"x_end": "1.000", "z_end": "0.000"},
        {"x_end": "1.000", "z_end": "-2.000"},
    ])

    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    passes = _parse_roughing_passes(gcode)
    assert len(passes) >= 5, (
        f"Expected at least 5 roughing passes, got {len(passes)}"
    )

    retract_d = 0.050
    stock_d = 2.500
    x_clear = stock_d + retract_d  # 2.5500 — the fixed (buggy) value

    violations = []
    for p in passes:
        expected_clear = round(p["current_d"] + retract_d, 4)

        if abs(p["approach_x"] - expected_clear) > 0.0001:
            violations.append(
                f"OD Pass {p['pass_num']} at current_d={p['current_d']:.4f}: "
                f"approach_x={p['approach_x']:.4f} (expected {expected_clear:.4f})"
            )
        if abs(p["retract_x"] - expected_clear) > 0.0001:
            violations.append(
                f"OD Pass {p['pass_num']} at current_d={p['current_d']:.4f}: "
                f"retract_x={p['retract_x']:.4f} (expected {expected_clear:.4f})"
            )

    assert len(violations) == 0, (
        f"Roughing passes use fixed x_clear={x_clear:.4f} instead of "
        f"incremental current_d + retract_d:\n" + "\n".join(violations)
    )


# ------------------------------------------------------------------
# Test 2: ID multi-pass cylinder — approach/retract should be per-pass
# ------------------------------------------------------------------

def test_id_roughing_incremental_retract():
    """ID cylinder: roughing approach/retract X must be current_d - retract_d, not x_clear.

    **Validates: Requirements 1.2, 1.3, 2.2**

    Profile: stock_d=0.500 (pilot hole), retract_d=0.050, doc=0.050
    Face from X0.5 to X1.5 Z0.0, then straight bore to X1.5 Z-2.0.
    This generates multiple roughing passes stepping from X0.6 up to X1.4.

    For each roughing pass, the approach and retract X should be
    current_d - retract_d (incremental clearance), NOT stock_d - retract_d
    (fixed x_clear = 0.450).

    On UNFIXED code, all approach/retract X values will be 0.4500 (x_clear)
    regardless of pass depth — this test will FAIL, confirming the bug.
    """
    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="ID",
        stock_dia="0.500",
        x_start="0.500",
        z_start="0.1",
        doc="0.050",
        fin_passes="1",
        fin_doc="0.002",
        feed_r="0.003",
        feed_f="0.002",
        retract="0.050",
        rough_tool="2",
        finish_tool="2",
        rpm="800",
        safe_x="0.300",
        safe_z="1.000",
    )

    # Face from pilot hole to X1.5, then straight bore to Z-2.0
    _add_segments(blk, [
        {"x_end": "1.500", "z_end": "0.000"},
        {"x_end": "1.500", "z_end": "-2.000"},
    ])

    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    passes = _parse_roughing_passes(gcode)
    assert len(passes) >= 5, (
        f"Expected at least 5 roughing passes, got {len(passes)}"
    )

    retract_d = 0.050
    stock_d = 0.500
    x_clear = stock_d - retract_d  # 0.4500 — the fixed (buggy) value

    violations = []
    for p in passes:
        expected_clear = round(p["current_d"] - retract_d, 4)

        if abs(p["approach_x"] - expected_clear) > 0.0001:
            violations.append(
                f"ID Pass {p['pass_num']} at current_d={p['current_d']:.4f}: "
                f"approach_x={p['approach_x']:.4f} (expected {expected_clear:.4f})"
            )
        if abs(p["retract_x"] - expected_clear) > 0.0001:
            violations.append(
                f"ID Pass {p['pass_num']} at current_d={p['current_d']:.4f}: "
                f"retract_x={p['retract_x']:.4f} (expected {expected_clear:.4f})"
            )

    assert len(violations) == 0, (
        f"Roughing passes use fixed x_clear={x_clear:.4f} instead of "
        f"incremental current_d - retract_d:\n" + "\n".join(violations)
    )


# ------------------------------------------------------------------
# Test 3: PBT — OD random configs, approach/retract == current_d + retract_d
# ------------------------------------------------------------------

@settings(max_examples=10, deadline=None,
          suppress_health_check=[HealthCheck.filter_too_much])
@given(
    stock_dia=floats(min_value=2.0, max_value=4.0, allow_nan=False, allow_infinity=False),
    retract_d=floats(min_value=0.020, max_value=0.100, allow_nan=False, allow_infinity=False),
    doc=floats(min_value=0.020, max_value=0.060, allow_nan=False, allow_infinity=False),
    target_frac=floats(min_value=0.2, max_value=0.5, allow_nan=False, allow_infinity=False),
)
def test_pbt_od_incremental_retract(stock_dia, retract_d, doc, target_frac):
    """PBT OD: all roughing pass approach/retract X == current_d + retract_d.

    **Validates: Requirements 1.1, 1.3, 2.1**

    Generates random OD configurations with a cylinder profile and verifies
    that every roughing pass uses incremental clearance, not fixed x_clear.
    """
    stock_dia = round(stock_dia, 4)
    retract_d = round(retract_d, 4)
    doc = round(doc, 4)

    # Target diameter is a fraction of stock (ensures material to remove)
    target_dia = round(stock_dia * target_frac, 4)
    assume(target_dia >= 0.5)

    fin_doc = 0.002
    fin_allowance = fin_doc
    min_target_d = target_dia + fin_allowance * 2

    # Need at least 3 roughing passes
    assume(stock_dia - doc * 2 * 3 > min_target_d)

    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="OD",
        stock_dia=f"{stock_dia:.4f}",
        x_start=f"{stock_dia:.4f}",
        z_start="0.1",
        doc=f"{doc:.4f}",
        fin_passes="1",
        fin_doc=f"{fin_doc:.4f}",
        feed_r="0.005",
        feed_f="0.003",
        retract=f"{retract_d:.4f}",
        rough_tool="1",
        finish_tool="1",
        rpm="1200",
        safe_x=f"{stock_dia + 1.0:.4f}",
        safe_z="1.000",
    )

    # Cylinder profile: face from stock to target, then straight to Z-2.0
    _add_segments(blk, [
        {"x_end": f"{target_dia:.4f}", "z_end": "0.000"},
        {"x_end": f"{target_dia:.4f}", "z_end": "-2.000"},
    ])

    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    passes = _parse_roughing_passes(gcode)
    assume(len(passes) >= 3)

    x_clear = round(stock_dia + retract_d, 4)

    violations = []
    for p in passes:
        expected_clear = round(p["current_d"] + retract_d, 4)

        if abs(p["approach_x"] - expected_clear) > 0.0001:
            violations.append(
                f"OD Pass {p['pass_num']} at current_d={p['current_d']:.4f}: "
                f"approach_x={p['approach_x']:.4f} (expected {expected_clear:.4f})"
            )
        if abs(p["retract_x"] - expected_clear) > 0.0001:
            violations.append(
                f"OD Pass {p['pass_num']} at current_d={p['current_d']:.4f}: "
                f"retract_x={p['retract_x']:.4f} (expected {expected_clear:.4f})"
            )

    assert len(violations) == 0, (
        f"OD roughing passes use fixed x_clear={x_clear:.4f} instead of "
        f"incremental current_d + retract_d:\n" + "\n".join(violations)
    )


# ------------------------------------------------------------------
# Test 4: PBT — ID random configs, approach/retract == current_d - retract_d
# ------------------------------------------------------------------

@settings(max_examples=10, deadline=None,
          suppress_health_check=[HealthCheck.filter_too_much])
@given(
    pilot_hole=floats(min_value=0.4, max_value=1.0, allow_nan=False, allow_infinity=False),
    retract_d=floats(min_value=0.020, max_value=0.060, allow_nan=False, allow_infinity=False),
    doc=floats(min_value=0.020, max_value=0.060, allow_nan=False, allow_infinity=False),
    target_mult=floats(min_value=2.0, max_value=3.0, allow_nan=False, allow_infinity=False),
)
def test_pbt_id_incremental_retract(pilot_hole, retract_d, doc, target_mult):
    """PBT ID: all roughing pass approach/retract X == current_d - retract_d.

    **Validates: Requirements 1.2, 1.3, 2.2**

    Generates random ID configurations with a cylinder bore profile and verifies
    that every roughing pass uses incremental clearance, not fixed x_clear.
    """
    pilot_hole = round(pilot_hole, 4)
    retract_d = round(retract_d, 4)
    doc = round(doc, 4)

    # x_clear must be positive
    x_clear_val = pilot_hole - retract_d
    assume(x_clear_val > 0.01)

    # Target diameter is a multiple of pilot hole
    target_dia = round(pilot_hole * target_mult, 4)
    assume(target_dia <= 3.0)

    fin_doc = 0.002
    fin_allowance = fin_doc
    max_target_d = target_dia - fin_allowance * 2

    # Need at least 3 roughing passes
    assume(pilot_hole + doc * 2 * 3 < max_target_d)

    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="ID",
        stock_dia=f"{pilot_hole:.4f}",
        x_start=f"{pilot_hole:.4f}",
        z_start="0.1",
        doc=f"{doc:.4f}",
        fin_passes="1",
        fin_doc=f"{fin_doc:.4f}",
        feed_r="0.003",
        feed_f="0.002",
        retract=f"{retract_d:.4f}",
        rough_tool="2",
        finish_tool="2",
        rpm="800",
        safe_x=f"{pilot_hole - 0.200:.4f}",
        safe_z="1.000",
    )

    # Cylinder bore: face from pilot hole to target, then straight to Z-2.0
    _add_segments(blk, [
        {"x_end": f"{target_dia:.4f}", "z_end": "0.000"},
        {"x_end": f"{target_dia:.4f}", "z_end": "-2.000"},
    ])

    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    passes = _parse_roughing_passes(gcode)
    assume(len(passes) >= 3)

    x_clear = round(pilot_hole - retract_d, 4)

    violations = []
    for p in passes:
        expected_clear = round(p["current_d"] - retract_d, 4)

        if abs(p["approach_x"] - expected_clear) > 0.0001:
            violations.append(
                f"ID Pass {p['pass_num']} at current_d={p['current_d']:.4f}: "
                f"approach_x={p['approach_x']:.4f} (expected {expected_clear:.4f})"
            )
        if abs(p["retract_x"] - expected_clear) > 0.0001:
            violations.append(
                f"ID Pass {p['pass_num']} at current_d={p['current_d']:.4f}: "
                f"retract_x={p['retract_x']:.4f} (expected {expected_clear:.4f})"
            )

    assert len(violations) == 0, (
        f"ID roughing passes use fixed x_clear={x_clear:.4f} instead of "
        f"incremental current_d - retract_d:\n" + "\n".join(violations)
    )


# ======================================================================
# Bugfix: incremental-roughing-retract, Property 2: Preservation
# ======================================================================
"""
Preservation property tests for ProfileBlock roughing pass generation.

These tests verify that cleanup pass, finish pass, Z clearance, and header
comments use the correct values on the UNFIXED code, and must continue to
pass after the fix is applied.

**Validates: Requirements 2.3, 2.4, 3.1, 3.2, 3.3, 3.5**
"""


# ------------------------------------------------------------------
# G-code section parsers
# ------------------------------------------------------------------

def _parse_cleanup_pass_x_values(gcode):
    """Extract approach and retract X values from the cleanup pass section.

    Returns a dict:
      {
        "approach_x": float or None,  # X from first G00 X... Z... in cleanup
        "retract_x": float or None,   # X from last G00 X... (retract) in cleanup
      }
    """
    lines = gcode.split("\n")
    in_cleanup = False
    approach_x = None
    retract_x = None

    for line in lines:
        stripped = line.strip()

        if "; --- Cleanup pass" in stripped:
            in_cleanup = True
            continue

        if in_cleanup and ("Roughing complete" in stripped
                           or "; --- Finish pass" in stripped):
            break

        if not in_cleanup:
            continue

        # First G00 X... Z... is the approach
        if approach_x is None:
            m = re.match(r'G00\s+X([+-]?\d+\.?\d*)\s+Z([+-]?\d+\.?\d*)', stripped)
            if m:
                approach_x = float(m.group(1))
                continue

        # Last G00 X... (no Z) is the retract
        m = re.match(r'G00\s+X([+-]?\d+\.?\d*)$', stripped)
        if m:
            retract_x = float(m.group(1))

    return {"approach_x": approach_x, "retract_x": retract_x}


def _parse_finish_pass_retract_x(gcode):
    """Extract the retract X value after the finish pass G01 moves.

    Returns the X value from the G00 X{value} line after the finish pass
    cutting moves, or None if not found.
    """
    lines = gcode.split("\n")
    in_finish = False
    retract_x = None

    for line in lines:
        stripped = line.strip()

        if "; --- Finish pass" in stripped:
            in_finish = True
            continue

        if in_finish and "Return to safe position" in stripped:
            break

        if not in_finish:
            continue

        # The G00 X... (no Z) after the G01 moves is the retract
        m = re.match(r'G00\s+X([+-]?\d+\.?\d*)$', stripped)
        if m:
            retract_x = float(m.group(1))

    return retract_x


def _parse_roughing_z_approach(gcode):
    """Extract Z values from roughing pass approach lines.

    Returns a list of Z values from G00 X... Z{value} lines that contain
    '(Pass' in the roughing section.
    """
    lines = gcode.split("\n")
    in_roughing = False
    z_values = []

    for line in lines:
        stripped = line.strip()

        if "; --- Roughing passes ---" in stripped:
            in_roughing = True
            continue

        if in_roughing and ("; --- Cleanup pass" in stripped
                            or "; --- Finish pass" in stripped
                            or "Roughing complete" in stripped):
            break

        if not in_roughing:
            continue

        # Match approach lines: G00 X... Z{z_value}  (Pass N ...)
        m = re.match(
            r'G00\s+X[+-]?\d+\.?\d*\s+Z([+-]?\d+\.?\d*)\s+\(Pass\s+\d+',
            stripped
        )
        if m:
            z_values.append(float(m.group(1)))

    return z_values


def _parse_header_comments(gcode):
    """Extract all comment lines before the G20 G18 preamble.

    Returns a list of comment strings (lines starting with ';').
    """
    lines = gcode.split("\n")
    comments = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("G20 G18"):
            break
        if stripped.startswith(";"):
            comments.append(stripped)
    return comments


# ------------------------------------------------------------------
# Preservation test — Cleanup pass retract (OD)
# ------------------------------------------------------------------

@settings(max_examples=10, deadline=None,
          suppress_health_check=[HealthCheck.filter_too_much])
@given(
    stock_dia=floats(min_value=1.5, max_value=4.0, allow_nan=False, allow_infinity=False),
    retract_d=floats(min_value=0.020, max_value=0.100, allow_nan=False, allow_infinity=False),
    doc=floats(min_value=0.020, max_value=0.060, allow_nan=False, allow_infinity=False),
    target_frac=floats(min_value=0.2, max_value=0.5, allow_nan=False, allow_infinity=False),
)
def test_preservation_cleanup_pass_od(stock_dia, retract_d, doc, target_frac):
    """Cleanup pass approach/retract X must equal x_clear = stock_d + retract_d for OD.

    **Validates: Requirements 2.3, 3.1**

    The cleanup pass traces the roughing boundary contour and needs full
    stock-boundary clearance. This behavior must be preserved after the fix.
    """
    stock_dia = round(stock_dia, 4)
    retract_d = round(retract_d, 4)
    doc = round(doc, 4)

    target_dia = round(stock_dia * target_frac, 4)
    assume(target_dia >= 0.5)

    fin_doc = 0.002
    fin_allowance = fin_doc
    min_target_d = target_dia + fin_allowance * 2
    assume(stock_dia - doc * 2 > min_target_d)

    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="OD",
        stock_dia=f"{stock_dia:.4f}",
        x_start=f"{stock_dia:.4f}",
        z_start="0.1",
        doc=f"{doc:.4f}",
        fin_passes="1",
        fin_doc=f"{fin_doc:.4f}",
        feed_r="0.005",
        feed_f="0.003",
        retract=f"{retract_d:.4f}",
        rough_tool="1",
        finish_tool="1",
        rpm="1200",
        safe_x=f"{stock_dia + 1.0:.4f}",
        safe_z="1.000",
    )

    _add_segments(blk, [
        {"x_end": f"{target_dia:.4f}", "z_end": "0.000"},
        {"x_end": f"{target_dia:.4f}", "z_end": "-2.000"},
    ])

    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    x_clear = round(stock_dia + retract_d, 4)
    cleanup = _parse_cleanup_pass_x_values(gcode)

    assert cleanup["approach_x"] is not None, "No cleanup pass approach found"
    assert cleanup["retract_x"] is not None, "No cleanup pass retract found"

    assert abs(cleanup["approach_x"] - x_clear) < 0.0001, (
        f"OD cleanup approach_x={cleanup['approach_x']:.4f}, "
        f"expected x_clear={x_clear:.4f}"
    )
    assert abs(cleanup["retract_x"] - x_clear) < 0.0001, (
        f"OD cleanup retract_x={cleanup['retract_x']:.4f}, "
        f"expected x_clear={x_clear:.4f}"
    )


# ------------------------------------------------------------------
# Preservation test — Cleanup pass retract (ID)
# ------------------------------------------------------------------

@settings(max_examples=10, deadline=None,
          suppress_health_check=[HealthCheck.filter_too_much])
@given(
    pilot_hole=floats(min_value=0.4, max_value=1.0, allow_nan=False, allow_infinity=False),
    retract_d=floats(min_value=0.020, max_value=0.060, allow_nan=False, allow_infinity=False),
    doc=floats(min_value=0.020, max_value=0.060, allow_nan=False, allow_infinity=False),
    target_mult=floats(min_value=2.0, max_value=3.0, allow_nan=False, allow_infinity=False),
)
def test_preservation_cleanup_pass_id(pilot_hole, retract_d, doc, target_mult):
    """Cleanup pass approach/retract X must equal x_clear = stock_d - retract_d for ID.

    **Validates: Requirements 2.3, 3.1**

    The cleanup pass traces the roughing boundary contour and needs full
    stock-boundary clearance. This behavior must be preserved after the fix.
    """
    pilot_hole = round(pilot_hole, 4)
    retract_d = round(retract_d, 4)
    doc = round(doc, 4)

    x_clear_val = pilot_hole - retract_d
    assume(x_clear_val > 0.01)

    target_dia = round(pilot_hole * target_mult, 4)
    assume(target_dia <= 3.0)

    fin_doc = 0.002
    fin_allowance = fin_doc
    max_target_d = target_dia - fin_allowance * 2
    assume(pilot_hole + doc * 2 < max_target_d)

    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="ID",
        stock_dia=f"{pilot_hole:.4f}",
        x_start=f"{pilot_hole:.4f}",
        z_start="0.1",
        doc=f"{doc:.4f}",
        fin_passes="1",
        fin_doc=f"{fin_doc:.4f}",
        feed_r="0.003",
        feed_f="0.002",
        retract=f"{retract_d:.4f}",
        rough_tool="2",
        finish_tool="2",
        rpm="800",
        safe_x=f"{pilot_hole - 0.200:.4f}",
        safe_z="1.000",
    )

    _add_segments(blk, [
        {"x_end": f"{target_dia:.4f}", "z_end": "0.000"},
        {"x_end": f"{target_dia:.4f}", "z_end": "-2.000"},
    ])

    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    x_clear = round(pilot_hole - retract_d, 4)
    cleanup = _parse_cleanup_pass_x_values(gcode)

    assert cleanup["approach_x"] is not None, "No cleanup pass approach found"
    assert cleanup["retract_x"] is not None, "No cleanup pass retract found"

    assert abs(cleanup["approach_x"] - x_clear) < 0.0001, (
        f"ID cleanup approach_x={cleanup['approach_x']:.4f}, "
        f"expected x_clear={x_clear:.4f}"
    )
    assert abs(cleanup["retract_x"] - x_clear) < 0.0001, (
        f"ID cleanup retract_x={cleanup['retract_x']:.4f}, "
        f"expected x_clear={x_clear:.4f}"
    )


# ------------------------------------------------------------------
# Preservation test — Finish pass retract
# ------------------------------------------------------------------

@settings(max_examples=10, deadline=None,
          suppress_health_check=[HealthCheck.filter_too_much])
@given(
    stock_dia=floats(min_value=1.5, max_value=4.0, allow_nan=False, allow_infinity=False),
    retract_d=floats(min_value=0.020, max_value=0.100, allow_nan=False, allow_infinity=False),
    doc=floats(min_value=0.020, max_value=0.060, allow_nan=False, allow_infinity=False),
    target_frac=floats(min_value=0.2, max_value=0.5, allow_nan=False, allow_infinity=False),
    is_id=floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False),
)
def test_preservation_finish_pass_retract(stock_dia, retract_d, doc, target_frac, is_id):
    """Finish pass retract X must equal x_clear for both OD and ID modes.

    **Validates: Requirements 2.4, 3.2**

    The finish pass traces the final part profile and retracts to full
    stock-boundary clearance. This behavior must be preserved after the fix.
    """
    use_id = is_id > 0.5

    if use_id:
        # ID mode
        pilot_hole = round(stock_dia * 0.3, 4)  # smaller pilot hole
        assume(pilot_hole >= 0.3)
        assume(pilot_hole <= 1.0)
        retract_d = round(min(retract_d, 0.060), 4)
        x_clear_val = pilot_hole - retract_d
        assume(x_clear_val > 0.01)

        target_dia = round(pilot_hole * 2.5, 4)
        assume(target_dia <= 3.0)

        fin_doc = 0.002
        max_target_d = target_dia - fin_doc * 2
        assume(pilot_hole + doc * 2 < max_target_d)

        blk = _make_profile_block()
        _set_profile_fields(blk,
            mode="ID",
            stock_dia=f"{pilot_hole:.4f}",
            x_start=f"{pilot_hole:.4f}",
            z_start="0.1",
            doc=f"{doc:.4f}",
            fin_passes="1",
            fin_doc=f"{fin_doc:.4f}",
            feed_r="0.003",
            feed_f="0.002",
            retract=f"{retract_d:.4f}",
            rough_tool="2",
            finish_tool="2",
            rpm="800",
            safe_x=f"{pilot_hole - 0.200:.4f}",
            safe_z="1.000",
        )

        _add_segments(blk, [
            {"x_end": f"{target_dia:.4f}", "z_end": "0.000"},
            {"x_end": f"{target_dia:.4f}", "z_end": "-2.000"},
        ])

        expected_x_clear = round(pilot_hole - retract_d, 4)
    else:
        # OD mode
        stock_dia = round(stock_dia, 4)
        retract_d = round(retract_d, 4)
        doc = round(doc, 4)

        target_dia = round(stock_dia * target_frac, 4)
        assume(target_dia >= 0.5)

        fin_doc = 0.002
        min_target_d = target_dia + fin_doc * 2
        assume(stock_dia - doc * 2 > min_target_d)

        blk = _make_profile_block()
        _set_profile_fields(blk,
            mode="OD",
            stock_dia=f"{stock_dia:.4f}",
            x_start=f"{stock_dia:.4f}",
            z_start="0.1",
            doc=f"{doc:.4f}",
            fin_passes="1",
            fin_doc=f"{fin_doc:.4f}",
            feed_r="0.005",
            feed_f="0.003",
            retract=f"{retract_d:.4f}",
            rough_tool="1",
            finish_tool="1",
            rpm="1200",
            safe_x=f"{stock_dia + 1.0:.4f}",
            safe_z="1.000",
        )

        _add_segments(blk, [
            {"x_end": f"{target_dia:.4f}", "z_end": "0.000"},
            {"x_end": f"{target_dia:.4f}", "z_end": "-2.000"},
        ])

        expected_x_clear = round(stock_dia + retract_d, 4)

    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    retract_x = _parse_finish_pass_retract_x(gcode)
    assert retract_x is not None, "No finish pass retract found"

    assert abs(retract_x - expected_x_clear) < 0.0001, (
        f"Finish pass retract_x={retract_x:.4f}, "
        f"expected x_clear={expected_x_clear:.4f}"
    )


# ------------------------------------------------------------------
# Preservation test — Z clearance
# ------------------------------------------------------------------

@settings(max_examples=10, deadline=None,
          suppress_health_check=[HealthCheck.filter_too_much])
@given(
    stock_dia=floats(min_value=1.5, max_value=4.0, allow_nan=False, allow_infinity=False),
    retract_d=floats(min_value=0.020, max_value=0.100, allow_nan=False, allow_infinity=False),
    doc=floats(min_value=0.020, max_value=0.060, allow_nan=False, allow_infinity=False),
    z_start=floats(min_value=0.050, max_value=0.500, allow_nan=False, allow_infinity=False),
    target_frac=floats(min_value=0.2, max_value=0.5, allow_nan=False, allow_infinity=False),
)
def test_preservation_z_clearance(stock_dia, retract_d, doc, z_start, target_frac):
    """All roughing pass Z approach values must equal z_start + 0.050.

    **Validates: Requirements 3.3**

    The Z clearance for roughing pass approach is computed as z_start + 0.050.
    This must remain unchanged after the fix.
    """
    stock_dia = round(stock_dia, 4)
    retract_d = round(retract_d, 4)
    doc = round(doc, 4)
    z_start = round(z_start, 4)

    target_dia = round(stock_dia * target_frac, 4)
    assume(target_dia >= 0.5)

    fin_doc = 0.002
    min_target_d = target_dia + fin_doc * 2
    assume(stock_dia - doc * 2 > min_target_d)

    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="OD",
        stock_dia=f"{stock_dia:.4f}",
        x_start=f"{stock_dia:.4f}",
        z_start=f"{z_start:.4f}",
        doc=f"{doc:.4f}",
        fin_passes="1",
        fin_doc=f"{fin_doc:.4f}",
        feed_r="0.005",
        feed_f="0.003",
        retract=f"{retract_d:.4f}",
        rough_tool="1",
        finish_tool="1",
        rpm="1200",
        safe_x=f"{stock_dia + 1.0:.4f}",
        safe_z="1.000",
    )

    _add_segments(blk, [
        {"x_end": f"{target_dia:.4f}", "z_end": "0.000"},
        {"x_end": f"{target_dia:.4f}", "z_end": "-2.000"},
    ])

    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    z_values = _parse_roughing_z_approach(gcode)
    assume(len(z_values) > 0)

    expected_z_clear = round(z_start + 0.050, 4)

    for i, z_val in enumerate(z_values):
        assert abs(z_val - expected_z_clear) < 0.0001, (
            f"Roughing pass {i+1} Z approach={z_val:.4f}, "
            f"expected z_clear={expected_z_clear:.4f} (z_start={z_start:.4f} + 0.050)"
        )


# ------------------------------------------------------------------
# Preservation test — Header comments
# ------------------------------------------------------------------

@settings(max_examples=10, deadline=None,
          suppress_health_check=[HealthCheck.filter_too_much])
@given(
    stock_dia=floats(min_value=1.5, max_value=4.0, allow_nan=False, allow_infinity=False),
    retract_d=floats(min_value=0.020, max_value=0.100, allow_nan=False, allow_infinity=False),
    doc=floats(min_value=0.020, max_value=0.060, allow_nan=False, allow_infinity=False),
    target_frac=floats(min_value=0.2, max_value=0.5, allow_nan=False, allow_infinity=False),
)
def test_preservation_header_comments(stock_dia, retract_d, doc, target_frac):
    """Header comments must contain stock diameter, tool numbers, feed rates, RPM.

    **Validates: Requirements 3.5**

    The G-code header comments include stock info, tool info, feed rates,
    and RPM. This must remain unchanged after the fix.
    """
    stock_dia = round(stock_dia, 4)
    retract_d = round(retract_d, 4)
    doc = round(doc, 4)

    target_dia = round(stock_dia * target_frac, 4)
    assume(target_dia >= 0.5)

    fin_doc = 0.002
    min_target_d = target_dia + fin_doc * 2
    assume(stock_dia - doc * 2 > min_target_d)

    rough_tool = "3"
    finish_tool = "5"
    feed_r = "0.007"
    feed_f = "0.004"
    rpm = "1500"

    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="OD",
        stock_dia=f"{stock_dia:.4f}",
        x_start=f"{stock_dia:.4f}",
        z_start="0.1",
        doc=f"{doc:.4f}",
        fin_passes="1",
        fin_doc=f"{fin_doc:.4f}",
        feed_r=feed_r,
        feed_f=feed_f,
        retract=f"{retract_d:.4f}",
        rough_tool=rough_tool,
        finish_tool=finish_tool,
        rpm=rpm,
        safe_x=f"{stock_dia + 1.0:.4f}",
        safe_z="1.000",
    )

    _add_segments(blk, [
        {"x_end": f"{target_dia:.4f}", "z_end": "0.000"},
        {"x_end": f"{target_dia:.4f}", "z_end": "-2.000"},
    ])

    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    header = _parse_header_comments(gcode)
    header_text = "\n".join(header)

    # Stock diameter must appear in header
    assert f"{stock_dia:.4f}" in header_text, (
        f"Stock diameter {stock_dia:.4f} not found in header:\n{header_text}"
    )

    # Tool numbers must appear in header
    assert f"T{rough_tool}" in header_text, (
        f"Rough tool T{rough_tool} not found in header:\n{header_text}"
    )
    assert f"T{finish_tool}" in header_text, (
        f"Finish tool T{finish_tool} not found in header:\n{header_text}"
    )

    # Feed rates must appear in header
    assert feed_r in header_text, (
        f"Roughing feed {feed_r} not found in header:\n{header_text}"
    )
    assert feed_f in header_text, (
        f"Finish feed {feed_f} not found in header:\n{header_text}"
    )

    # RPM must appear in header
    assert rpm in header_text, (
        f"RPM {rpm} not found in header:\n{header_text}"
    )
