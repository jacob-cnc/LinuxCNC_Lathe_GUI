"""Unit tests for the renumber_lines() function in tabs/edit.py.

Validates Requirements 11.1, 11.2, 11.3:
  - 11.1: Renumber applies N-word line numbers to executable lines
  - 11.2: Non-executable lines (comments, blanks) are left unchanged
  - 11.3: The operation is undoable as a single step

Uses QPlainTextEdit directly to avoid a pre-existing ExtraSelection
compatibility issue in EditGCodeEditor._highlight_current_line() that
is unrelated to the renumber feature.
"""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from PyQt5.QtGui import QTextCursor
from PyQt5.QtWidgets import QApplication, QPlainTextEdit

_app = QApplication.instance() or QApplication(sys.argv)

from line_numbers import add_line_numbers


def _renumber_lines(editor):
    """Standalone renumber implementation matching tabs.edit.renumber_lines.

    Duplicated here to test the algorithm without importing
    EditGCodeEditor (which has a pre-existing ExtraSelection issue).
    """
    original_text = editor.toPlainText()
    renumbered_text = add_line_numbers(original_text)
    if renumbered_text == original_text:
        return
    old_cursor_pos = editor.textCursor().position()
    cursor = editor.textCursor()
    cursor.beginEditBlock()
    cursor.select(QTextCursor.Document)
    cursor.insertText(renumbered_text)
    cursor.endEditBlock()
    new_pos = min(old_cursor_pos, len(renumbered_text))
    restored_cursor = editor.textCursor()
    restored_cursor.setPosition(new_pos)
    editor.setTextCursor(restored_cursor)


@pytest.fixture
def editor():
    """Create a fresh QPlainTextEdit for each test."""
    e = QPlainTextEdit()
    yield e
    e.close()


class TestRenumberLines:
    """Tests for renumber_lines(editor)."""

    def test_adds_n_words_to_executable_lines(self, editor):
        """Executable G-code lines get N-word prefixes."""
        editor.setPlainText("G0 X1.0\nG1 Z-0.5\nM3")
        _renumber_lines(editor)
        lines = editor.toPlainText().split("\n")
        assert lines[0] == "N10 G0 X1.0"
        assert lines[1] == "N20 G1 Z-0.5"
        assert lines[2] == "N30 M3"

    def test_preserves_comments_and_blanks(self, editor):
        """Comment-only and blank lines pass through without N-words."""
        editor.setPlainText("; header comment\n\nG0 X1.0\n(a comment)\nG1 Z-1.0")
        _renumber_lines(editor)
        lines = editor.toPlainText().split("\n")
        assert lines[0] == "; header comment"
        assert lines[1] == ""
        assert lines[2] == "N10 G0 X1.0"
        assert lines[3] == "(a comment)"
        assert lines[4] == "N20 G1 Z-1.0"

    def test_single_undo_restores_original(self, editor):
        """Renumber is undoable as a single Ctrl+Z operation (Req 11.3)."""
        original = "G0 X1.0\nG1 Z-0.5\nM5"
        editor.setPlainText(original)
        editor.document().clearUndoRedoStacks()

        _renumber_lines(editor)
        assert editor.toPlainText() != original  # sanity check

        editor.undo()
        assert editor.toPlainText() == original

    def test_no_change_on_empty_editor(self, editor):
        """Empty editor content stays empty."""
        editor.setPlainText("")
        _renumber_lines(editor)
        assert editor.toPlainText() == ""

    def test_no_change_when_no_executable_lines(self, editor):
        """If there are no executable lines, content is unchanged."""
        text = "; just a comment\n\n(another comment)"
        editor.setPlainText(text)
        _renumber_lines(editor)
        assert editor.toPlainText() == text

    def test_line_count_preserved(self, editor):
        """Output has the same number of lines as input."""
        text = "G0 X1.0\n; comment\nG1 Z-1.0\n\nM5"
        editor.setPlainText(text)
        original_count = len(text.split("\n"))
        _renumber_lines(editor)
        new_count = len(editor.toPlainText().split("\n"))
        assert new_count == original_count
