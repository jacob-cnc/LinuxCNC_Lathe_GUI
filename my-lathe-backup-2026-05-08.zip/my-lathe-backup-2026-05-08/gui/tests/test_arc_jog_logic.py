"""Unit tests for ArcJogLogic pure computation class.

Covers tasks 2.1–2.5:
- 2.1: validate_radius, compute_arc_center (all 8 quadrant×start_type combos),
        get_quadrant_angle_range
- 2.2: compute_tangent at known angles, decompose_arc_pulse linearity/sign,
        check_soft_limits
- 2.3: reproject_onto_arc maintains exact radius, clamp_angle at boundaries/interior,
        degenerate case
- 2.4: process_pulse end-to-end (normal, soft limit hit, angular boundary, reverse)
- 2.5: activate sets correct initial angle, accumulate_distance sums, reset clears
"""

import math
import pytest
import sys
import os

# Add parent directory to path so we can import arc_jog_logic
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from arc_jog_logic import ArcJogLogic, Quadrant, StartType


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_logic(x_min=-1.0, x_max=5.0, z_min=-1.0, z_max=25.0):
    """Create an ArcJogLogic instance with generous soft limits."""
    return ArcJogLogic(x_min=x_min, x_max=x_max, z_min=z_min, z_max=z_max)


# ===========================================================================
# Task 2.1: validate_radius, compute_arc_center, get_quadrant_angle_range
# ===========================================================================


class TestValidateRadius:
    """Test radius validation accepts only positive numeric values."""

    def test_valid_positive_float(self):
        valid, val = ArcJogLogic.validate_radius(0.25)
        assert valid is True
        assert val == 0.25

    def test_valid_positive_int(self):
        valid, val = ArcJogLogic.validate_radius(1)
        assert valid is True
        assert val == 1.0

    def test_valid_string_number(self):
        valid, val = ArcJogLogic.validate_radius("0.125")
        assert valid is True
        assert val == 0.125

    def test_valid_large_value(self):
        valid, val = ArcJogLogic.validate_radius(2.5)
        assert valid is True
        assert val == 2.5

    def test_invalid_zero(self):
        valid, val = ArcJogLogic.validate_radius(0.0)
        assert valid is False
        assert val == 0.0

    def test_invalid_negative(self):
        valid, val = ArcJogLogic.validate_radius(-0.5)
        assert valid is False
        assert val == 0.0

    def test_invalid_string(self):
        valid, val = ArcJogLogic.validate_radius("abc")
        assert valid is False
        assert val == 0.0

    def test_invalid_empty_string(self):
        valid, val = ArcJogLogic.validate_radius("")
        assert valid is False
        assert val == 0.0

    def test_invalid_none(self):
        valid, val = ArcJogLogic.validate_radius(None)
        assert valid is False
        assert val == 0.0


class TestComputeArcCenter:
    """Test arc center computation for all 8 quadrant × start_type combos."""

    def setup_method(self):
        self.logic = make_logic()
        self.x = 1.0
        self.z = 10.0
        self.r = 0.5

    # --- Pole start type (offset in Z, center_x == current_x) ---

    def test_pole_top_right(self):
        cx, cz = self.logic.compute_arc_center(
            self.x, self.z, self.r, Quadrant.TOP_RIGHT, StartType.POLE)
        assert cx == self.x
        assert cz == self.z - self.r

    def test_pole_top_left(self):
        cx, cz = self.logic.compute_arc_center(
            self.x, self.z, self.r, Quadrant.TOP_LEFT, StartType.POLE)
        assert cx == self.x
        assert cz == self.z + self.r

    def test_pole_bottom_left(self):
        cx, cz = self.logic.compute_arc_center(
            self.x, self.z, self.r, Quadrant.BOTTOM_LEFT, StartType.POLE)
        assert cx == self.x
        assert cz == self.z + self.r

    def test_pole_bottom_right(self):
        cx, cz = self.logic.compute_arc_center(
            self.x, self.z, self.r, Quadrant.BOTTOM_RIGHT, StartType.POLE)
        assert cx == self.x
        assert cz == self.z - self.r

    # --- Midpoint start type (offset in X, center_z == current_z) ---

    def test_midpoint_top_right(self):
        cx, cz = self.logic.compute_arc_center(
            self.x, self.z, self.r, Quadrant.TOP_RIGHT, StartType.MIDPOINT)
        assert cx == self.x - self.r
        assert cz == self.z

    def test_midpoint_top_left(self):
        cx, cz = self.logic.compute_arc_center(
            self.x, self.z, self.r, Quadrant.TOP_LEFT, StartType.MIDPOINT)
        assert cx == self.x - self.r
        assert cz == self.z

    def test_midpoint_bottom_left(self):
        cx, cz = self.logic.compute_arc_center(
            self.x, self.z, self.r, Quadrant.BOTTOM_LEFT, StartType.MIDPOINT)
        assert cx == self.x + self.r
        assert cz == self.z

    def test_midpoint_bottom_right(self):
        cx, cz = self.logic.compute_arc_center(
            self.x, self.z, self.r, Quadrant.BOTTOM_RIGHT, StartType.MIDPOINT)
        assert cx == self.x + self.r
        assert cz == self.z

    # --- Distance verification: center is exactly radius from start ---

    def test_pole_center_distance(self):
        """For all pole cases, center should be exactly radius away."""
        for quad in Quadrant:
            cx, cz = self.logic.compute_arc_center(
                self.x, self.z, self.r, quad, StartType.POLE)
            dist = math.sqrt((cx - self.x)**2 + (cz - self.z)**2)
            assert abs(dist - self.r) < 1e-10, f"Failed for {quad}"

    def test_midpoint_center_distance(self):
        """For all midpoint cases, center should be exactly radius away."""
        for quad in Quadrant:
            cx, cz = self.logic.compute_arc_center(
                self.x, self.z, self.r, quad, StartType.MIDPOINT)
            dist = math.sqrt((cx - self.x)**2 + (cz - self.z)**2)
            assert abs(dist - self.r) < 1e-10, f"Failed for {quad}"


class TestGetQuadrantAngleRange:
    """Test that each quadrant returns the correct 90-degree angular range."""

    def setup_method(self):
        self.logic = make_logic()

    def test_top_right(self):
        start, end = self.logic.get_quadrant_angle_range(Quadrant.TOP_RIGHT)
        assert start == 0.0
        assert end == math.pi / 2

    def test_top_left(self):
        start, end = self.logic.get_quadrant_angle_range(Quadrant.TOP_LEFT)
        assert start == math.pi / 2
        assert end == math.pi

    def test_bottom_left(self):
        start, end = self.logic.get_quadrant_angle_range(Quadrant.BOTTOM_LEFT)
        assert start == math.pi
        assert end == 3 * math.pi / 2

    def test_bottom_right(self):
        start, end = self.logic.get_quadrant_angle_range(Quadrant.BOTTOM_RIGHT)
        assert start == 3 * math.pi / 2
        assert end == 2 * math.pi

    def test_all_ranges_are_90_degrees(self):
        """Each quadrant spans exactly pi/2 radians."""
        for quad in Quadrant:
            start, end = self.logic.get_quadrant_angle_range(quad)
            assert abs((end - start) - math.pi / 2) < 1e-10



# ===========================================================================
# Task 2.2: compute_tangent, decompose_arc_pulse, check_soft_limits
# ===========================================================================


class TestComputeTangent:
    """Test tangent vector at known angles."""

    def setup_method(self):
        self.logic = make_logic()

    def test_tangent_at_zero(self):
        """At angle 0 (positive Z direction), tangent is (1, 0) — pure X."""
        tx, tz = self.logic.compute_tangent(0.0)
        assert abs(tx - 1.0) < 1e-10
        assert abs(tz - 0.0) < 1e-10

    def test_tangent_at_pi_over_4(self):
        """At angle π/4, tangent is (cos(π/4), -sin(π/4))."""
        tx, tz = self.logic.compute_tangent(math.pi / 4)
        expected_x = math.cos(math.pi / 4)
        expected_z = -math.sin(math.pi / 4)
        assert abs(tx - expected_x) < 1e-10
        assert abs(tz - expected_z) < 1e-10

    def test_tangent_at_pi_over_2(self):
        """At angle π/2 (positive X direction), tangent is (0, -1) — pure -Z."""
        tx, tz = self.logic.compute_tangent(math.pi / 2)
        assert abs(tx - 0.0) < 1e-10
        assert abs(tz - (-1.0)) < 1e-10

    def test_tangent_at_pi(self):
        """At angle π (negative Z direction), tangent is (-1, 0) — pure -X."""
        tx, tz = self.logic.compute_tangent(math.pi)
        assert abs(tx - (-1.0)) < 1e-10
        assert abs(tz - 0.0) < 1e-10

    def test_tangent_is_unit_vector(self):
        """Tangent should always be a unit vector."""
        for angle in [0, math.pi/6, math.pi/4, math.pi/3, math.pi/2,
                      math.pi, 3*math.pi/2, 5*math.pi/3]:
            tx, tz = self.logic.compute_tangent(angle)
            magnitude = math.sqrt(tx**2 + tz**2)
            assert abs(magnitude - 1.0) < 1e-10

    def test_tangent_perpendicular_to_radius(self):
        """Tangent dot radius direction should be zero."""
        for angle in [0, math.pi/4, math.pi/2, math.pi, 3*math.pi/2]:
            tx, tz = self.logic.compute_tangent(angle)
            # Radius direction at angle: (sin(angle), cos(angle))
            rx = math.sin(angle)
            rz = math.cos(angle)
            dot = tx * rx + tz * rz
            assert abs(dot) < 1e-10


class TestDecomposeArcPulse:
    """Test pulse decomposition linearity and sign preservation."""

    def setup_method(self):
        self.logic = make_logic()
        # Activate at top-right pole to set current_angle = 0
        self.logic.activate(1.0, 10.5, 0.5, Quadrant.TOP_RIGHT, StartType.POLE)

    def test_single_positive_pulse(self):
        """Single positive pulse at angle 0: tangent is (1, 0)."""
        x, z = self.logic.decompose_arc_pulse(1, 0.001)
        assert abs(x - 0.001) < 1e-10
        assert abs(z - 0.0) < 1e-10

    def test_single_negative_pulse(self):
        """Negating count negates both components."""
        x, z = self.logic.decompose_arc_pulse(-1, 0.001)
        assert abs(x - (-0.001)) < 1e-10
        assert abs(z - 0.0) < 1e-10

    def test_linearity_in_count(self):
        """Result scales linearly with count_delta."""
        x1, z1 = self.logic.decompose_arc_pulse(1, 0.001)
        x5, z5 = self.logic.decompose_arc_pulse(5, 0.001)
        assert abs(x5 - 5 * x1) < 1e-10
        assert abs(z5 - 5 * z1) < 1e-10

    def test_linearity_in_scale(self):
        """Result scales linearly with jog_scale."""
        x1, z1 = self.logic.decompose_arc_pulse(1, 0.001)
        x2, z2 = self.logic.decompose_arc_pulse(1, 0.01)
        assert abs(x2 - 10 * x1) < 1e-10
        assert abs(z2 - 10 * z1) < 1e-10

    def test_zero_count_gives_zero(self):
        """Zero count delta produces zero motion."""
        x, z = self.logic.decompose_arc_pulse(0, 0.001)
        assert x == 0.0
        assert z == 0.0

    def test_at_pi_over_2(self):
        """At angle π/2, tangent is (0, -1): motion is pure -Z."""
        self.logic.current_angle = math.pi / 2
        x, z = self.logic.decompose_arc_pulse(1, 0.001)
        assert abs(x) < 1e-10
        assert abs(z - (-0.001)) < 1e-10


class TestCheckSoftLimits:
    """Test soft limit enforcement — all-or-nothing suppression."""

    def setup_method(self):
        self.logic = ArcJogLogic(x_min=0.0, x_max=4.0, z_min=0.0, z_max=20.0)

    def test_within_limits_passes(self):
        """Motion within limits returns original deltas, not suppressed."""
        x, z, suppressed = self.logic.check_soft_limits(2.0, 10.0, 0.1, 0.1)
        assert x == 0.1
        assert z == 0.1
        assert suppressed is False

    def test_x_exceeds_max_suppresses_both(self):
        """X exceeding max suppresses both axes."""
        x, z, suppressed = self.logic.check_soft_limits(3.9, 10.0, 0.2, 0.1)
        assert x == 0.0
        assert z == 0.0
        assert suppressed is True

    def test_x_below_min_suppresses_both(self):
        """X below min suppresses both axes."""
        x, z, suppressed = self.logic.check_soft_limits(0.05, 10.0, -0.1, 0.1)
        assert x == 0.0
        assert z == 0.0
        assert suppressed is True

    def test_z_exceeds_max_suppresses_both(self):
        """Z exceeding max suppresses both axes."""
        x, z, suppressed = self.logic.check_soft_limits(2.0, 19.9, 0.01, 0.2)
        assert x == 0.0
        assert z == 0.0
        assert suppressed is True

    def test_z_below_min_suppresses_both(self):
        """Z below min suppresses both axes."""
        x, z, suppressed = self.logic.check_soft_limits(2.0, 0.05, 0.01, -0.1)
        assert x == 0.0
        assert z == 0.0
        assert suppressed is True

    def test_exactly_at_limit_is_ok(self):
        """Position exactly at limit boundary is within limits."""
        x, z, suppressed = self.logic.check_soft_limits(2.0, 10.0, 2.0, 10.0)
        # new_x = 4.0 (== x_max), new_z = 20.0 (== z_max) — at boundary
        assert x == 2.0
        assert z == 10.0
        assert suppressed is False

    def test_negative_motion_within_limits(self):
        """Negative motion that stays within limits passes."""
        x, z, suppressed = self.logic.check_soft_limits(2.0, 10.0, -1.0, -5.0)
        assert x == -1.0
        assert z == -5.0
        assert suppressed is False



# ===========================================================================
# Task 2.3: reproject_onto_arc and clamp_angle
# ===========================================================================


class TestReprojectOntoArc:
    """Test re-projection maintains exact radius distance."""

    def setup_method(self):
        self.logic = make_logic()
        # Set up arc state: center at (1.0, 10.0), radius 0.5
        self.logic.arc_center_x = 1.0
        self.logic.arc_center_z = 10.0
        self.logic.radius = 0.5
        self.logic.current_angle = 0.0

    def test_point_outside_arc_reprojected_to_radius(self):
        """A point farther than radius is pulled back to exact radius."""
        # Point at (1.0, 10.7) — 0.7 from center, should be snapped to 0.5
        rx, rz = self.logic.reproject_onto_arc(1.0, 10.7)
        dist = math.sqrt((rx - 1.0)**2 + (rz - 10.0)**2)
        assert abs(dist - 0.5) < 1e-10

    def test_point_inside_arc_reprojected_to_radius(self):
        """A point closer than radius is pushed out to exact radius."""
        # Point at (1.0, 10.3) — 0.3 from center, should be pushed to 0.5
        rx, rz = self.logic.reproject_onto_arc(1.0, 10.3)
        dist = math.sqrt((rx - 1.0)**2 + (rz - 10.0)**2)
        assert abs(dist - 0.5) < 1e-10

    def test_point_already_on_arc_unchanged(self):
        """A point already at exact radius stays put."""
        # Point at (1.0, 10.5) — exactly 0.5 from center
        rx, rz = self.logic.reproject_onto_arc(1.0, 10.5)
        assert abs(rx - 1.0) < 1e-10
        assert abs(rz - 10.5) < 1e-10

    def test_direction_preserved(self):
        """Re-projection preserves the direction from center."""
        # Point at (1.3, 10.4) — direction should be preserved
        px, pz = 1.3, 10.4
        rx, rz = self.logic.reproject_onto_arc(px, pz)
        # Direction from center to original
        dx_orig = px - 1.0
        dz_orig = pz - 10.0
        # Direction from center to reprojected
        dx_repr = rx - 1.0
        dz_repr = rz - 10.0
        # Normalize both and compare
        mag_orig = math.sqrt(dx_orig**2 + dz_orig**2)
        mag_repr = math.sqrt(dx_repr**2 + dz_repr**2)
        assert abs(dx_orig/mag_orig - dx_repr/mag_repr) < 1e-10
        assert abs(dz_orig/mag_orig - dz_repr/mag_repr) < 1e-10

    def test_degenerate_case_at_center(self):
        """When position is at arc center, returns position at current angle."""
        self.logic.current_angle = math.pi / 4
        rx, rz = self.logic.reproject_onto_arc(1.0, 10.0)  # exactly at center
        # Should return position at current_angle
        expected_x = 1.0 + 0.5 * math.sin(math.pi / 4)
        expected_z = 10.0 + 0.5 * math.cos(math.pi / 4)
        assert abs(rx - expected_x) < 1e-10
        assert abs(rz - expected_z) < 1e-10

    def test_reprojection_maintains_radius_various_angles(self):
        """Re-projection from various directions all land at exact radius."""
        angles = [0, math.pi/6, math.pi/3, math.pi/2, 2*math.pi/3, math.pi]
        for angle in angles:
            # Create a point slightly off the arc in this direction
            off_dist = 0.55  # slightly more than radius
            px = 1.0 + off_dist * math.sin(angle)
            pz = 10.0 + off_dist * math.cos(angle)
            rx, rz = self.logic.reproject_onto_arc(px, pz)
            dist = math.sqrt((rx - 1.0)**2 + (rz - 10.0)**2)
            assert abs(dist - 0.5) < 1e-10


class TestClampAngle:
    """Test angular clamping at boundaries and interior."""

    def setup_method(self):
        self.logic = make_logic()
        # Set quadrant to top-right: [0, π/2]
        self.logic.angle_start = 0.0
        self.logic.angle_end = math.pi / 2

    def test_interior_angle_not_clamped(self):
        """Angle within range passes through unchanged."""
        angle, clamped = self.logic.clamp_angle(math.pi / 4)
        assert abs(angle - math.pi / 4) < 1e-10
        assert clamped is False

    def test_angle_at_start_boundary_not_clamped(self):
        """Angle exactly at start boundary is not clamped."""
        angle, clamped = self.logic.clamp_angle(0.0)
        assert angle == 0.0
        assert clamped is False

    def test_angle_at_end_boundary_not_clamped(self):
        """Angle exactly at end boundary is not clamped."""
        angle, clamped = self.logic.clamp_angle(math.pi / 2)
        assert abs(angle - math.pi / 2) < 1e-10
        assert clamped is False

    def test_angle_below_start_clamped(self):
        """Angle below start is clamped to start."""
        angle, clamped = self.logic.clamp_angle(-0.1)
        assert angle == 0.0
        assert clamped is True

    def test_angle_above_end_clamped(self):
        """Angle above end is clamped to end."""
        angle, clamped = self.logic.clamp_angle(math.pi / 2 + 0.1)
        assert abs(angle - math.pi / 2) < 1e-10
        assert clamped is True

    def test_clamp_with_bottom_left_quadrant(self):
        """Test clamping with a different quadrant range [π, 3π/2]."""
        self.logic.angle_start = math.pi
        self.logic.angle_end = 3 * math.pi / 2
        # Below start
        angle, clamped = self.logic.clamp_angle(math.pi - 0.1)
        assert abs(angle - math.pi) < 1e-10
        assert clamped is True
        # Above end
        angle, clamped = self.logic.clamp_angle(3 * math.pi / 2 + 0.1)
        assert abs(angle - 3 * math.pi / 2) < 1e-10
        assert clamped is True
        # Interior
        angle, clamped = self.logic.clamp_angle(5 * math.pi / 4)
        assert abs(angle - 5 * math.pi / 4) < 1e-10
        assert clamped is False



# ===========================================================================
# Task 2.4: process_pulse end-to-end
# ===========================================================================


class TestProcessPulse:
    """Test process_pulse end-to-end pipeline."""

    def setup_method(self):
        self.logic = make_logic()
        # Activate at top-right, pole start: tool at (1.0, 10.5), center at (1.0, 10.0)
        self.logic.activate(1.0, 10.5, 0.5, Quadrant.TOP_RIGHT, StartType.POLE)
        # current_angle should be 0 (tool is directly above center in +Z)

    def test_normal_pulse_no_clamping_no_suppression(self):
        """Normal pulse produces motion, not suppressed or clamped."""
        x_delta, z_delta, suppressed, clamped = self.logic.process_pulse(
            1, 0.001, 1.0, 10.5)
        assert suppressed is False
        assert clamped is False
        # Should have some positive x motion (tangent at angle 0 is (1, 0))
        assert x_delta > 0
        # After reprojection, the position should be on the arc
        new_x = 1.0 + x_delta
        new_z = 10.5 + z_delta
        dist = math.sqrt((new_x - 1.0)**2 + (new_z - 10.0)**2)
        assert abs(dist - 0.5) < 1e-10

    def test_pulse_hits_soft_limit(self):
        """Pulse that would exceed soft limit is suppressed."""
        # Create logic with tight X limit
        logic = ArcJogLogic(x_min=0.0, x_max=1.0, z_min=0.0, z_max=20.0)
        logic.activate(1.0, 10.5, 0.5, Quadrant.TOP_RIGHT, StartType.POLE)
        # At angle 0, tangent is (1, 0) — positive X motion
        # Current x is 1.0, x_max is 1.0, so any positive X motion exceeds limit
        x_delta, z_delta, suppressed, clamped = logic.process_pulse(
            1, 0.001, 1.0, 10.5)
        assert suppressed is True
        assert x_delta == 0.0
        assert z_delta == 0.0

    def test_pulse_hits_angular_boundary(self):
        """Pulse that would exceed quadrant end is clamped."""
        # Move angle close to end boundary (π/2)
        self.logic.current_angle = math.pi / 2 - 0.001
        # Position near the end of the quadrant
        pos_x = 1.0 + 0.5 * math.sin(self.logic.current_angle)
        pos_z = 10.0 + 0.5 * math.cos(self.logic.current_angle)
        # Large positive pulse should try to go past π/2
        x_delta, z_delta, suppressed, clamped = self.logic.process_pulse(
            10, 0.01, pos_x, pos_z)
        assert clamped is True
        assert suppressed is False
        # Angle should be clamped to π/2
        assert abs(self.logic.current_angle - math.pi / 2) < 1e-10

    def test_reverse_at_boundary_allowed(self):
        """At start boundary, reverse (negative) pulse moves back into interior."""
        # Set angle to end boundary
        self.logic.current_angle = math.pi / 2
        pos_x = 1.0 + 0.5 * math.sin(math.pi / 2)  # = 1.5
        pos_z = 10.0 + 0.5 * math.cos(math.pi / 2)  # ≈ 10.0
        # Negative pulse should move back toward start (decreasing angle)
        x_delta, z_delta, suppressed, clamped = self.logic.process_pulse(
            -1, 0.001, pos_x, pos_z)
        assert suppressed is False
        # Angle should have decreased from π/2
        assert self.logic.current_angle < math.pi / 2

    def test_at_start_boundary_forward_allowed(self):
        """At start boundary (angle=0), forward pulse moves into interior."""
        # Already at angle 0 from setup
        x_delta, z_delta, suppressed, clamped = self.logic.process_pulse(
            1, 0.001, 1.0, 10.5)
        assert suppressed is False
        # Angle should have increased from 0
        assert self.logic.current_angle > 0

    def test_at_end_boundary_further_forward_suppressed(self):
        """At end boundary, further forward pulse is clamped to zero."""
        self.logic.current_angle = math.pi / 2
        pos_x = 1.0 + 0.5 * math.sin(math.pi / 2)
        pos_z = 10.0 + 0.5 * math.cos(math.pi / 2)
        # First pulse to reach boundary
        x_delta, z_delta, suppressed, clamped = self.logic.process_pulse(
            1, 0.001, pos_x, pos_z)
        # Should be clamped (already at boundary)
        assert clamped is True
        assert x_delta == 0.0
        assert z_delta == 0.0

    def test_reprojection_after_pulse(self):
        """After a normal pulse, tool position is exactly on the arc."""
        # Use a mid-angle position
        self.logic.current_angle = math.pi / 4
        pos_x = 1.0 + 0.5 * math.sin(math.pi / 4)
        pos_z = 10.0 + 0.5 * math.cos(math.pi / 4)
        x_delta, z_delta, suppressed, clamped = self.logic.process_pulse(
            1, 0.001, pos_x, pos_z)
        if not suppressed and not (clamped and x_delta == 0.0):
            new_x = pos_x + x_delta
            new_z = pos_z + z_delta
            dist = math.sqrt((new_x - 1.0)**2 + (new_z - 10.0)**2)
            assert abs(dist - 0.5) < 1e-10



# ===========================================================================
# Task 2.5: activate and accumulate_distance
# ===========================================================================


class TestActivate:
    """Test activate sets correct initial angle for each quadrant/start_type."""

    def setup_method(self):
        self.logic = make_logic()

    def test_activate_top_right_pole(self):
        """Pole start in top-right: tool at top of arc, angle = 0."""
        self.logic.activate(1.0, 10.5, 0.5, Quadrant.TOP_RIGHT, StartType.POLE)
        # Tool is at (1.0, 10.5), center at (1.0, 10.0)
        # dx=0, dz=0.5 → atan2(0, 0.5) = 0
        assert abs(self.logic.current_angle - 0.0) < 1e-10
        assert self.logic.arc_center_x == 1.0
        assert self.logic.arc_center_z == 10.0

    def test_activate_top_right_midpoint(self):
        """Midpoint start in top-right: tool at right of arc, angle = π/2."""
        self.logic.activate(1.5, 10.0, 0.5, Quadrant.TOP_RIGHT, StartType.MIDPOINT)
        # Tool is at (1.5, 10.0), center at (1.0, 10.0)
        # dx=0.5, dz=0 → atan2(0.5, 0) = π/2
        assert abs(self.logic.current_angle - math.pi / 2) < 1e-10
        assert self.logic.arc_center_x == 1.0
        assert self.logic.arc_center_z == 10.0

    def test_activate_top_left_pole(self):
        """Pole start in top-left: tool at top of arc, angle = π/2."""
        # For top-left pole: center at (x, z + r)
        # Tool at (1.0, 10.0), center at (1.0, 10.5)
        # dx=0, dz=-0.5 → atan2(0, -0.5) = π
        self.logic.activate(1.0, 10.0, 0.5, Quadrant.TOP_LEFT, StartType.POLE)
        # atan2(0, -0.5) = π — which is the end of top-left range [π/2, π]
        assert abs(self.logic.current_angle - math.pi) < 1e-10

    def test_activate_top_left_midpoint(self):
        """Midpoint start in top-left: tool at left of arc, angle = π/2."""
        # For top-left midpoint: center at (x - r, z)
        # Tool at (1.0, 10.0), center at (0.5, 10.0)
        # dx=0.5, dz=0 → atan2(0.5, 0) = π/2
        self.logic.activate(1.0, 10.0, 0.5, Quadrant.TOP_LEFT, StartType.MIDPOINT)
        assert abs(self.logic.current_angle - math.pi / 2) < 1e-10

    def test_activate_bottom_left_pole(self):
        """Pole start in bottom-left: tool at bottom of arc."""
        # For bottom-left pole: center at (x, z + r)
        # Tool at (1.0, 10.0), center at (1.0, 10.5)
        # dx=0, dz=-0.5 → atan2(0, -0.5) = π
        self.logic.activate(1.0, 10.0, 0.5, Quadrant.BOTTOM_LEFT, StartType.POLE)
        assert abs(self.logic.current_angle - math.pi) < 1e-10

    def test_activate_bottom_left_midpoint(self):
        """Midpoint start in bottom-left: tool at left of arc."""
        # For bottom-left midpoint: center at (x + r, z)
        # Tool at (1.0, 10.0), center at (1.5, 10.0)
        # dx=-0.5, dz=0 → atan2(-0.5, 0) = -π/2 → normalized to 3π/2
        self.logic.activate(1.0, 10.0, 0.5, Quadrant.BOTTOM_LEFT, StartType.MIDPOINT)
        assert abs(self.logic.current_angle - 3 * math.pi / 2) < 1e-10

    def test_activate_bottom_right_pole(self):
        """Pole start in bottom-right: tool at bottom of arc."""
        # For bottom-right pole: center at (x, z - r)
        # Tool at (1.0, 10.0), center at (1.0, 9.5)
        # dx=0, dz=0.5 → atan2(0, 0.5) = 0 → but range is [3π/2, 2π]
        # The code handles 0/2π wrap: angle 0 becomes 2π for bottom-right
        self.logic.activate(1.0, 10.0, 0.5, Quadrant.BOTTOM_RIGHT, StartType.POLE)
        assert abs(self.logic.current_angle - 2 * math.pi) < 1e-10

    def test_activate_bottom_right_midpoint(self):
        """Midpoint start in bottom-right: tool at right of arc."""
        # For bottom-right midpoint: center at (x + r, z)
        # Tool at (1.0, 10.0), center at (1.5, 10.0)
        # dx=-0.5, dz=0 → atan2(-0.5, 0) = -π/2 → normalized to 3π/2
        self.logic.activate(1.0, 10.0, 0.5, Quadrant.BOTTOM_RIGHT, StartType.MIDPOINT)
        assert abs(self.logic.current_angle - 3 * math.pi / 2) < 1e-10

    def test_activate_resets_cumulative_distance(self):
        """Activation resets cumulative distance to zero."""
        self.logic.cumulative_distance = 5.0
        self.logic.activate(1.0, 10.5, 0.5, Quadrant.TOP_RIGHT, StartType.POLE)
        assert self.logic.cumulative_distance == 0.0

    def test_activate_sets_angle_range(self):
        """Activation sets the correct angle range for the quadrant."""
        self.logic.activate(1.0, 10.5, 0.5, Quadrant.TOP_RIGHT, StartType.POLE)
        assert self.logic.angle_start == 0.0
        assert self.logic.angle_end == math.pi / 2


class TestAccumulateDistance:
    """Test cumulative distance tracking."""

    def setup_method(self):
        self.logic = make_logic()
        self.logic.cumulative_distance = 0.0

    def test_single_accumulation(self):
        """Single call adds Euclidean magnitude."""
        result = self.logic.accumulate_distance(0.003, 0.004)
        assert abs(result - 0.005) < 1e-10
        assert abs(self.logic.cumulative_distance - 0.005) < 1e-10

    def test_multiple_accumulations_sum(self):
        """Multiple calls sum correctly."""
        self.logic.accumulate_distance(0.003, 0.004)  # 0.005
        self.logic.accumulate_distance(0.006, 0.008)  # 0.010
        result = self.logic.accumulate_distance(0.0, 0.001)  # 0.001
        expected = 0.005 + 0.010 + 0.001
        assert abs(result - expected) < 1e-10
        assert abs(self.logic.cumulative_distance - expected) < 1e-10

    def test_zero_motion_adds_nothing(self):
        """Zero deltas add zero distance."""
        self.logic.accumulate_distance(0.003, 0.004)
        result = self.logic.accumulate_distance(0.0, 0.0)
        assert abs(result - 0.005) < 1e-10

    def test_negative_deltas_still_positive_distance(self):
        """Negative deltas produce positive distance (magnitude)."""
        result = self.logic.accumulate_distance(-0.003, -0.004)
        assert abs(result - 0.005) < 1e-10


class TestReset:
    """Test reset clears state."""

    def setup_method(self):
        self.logic = make_logic()

    def test_reset_clears_distance(self):
        """Reset zeroes cumulative distance."""
        self.logic.cumulative_distance = 1.234
        self.logic.reset()
        assert self.logic.cumulative_distance == 0.0

    def test_reset_clears_angle(self):
        """Reset zeroes current angle."""
        self.logic.current_angle = math.pi / 3
        self.logic.reset()
        assert self.logic.current_angle == 0.0
