# Bugfix: arc-valley-roughing-fix, Property 2: Preservation
"""
Preservation property tests for non-valley profile behavior.

These tests verify that the roughing system's behavior is UNCHANGED for
profiles that do NOT involve arc valleys:
  1. Straight-line monotonically-decreasing OD profiles → has_peaks=False,
     build_z_limit_chart produces correct Z limits
  2. Non-vertical arc profiles (endpoint X difference > 0.01") →
     build_z_interval_chart produces correct intervals
  3. Peak profiles (X increases beyond stock) → has_peaks=True,
     interval results correctly skip peak zones
  4. Degenerate arcs (R < chord/2 or zero-length chord) → fallback to
     linear interpolation is unchanged

**Validates: Requirements 3.1, 3.2, 3.3, 3.4, 3.5, 3.6**

These tests MUST PASS on the current UNFIXED code — they establish the
baseline behavior that must be preserved after the fix is applied.
"""

import sys
import os
import math

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from hypothesis import given, settings, assume, HealthCheck
from hypothesis.strategies import (
    floats, integers, lists, composite, sampled_from, just
)

from conv_profile import _linearize_arc, build_z_interval_chart, build_z_limit_chart


# ==================================================================
# Helper: Reproduce has_peaks detection logic from generate_gcode
# ==================================================================

def _detect_has_peaks(finish_moves, x_start_d, z_start, fin_passes, fin_doc, mode="OD"):
    """Reproduce the has_peaks detection logic from ProfileBlock.generate_gcode.

    This mirrors the exact logic at line ~1846 of conv_profile.py:
    1. Arc geometry awareness: detect valleys from arc center/radius
    2. Build rough_pts by linearizing arcs
    3. Build roughing_bnd by offsetting X by fin_allowance * 2
    4. Fallback: Check for peaks/valleys using the 0.001" threshold
    """
    fin_allowance = fin_passes * fin_doc
    offset_d = fin_allowance * 2

    rough_pts = [(x_start_d, z_start)]
    for mv in finish_moves:
        if mv[0] == "LINE":
            rough_pts.append((mv[1], mv[2]))
        elif mv[0] == "ARC":
            prev_x, prev_z = rough_pts[-1]
            arc_pts = _linearize_arc(prev_x, prev_z, mv[1], mv[2], mv[3])
            rough_pts.extend(arc_pts)

    roughing_bnd = []
    for x, z in rough_pts:
        if mode == "OD":
            roughing_bnd.append((x + offset_d, z))
        else:
            roughing_bnd.append((x - offset_d, z))

    # --- Arc geometry awareness: detect valleys that linearization obscures ---
    has_peaks = False
    _ARC_VALLEY_EPS = 0.0001
    prev_pt = (x_start_d, z_start)
    for mv in finish_moves:
        if mv[0] == "ARC":
            arc_x1 = prev_pt[0]
            arc_z1 = prev_pt[1]
            arc_x2 = mv[1]
            arc_z2 = mv[2]
            arc_radius = mv[3]

            R_abs = abs(arc_radius)
            adx = arc_x2 - arc_x1
            adz = arc_z2 - arc_z1
            arc_chord = math.sqrt(adx * adx + adz * adz)

            if R_abs >= 1e-9 and arc_chord >= 1e-9 and arc_chord <= 2.0 * R_abs + 1e-6:
                ar = max(R_abs, arc_chord / 2 + 0.0001)
                h = math.sqrt(max(0, ar * ar - (arc_chord / 2) ** 2))
                amx = (arc_x1 + arc_x2) / 2.0
                amz = (arc_z1 + arc_z2) / 2.0
                apx = -adz / arc_chord
                apz = adx / arc_chord

                cw = arc_radius > 0
                if arc_radius > 0:
                    ccx, ccz = amx - h * apx, amz - h * apz
                else:
                    ccx, ccz = amx - h * apx, amz - h * apz

                sa = math.atan2(arc_x1 - ccx, arc_z1 - ccz)
                ea = math.atan2(arc_x2 - ccx, arc_z2 - ccz)

                if cw:
                    if ea >= sa:
                        ea -= 2 * math.pi
                    if abs(ea - sa) > math.pi and arc_radius > 0:
                        ccx, ccz = 2 * amx - ccx, 2 * amz - ccz
                        sa = math.atan2(arc_x1 - ccx, arc_z1 - ccz)
                        ea = math.atan2(arc_x2 - ccx, arc_z2 - ccz)
                        if ea >= sa:
                            ea -= 2 * math.pi
                else:
                    if ea <= sa:
                        ea += 2 * math.pi
                    if abs(ea - sa) > math.pi and arc_radius > 0:
                        ccx, ccz = 2 * amx - ccx, 2 * amz - ccz
                        sa = math.atan2(arc_x1 - ccx, arc_z1 - ccz)
                        ea = math.atan2(arc_x2 - ccx, arc_z2 - ccz)
                        if ea <= sa:
                            ea += 2 * math.pi

                min_x_angle = -math.pi / 2.0
                arc_passes_through_min_x = False
                if cw:
                    a = min_x_angle
                    while a > sa + _ARC_VALLEY_EPS:
                        a -= 2 * math.pi
                    while a < ea - _ARC_VALLEY_EPS:
                        a += 2 * math.pi
                    if ea - _ARC_VALLEY_EPS <= a <= sa + _ARC_VALLEY_EPS:
                        arc_passes_through_min_x = True
                else:
                    a = min_x_angle
                    while a < sa - _ARC_VALLEY_EPS:
                        a += 2 * math.pi
                    while a > ea + _ARC_VALLEY_EPS:
                        a -= 2 * math.pi
                    if sa - _ARC_VALLEY_EPS <= a <= ea + _ARC_VALLEY_EPS:
                        arc_passes_through_min_x = True

                if arc_passes_through_min_x:
                    arc_min_x_d = ccx - ar
                    endpoints_min_x_d = min(arc_x1, arc_x2)
                    if arc_min_x_d < endpoints_min_x_d - _ARC_VALLEY_EPS:
                        has_peaks = True

            prev_pt = (mv[1], mv[2])
        elif mv[0] == "LINE":
            prev_pt = (mv[1], mv[2])

        if has_peaks:
            break

    # Fallback: existing roughing_bnd loop for non-arc peaks/valleys
    if not has_peaks:
        for i in range(1, len(roughing_bnd) - 1):
            x_prev = roughing_bnd[i - 1][0]
            x_curr = roughing_bnd[i][0]
            x_next = roughing_bnd[i + 1][0]
            if x_curr > x_prev + 0.001 and x_curr > x_next + 0.001:
                has_peaks = True
                break
            if x_curr < x_prev - 0.001 and x_curr < x_next - 0.001:
                has_peaks = True
                break

    return has_peaks


# ==================================================================
# Hypothesis strategies for generating profiles
# ==================================================================

@composite
def straight_line_decreasing_od_profile(draw):
    """Generate a random straight-line monotonically-decreasing OD profile.

    These profiles have X values that strictly decrease from x_start_d
    toward the part center. Z values strictly decrease (moving toward chuck).
    No arcs, no peaks, no valleys — just a simple OD turn.
    """
    # Stock diameter
    x_start_d = draw(floats(min_value=2.0, max_value=4.0,
                            allow_nan=False, allow_infinity=False))
    x_start_d = round(x_start_d, 4)

    # Generate 1-4 LINE segments with strictly decreasing X
    n_segments = draw(integers(min_value=1, max_value=4))
    z_start = 0.0
    fin_allowance = draw(floats(min_value=0.002, max_value=0.010,
                                allow_nan=False, allow_infinity=False))
    fin_allowance = round(fin_allowance, 4)

    finish_moves = []
    prev_x = x_start_d
    prev_z = z_start
    for i in range(n_segments):
        # X strictly decreases (monotonic)
        x_step = draw(floats(min_value=0.05, max_value=0.5,
                             allow_nan=False, allow_infinity=False))
        x_step = round(x_step, 4)
        new_x = round(prev_x - x_step, 4)
        # Z strictly decreases
        z_step = draw(floats(min_value=0.2, max_value=1.0,
                             allow_nan=False, allow_infinity=False))
        z_step = round(z_step, 4)
        new_z = round(prev_z - z_step, 4)

        assume(new_x > 0.3)  # Keep X positive and reasonable
        finish_moves.append(("LINE", new_x, new_z))
        prev_x = new_x
        prev_z = new_z

    # Generate X levels between final X and x_start_d
    final_x = finish_moves[-1][1]
    assume(x_start_d - final_x > 0.2)

    n_levels = draw(integers(min_value=2, max_value=5))
    x_levels = []
    for _ in range(n_levels):
        frac = draw(floats(min_value=0.1, max_value=0.9,
                           allow_nan=False, allow_infinity=False))
        level = round(final_x + (x_start_d - final_x) * frac, 4)
        x_levels.append(level)

    x_levels = sorted(set(x_levels), reverse=True)
    assume(len(x_levels) >= 2)

    return {
        "finish_moves": finish_moves,
        "x_start_d": x_start_d,
        "z_start": z_start,
        "x_levels": x_levels,
        "fin_allowance": fin_allowance,
    }


@composite
def non_vertical_arc_od_profile(draw):
    """Generate a random non-vertical arc OD profile.

    The arc endpoints differ in X by more than 0.01" (non-vertical).
    This ensures the existing X-range check in build_z_interval_chart
    already works correctly for these arcs.
    """
    x_start_d = draw(floats(min_value=2.0, max_value=3.5,
                            allow_nan=False, allow_infinity=False))
    x_start_d = round(x_start_d, 4)

    z_start = 0.0
    fin_allowance = draw(floats(min_value=0.002, max_value=0.010,
                                allow_nan=False, allow_infinity=False))
    fin_allowance = round(fin_allowance, 4)

    # Arc endpoint: X must differ from start by > 0.01"
    x_drop = draw(floats(min_value=0.2, max_value=0.8,
                         allow_nan=False, allow_infinity=False))
    x_drop = round(x_drop, 4)
    arc_end_x = round(x_start_d - x_drop, 4)
    assume(arc_end_x > 0.5)

    # Z drop for the arc
    z_drop = draw(floats(min_value=0.3, max_value=1.0,
                         allow_nan=False, allow_infinity=False))
    z_drop = round(z_drop, 4)
    arc_end_z = round(z_start - z_drop, 4)

    # Radius must be >= chord/2 for a valid arc
    dx = arc_end_x - x_start_d
    dz = arc_end_z - z_start
    chord = math.sqrt(dx * dx + dz * dz)
    min_radius = chord / 2.0 + 0.01

    radius = draw(floats(min_value=min_radius, max_value=min_radius + 0.5,
                         allow_nan=False, allow_infinity=False))
    radius = round(radius, 4)

    # Choose CW or CCW (negative radius = CCW/G03)
    sign = draw(sampled_from([-1, 1]))
    signed_radius = radius * sign

    # Build profile: optional leading LINE, then ARC, then trailing LINE
    finish_moves = []

    # Leading line segment (face cut)
    lead_z = draw(floats(min_value=0.1, max_value=0.3,
                         allow_nan=False, allow_infinity=False))
    lead_z = round(lead_z, 4)
    finish_moves.append(("LINE", x_start_d, -lead_z))

    # The arc segment
    finish_moves.append(("ARC", arc_end_x, arc_end_z - lead_z, signed_radius))

    # Trailing line
    trail_z = draw(floats(min_value=0.2, max_value=0.5,
                          allow_nan=False, allow_infinity=False))
    trail_z = round(trail_z, 4)
    finish_moves.append(("LINE", arc_end_x, arc_end_z - lead_z - trail_z))

    # X levels between arc_end_x and x_start_d (within the arc's X range)
    assume(x_start_d - arc_end_x > 0.1)
    n_levels = draw(integers(min_value=2, max_value=4))
    x_levels = []
    for _ in range(n_levels):
        frac = draw(floats(min_value=0.1, max_value=0.9,
                           allow_nan=False, allow_infinity=False))
        level = round(arc_end_x + (x_start_d - arc_end_x) * frac, 4)
        x_levels.append(level)

    x_levels = sorted(set(x_levels), reverse=True)
    assume(len(x_levels) >= 2)

    return {
        "finish_moves": finish_moves,
        "x_start_d": x_start_d,
        "z_start": z_start,
        "x_levels": x_levels,
        "fin_allowance": fin_allowance,
    }


@composite
def peak_od_profile(draw):
    """Generate a random OD profile with a peak (X increases beyond stock).

    A peak occurs when the profile X increases beyond the starting stock
    diameter — like a boss or shoulder that sticks out. The has_peaks
    detector should catch this.
    """
    x_start_d = draw(floats(min_value=2.0, max_value=3.0,
                            allow_nan=False, allow_infinity=False))
    x_start_d = round(x_start_d, 4)

    z_start = 0.0
    fin_allowance = draw(floats(min_value=0.002, max_value=0.010,
                                allow_nan=False, allow_infinity=False))
    fin_allowance = round(fin_allowance, 4)

    # First segment: face cut at stock diameter
    z1 = draw(floats(min_value=0.2, max_value=0.5,
                     allow_nan=False, allow_infinity=False))
    z1 = round(z1, 4)
    finish_moves = [("LINE", x_start_d, -z1)]

    # Peak: X increases beyond stock (boss)
    peak_rise = draw(floats(min_value=0.1, max_value=0.5,
                            allow_nan=False, allow_infinity=False))
    peak_rise = round(peak_rise, 4)
    peak_x = round(x_start_d + peak_rise, 4)
    z2 = draw(floats(min_value=0.2, max_value=0.5,
                     allow_nan=False, allow_infinity=False))
    z2 = round(z2, 4)
    finish_moves.append(("LINE", peak_x, -(z1 + z2)))

    # Return to stock or below
    z3 = draw(floats(min_value=0.2, max_value=0.5,
                     allow_nan=False, allow_infinity=False))
    z3 = round(z3, 4)
    finish_moves.append(("LINE", x_start_d, -(z1 + z2 + z3)))

    # Final segment below stock
    x_final_drop = draw(floats(min_value=0.1, max_value=0.5,
                               allow_nan=False, allow_infinity=False))
    x_final_drop = round(x_final_drop, 4)
    final_x = round(x_start_d - x_final_drop, 4)
    assume(final_x > 0.5)
    z4 = draw(floats(min_value=0.3, max_value=0.8,
                     allow_nan=False, allow_infinity=False))
    z4 = round(z4, 4)
    finish_moves.append(("LINE", final_x, -(z1 + z2 + z3 + z4)))

    # X levels below stock diameter (where material exists after the peak)
    n_levels = draw(integers(min_value=2, max_value=4))
    x_levels = []
    for _ in range(n_levels):
        frac = draw(floats(min_value=0.1, max_value=0.9,
                           allow_nan=False, allow_infinity=False))
        level = round(final_x + (x_start_d - final_x) * frac, 4)
        x_levels.append(level)

    x_levels = sorted(set(x_levels), reverse=True)
    assume(len(x_levels) >= 2)

    return {
        "finish_moves": finish_moves,
        "x_start_d": x_start_d,
        "z_start": z_start,
        "x_levels": x_levels,
        "fin_allowance": fin_allowance,
    }


@composite
def degenerate_arc_profile(draw):
    """Generate a profile with a degenerate arc (R < chord/2 or zero-length chord).

    Degenerate arcs should fall back to linear interpolation in _linearize_arc.
    For build_z_limit_chart, the degenerate check uses offset coordinates,
    so we ensure R is very small relative to chord to guarantee degenerate
    behavior in both functions.

    We use R < chord/4 to ensure the arc remains degenerate even after
    the fin_allowance offset changes the effective chord slightly.
    """
    x_start_d = draw(floats(min_value=2.0, max_value=3.5,
                            allow_nan=False, allow_infinity=False))
    x_start_d = round(x_start_d, 4)

    z_start = 0.0
    fin_allowance = draw(floats(min_value=0.002, max_value=0.005,
                                allow_nan=False, allow_infinity=False))
    fin_allowance = round(fin_allowance, 4)

    # Arc endpoint — use large X drop and Z drop to ensure large chord
    x_drop = draw(floats(min_value=0.4, max_value=0.8,
                         allow_nan=False, allow_infinity=False))
    x_drop = round(x_drop, 4)
    arc_end_x = round(x_start_d - x_drop, 4)
    assume(arc_end_x > 0.5)

    z_drop = draw(floats(min_value=0.4, max_value=1.0,
                         allow_nan=False, allow_infinity=False))
    z_drop = round(z_drop, 4)
    arc_end_z = round(z_start - z_drop, 4)

    # Compute chord and make R very small (< chord/4) to ensure degenerate
    # even after offset changes the effective chord
    dx = arc_end_x - x_start_d
    dz = arc_end_z - z_start
    chord = math.sqrt(dx * dx + dz * dz)
    # R must be much less than chord/2 to remain degenerate after offset
    max_r = chord / 4.0
    assume(max_r > 0.02)

    radius = draw(floats(min_value=0.01, max_value=max_r,
                         allow_nan=False, allow_infinity=False))
    radius = round(radius, 4)

    sign = draw(sampled_from([-1, 1]))
    signed_radius = radius * sign

    # Leading line (face cut at stock diameter)
    lead_z = draw(floats(min_value=0.1, max_value=0.2,
                         allow_nan=False, allow_infinity=False))
    lead_z = round(lead_z, 4)

    finish_moves_arc = [
        ("LINE", x_start_d, -lead_z),
        ("ARC", arc_end_x, arc_end_z - lead_z, signed_radius),
        ("LINE", arc_end_x, arc_end_z - lead_z - 0.3),
    ]

    # Equivalent LINE profile (for comparison)
    finish_moves_line = [
        ("LINE", x_start_d, -lead_z),
        ("LINE", arc_end_x, arc_end_z - lead_z),
        ("LINE", arc_end_x, arc_end_z - lead_z - 0.3),
    ]

    # X levels between arc_end_x and x_start_d
    assume(x_start_d - arc_end_x > 0.2)
    n_levels = draw(integers(min_value=2, max_value=4))
    x_levels = []
    for _ in range(n_levels):
        frac = draw(floats(min_value=0.15, max_value=0.85,
                           allow_nan=False, allow_infinity=False))
        level = round(arc_end_x + (x_start_d - arc_end_x) * frac, 4)
        x_levels.append(level)

    x_levels = sorted(set(x_levels), reverse=True)
    assume(len(x_levels) >= 2)

    return {
        "finish_moves_arc": finish_moves_arc,
        "finish_moves_line": finish_moves_line,
        "x_start_d": x_start_d,
        "z_start": z_start,
        "x_levels": x_levels,
        "fin_allowance": fin_allowance,
        "arc_end_x": arc_end_x,
        "signed_radius": signed_radius,
        "chord": chord,
    }


# ==================================================================
# Property 2a: Straight-line monotonically-decreasing OD profiles
# ==================================================================

@settings(max_examples=15, deadline=None,
          suppress_health_check=[HealthCheck.filter_too_much, HealthCheck.too_slow])
@given(profile=straight_line_decreasing_od_profile())
def test_pbt_straight_line_od_has_peaks_false(profile):
    """PBT 2a: Straight-line monotonically-decreasing OD profiles → has_peaks=False.

    **Validates: Requirements 3.1, 3.4**

    For all randomly-generated straight-line monotonically-decreasing OD
    profiles, has_peaks must remain False and build_z_limit_chart must
    produce correct Z limits (monotonically decreasing as X decreases).
    """
    finish_moves = profile["finish_moves"]
    x_start_d = profile["x_start_d"]
    z_start = profile["z_start"]
    x_levels = profile["x_levels"]
    fin_allowance = profile["fin_allowance"]

    # Property: has_peaks must be False for monotonically-decreasing profiles
    has_peaks = _detect_has_peaks(finish_moves, x_start_d, z_start, 1, fin_allowance, "OD")
    assert has_peaks is False, (
        f"has_peaks returned True for a monotonically-decreasing straight-line "
        f"OD profile. finish_moves={finish_moves}, x_start_d={x_start_d}"
    )

    # Property: build_z_limit_chart produces results for all X levels
    chart = build_z_limit_chart(finish_moves, x_start_d, z_start,
                                x_levels, fin_allowance, "OD")

    # All X levels should have Z limits (profile spans the full range)
    for xl in x_levels:
        assert xl in chart, (
            f"build_z_limit_chart missing X level {xl}. "
            f"Chart keys: {list(chart.keys())}"
        )

    # Property: Z limits are monotonically decreasing as X decreases
    # (deeper cuts go further into the part)
    sorted_levels = sorted(x_levels, reverse=True)
    for i in range(len(sorted_levels) - 1):
        z_higher = chart[sorted_levels[i]]
        z_lower = chart[sorted_levels[i + 1]]
        assert z_higher >= z_lower - 0.001, (
            f"Z limits not monotonic: X={sorted_levels[i]:.4f} → Z={z_higher:.4f}, "
            f"X={sorted_levels[i+1]:.4f} → Z={z_lower:.4f}. "
            f"Smaller X should have more negative Z limit."
        )

    # Property: All Z limits are between z_start and the back wall
    for xl in x_levels:
        z_limit = chart[xl]
        assert z_limit <= z_start + 0.001, (
            f"Z limit {z_limit:.4f} exceeds z_start={z_start} for X={xl:.4f}"
        )


# ==================================================================
# Property 2b: Non-vertical arc profiles
# ==================================================================

@settings(max_examples=15, deadline=None,
          suppress_health_check=[HealthCheck.filter_too_much, HealthCheck.too_slow])
@given(profile=non_vertical_arc_od_profile())
def test_pbt_non_vertical_arc_interval_chart(profile):
    """PBT 2b: Non-vertical arc profiles produce correct intervals.

    **Validates: Requirements 3.2, 3.5**

    For all randomly-generated non-vertical arc profiles (endpoint X
    difference > 0.01"), build_z_interval_chart produces non-empty
    intervals for X levels within the arc's X range, and intervals
    are geometrically consistent (deeper X levels have intervals that
    start further into the part).
    """
    finish_moves = profile["finish_moves"]
    x_start_d = profile["x_start_d"]
    z_start = profile["z_start"]
    x_levels = profile["x_levels"]
    fin_allowance = profile["fin_allowance"]

    chart = build_z_interval_chart(finish_moves, x_start_d, z_start,
                                   x_levels, fin_allowance, "OD")

    # Property: At least some X levels should produce intervals
    # (the profile spans the X range we're querying)
    levels_with_intervals = [xl for xl in x_levels if xl in chart and chart[xl]]
    assert len(levels_with_intervals) > 0, (
        f"build_z_interval_chart returned no intervals for any X level. "
        f"Profile: x_start={x_start_d}, moves={finish_moves}, "
        f"x_levels={x_levels}"
    )

    # Property: For each X level with intervals, intervals are well-formed
    for xl in levels_with_intervals:
        intervals = chart[xl]
        for z_begin, z_end in intervals:
            # z_begin should be closer to z_start (more positive)
            # z_end should be further from z_start (more negative)
            assert z_begin >= z_end - 0.001, (
                f"Malformed interval at X={xl:.4f}: z_begin={z_begin:.4f} < "
                f"z_end={z_end:.4f}. z_begin should be >= z_end."
            )

    # Property: Intervals don't extend beyond z_start
    for xl in levels_with_intervals:
        intervals = chart[xl]
        for z_begin, z_end in intervals:
            assert z_begin <= z_start + fin_allowance + 0.01, (
                f"Interval start Z={z_begin:.4f} exceeds z_start={z_start} "
                f"at X={xl:.4f}"
            )


# ==================================================================
# Property 2c: Peak profiles (X increases beyond stock)
# ==================================================================

@settings(max_examples=15, deadline=None,
          suppress_health_check=[HealthCheck.filter_too_much, HealthCheck.too_slow])
@given(profile=peak_od_profile())
def test_pbt_peak_profile_has_peaks_true(profile):
    """PBT 2c: Peak profiles (X increases beyond stock) → has_peaks=True.

    **Validates: Requirements 3.3**

    For all randomly-generated peak profiles where X increases beyond
    the stock diameter, has_peaks must remain True and
    build_z_interval_chart must produce intervals that correctly skip
    the peak zone (no intervals where the profile sticks out beyond
    the cutting level).
    """
    finish_moves = profile["finish_moves"]
    x_start_d = profile["x_start_d"]
    z_start = profile["z_start"]
    x_levels = profile["x_levels"]
    fin_allowance = profile["fin_allowance"]

    # Property: has_peaks must be True for profiles with peaks
    has_peaks = _detect_has_peaks(finish_moves, x_start_d, z_start, 1, fin_allowance, "OD")
    assert has_peaks is True, (
        f"has_peaks returned False for a profile with a peak "
        f"(X increases beyond stock). finish_moves={finish_moves}, "
        f"x_start_d={x_start_d}"
    )

    # Property: build_z_interval_chart produces intervals
    chart = build_z_interval_chart(finish_moves, x_start_d, z_start,
                                   x_levels, fin_allowance, "OD")

    # At least some X levels should have intervals (material exists
    # after the peak zone)
    levels_with_intervals = [xl for xl in x_levels if xl in chart and chart[xl]]
    assert len(levels_with_intervals) > 0, (
        f"build_z_interval_chart returned no intervals for peak profile. "
        f"x_levels={x_levels}, chart={chart}"
    )

    # Property: Intervals are well-formed
    for xl in levels_with_intervals:
        intervals = chart[xl]
        for z_begin, z_end in intervals:
            assert z_begin >= z_end - 0.001, (
                f"Malformed interval at X={xl:.4f}: z_begin={z_begin:.4f} < "
                f"z_end={z_end:.4f}"
            )


# ==================================================================
# Property 2d: Degenerate arcs fall back to linear interpolation
# ==================================================================

@settings(max_examples=15, deadline=None,
          suppress_health_check=[HealthCheck.filter_too_much, HealthCheck.too_slow])
@given(profile=degenerate_arc_profile())
def test_pbt_degenerate_arc_fallback_to_linear(profile):
    """PBT 2d: Degenerate arcs fall back to linear interpolation.

    **Validates: Requirements 3.6**

    For all degenerate arcs (R < chord/2 or zero-length chord),
    _linearize_arc returns just the endpoint (fallback to linear),
    and build_z_limit_chart produces identical results to an equivalent
    LINE segment between the same endpoints.
    """
    finish_moves_arc = profile["finish_moves_arc"]
    finish_moves_line = profile["finish_moves_line"]
    x_start_d = profile["x_start_d"]
    z_start = profile["z_start"]
    x_levels = profile["x_levels"]
    fin_allowance = profile["fin_allowance"]
    arc_end_x = profile["arc_end_x"]
    signed_radius = profile["signed_radius"]

    # Property: _linearize_arc returns just the endpoint for degenerate arcs
    # (The arc in finish_moves_arc[1] goes from the end of finish_moves_arc[0]
    # to arc_end_x)
    prev_x = finish_moves_arc[0][1]  # end X of leading LINE
    prev_z = finish_moves_arc[0][2]  # end Z of leading LINE
    end_x = finish_moves_arc[1][1]
    end_z = finish_moves_arc[1][2]
    radius = finish_moves_arc[1][3]

    pts = _linearize_arc(prev_x, prev_z, end_x, end_z, radius)
    assert len(pts) == 1, (
        f"_linearize_arc returned {len(pts)} points for degenerate arc "
        f"(R={abs(radius):.4f}, chord={profile['chord']:.4f}, "
        f"chord/2={profile['chord']/2:.4f}). Expected 1 point (fallback)."
    )
    assert pts[0] == (end_x, end_z), (
        f"_linearize_arc fallback point {pts[0]} != endpoint ({end_x}, {end_z})"
    )

    # Property: build_z_limit_chart produces identical results for
    # degenerate arc vs equivalent LINE
    chart_arc = build_z_limit_chart(finish_moves_arc, x_start_d, z_start,
                                    x_levels, fin_allowance, "OD")
    chart_line = build_z_limit_chart(finish_moves_line, x_start_d, z_start,
                                     x_levels, fin_allowance, "OD")

    # Both charts should have the same keys
    assert set(chart_arc.keys()) == set(chart_line.keys()), (
        f"Degenerate arc chart keys {set(chart_arc.keys())} != "
        f"line chart keys {set(chart_line.keys())}"
    )

    # Z limits should be identical (within floating point tolerance)
    for xl in chart_arc:
        z_arc = chart_arc[xl]
        z_line = chart_line[xl]
        assert abs(z_arc - z_line) < 0.001, (
            f"Degenerate arc Z limit differs from LINE at X={xl:.4f}: "
            f"arc={z_arc:.6f}, line={z_line:.6f}, diff={abs(z_arc-z_line):.6f}. "
            f"Degenerate arcs should fall back to linear interpolation."
        )
