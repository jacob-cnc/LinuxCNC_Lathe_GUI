"""Functional tests for LimitEnforcer module.

Verifies the LimitEnforcer works correctly with LimitManager for:
- No enforcement when not homed
- No violation when position is within limits and homed
- Violation detected when position violates z_minus and homed
- Violation detected when position violates z_plus and homed
"""

import os
import tempfile
import pytest

from gui.limit_manager import LimitManager
from gui.limit_enforcer import LimitEnforcer


@pytest.fixture
def limit_manager_with_tool1():
    """Create a LimitManager with tool 1 limits: z_minus=-1.0, z_plus=6.0."""
    with tempfile.TemporaryDirectory() as tmpdir:
        mgr = LimitManager(tmpdir)
        mgr.set_limit(1, z_minus=-1.0, z_plus=6.0)
        yield mgr


@pytest.fixture
def enforcer(limit_manager_with_tool1):
    """Create a LimitEnforcer with cmd=None (offline mode)."""
    return LimitEnforcer(limit_manager_with_tool1, cmd=None)


class TestLimitEnforcerNotHomed:
    """Verify check() returns None when not homed."""

    def test_no_enforcement_when_not_homed_within_limits(self, enforcer):
        result = enforcer.check(z_machine=2.0, tool_num=1, is_homed=False, is_program_running=False)
        assert result is None

    def test_no_enforcement_when_not_homed_at_z_minus(self, enforcer):
        result = enforcer.check(z_machine=-2.0, tool_num=1, is_homed=False, is_program_running=False)
        assert result is None

    def test_no_enforcement_when_not_homed_at_z_plus(self, enforcer):
        result = enforcer.check(z_machine=7.0, tool_num=1, is_homed=False, is_program_running=False)
        assert result is None


class TestLimitEnforcerWithinLimits:
    """Verify check() returns None when position is within limits and homed."""

    def test_no_violation_at_midpoint(self, enforcer):
        result = enforcer.check(z_machine=2.5, tool_num=1, is_homed=True, is_program_running=False)
        assert result is None

    def test_no_violation_just_inside_z_minus(self, enforcer):
        result = enforcer.check(z_machine=-0.5, tool_num=1, is_homed=True, is_program_running=False)
        assert result is None

    def test_no_violation_just_inside_z_plus(self, enforcer):
        result = enforcer.check(z_machine=5.5, tool_num=1, is_homed=True, is_program_running=False)
        assert result is None

    def test_no_violation_at_zero(self, enforcer):
        result = enforcer.check(z_machine=0.0, tool_num=1, is_homed=True, is_program_running=False)
        assert result is None


class TestLimitEnforcerZMinusViolation:
    """Verify check() returns a message when position violates z_minus and homed."""

    def test_violation_at_z_minus_boundary(self, enforcer):
        result = enforcer.check(z_machine=-1.0, tool_num=1, is_homed=True, is_program_running=False)
        assert result is not None
        assert "Z-" in result
        assert "T1" in result

    def test_violation_below_z_minus(self, enforcer):
        result = enforcer.check(z_machine=-2.0, tool_num=1, is_homed=True, is_program_running=False)
        assert result is not None
        assert "Z-" in result
        assert "T1" in result

    def test_violation_message_format_jog(self, enforcer):
        result = enforcer.check(z_machine=-1.5, tool_num=1, is_homed=True, is_program_running=False)
        assert result is not None
        assert "Z- limit reached" in result
        assert "T1" in result
        # Should NOT contain "program halted" for jog mode
        assert "program halted" not in result


class TestLimitEnforcerZPlusViolation:
    """Verify check() returns a message when position violates z_plus and homed."""

    def test_violation_at_z_plus_boundary(self, enforcer):
        result = enforcer.check(z_machine=6.0, tool_num=1, is_homed=True, is_program_running=False)
        assert result is not None
        assert "Z+" in result
        assert "T1" in result

    def test_violation_above_z_plus(self, enforcer):
        result = enforcer.check(z_machine=8.0, tool_num=1, is_homed=True, is_program_running=False)
        assert result is not None
        assert "Z+" in result
        assert "T1" in result

    def test_violation_message_format_jog(self, enforcer):
        result = enforcer.check(z_machine=7.0, tool_num=1, is_homed=True, is_program_running=False)
        assert result is not None
        assert "Z+ limit reached" in result
        assert "T1" in result
        assert "program halted" not in result

    def test_violation_message_format_program(self, enforcer):
        result = enforcer.check(z_machine=7.0, tool_num=1, is_homed=True, is_program_running=True)
        assert result is not None
        assert "Z+ limit reached" in result
        assert "T1" in result
        assert "program halted" in result


class TestLimitEnforcerRepeatedViolation:
    """Verify repeated violations don't produce duplicate messages."""

    def test_same_violation_returns_none_second_time(self, enforcer):
        # First violation should return a message
        result1 = enforcer.check(z_machine=-1.5, tool_num=1, is_homed=True, is_program_running=False)
        assert result1 is not None

        # Same violation again should return None (avoid repeated messages)
        result2 = enforcer.check(z_machine=-1.5, tool_num=1, is_homed=True, is_program_running=False)
        assert result2 is None

    def test_different_direction_violation_returns_message(self, enforcer):
        # First violation Z-
        result1 = enforcer.check(z_machine=-1.5, tool_num=1, is_homed=True, is_program_running=False)
        assert result1 is not None
        assert "Z-" in result1

        # Clear by moving within limits
        enforcer.check(z_machine=2.0, tool_num=1, is_homed=True, is_program_running=False)

        # New violation Z+
        result2 = enforcer.check(z_machine=7.0, tool_num=1, is_homed=True, is_program_running=False)
        assert result2 is not None
        assert "Z+" in result2


class TestLimitEnforcerUnconfiguredTool:
    """Verify no enforcement for tools without configured limits."""

    def test_unconfigured_tool_no_violation(self, enforcer):
        # Tool 99 has no limits configured
        result = enforcer.check(z_machine=-100.0, tool_num=99, is_homed=True, is_program_running=False)
        assert result is None

    def test_unconfigured_tool_any_position(self, enforcer):
        result = enforcer.check(z_machine=1000.0, tool_num=99, is_homed=True, is_program_running=False)
        assert result is None


class TestLimitEnforcerDisabled:
    """Verify enforcement can be disabled."""

    def test_disabled_enforcer_no_violation(self, enforcer):
        enforcer.set_enabled(False)
        result = enforcer.check(z_machine=-5.0, tool_num=1, is_homed=True, is_program_running=False)
        assert result is None

    def test_re_enabled_enforcer_detects_violation(self, enforcer):
        enforcer.set_enabled(False)
        enforcer.check(z_machine=-5.0, tool_num=1, is_homed=True, is_program_running=False)

        enforcer.set_enabled(True)
        result = enforcer.check(z_machine=-5.0, tool_num=1, is_homed=True, is_program_running=False)
        assert result is not None
