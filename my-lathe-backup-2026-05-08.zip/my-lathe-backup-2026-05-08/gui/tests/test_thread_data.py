# Feature: threading-conv-block, Property 1: Database entry completeness
"""
Property-based test verifying that every entry in THREAD_DATABASE has
complete, well-formed data: non-None numeric dimensions, a valid pitch
field, and at least one fit class with properly structured tolerance tuples.

**Validates: Requirements 1.4, 1.5**
"""

import sys
import os

# Ensure the gui package is importable
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from hypothesis import given, settings
from hypothesis.strategies import sampled_from

from thread_data import THREAD_DATABASE


def _all_entries():
    """Flatten THREAD_DATABASE into a single list of entries."""
    entries = []
    for family_entries in THREAD_DATABASE.values():
        entries.extend(family_entries)
    return entries


_ALL_ENTRIES = _all_entries()

# Required numeric dimension fields that must be non-None floats/ints
_REQUIRED_NUMERIC = [
    "major_d_basic",
    "pitch_d_basic",
    "minor_d_basic",
    "thread_angle",
    "compound_angle",
]


@settings(max_examples=max(len(_ALL_ENTRIES), 100))
@given(entry=sampled_from(_ALL_ENTRIES))
def test_database_entry_completeness(entry):
    """Every THREAD_DATABASE entry has complete, well-formed data.

    Checks:
    - major_d_basic, pitch_d_basic, minor_d_basic, thread_angle,
      compound_angle are non-None numeric values
    - Either tpi or pitch_mm is non-None
    - tolerances dict has at least one fit class
    - Each fit class has major_d, pitch_d, minor_d keys with tuple values
    """
    # 1. Required numeric fields are present and non-None
    for field in _REQUIRED_NUMERIC:
        val = entry.get(field)
        assert val is not None, (
            f"Entry {entry['key']!r}: {field} is None"
        )
        assert isinstance(val, (int, float)), (
            f"Entry {entry['key']!r}: {field} is {type(val).__name__}, "
            f"expected int or float"
        )

    # 2. Either tpi or pitch_mm must be non-None
    assert entry.get("tpi") is not None or entry.get("pitch_mm") is not None, (
        f"Entry {entry['key']!r}: both tpi and pitch_mm are None"
    )

    # 3. tolerances dict exists and has at least one fit class
    tolerances = entry.get("tolerances")
    assert isinstance(tolerances, dict), (
        f"Entry {entry['key']!r}: tolerances is not a dict"
    )
    assert len(tolerances) >= 1, (
        f"Entry {entry['key']!r}: tolerances dict is empty"
    )

    # 4. Each fit class has major_d, pitch_d, minor_d as tuples
    for fit_class, dims in tolerances.items():
        for dim_key in ("major_d", "pitch_d", "minor_d"):
            assert dim_key in dims, (
                f"Entry {entry['key']!r}, class {fit_class!r}: "
                f"missing {dim_key}"
            )
            val = dims[dim_key]
            assert isinstance(val, tuple), (
                f"Entry {entry['key']!r}, class {fit_class!r}: "
                f"{dim_key} is {type(val).__name__}, expected tuple"
            )
            assert len(val) == 2, (
                f"Entry {entry['key']!r}, class {fit_class!r}: "
                f"{dim_key} tuple has {len(val)} elements, expected 2"
            )


# Feature: threading-conv-block, Property 4: Tolerance target computation
"""
Property-based test verifying that compute_tolerance_target returns
dimension values consistent with the tolerance band and the selected
target (MMC / LMC / Mid) for both External and Internal thread types.

**Validates: Requirements 3.1, 3.3, 3.4**
"""

from thread_data import compute_tolerance_target, FAMILY_FIT_CLASSES


def _entries_with_fit():
    """Build (entry, fit_class, thread_type) combos from the database."""
    combos = []
    for entry in _ALL_ENTRIES:
        family = entry["family"]
        fam_classes = FAMILY_FIT_CLASSES.get(family, {})
        for ttype, classes in fam_classes.items():
            for fc in classes:
                if fc in entry["tolerances"]:
                    combos.append((entry, fc, ttype))
    return combos


_ENTRY_FIT_COMBOS = _entries_with_fit()
_TARGETS = ["MMC", "LMC", "Mid"]


@settings(max_examples=max(len(_ENTRY_FIT_COMBOS) * 3, 100))
@given(
    combo=sampled_from(_ENTRY_FIT_COMBOS),
    target=sampled_from(_TARGETS),
)
def test_tolerance_target_computation(combo, target):
    """compute_tolerance_target returns correct values for every
    entry / fit-class / target / thread-type combination.

    For each dimension (major_d, pitch_d, minor_d):
      - If the tolerance band has non-None lo and hi:
          MMC External  → hi  (max of band)
          LMC External  → lo  (min of band)
          Mid           → (lo + hi) / 2.0
          MMC Internal  → lo  (min of band)
          LMC Internal  → hi  (max of band)
      - If the tolerance band has None values → basic dimension
    """
    entry, fit_class, thread_type = combo
    result = compute_tolerance_target(entry, fit_class, target, thread_type)

    tol = entry["tolerances"].get(fit_class, {})

    for dim in ("major_d", "pitch_d", "minor_d"):
        band = tol.get(dim, (None, None))
        lo, hi = band
        val = result[dim]

        if lo is None or hi is None:
            # Should fall back to basic dimension
            expected = entry[f"{dim}_basic"]
            assert val == expected, (
                f"{entry['key']!r} {fit_class} {target} {thread_type}: "
                f"{dim} = {val}, expected basic {expected} (band has None)"
            )
        else:
            # Value must be within the tolerance band
            assert lo <= val <= hi, (
                f"{entry['key']!r} {fit_class} {target} {thread_type}: "
                f"{dim} = {val} outside band ({lo}, {hi})"
            )

            # Check exact target mapping
            if target == "MMC":
                if thread_type == "External":
                    expected = hi
                else:
                    expected = lo
            elif target == "LMC":
                if thread_type == "External":
                    expected = lo
                else:
                    expected = hi
            else:  # Mid
                expected = (lo + hi) / 2.0

            assert val == expected, (
                f"{entry['key']!r} {fit_class} {target} {thread_type}: "
                f"{dim} = {val}, expected {expected}"
            )
