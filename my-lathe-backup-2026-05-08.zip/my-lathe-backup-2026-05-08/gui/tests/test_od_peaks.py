"""
Tests for OD roughing with peaks and valleys.

Verifies that build_z_interval_chart() in OD mode correctly identifies
material zones and avoids plunging through peaks where the profile
sticks out past the cutting diameter.
"""

import sys
import os
import math

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from conv_profile import build_z_interval_chart, build_z_limit_chart


def _build_cleanup_segments(finish_moves, x_start_d, z_start, fin_allowance, mode="OD"):
    """Build cleanup boundary segments the same way build_z_interval_chart does."""
    offset_d = fin_allowance * 2
    if mode == "OD":
        cp_start_x = x_start_d + offset_d
    else:
        cp_start_x = x_start_d - offset_d

    segments = []
    prev_x, prev_z = cp_start_x, z_start
    for mv in finish_moves:
        if mv[0] == "LINE":
            ox = mv[1] + offset_d if mode == "OD" else mv[1] - offset_d
            oz = mv[2] + fin_allowance
            segments.append(("LINE", prev_x, prev_z, ox, oz))
            prev_x, prev_z = ox, oz
        elif mv[0] == "ARC":
            ox = mv[1] + offset_d if mode == "OD" else mv[1] - offset_d
            oz = mv[2] + fin_allowance
            segments.append(("ARC", prev_x, prev_z, ox, oz, mv[3]))
            prev_x, prev_z = ox, oz
    return segments


def _interpolate_boundary_x_at_z(segments, z_query):
    """Find all boundary X values at a given Z (handles multi-valued profiles)."""
    results = []
    for seg in segments:
        if seg[0] != "LINE":
            continue
        x1, z1, x2, z2 = seg[1], seg[2], seg[3], seg[4]
        z_lo = min(z1, z2)
        z_hi = max(z1, z2)
        if z_lo - 1e-9 <= z_query <= z_hi + 1e-9:
            if abs(z2 - z1) < 1e-9:
                results.append((x1 + x2) / 2.0)
            else:
                t = (z_query - z1) / (z2 - z1)
                t = max(0.0, min(1.0, t))
                results.append(x1 + t * (x2 - x1))
    return results


# ------------------------------------------------------------------
# Test 1: Profile with peak — OD intervals avoid the peak zone
# ------------------------------------------------------------------

def test_od_peak_profile_intervals():
    """OD profile with peak: intervals must not include the peak zone.

    Profile (from user's G-code):
      X=0.0 Z=0 → X=0.5 Z=0 → X=0.5 Z=-0.5 → X=0.75 Z=-0.75 (peak)
      → X=0.5 Z=-1.0 → X=0.5 Z=-1.5 → X=0.375 Z=-1.75 → X=0.375 Z=-2.0
      → X=0.5 Z=-2.5

    At cutting X=0.6:
    - Material exists from Z=0 to Z≈-0.6 (profile < 0.6, stock above)
    - NO material from Z≈-0.6 to Z≈-0.85 (peak zone, profile > 0.6)
    - Material exists from Z≈-0.85 to Z=-2.5 (profile < 0.6 again)

    The interval chart should return TWO intervals, skipping the peak.
    """
    finish_moves = [
        ("LINE", 0.5, 0.0),      # face to X=0.5
        ("LINE", 0.5, -0.5),     # straight OD
        ("LINE", 0.75, -0.75),   # taper out (peak)
        ("LINE", 0.5, -1.0),     # taper back in
        ("LINE", 0.5, -1.5),     # straight OD
        ("LINE", 0.375, -1.75),  # taper in
        ("LINE", 0.375, -2.0),   # straight OD
        ("LINE", 0.5, -2.5),     # taper out
    ]
    x_start_d = 0.0
    z_start = 0.1  # slightly above Z=0 for approach
    fin_allowance = 0.001  # small for clarity
    cutting_x = 0.6
    x_levels = [cutting_x]

    chart = build_z_interval_chart(finish_moves, x_start_d, z_start,
                                   x_levels, fin_allowance, "OD")

    assert cutting_x in chart, (
        f"No intervals returned for X={cutting_x}. Chart: {chart}"
    )

    intervals = chart[cutting_x]

    # Should have at least 2 intervals (before peak and after peak)
    assert len(intervals) >= 2, (
        f"Expected at least 2 intervals for peak profile at X={cutting_x}, "
        f"got {len(intervals)}: {intervals}. "
        f"The peak at X=0.75 should split the material into separate zones."
    )

    # Verify no interval spans the peak zone
    # The peak is at Z≈-0.75. At X=0.6, the profile crosses 0.6 on the
    # way up (around Z≈-0.6) and on the way down (around Z≈-0.85).
    # No single interval should span from before -0.6 to after -0.85.
    for z_begin, z_end in intervals:
        z_min = min(z_begin, z_end)
        z_max = max(z_begin, z_end)
        # An interval should NOT span from above -0.55 to below -0.9
        # (that would mean it crosses the peak zone)
        if z_max > -0.55 and z_min < -0.9:
            pytest.fail(
                f"Interval [{z_begin:.4f}, {z_end:.4f}] spans the peak zone "
                f"(Z≈-0.6 to Z≈-0.85). Tool would collide with the peak!"
            )


def test_od_peak_profile_material_correctness():
    """OD peak profile: all points within intervals must have material.

    For OD mode: material exists where boundary_x < cutting_x
    (the profile is inside the tool's cutting path, so stock exists
    between the stock OD and the profile).
    """
    finish_moves = [
        ("LINE", 0.5, 0.0),
        ("LINE", 0.5, -0.5),
        ("LINE", 0.75, -0.75),   # peak
        ("LINE", 0.5, -1.0),
        ("LINE", 0.5, -1.5),
        ("LINE", 0.375, -1.75),
        ("LINE", 0.375, -2.0),
        ("LINE", 0.5, -2.5),
    ]
    x_start_d = 0.0
    z_start = 0.1
    fin_allowance = 0.001
    cutting_x = 0.6
    x_levels = [cutting_x]

    chart = build_z_interval_chart(finish_moves, x_start_d, z_start,
                                   x_levels, fin_allowance, "OD")

    assert cutting_x in chart
    intervals = chart[cutting_x]

    segments = _build_cleanup_segments(finish_moves, x_start_d, z_start,
                                       fin_allowance, "OD")

    # For each interval, verify material exists at sampled points
    for z_begin, z_end in intervals:
        z_min = min(z_begin, z_end)
        z_max = max(z_begin, z_end)
        n_samples = 10

        for i in range(n_samples + 1):
            z_sample = z_min + (z_max - z_min) * i / n_samples
            boundary_xs = _interpolate_boundary_x_at_z(segments, z_sample)
            if not boundary_xs:
                continue  # outside segment range

            # For OD: material exists where boundary < cutting_x
            # At least one boundary segment at this Z should be < cutting_x
            has_material = any(bx < cutting_x + 1e-6 for bx in boundary_xs)
            assert has_material, (
                f"At X={cutting_x}, interval [{z_begin:.4f}, {z_end:.4f}], "
                f"Z={z_sample:.4f}: boundary_x values = {boundary_xs}, "
                f"none are < cutting_x={cutting_x}. No material here!"
            )


def test_od_simple_monotonic_no_intervals_needed():
    """Simple monotonic OD profile: single interval from z_start to z_end.

    Profile: X=0.5 Z=0 → X=0.5 Z=-1.0 (straight cylinder)
    At cutting X=0.6: material exists everywhere (profile 0.5 < 0.6).
    Should return a single interval spanning the full Z range.
    """
    finish_moves = [
        ("LINE", 0.5, -1.0),
    ]
    x_start_d = 0.5
    z_start = 0.1
    fin_allowance = 0.001
    cutting_x = 0.6
    x_levels = [cutting_x]

    chart = build_z_interval_chart(finish_moves, x_start_d, z_start,
                                   x_levels, fin_allowance, "OD")

    assert cutting_x in chart
    intervals = chart[cutting_x]

    # Should be a single interval
    assert len(intervals) == 1, (
        f"Simple monotonic profile should have 1 interval, got {len(intervals)}: {intervals}"
    )

    # The interval should span approximately from z_start to z_end
    z_begin, z_end = intervals[0]
    assert z_begin > -0.1, f"Interval should start near z_start, got {z_begin}"
    assert z_end < -0.9, f"Interval should end near z=-1.0, got {z_end}"


def test_od_peak_multiple_x_levels():
    """OD peak profile: verify multiple X levels produce correct intervals.

    At X levels above the peak (X > 0.75): single interval (peak is below)
    At X levels below the peak (X < 0.75): two intervals (peak splits them)
    """
    finish_moves = [
        ("LINE", 0.5, 0.0),
        ("LINE", 0.5, -0.5),
        ("LINE", 0.75, -0.75),   # peak
        ("LINE", 0.5, -1.0),
        ("LINE", 0.5, -1.5),
    ]
    x_start_d = 0.0
    z_start = 0.1
    fin_allowance = 0.001

    # X=0.8 is above the peak — should have single interval
    # X=0.6 is below the peak — should have two intervals
    x_levels = [0.8, 0.6]

    chart = build_z_interval_chart(finish_moves, x_start_d, z_start,
                                   x_levels, fin_allowance, "OD")

    # X=0.8: above peak, profile is always < 0.8, single interval
    if 0.8 in chart:
        intervals_08 = chart[0.8]
        assert len(intervals_08) == 1, (
            f"At X=0.8 (above peak), expected 1 interval, got {len(intervals_08)}: {intervals_08}"
        )

    # X=0.6: below peak, peak zone has no material, should be 2 intervals
    assert 0.6 in chart, f"No intervals for X=0.6. Chart: {chart}"
    intervals_06 = chart[0.6]
    assert len(intervals_06) >= 2, (
        f"At X=0.6 (below peak), expected >= 2 intervals, got {len(intervals_06)}: {intervals_06}"
    )


def test_od_valley_profile():
    """OD profile with valley: valley creates a zone where profile is smaller.

    Profile: X=0.5 Z=0 → X=0.3 Z=-0.5 (valley) → X=0.5 Z=-1.0
    At cutting X=0.4:
    - Material from Z=0 to crossing (profile goes below 0.4)
    - Then profile < 0.4 in the valley — material exists
    - Then profile goes back above 0.4 — still material
    Actually for OD: material = boundary < cutting_x.
    Profile goes 0.5 → 0.3 → 0.5.
    At X=0.4: boundary starts at 0.5 (> 0.4, no material), crosses to 0.3 (< 0.4, material),
    then crosses back to 0.5 (> 0.4, no material).
    Wait — for OD, x_start_d is the starting profile diameter.
    Let me reconsider with stock_d > profile.

    Actually the profile boundary for OD is offset outward by fin_allowance.
    Let's use a clear case:
    x_start_d = 0.5, profile goes to X=0.3 (valley) then back to X=0.5.
    At cutting X=0.4: boundary starts at ~0.5 (no material since 0.5 > 0.4),
    then goes to ~0.3 (material since 0.3 < 0.4), then back to ~0.5 (no material).
    Should produce 1 interval in the valley zone.
    """
    finish_moves = [
        ("LINE", 0.3, -0.5),   # valley
        ("LINE", 0.5, -1.0),   # back up
    ]
    x_start_d = 0.5
    z_start = 0.1
    fin_allowance = 0.001
    cutting_x = 0.4
    x_levels = [cutting_x]

    chart = build_z_interval_chart(finish_moves, x_start_d, z_start,
                                   x_levels, fin_allowance, "OD")

    assert cutting_x in chart, f"No intervals for X={cutting_x}. Chart: {chart}"
    intervals = chart[cutting_x]

    # Should have exactly 1 interval in the valley zone
    assert len(intervals) == 1, (
        f"Valley profile at X={cutting_x} should have 1 interval, "
        f"got {len(intervals)}: {intervals}"
    )

    # The interval should be in the middle (valley zone)
    z_begin, z_end = intervals[0]
    z_min = min(z_begin, z_end)
    z_max = max(z_begin, z_end)
    # Should be roughly between Z=-0.1 and Z=-0.9
    assert z_max < 0.05, f"Interval start should be below z_start, got {z_max}"
    assert z_min > -0.95, f"Interval end should be above z=-1.0, got {z_min}"
