# Feature: threading-conv-block, Property 12: Block ordering and M0 pauses
"""
Property-based test verifying that combined "Generate All" output contains
each block's G-code in process list order with M0 pauses between blocks.

**Validates: Requirements 7.4, 7.5**
"""

import sys
import os
import re

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from hypothesis import given, settings, assume
from hypothesis.strategies import lists, sampled_from, integers

from PyQt5.QtWidgets import QApplication

_app = None


def _get_app():
    global _app
    if _app is None:
        _app = QApplication.instance() or QApplication(sys.argv)
    return _app


def _make_tab():
    _get_app()
    from conv_profile import ProfileConvTab
    tab = ProfileConvTab()
    # Remove the default profile block
    for blk in list(tab.blocks):
        tab.remove_block(blk)
    return tab


def _add_profile_block(tab):
    """Add a profile block with minimal valid data."""
    tab.add_profile()
    blk = tab.blocks[-1]
    # Set minimal valid profile data
    blk.stock_dia.setText("1.0000")
    blk.x_start.setText("1.0000")
    blk.z_start.setText("0.0000")
    blk.safe_x.setText("2.0000")
    blk.safe_z.setText("1.0000")
    blk.doc.setText("0.020")
    blk.fin_passes.setText("1")
    blk.fin_doc.setText("0.005")
    blk.feed_r.setText("0.010")
    blk.feed_f.setText("0.005")
    blk.retract.setText("0.050")
    blk.rough_tool.setText("1")
    blk.finish_tool.setText("1")
    blk.rpm.setText("1000")
    # Add one segment
    blk.add_segment()
    seg = blk.segments[-1]
    seg.x_end.setText("0.8000")
    seg.z_end.setText("-1.5000")
    return blk


def _add_threading_block(tab):
    """Add a threading block with valid defaults."""
    tab.add_threading()
    blk = tab.blocks[-1]
    blk.inp_major_d.setText("0.5000")
    blk.inp_minor_d.setText("0.4056")
    blk.inp_pitch_d.setText("0.4500")
    blk.inp_pitch_tpi.setText("13")
    blk.inp_z_start.setText("0.000")
    blk.inp_thread_length.setText("1.000")
    blk.inp_lead_in.setText("0.100")
    blk.inp_lead_out.setText("0.050")
    blk.inp_first_doc.setText("0.010")
    blk.inp_min_doc.setText("0.002")
    blk.inp_spring_passes.setText("2")
    blk.inp_compound_angle.setText("29.5")
    blk.inp_degression.setText("1.0")
    blk.inp_num_starts.setText("1")
    blk.inp_tool_num.setText("4")
    blk.inp_rpm.setText("400")
    return blk


# Strategy: random sequence of block types, minimum 2
_BLOCK_TYPES = ["Profile", "Threading"]


@settings(max_examples=100, deadline=None)
@given(
    block_sequence=lists(
        sampled_from(_BLOCK_TYPES), min_size=2, max_size=5
    ),
)
def test_block_ordering_and_m0_pauses(block_sequence):
    """Combined output has blocks in order with M0 pauses between them."""
    tab = _make_tab()

    # Add blocks in sequence
    for btype in block_sequence:
        if btype == "Profile":
            _add_profile_block(tab)
        else:
            _add_threading_block(tab)

    # Generate
    tab.generate()
    output = tab.gcode_preview.toPlainText()
    assert output.strip(), "No output generated"

    # Verify block headers appear in order
    block_headers = []
    for line in output.split("\n"):
        match = re.match(r';\s*BLOCK\s+(\d+):\s+(\w+)', line)
        if match:
            block_headers.append((int(match.group(1)), match.group(2)))

    assert len(block_headers) == len(block_sequence), (
        f"Expected {len(block_sequence)} block headers, got {len(block_headers)}"
    )

    for i, (num, btype) in enumerate(block_headers):
        assert num == i + 1, f"Block {i+1} has number {num}"
        assert btype == block_sequence[i], (
            f"Block {i+1}: expected {block_sequence[i]}, got {btype}"
        )

    # Verify M0 pauses between blocks (not after last)
    m0_count = sum(1 for line in output.split("\n") if line.strip().startswith("M0"))
    expected_pauses = len(block_sequence) - 1
    assert m0_count == expected_pauses, (
        f"Expected {expected_pauses} M0 pauses, got {m0_count}"
    )
