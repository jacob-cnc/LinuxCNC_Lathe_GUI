# Feature: tool-wear-offsets, Property 1: Numeric display formatting
"""
Property-based test verifying that WearOffsetModel.format_display_value
produces correctly formatted strings for any float input:
  - X-axis values are displayed as diameter (internal radius × 2) with 4 decimal places
  - Z-axis values are displayed unchanged with 4 decimal places

**Validates: Requirements 1.4, 1.5**
"""

import sys
import os

# Ensure the gui package is importable
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from hypothesis import given, settings
from hypothesis.strategies import floats

from tabs.wear_offsets import WearOffsetModel


# Feature: tool-wear-offsets, Property 1: Numeric display formatting
@given(value=floats(allow_nan=False, allow_infinity=False))
@settings(max_examples=100)
def test_display_formatting_property(value):
    """For any float value, format_display_value with axis='x' produces
    f\"{value*2:.4f}\" and axis='z' produces f\"{value:.4f}\".

    **Validates: Requirements 1.4, 1.5**
    """
    model = WearOffsetModel()

    # X-axis: displayed as diameter (radius × 2), 4 decimal places
    x_result = model.format_display_value(value, "x")
    assert x_result == f"{value * 2:.4f}", (
        f"X-axis format mismatch for value={value}: "
        f"got {x_result!r}, expected {f'{value * 2:.4f}'!r}"
    )

    # Z-axis: displayed unchanged, 4 decimal places
    z_result = model.format_display_value(value, "z")
    assert z_result == f"{value:.4f}", (
        f"Z-axis format mismatch for value={value}: "
        f"got {z_result!r}, expected {f'{value:.4f}'!r}"
    )

# Feature: tool-wear-offsets, Property 2: Increment arithmetic correctness
"""
Property-based test verifying that WearOffsetModel.apply_increment
correctly adds or subtracts the selected increment from the current wear:
  - Positive direction (+1) adds the increment to the current wear
  - Negative direction (-1) subtracts the increment from the current wear

**Validates: Requirements 2.2, 2.3**
"""

from hypothesis.strategies import floats as _p2_floats, sampled_from, integers


@given(
    current_wear=_p2_floats(min_value=-10, max_value=10, allow_nan=False, allow_infinity=False),
    increment=sampled_from([0.0001, 0.0005, 0.001]),
    tool_num=integers(min_value=1, max_value=6),
    axis=sampled_from(["x", "z"]),
)
@settings(max_examples=100)
def test_increment_arithmetic_property(current_wear, increment, tool_num, axis):
    """For any current wear and valid increment, positive direction adds
    the increment and negative direction subtracts it.

    **Validates: Requirements 2.2, 2.3**
    """
    # --- Positive direction ---
    model = WearOffsetModel()
    model.wear[tool_num][axis] = current_wear
    result_pos = model.apply_increment(tool_num, axis, increment, +1)
    expected_pos = current_wear + increment
    assert abs(result_pos - expected_pos) < 1e-12, (
        f"Positive increment failed for wear={current_wear}, inc={increment}: "
        f"got {result_pos!r}, expected {expected_pos!r}"
    )
    assert abs(model.wear[tool_num][axis] - expected_pos) < 1e-12, (
        f"Model wear not updated correctly after positive increment"
    )

    # --- Negative direction ---
    model2 = WearOffsetModel()
    model2.wear[tool_num][axis] = current_wear
    result_neg = model2.apply_increment(tool_num, axis, increment, -1)
    expected_neg = current_wear - increment
    assert abs(result_neg - expected_neg) < 1e-12, (
        f"Negative increment failed for wear={current_wear}, inc={increment}: "
        f"got {result_neg!r}, expected {expected_neg!r}"
    )
    assert abs(model2.wear[tool_num][axis] - expected_neg) < 1e-12, (
        f"Model wear not updated correctly after negative increment"
    )

# Feature: tool-wear-offsets, Property 3: Total offset computation
"""
Property-based test verifying that WearOffsetModel.compute_total
returns the sum of geometry and wear for any tool/axis combination.

**Validates: Requirements 3.1, 3.2**
"""


@given(
    geo_val=floats(min_value=-10, max_value=10, allow_nan=False, allow_infinity=False),
    wear_val=floats(min_value=-1, max_value=1, allow_nan=False, allow_infinity=False),
    tool_num=integers(min_value=1, max_value=6),
    axis=sampled_from(["x", "z"]),
)
@settings(max_examples=100)
def test_total_computation_property(geo_val, wear_val, tool_num, axis):
    """For any geometry and wear values, compute_total returns their sum.

    **Validates: Requirements 3.1, 3.2**
    """
    model = WearOffsetModel()
    model.geometry[tool_num][axis] = geo_val
    model.wear[tool_num][axis] = wear_val

    result = model.compute_total(tool_num, axis)
    expected = geo_val + wear_val

    assert result == expected, (
        f"Total offset mismatch for tool={tool_num}, axis={axis}: "
        f"geo={geo_val}, wear={wear_val}, got {result!r}, expected {expected!r}"
    )

# Feature: tool-wear-offsets, Property 4: Zero resets wear to zero
"""
Property-based test verifying that WearOffsetModel.zero_wear
resets the wear value to exactly 0.0 for any tool/axis combination,
regardless of the prior wear value.

**Validates: Requirements 4.2, 4.3**
"""


@given(
    wear_val=floats(min_value=-10, max_value=10, allow_nan=False, allow_infinity=False),
    tool_num=integers(min_value=1, max_value=6),
    axis=sampled_from(["x", "z"]),
)
@settings(max_examples=100)
def test_zero_resets_wear_property(wear_val, tool_num, axis):
    """For any tool/axis with any wear value, zero_wear results in
    wear becoming exactly 0.0.

    **Validates: Requirements 4.2, 4.3**
    """
    model = WearOffsetModel()
    model.wear[tool_num][axis] = wear_val

    model.zero_wear(tool_num, axis)

    assert model.wear[tool_num][axis] == 0.0, (
        f"Wear not zeroed for tool={tool_num}, axis={axis}: "
        f"started with {wear_val!r}, got {model.wear[tool_num][axis]!r}, expected 0.0"
    )

# Feature: tool-wear-offsets, Property 5: History captures previous value
"""
Property-based test verifying that WearOffsetModel stores the previous
wear value in history before any change (increment, zero, or undo).

**Validates: Requirements 4.4, 5.1**
"""


@given(
    initial_wear=floats(min_value=-10, max_value=10, allow_nan=False, allow_infinity=False),
    increment=sampled_from([0.0001, 0.0005, 0.001]),
    tool_num=integers(min_value=1, max_value=6),
    axis=sampled_from(["x", "z"]),
    operation=sampled_from(["increment", "zero"]),
)
@settings(max_examples=100)
def test_history_captures_previous_value_property(initial_wear, increment, tool_num, axis, operation):
    """After any change (increment, zero, undo), history holds the value
    that existed before the change.

    **Validates: Requirements 4.4, 5.1**
    """
    model = WearOffsetModel()
    model.wear[tool_num][axis] = initial_wear

    if operation == "increment":
        model.apply_increment(tool_num, axis, increment, +1)
    else:  # zero
        model.zero_wear(tool_num, axis)

    assert model.history[tool_num][axis] == initial_wear, (
        f"History mismatch after {operation} for tool={tool_num}, axis={axis}: "
        f"initial_wear={initial_wear!r}, "
        f"history={model.history[tool_num][axis]!r}, expected={initial_wear!r}"
    )

# Feature: tool-wear-offsets, Property 6: Undo restores previous value
"""
Property-based test verifying that WearOffsetModel.undo restores the
pre-change wear value after an increment has been applied.

**Validates: Requirements 5.2**
"""


@given(
    initial_wear=floats(min_value=-10, max_value=10, allow_nan=False, allow_infinity=False),
    increment=sampled_from([0.0001, 0.0005, 0.001]),
    tool_num=integers(min_value=1, max_value=6),
    axis=sampled_from(["x", "z"]),
)
@settings(max_examples=100)
def test_undo_roundtrip_property(initial_wear, increment, tool_num, axis):
    """After a change, undo restores the pre-change value.

    **Validates: Requirements 5.2**
    """
    model = WearOffsetModel()
    model.wear[tool_num][axis] = initial_wear

    # Apply an increment to create a change with history
    model.apply_increment(tool_num, axis, increment, +1)

    # Undo should restore the initial wear value
    restored = model.undo(tool_num, axis)

    assert restored == initial_wear, (
        f"Undo return value mismatch for tool={tool_num}, axis={axis}: "
        f"got {restored!r}, expected {initial_wear!r}"
    )
    assert model.wear[tool_num][axis] == initial_wear, (
        f"Model wear not restored after undo for tool={tool_num}, axis={axis}: "
        f"got {model.wear[tool_num][axis]!r}, expected {initial_wear!r}"
    )

# Feature: tool-wear-offsets, Property 9: G10 L11 command format
"""
Property-based test verifying that WearOffsetModel.build_g10_wear_command
produces a correctly formatted G10 L11 command string for any tool number
and wear values:
  - Command starts with "G10 L11"
  - Contains P{tool_num}
  - Contains U{x_wear_radius:.4f} and W{z_wear:.4f}
  - Parsed U and W values match the inputs

**Validates: Requirements 2.4, 8.1**
"""

import re


@given(
    tool_num=integers(min_value=1, max_value=6),
    x_wear_radius=floats(min_value=-1, max_value=1, allow_nan=False, allow_infinity=False),
    z_wear=floats(min_value=-1, max_value=1, allow_nan=False, allow_infinity=False),
)
@settings(max_examples=100)
def test_g10_l11_format_property(tool_num, x_wear_radius, z_wear):
    """For any tool number and wear values, build_g10_wear_command produces
    G10 L11 P{tool} U{x_wear_radius} W{z_wear}.

    **Validates: Requirements 2.4, 8.1**
    """
    model = WearOffsetModel()
    cmd = model.build_g10_wear_command(tool_num, x_wear_radius, z_wear)

    # 1. Command starts with "G10 L11"
    assert cmd.startswith("G10 L11"), (
        f"Command does not start with 'G10 L11': {cmd!r}"
    )

    # 2. Contains P{tool_num}
    assert f"P{tool_num}" in cmd, (
        f"Command missing P{tool_num}: {cmd!r}"
    )

    # 3. Contains the exact formatted U and W values
    expected_u = f"U{x_wear_radius:.4f}"
    expected_w = f"W{z_wear:.4f}"
    assert expected_u in cmd, (
        f"Command missing {expected_u!r}: {cmd!r}"
    )
    assert expected_w in cmd, (
        f"Command missing {expected_w!r}: {cmd!r}"
    )

    # 4. Parse the command and verify U and W values match the 4-decimal
    #    formatted inputs (tolerance accounts for :.4f rounding)
    u_match = re.search(r"U([+-]?\d+\.\d+)", cmd)
    w_match = re.search(r"W([+-]?\d+\.\d+)", cmd)
    assert u_match is not None, f"Could not parse U value from: {cmd!r}"
    assert w_match is not None, f"Could not parse W value from: {cmd!r}"

    parsed_u = float(u_match.group(1))
    parsed_w = float(w_match.group(1))
    # The command formats with :.4f, so parsed value equals round(input, 4)
    assert parsed_u == round(x_wear_radius, 4), (
        f"Parsed U value {parsed_u} != round(x_wear_radius, 4) = {round(x_wear_radius, 4)}"
    )
    assert parsed_w == round(z_wear, 4), (
        f"Parsed W value {parsed_w} != round(z_wear, 4) = {round(z_wear, 4)}"
    )


# Feature: tool-wear-offsets, Property 10: G10 L1 command format
"""
Property-based test verifying that WearOffsetModel.build_g10_geo_command
produces a correctly formatted G10 L1 command string for any tool number
and geometry values:
  - Command starts with "G10 L1 " (not "G10 L11")
  - Contains P{tool_num}
  - Parsed X and Z values match round(input, 4)

**Validates: Requirements 8.2**
"""


@given(
    tool_num=integers(min_value=1, max_value=6),
    x_geo=floats(min_value=-10, max_value=10, allow_nan=False, allow_infinity=False),
    z_geo=floats(min_value=-10, max_value=10, allow_nan=False, allow_infinity=False),
)
@settings(max_examples=100)
def test_g10_l1_format_property(tool_num, x_geo, z_geo):
    """For any tool number and geometry values, build_g10_geo_command produces
    G10 L1 P{tool} X{x_geo} Z{z_geo}.

    **Validates: Requirements 8.2**
    """
    model = WearOffsetModel()
    cmd = model.build_g10_geo_command(tool_num, x_geo, z_geo)

    # 1. Command starts with "G10 L1 " (note the trailing space to exclude "G10 L11")
    assert cmd.startswith("G10 L1 "), (
        f"Command does not start with 'G10 L1 ': {cmd!r}"
    )

    # 2. Contains P{tool_num}
    assert f"P{tool_num}" in cmd, (
        f"Command missing P{tool_num}: {cmd!r}"
    )

    # 3. Parse the command and verify X and Z values match round(input, 4)
    x_match = re.search(r"X([+-]?\d+\.\d+)", cmd)
    z_match = re.search(r"Z([+-]?\d+\.\d+)", cmd)
    assert x_match is not None, f"Could not parse X value from: {cmd!r}"
    assert z_match is not None, f"Could not parse Z value from: {cmd!r}"

    parsed_x = float(x_match.group(1))
    parsed_z = float(z_match.group(1))
    assert parsed_x == round(x_geo, 4), (
        f"Parsed X value {parsed_x} != round(x_geo, 4) = {round(x_geo, 4)}"
    )
    assert parsed_z == round(z_geo, 4), (
        f"Parsed Z value {parsed_z} != round(z_geo, 4) = {round(z_geo, 4)}"
    )


# Feature: tool-wear-offsets, Property 7: Non-zero highlight correctness
"""
Property-based test verifying that the highlight decision logic is correct:
  - Highlight should be shown (True) when wear value != 0.0
  - Highlight should not be shown (False) when wear value == 0.0

This tests the model-level decision that drives WearToolRow.set_highlight()
calls in WearOffsetPage._refresh_row().

**Validates: Requirements 6.1, 6.2**
"""


@given(
    wear_val=floats(min_value=-10, max_value=10, allow_nan=False, allow_infinity=False),
)
@settings(max_examples=100)
def test_nonzero_highlight_property(wear_val):
    """For any wear value, highlight is shown if and only if value != 0.0.

    The _refresh_row method calls:
        row.set_highlight(axis, m.wear[tool_num][axis] != 0.0)

    This property verifies that decision logic is correct for all floats.

    **Validates: Requirements 6.1, 6.2**
    """
    # The highlight decision used in _refresh_row
    should_highlight = wear_val != 0.0

    # Requirement 6.1: non-zero wear values SHALL be highlighted
    if wear_val != 0.0:
        assert should_highlight is True, (
            f"Non-zero wear value {wear_val!r} should be highlighted but isn't"
        )

    # Requirement 6.2: zero wear values SHALL NOT be highlighted
    if wear_val == 0.0:
        assert should_highlight is False, (
            f"Zero wear value {wear_val!r} should not be highlighted but is"
        )


# Feature: tool-wear-offsets, Property 8: Stale indicator tracks geometry divergence
"""
Property-based test verifying that WearOffsetModel.is_stale correctly tracks
geometry divergence from the recorded baseline:
  - Stale indicator shown iff current geometry differs from recorded baseline
  - Zeroing wear updates baseline to current geometry and clears stale

**Validates: Requirements 7.2, 7.3**
"""


@given(
    geo_x=floats(min_value=-10, max_value=10, allow_nan=False, allow_infinity=False),
    geo_z=floats(min_value=-10, max_value=10, allow_nan=False, allow_infinity=False),
    new_geo_x=floats(min_value=-10, max_value=10, allow_nan=False, allow_infinity=False),
    new_geo_z=floats(min_value=-10, max_value=10, allow_nan=False, allow_infinity=False),
    tool_num=integers(min_value=1, max_value=6),
)
@settings(max_examples=100)
def test_stale_indicator_tracks_geometry_divergence_property(geo_x, geo_z, new_geo_x, new_geo_z, tool_num):
    """Stale indicator shown iff current geometry differs from recorded baseline;
    zeroing updates baseline and clears stale.

    **Validates: Requirements 7.2, 7.3**
    """
    model = WearOffsetModel()

    # Set initial geometry
    model.geometry[tool_num]["x"] = geo_x
    model.geometry[tool_num]["z"] = geo_z

    # Zero both axes to establish baseline (baseline = current geometry)
    model.zero_wear(tool_num, "x")
    model.zero_wear(tool_num, "z")

    # Baseline should now match current geometry — not stale
    assert model.is_stale(tool_num) is False, (
        f"Tool {tool_num} should NOT be stale right after zeroing: "
        f"geo=({geo_x}, {geo_z}), baseline=({model.geo_baseline[tool_num]['x']}, {model.geo_baseline[tool_num]['z']})"
    )

    # Change geometry to new values
    model.geometry[tool_num]["x"] = new_geo_x
    model.geometry[tool_num]["z"] = new_geo_z

    # Stale iff new geometry differs from baseline (original geometry)
    expected_stale = (new_geo_x != geo_x) or (new_geo_z != geo_z)
    assert model.is_stale(tool_num) is expected_stale, (
        f"Stale mismatch for tool {tool_num}: "
        f"baseline=({geo_x}, {geo_z}), current=({new_geo_x}, {new_geo_z}), "
        f"expected_stale={expected_stale}, got={model.is_stale(tool_num)}"
    )

    # Zero both axes again to update baseline to new geometry
    model.zero_wear(tool_num, "x")
    model.zero_wear(tool_num, "z")

    # After zeroing, baseline updated to current geometry — not stale
    assert model.is_stale(tool_num) is False, (
        f"Tool {tool_num} should NOT be stale after re-zeroing: "
        f"new_geo=({new_geo_x}, {new_geo_z}), "
        f"baseline=({model.geo_baseline[tool_num]['x']}, {model.geo_baseline[tool_num]['z']})"
    )


# ---------------------------------------------------------------------------
# Unit Tests: WearOffsetPage (Task 4.2)
# ---------------------------------------------------------------------------
import pytest
from PyQt5.QtWidgets import QApplication, QLabel

from tabs.wear_offsets import WearOffsetPage, WearToolRow, IncrementControl
from theme import COLORS


@pytest.fixture(scope="module")
def qapp():
    """Provide a QApplication instance, reusing the existing singleton if present."""
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    return app


@pytest.fixture
def page(qapp):
    """Create a WearOffsetPage in offline mode (stat=None, cmd=None)."""
    return WearOffsetPage(stat=None, cmd=None)


class TestWearOffsetPage:
    """Unit tests for WearOffsetPage — example-based.

    **Validates: Requirements 1.1, 1.3, 2.1, 3.4, 4.1, 5.4, 7.4, 9.5**
    """

    def test_table_has_correct_row_count(self, page):
        """Table has 6 tool rows (Req 1.1)."""
        assert len(page._rows) == 6
        for t in range(1, 7):
            assert t in page._rows
            assert isinstance(page._rows[t], WearToolRow)

    def test_each_row_has_expected_columns(self, page):
        """Each row has Geo X/Z, Wear X/Z, Total X/Z value labels (Req 1.1)."""
        for t in range(1, 7):
            row = page._rows[t]
            # Geometry columns (read-only)
            assert isinstance(row._geo_x, QLabel)
            assert isinstance(row._geo_z, QLabel)
            # Wear columns
            assert isinstance(row._wear_x, QLabel)
            assert isinstance(row._wear_z, QLabel)
            # Total columns (read-only)
            assert isinstance(row._total_x, QLabel)
            assert isinstance(row._total_z, QLabel)

    def test_offline_mode_populates_demo_data(self, page):
        """Offline mode populates demo data for all 6 tools (Req 1.3, 9.5)."""
        demo = WearOffsetPage._DEMO_DATA
        m = page._model

        for t in range(1, 7):
            assert t in demo, f"Demo data missing for tool {t}"
            # Model should have the demo geometry and wear values
            assert m.geometry[t]["x"] == demo[t]["geo_x"]
            assert m.geometry[t]["z"] == demo[t]["geo_z"]
            assert m.wear[t]["x"] == demo[t]["wear_x"]
            assert m.wear[t]["z"] == demo[t]["wear_z"]

        # Rows should display non-default values (not all "0.0000")
        row1 = page._rows[1]
        # Tool 1 has non-zero wear_x=0.0006 → displayed as diameter 0.0012
        assert row1._wear_x.text() != "0.0000"

    def test_offline_status_label(self, page):
        """Offline mode shows 'Offline' status message (Req 9.5)."""
        assert "Offline" in page._status_label.text()

    def test_increment_selector_has_three_options(self, page):
        """Increment selector has exactly 3 options: 0.0001, 0.0005, 0.001 (Req 2.1)."""
        combo = page._increment_ctrl._combo
        assert combo.count() == 3
        expected = IncrementControl.INCREMENTS
        for i in range(3):
            assert combo.itemData(i) == expected[i]

    def test_total_fields_are_readonly(self, page):
        """Total X and Total Z labels use read-only styling (Req 3.4)."""
        for t in range(1, 7):
            row = page._rows[t]
            # Read-only labels use bg_dark background and text_dim color
            total_x_style = row._total_x.styleSheet()
            total_z_style = row._total_z.styleSheet()
            assert COLORS["bg_dark"] in total_x_style
            assert COLORS["text_dim"] in total_x_style
            assert COLORS["bg_dark"] in total_z_style
            assert COLORS["text_dim"] in total_z_style

    def test_each_row_has_zero_buttons(self, page):
        """Each row has X and Z zero buttons (Req 4.1)."""
        for t in range(1, 7):
            row = page._rows[t]
            assert row._btn_zero_x is not None
            assert row._btn_zero_z is not None
            assert row._btn_zero_x.text() == "0"
            assert row._btn_zero_z.text() == "0"

    def test_undo_disabled_when_no_history(self, page):
        """Undo buttons are disabled when no history exists (Req 5.4)."""
        for t in range(1, 7):
            row = page._rows[t]
            # Fresh page — no changes have been made, so no history
            assert not row._btn_undo_x.isEnabled(), (
                f"Tool {t} undo X should be disabled with no history"
            )
            assert not row._btn_undo_z.isEnabled(), (
                f"Tool {t} undo Z should be disabled with no history"
            )

    def test_stale_color_differs_from_highlight_color(self, page):
        """Stale indicator color differs from non-zero highlight color (Req 7.4)."""
        # These are class-level constants on WearToolRow
        assert WearToolRow._STALE_COLOR != WearToolRow._HIGHLIGHT_COLOR
        # Verify the actual color values
        assert WearToolRow._STALE_COLOR == COLORS["accent"]       # crimson
        assert WearToolRow._HIGHLIGHT_COLOR == COLORS["accent_warm"]  # orange

        # Also verify the stale label uses the stale color in its stylesheet
        row = page._rows[1]
        stale_style = row._stale_label.styleSheet()
        assert WearToolRow._STALE_COLOR in stale_style


# ---------------------------------------------------------------------------
# Integration Tests: LinuxCNC Command Flow (Task 6.3)
# ---------------------------------------------------------------------------
from unittest.mock import MagicMock, patch, call
import types


def _make_tool_entry(xoffset=0.0, zoffset=0.0):
    """Create a mock tool table entry with xoffset and zoffset attributes."""
    entry = MagicMock()
    entry.xoffset = xoffset
    entry.zoffset = zoffset
    return entry


def _make_mock_stat(num_tools=6, entries=None):
    """Create a mock stat channel with a tool_table array.

    Args:
        num_tools: Number of tools.
        entries: Optional dict {tool_num: (xoffset, zoffset)} to pre-populate.
    """
    stat = MagicMock()
    # Build tool_table as a list indexed by tool number (0 is unused)
    tool_table = [_make_tool_entry() for _ in range(num_tools + 1)]
    if entries:
        for t, (x, z) in entries.items():
            tool_table[t] = _make_tool_entry(x, z)
    stat.tool_table = tool_table
    return stat


def _make_mock_linuxcnc_module():
    """Create a mock linuxcnc module with MODE_MDI constant."""
    mod = types.ModuleType("linuxcnc")
    mod.MODE_MDI = 2  # typical value
    return mod


class TestLinuxCNCIntegration:
    """Integration tests for LinuxCNC command flow using mocked stat/cmd.

    **Validates: Requirements 1.2, 2.5, 2.6, 4.5, 5.3, 8.3, 8.4, 8.5**
    """

    def test_stat_channel_read_populates_table(self, qapp):
        """Stat channel read populates table with tool offsets (Req 1.2)."""
        entries = {
            1: (-0.6170, -3.5670),
            2: (-0.5890, -2.1230),
            3: (-0.7250, -4.8900),
            4: (-0.4320, -1.7540),
            5: (-0.8100, -5.2310),
            6: (-0.5500, -3.0150),
        }
        stat = _make_mock_stat(entries=entries)
        cmd = MagicMock()

        page = WearOffsetPage(stat=stat, cmd=cmd)

        # refresh_from_stat is called in __init__ when stat is not None
        stat.poll.assert_called()

        # Model geometry should reflect stat values (wear starts at 0,
        # so geometry = stat_total - wear = stat_total)
        for t in range(1, 7):
            expected_x, expected_z = entries[t]
            assert abs(page._model.geometry[t]["x"] - expected_x) < 1e-9, (
                f"Tool {t} geometry X mismatch"
            )
            assert abs(page._model.geometry[t]["z"] - expected_z) < 1e-9, (
                f"Tool {t} geometry Z mismatch"
            )

    def test_increment_writes_g10_l11_then_g43(self, qapp):
        """Increment writes G10 L11 then G43 via MDI (Req 2.5)."""
        stat = _make_mock_stat(entries={1: (0.0, 0.0)})
        cmd = MagicMock()
        mock_lcnc = _make_mock_linuxcnc_module()

        page = WearOffsetPage(stat=stat, cmd=cmd)

        # Reset call tracking after __init__
        cmd.reset_mock()
        stat.reset_mock()
        # Re-set tool_table since reset_mock clears it
        stat.tool_table = _make_mock_stat(entries={1: (0.0001, 0.0)}).tool_table

        with patch.dict("sys.modules", {"linuxcnc": mock_lcnc}):
            page.apply_increment(1, "x", 1)

        # Verify MDI calls: mode, wait, G10 L11, wait, G43, wait
        mdi_calls = [c for c in cmd.method_calls if c[0] == "mdi"]
        assert len(mdi_calls) == 2, f"Expected 2 mdi calls, got {len(mdi_calls)}: {mdi_calls}"

        g10_cmd_str = mdi_calls[0][1][0]
        assert "G10 L11" in g10_cmd_str, f"First MDI should be G10 L11: {g10_cmd_str}"
        assert "P1" in g10_cmd_str, f"G10 should target tool 1: {g10_cmd_str}"

        g43_cmd_str = mdi_calls[1][1][0]
        assert g43_cmd_str == "G43", f"Second MDI should be G43: {g43_cmd_str}"

        # Verify mode was set to MDI
        cmd.mode.assert_called_with(mock_lcnc.MODE_MDI)

    def test_write_triggers_readback_confirmation(self, qapp):
        """Write triggers read-back from stat channel for confirmation (Req 2.6)."""
        initial_entries = {1: (0.0, 0.0)}
        stat = _make_mock_stat(entries=initial_entries)
        cmd = MagicMock()
        mock_lcnc = _make_mock_linuxcnc_module()

        page = WearOffsetPage(stat=stat, cmd=cmd)

        # After init, stat.poll was called once for refresh_from_stat
        initial_poll_count = stat.poll.call_count

        # Set up readback values that match expected total
        # After increment of 0.0005 on x: wear_x = 0.0005, geo_x = 0.0
        # Expected total_x = 0.0005
        stat.tool_table[1] = _make_tool_entry(xoffset=0.0005, zoffset=0.0)

        with patch.dict("sys.modules", {"linuxcnc": mock_lcnc}):
            page.apply_increment(1, "x", 1)

        # stat.poll should have been called again for read-back
        assert stat.poll.call_count > initial_poll_count, (
            "stat.poll should be called for read-back after write"
        )

    def test_zero_button_issues_g43_after_write(self, qapp):
        """Zero button issues G43 after G10 L11 write (Req 4.5)."""
        stat = _make_mock_stat(entries={1: (0.001, -0.002)})
        cmd = MagicMock()
        mock_lcnc = _make_mock_linuxcnc_module()

        page = WearOffsetPage(stat=stat, cmd=cmd)

        # Give tool 1 some wear to zero
        page._model.wear[1]["x"] = 0.0005

        cmd.reset_mock()
        stat.reset_mock()
        stat.tool_table = _make_mock_stat(entries={1: (0.001 - 0.0005, -0.002)}).tool_table

        with patch.dict("sys.modules", {"linuxcnc": mock_lcnc}):
            page.zero_wear(1, "x")

        mdi_calls = [c for c in cmd.method_calls if c[0] == "mdi"]
        assert len(mdi_calls) == 2, f"Expected 2 mdi calls, got {len(mdi_calls)}"

        g10_cmd_str = mdi_calls[0][1][0]
        assert "G10 L11" in g10_cmd_str, f"First MDI should be G10 L11: {g10_cmd_str}"

        assert mdi_calls[1][1][0] == "G43", "Second MDI should be G43"

    def test_undo_writes_restored_value_via_g10_l11(self, qapp):
        """Undo writes restored value via G10 L11 (Req 5.3)."""
        stat = _make_mock_stat(entries={2: (0.0, 0.0)})
        cmd = MagicMock()
        mock_lcnc = _make_mock_linuxcnc_module()

        page = WearOffsetPage(stat=stat, cmd=cmd)

        # Apply an increment first to create history
        stat.tool_table[2] = _make_tool_entry(xoffset=0.0005, zoffset=0.0)
        with patch.dict("sys.modules", {"linuxcnc": mock_lcnc}):
            page.apply_increment(2, "x", 1)

        # Now undo — should write the previous value (0.0) back
        cmd.reset_mock()
        stat.reset_mock()
        stat.tool_table = _make_mock_stat(entries={2: (0.0, 0.0)}).tool_table

        with patch.dict("sys.modules", {"linuxcnc": mock_lcnc}):
            page.undo_wear(2, "x")

        mdi_calls = [c for c in cmd.method_calls if c[0] == "mdi"]
        assert len(mdi_calls) == 2, f"Expected 2 mdi calls for undo, got {len(mdi_calls)}"

        g10_cmd_str = mdi_calls[0][1][0]
        assert "G10 L11" in g10_cmd_str, f"Undo should issue G10 L11: {g10_cmd_str}"
        assert "P2" in g10_cmd_str, f"G10 should target tool 2: {g10_cmd_str}"

        # Wear was restored to 0.0, so U should be 0.0000
        assert "U0.0000" in g10_cmd_str, (
            f"Undo should write restored wear value (0.0): {g10_cmd_str}"
        )

    def test_g43_issued_after_every_offset_write(self, qapp):
        """G43 is issued after every offset write (Req 8.3)."""
        stat = _make_mock_stat(entries={1: (0.0, 0.0), 3: (0.0, 0.0)})
        cmd = MagicMock()
        mock_lcnc = _make_mock_linuxcnc_module()

        page = WearOffsetPage(stat=stat, cmd=cmd)
        cmd.reset_mock()

        # Perform multiple writes: increment on tool 1, zero on tool 3
        stat.tool_table[1] = _make_tool_entry(xoffset=0.0005, zoffset=0.0)
        with patch.dict("sys.modules", {"linuxcnc": mock_lcnc}):
            page.apply_increment(1, "x", 1)

        stat.tool_table[3] = _make_tool_entry(xoffset=0.0, zoffset=0.0)
        with patch.dict("sys.modules", {"linuxcnc": mock_lcnc}):
            page.zero_wear(3, "z")

        # Every write should have a G43 after it
        mdi_calls = [c for c in cmd.method_calls if c[0] == "mdi"]
        # 2 writes × 2 mdi calls each (G10 + G43) = 4
        assert len(mdi_calls) == 4, f"Expected 4 mdi calls, got {len(mdi_calls)}"
        # G43 should be at positions 1 and 3
        assert mdi_calls[1][1][0] == "G43", "G43 missing after first write"
        assert mdi_calls[3][1][0] == "G43", "G43 missing after second write"

    def test_offline_mode_issues_no_g10_g43_commands(self, qapp):
        """Offline mode issues no G10/G43 commands (Req 8.4)."""
        # Create page in offline mode (stat=None, cmd=None)
        page = WearOffsetPage(stat=None, cmd=None)

        # Perform various operations
        page.apply_increment(1, "x", 1)
        page.zero_wear(2, "z")

        # Give tool 3 some history so undo works
        page._model.wear[3]["x"] = 0.001
        page._model.history[3]["x"] = 0.0
        page.undo_wear(3, "x")

        # No cmd or stat to call — if we got here without error,
        # offline mode correctly skipped all LinuxCNC commands.
        # Verify the model still updated locally
        assert page._model.wear[1]["x"] != 0.0, "Increment should update model locally"
        assert page._model.wear[2]["z"] == 0.0, "Zero should update model locally"
        assert page._model.wear[3]["x"] == 0.0, "Undo should update model locally"

    def test_failed_write_shows_error_in_status_bar(self, qapp):
        """Failed write shows error in status bar (Req 8.5)."""
        stat = _make_mock_stat(entries={1: (0.0, 0.0)})
        cmd = MagicMock()
        mock_lcnc = _make_mock_linuxcnc_module()

        page = WearOffsetPage(stat=stat, cmd=cmd)

        # Make mdi raise an exception to simulate write failure
        cmd.mdi.side_effect = RuntimeError("MDI command failed")

        with patch.dict("sys.modules", {"linuxcnc": mock_lcnc}):
            page.apply_increment(1, "x", 1)

        # Status bar should show error
        status_text = page._status_label.text()
        assert "error" in status_text.lower() or "Error" in status_text or "T1" in status_text, (
            f"Status bar should show error after failed write, got: {status_text!r}"
        )
