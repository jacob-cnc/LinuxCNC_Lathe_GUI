# Bugfix: id-toolpath-fix, Property 1: Bug Condition Exploration
"""
Bug condition exploration tests for ID (boring) toolpath generation.

These tests verify that:
- `build_z_limit_chart()` returns a non-empty dict for ID mode
- ID roughing passes are generated in G-code output
- UI fields adapt correctly when switching to ID mode
- Point chart debug comments appear in ID G-code output

**Validates: Requirements 1.1, 1.2, 1.3, 1.4, 1.5, 2.1, 2.2, 2.3, 2.4, 2.5**

On UNFIXED code, these tests are EXPECTED TO FAIL — failure confirms the bug
exists (empty Z chart for ID mode, zero roughing passes, UI fields not adapting,
no point chart comments).
"""

import sys
import os
import re
import math

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from PyQt5.QtWidgets import QApplication
from hypothesis import given, settings, assume, HealthCheck
from hypothesis.strategies import floats

_app = None


def _get_app():
    global _app
    if _app is None:
        _app = QApplication.instance() or QApplication(sys.argv)
    return _app


def _make_profile_block():
    """Create a fresh ProfileBlock instance (requires QApplication)."""
    _get_app()
    from conv_profile import ProfileBlock
    return ProfileBlock(block_num=1)


def _set_profile_fields(blk, **kwargs):
    """Set ProfileBlock fields from keyword arguments."""
    field_map = {
        "stock_dia": blk.stock_dia,
        "x_start": blk.x_start,
        "z_start": blk.z_start,
        "doc": blk.doc,
        "fin_passes": blk.fin_passes,
        "fin_doc": blk.fin_doc,
        "feed_r": blk.feed_r,
        "feed_f": blk.feed_f,
        "retract": blk.retract,
        "rough_tool": blk.rough_tool,
        "finish_tool": blk.finish_tool,
        "rpm": blk.rpm,
        "safe_x": blk.safe_x,
        "safe_z": blk.safe_z,
    }
    for k, v in kwargs.items():
        if k == "mode":
            idx = blk.cmb_mode.findText(v)
            if idx >= 0:
                blk.cmb_mode.setCurrentIndex(idx)
        elif k in field_map:
            field_map[k].setText(str(v))


def _add_segments(blk, segments):
    """Add profile segments to a ProfileBlock.

    Each segment is a dict with keys: x_end, z_end, and optionally
    is_arc (bool), arc_r (str).
    The block starts with one default segment, so we remove it first.
    """
    for seg in list(blk.segments):
        blk.remove_segment(seg)

    for seg_data in segments:
        blk.add_segment()
        seg = blk.segments[-1]
        seg.x_end.setText(str(seg_data["x_end"]))
        seg.z_end.setText(str(seg_data["z_end"]))
        if seg_data.get("is_arc"):
            seg.arc_check.setChecked(True)
            seg.arc_r.setText(str(seg_data.get("arc_r", "")))


# ------------------------------------------------------------------
# Test 1: ID taper profile — roughing passes and point chart
# ------------------------------------------------------------------

def test_id_taper_roughing_passes_and_point_chart():
    """ID taper: roughing passes must exist and point chart comments must be present.

    **Validates: Requirements 1.1, 1.4, 2.1, 2.4**

    Profile: pilot_hole=0.500, taper from X0.500 Z0.0 to X1.500 Z-2.0.
    Expected: roughing passes stepping outward from pilot hole, with
    `; --- Point Chart` debug comments in the output.

    On UNFIXED code, `build_z_limit_chart()` returns {} for ID mode,
    causing zero roughing passes and no point chart — this test will FAIL.
    """
    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="ID",
        stock_dia="0.500",
        x_start="0.500",
        z_start="0.1",
        doc="0.020",
        fin_passes="1",
        fin_doc="0.002",
        feed_r="0.003",
        feed_f="0.002",
        retract="0.005",
        rough_tool="2",
        finish_tool="2",
        rpm="800",
        safe_x="0.300",
        safe_z="1.000",
    )

    _add_segments(blk, [
        {"x_end": "0.500", "z_end": "0.000"},
        {"x_end": "1.500", "z_end": "-2.000"},
    ])

    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    # Check roughing passes exist
    roughing_pass_lines = [
        line for line in gcode.split("\n")
        if re.match(r'\s*G00\s+X[+-]?\d+\.?\d*\s+Z[+-]?\d+\.?\d*\s+\(Pass\s+\d+', line.strip())
    ]
    assert len(roughing_pass_lines) >= 1, (
        f"Expected at least 1 roughing pass for ID taper profile, "
        f"but found {len(roughing_pass_lines)}. "
        f"build_z_limit_chart() likely returned empty dict for ID mode."
    )

    # Check point chart debug comments
    assert "; --- Point Chart" in gcode, (
        "Expected '; --- Point Chart' debug comments in ID G-code output, "
        "but none found. ID roughing path does not emit point chart comments."
    )


# ------------------------------------------------------------------
# Test 2: ID cylinder bore — roughing passes exist
# ------------------------------------------------------------------

def test_id_cylinder_bore_roughing_passes():
    """ID cylinder bore: roughing passes must exist for straight bore.

    **Validates: Requirements 1.1, 2.1**

    Profile: pilot_hole=0.500, face from X0.500 Z0.0, then straight bore
    at X1.500 from Z0.0 to Z-2.0. The face move goes from small X to large X
    at constant Z, and the bore segment is constant X — the taper segment
    (face) transitions from unsafe→safe which the unfixed code cannot detect.

    Expected: roughing passes stepping outward from pilot hole, each cutting
    to Z-2.0 (since the bore is constant diameter).

    On UNFIXED code, build_z_limit_chart() returns {} for the taper-like
    face segment — this test will FAIL.
    """
    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="ID",
        stock_dia="0.500",
        x_start="0.500",
        z_start="0.1",
        doc="0.020",
        fin_passes="1",
        fin_doc="0.002",
        feed_r="0.003",
        feed_f="0.002",
        retract="0.005",
        rough_tool="2",
        finish_tool="2",
        rpm="800",
        safe_x="0.300",
        safe_z="1.000",
    )

    # Face from pilot hole to bore diameter, then straight bore
    _add_segments(blk, [
        {"x_end": "0.500", "z_end": "0.000"},
        {"x_end": "1.500", "z_end": "-2.000"},
    ])

    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    # Count actual roughing G01 Z moves (not just approach lines)
    roughing_g01_count = 0
    in_roughing = False
    for line in gcode.split("\n"):
        stripped = line.strip()
        if "; --- Roughing passes ---" in stripped:
            in_roughing = True
            continue
        if in_roughing and ("; --- Cleanup pass" in stripped or
                            "Roughing complete" in stripped):
            break
        if in_roughing and re.match(r'G01\s+Z[+-]?\d+\.?\d*', stripped):
            roughing_g01_count += 1

    assert roughing_g01_count >= 1, (
        f"Expected at least 1 roughing G01 Z move for ID cylinder bore, "
        f"but found {roughing_g01_count}. "
        f"build_z_limit_chart() likely returned empty dict for ID mode."
    )


# ------------------------------------------------------------------
# Test 3: build_z_limit_chart() directly with ID parameters
# ------------------------------------------------------------------

def test_build_z_limit_chart_id_nonempty():
    """Direct call to build_z_limit_chart() with ID params must return non-empty dict.

    **Validates: Requirements 1.1, 2.1**

    Constructs finish_moves for an ID taper profile (X0.500 Z0.0 to X1.500 Z-2.0)
    and calls build_z_limit_chart() with mode="ID". The result must be a non-empty
    dict with valid Z limits.

    On UNFIXED code, returns {} — this test will FAIL.
    """
    from conv_profile import build_z_limit_chart

    # Simulate an ID taper profile: face from X0.500 to X0.500 Z0.0,
    # then taper to X1.500 Z-2.0
    finish_moves = [
        ("LINE", 0.500, 0.0),
        ("LINE", 1.500, -2.0),
    ]
    x_start_d = 0.500
    z_start = 0.1
    fin_allowance = 0.002  # 1 pass * 0.002 fin_doc

    # Build x_levels: stepping outward from pilot hole
    doc = 0.020
    x_levels = []
    cd = x_start_d + doc * 2
    max_x = 1.500 - fin_allowance * 2
    while cd < max_x:
        x_levels.append(cd)
        cd += doc * 2

    assert len(x_levels) > 0, "Test setup error: no x_levels generated"

    z_chart = build_z_limit_chart(finish_moves, x_start_d, z_start,
                                  x_levels, fin_allowance, "ID")

    assert len(z_chart) > 0, (
        f"build_z_limit_chart() returned empty dict for ID mode with "
        f"{len(x_levels)} x_levels. Root cause: crossing detection only "
        f"checks safe1=True AND safe2=False, but ID segments transition "
        f"unsafe→safe (safe1=False AND safe2=True)."
    )


# ------------------------------------------------------------------
# Test 4: Switch to ID mode — x_start equals stock_dia
# ------------------------------------------------------------------

def test_id_mode_x_start_equals_stock_dia():
    """Switching to ID mode must auto-populate x_start with stock_dia value.

    **Validates: Requirements 1.2, 2.2**

    When the user switches to ID mode, x_start should be set to the
    pilot hole diameter (stock_dia value) since ID roughing starts at
    the pilot hole.

    On UNFIXED code, x_start is not updated — this test will FAIL.
    """
    blk = _make_profile_block()

    # Set stock_dia first (while still in OD mode)
    blk.stock_dia.setText("0.750")
    blk.x_start.setText("2.000")  # OD default — should change on ID switch

    # Switch to ID mode
    idx = blk.cmb_mode.findText("ID")
    assert idx >= 0, "ID mode not found in combo box"
    blk.cmb_mode.setCurrentIndex(idx)

    # x_start should now equal stock_dia
    assert blk.x_start.text() == blk.stock_dia.text(), (
        f"After switching to ID mode, x_start should equal stock_dia "
        f"('{blk.stock_dia.text()}'), but got '{blk.x_start.text()}'. "
        f"_on_mode_changed() does not auto-populate x_start for ID mode."
    )


# ------------------------------------------------------------------
# Test 5: Switch to ID mode — x_start tooltip is ID-appropriate
# ------------------------------------------------------------------

def test_id_mode_x_start_tooltip():
    """Switching to ID mode must update x_start tooltip to ID-appropriate text.

    **Validates: Requirements 1.3, 2.3**

    The tooltip should NOT contain "0 for face start" when in ID mode,
    since that guidance is OD-specific.

    On UNFIXED code, tooltip remains OD-centric — this test will FAIL.
    """
    blk = _make_profile_block()

    # Switch to ID mode
    idx = blk.cmb_mode.findText("ID")
    assert idx >= 0
    blk.cmb_mode.setCurrentIndex(idx)

    tooltip = blk.x_start.toolTip()
    assert "0 for face start" not in tooltip, (
        f"After switching to ID mode, x_start tooltip should not contain "
        f"'0 for face start' (OD-centric text). Got: '{tooltip}'. "
        f"_on_mode_changed() does not update x_start tooltip for ID mode."
    )


# ------------------------------------------------------------------
# Test 6: Switch to ID mode — safe_x changes to inside-bore value
# ------------------------------------------------------------------

def test_id_mode_safe_x_adapts():
    """Switching to ID mode must change safe_x to an appropriate inside-bore value.

    **Validates: Requirements 1.5, 2.5**

    The safe_x default of 3.000 is appropriate for OD (outside the stock),
    but for ID mode it should be a smaller value inside the bore.

    On UNFIXED code, safe_x remains at OD default — this test will FAIL.
    """
    blk = _make_profile_block()

    # Verify OD default
    od_safe_x = float(blk.safe_x.text())
    assert od_safe_x > 1.0, f"Expected OD safe_x > 1.0, got {od_safe_x}"

    # Set pilot hole diameter
    blk.stock_dia.setText("0.500")

    # Switch to ID mode
    idx = blk.cmb_mode.findText("ID")
    assert idx >= 0
    blk.cmb_mode.setCurrentIndex(idx)

    id_safe_x = float(blk.safe_x.text())
    pilot_hole = float(blk.stock_dia.text())

    assert id_safe_x < pilot_hole, (
        f"After switching to ID mode with pilot_hole={pilot_hole:.4f}, "
        f"safe_x should be less than pilot hole (inside bore), "
        f"but got safe_x={id_safe_x:.4f}. "
        f"_on_mode_changed() does not update safe_x for ID mode."
    )


# ------------------------------------------------------------------
# Test 7: Generate ID G-code — point chart debug comments
# ------------------------------------------------------------------

def test_id_gcode_point_chart_comments():
    """ID G-code must include point chart debug comments.

    **Validates: Requirements 1.4, 2.4**

    The OD roughing path prints `; --- Point Chart ...` comments showing
    the Z limit at each roughing X level. The ID path should do the same.

    On UNFIXED code, no point chart comments in ID output — this test will FAIL.
    """
    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="ID",
        stock_dia="0.500",
        x_start="0.500",
        z_start="0.1",
        doc="0.020",
        fin_passes="1",
        fin_doc="0.002",
        feed_r="0.003",
        feed_f="0.002",
        retract="0.005",
        rough_tool="2",
        finish_tool="2",
        rpm="800",
        safe_x="0.300",
        safe_z="1.000",
    )

    _add_segments(blk, [
        {"x_end": "0.500", "z_end": "0.000"},
        {"x_end": "1.500", "z_end": "-2.000"},
    ])

    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    assert "; --- Point Chart" in gcode, (
        "Expected '; --- Point Chart' debug comments in ID G-code output, "
        "but none found. The ID roughing path does not emit point chart "
        "comments unlike the OD path."
    )

    # Also check that individual point chart entries exist
    point_chart_entries = [
        line for line in gcode.split("\n")
        if line.strip().startswith(";   X") and "-> Z" in line
    ]
    assert len(point_chart_entries) >= 1, (
        "Expected at least 1 point chart entry (';   X... -> Z...') "
        "in ID G-code output, but found none."
    )


# ------------------------------------------------------------------
# Test 8: PBT — random valid ID profiles, z_chart non-empty
# ------------------------------------------------------------------

@settings(max_examples=10, deadline=None,
          suppress_health_check=[HealthCheck.filter_too_much])
@given(
    pilot_hole=floats(min_value=0.3, max_value=1.0, allow_nan=False, allow_infinity=False),
    target_mult=floats(min_value=2.0, max_value=3.0, allow_nan=False, allow_infinity=False),
    doc=floats(min_value=0.010, max_value=0.050, allow_nan=False, allow_infinity=False),
    fin_doc=floats(min_value=0.001, max_value=0.005, allow_nan=False, allow_infinity=False),
)
def test_pbt_id_z_chart_nonempty(pilot_hole, target_mult, doc, fin_doc):
    """PBT: For random valid ID profiles, build_z_limit_chart() returns non-empty dict.

    **Validates: Requirements 1.1, 2.1**

    Generates random ID taper profiles and verifies that build_z_limit_chart()
    returns a non-empty dict with Z limits in valid range (between z_start
    and profile Z end).

    On UNFIXED code, always returns {} — this test will FAIL.
    """
    from conv_profile import build_z_limit_chart

    pilot_hole = round(pilot_hole, 4)
    doc = round(doc, 4)
    fin_doc = round(fin_doc, 4)

    target_dia = round(pilot_hole * target_mult, 4)
    assume(target_dia <= 3.0)

    fin_allowance = fin_doc  # 1 finish pass
    max_target_d = target_dia - fin_allowance * 2

    # Need at least 3 roughing passes
    assume(pilot_hole + doc * 2 * 3 < max_target_d)

    z_start = 0.1
    z_end = -2.0

    # ID taper profile: face from pilot_hole to pilot_hole Z0.0,
    # then taper to target_dia Z-2.0
    finish_moves = [
        ("LINE", pilot_hole, 0.0),
        ("LINE", target_dia, z_end),
    ]

    # Build x_levels
    x_levels = []
    cd = pilot_hole + doc * 2
    while cd < max_target_d:
        x_levels.append(round(cd, 4))
        cd += doc * 2

    assume(len(x_levels) >= 3)

    z_chart = build_z_limit_chart(finish_moves, pilot_hole, z_start,
                                  x_levels, fin_allowance, "ID")

    assert len(z_chart) > 0, (
        f"build_z_limit_chart() returned empty dict for ID mode with "
        f"pilot_hole={pilot_hole:.4f}, target_dia={target_dia:.4f}, "
        f"doc={doc:.4f}, {len(x_levels)} x_levels. "
        f"Root cause: crossing detection only checks safe→unsafe transitions, "
        f"but ID segments transition unsafe→safe."
    )

    # Verify Z limits are in valid range
    for xl, zl in z_chart.items():
        assert z_end <= zl <= z_start, (
            f"Z limit at X{xl:.4f} is {zl:.4f}, which is outside "
            f"valid range [{z_end:.4f}, {z_start:.4f}]"
        )


# ======================================================================
# Bugfix: id-toolpath-fix, Property 2: Preservation
# ======================================================================
"""
Preservation property tests for OD toolpath and G-code structure.

These tests verify that OD roughing, cleanup pass, finish pass, point chart,
UI fields, and G-code header format remain unchanged after the ID toolpath fix.

**Validates: Requirements 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7**

These tests MUST PASS on UNFIXED code — they capture baseline OD behavior
that must be preserved after the fix is applied.
"""


# ------------------------------------------------------------------
# G-code section parsers (local to this file)
# ------------------------------------------------------------------

def _parse_cleanup_pass_x_values(gcode):
    """Extract approach and retract X values from the cleanup pass section."""
    lines = gcode.split("\n")
    in_cleanup = False
    approach_x = None
    retract_x = None

    for line in lines:
        stripped = line.strip()

        if "; --- Cleanup pass" in stripped:
            in_cleanup = True
            continue

        if in_cleanup and ("Roughing complete" in stripped
                           or "; --- Finish pass" in stripped):
            break

        if not in_cleanup:
            continue

        # First G00 X... Z... is the approach
        if approach_x is None:
            m = re.match(r'G00\s+X([+-]?\d+\.?\d*)\s+Z([+-]?\d+\.?\d*)', stripped)
            if m:
                approach_x = float(m.group(1))
                continue

        # Last G00 X... (no Z) is the retract
        m = re.match(r'G00\s+X([+-]?\d+\.?\d*)$', stripped)
        if m:
            retract_x = float(m.group(1))

    return {"approach_x": approach_x, "retract_x": retract_x}


def _parse_finish_pass_retract_x(gcode):
    """Extract the retract X value after the finish pass G01 moves."""
    lines = gcode.split("\n")
    in_finish = False
    retract_x = None

    for line in lines:
        stripped = line.strip()

        if "; --- Finish pass" in stripped:
            in_finish = True
            continue

        if in_finish and "Return to safe position" in stripped:
            break

        if not in_finish:
            continue

        m = re.match(r'G00\s+X([+-]?\d+\.?\d*)$', stripped)
        if m:
            retract_x = float(m.group(1))

    return retract_x


# ------------------------------------------------------------------
# Preservation Test 1 (PBT): OD Z chart preservation
# ------------------------------------------------------------------

@settings(max_examples=10, deadline=None,
          suppress_health_check=[HealthCheck.filter_too_much])
@given(
    stock_dia=floats(min_value=2.0, max_value=4.0, allow_nan=False, allow_infinity=False),
    doc=floats(min_value=0.020, max_value=0.060, allow_nan=False, allow_infinity=False),
    target_frac=floats(min_value=0.3, max_value=0.6, allow_nan=False, allow_infinity=False),
    fin_doc=floats(min_value=0.001, max_value=0.005, allow_nan=False, allow_infinity=False),
)
def test_preservation_od_z_chart(stock_dia, doc, target_frac, fin_doc):
    """PBT: OD Z chart returns non-empty dict with valid Z limits for random OD profiles.

    **Validates: Requirements 3.1, 3.6**

    For random OD profiles with a face move from stock to target diameter,
    `build_z_limit_chart()` returns a non-empty dict with Z limits in valid
    range. This behavior must remain unchanged after the ID fix.
    """
    from conv_profile import build_z_limit_chart

    stock_dia = round(stock_dia, 4)
    doc = round(doc, 4)
    fin_doc = round(fin_doc, 4)

    target_dia = round(stock_dia * target_frac, 4)
    assume(target_dia >= 0.5)

    fin_allowance = fin_doc  # 1 finish pass
    min_target_d = target_dia + fin_allowance * 2

    # Need at least 3 roughing passes
    assume(stock_dia - doc * 2 * 3 > min_target_d)

    z_start = 0.1
    z_end = -2.0

    # OD profile: face from stock to target, then straight to Z-2.0
    finish_moves = [
        ("LINE", target_dia, 0.0),
        ("LINE", target_dia, z_end),
    ]

    # Build x_levels stepping inward from stock
    x_levels = []
    cd = stock_dia - doc * 2
    while cd > min_target_d:
        x_levels.append(round(cd, 4))
        cd -= doc * 2

    assume(len(x_levels) >= 3)

    z_chart = build_z_limit_chart(finish_moves, stock_dia, z_start,
                                  x_levels, fin_allowance, "OD")

    assert len(z_chart) > 0, (
        f"OD build_z_limit_chart() returned empty dict with "
        f"stock_dia={stock_dia:.4f}, target_dia={target_dia:.4f}, "
        f"doc={doc:.4f}, {len(x_levels)} x_levels."
    )

    # Verify Z limits are in valid range
    for xl, zl in z_chart.items():
        assert z_end <= zl <= z_start, (
            f"OD Z limit at X{xl:.4f} is {zl:.4f}, outside "
            f"valid range [{z_end:.4f}, {z_start:.4f}]"
        )


# ------------------------------------------------------------------
# Preservation Test 2 (PBT): OD roughing pass count
# ------------------------------------------------------------------

@settings(max_examples=10, deadline=None,
          suppress_health_check=[HealthCheck.filter_too_much])
@given(
    stock_dia=floats(min_value=2.0, max_value=4.0, allow_nan=False, allow_infinity=False),
    doc=floats(min_value=0.020, max_value=0.060, allow_nan=False, allow_infinity=False),
    target_frac=floats(min_value=0.3, max_value=0.6, allow_nan=False, allow_infinity=False),
)
def test_preservation_od_roughing_pass_count(stock_dia, doc, target_frac):
    """PBT: OD taper profiles generate roughing passes with correct Z limits from chart.

    **Validates: Requirements 3.1, 3.6**

    For random OD profiles, verify roughing passes are generated and each
    pass has a valid Z limit from the point chart. This behavior must remain
    unchanged after the ID fix.
    """
    stock_dia = round(stock_dia, 4)
    doc = round(doc, 4)

    target_dia = round(stock_dia * target_frac, 4)
    assume(target_dia >= 0.5)

    fin_doc = 0.002
    fin_allowance = fin_doc
    min_target_d = target_dia + fin_allowance * 2

    # Need at least 3 roughing passes
    assume(stock_dia - doc * 2 * 3 > min_target_d)

    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="OD",
        stock_dia=f"{stock_dia:.4f}",
        x_start=f"{stock_dia:.4f}",
        z_start="0.1",
        doc=f"{doc:.4f}",
        fin_passes="1",
        fin_doc=f"{fin_doc:.4f}",
        feed_r="0.005",
        feed_f="0.003",
        retract="0.050",
        rough_tool="1",
        finish_tool="1",
        rpm="1200",
        safe_x=f"{stock_dia + 1.0:.4f}",
        safe_z="1.000",
    )

    # Face from stock to target, then straight bore to Z-2.0
    _add_segments(blk, [
        {"x_end": f"{target_dia:.4f}", "z_end": "0.000"},
        {"x_end": f"{target_dia:.4f}", "z_end": "-2.000"},
    ])

    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    # Count roughing passes
    roughing_pass_lines = [
        line for line in gcode.split("\n")
        if re.match(r'\s*G00\s+X[+-]?\d+\.?\d*\s+Z[+-]?\d+\.?\d*\s+\(Pass\s+\d+', line.strip())
    ]
    assume(len(roughing_pass_lines) >= 3)

    # Verify each pass has a chart reference in its comment
    for line in roughing_pass_lines:
        assert "chart:" in line, (
            f"OD roughing pass missing chart reference: {line.strip()}"
        )


# ------------------------------------------------------------------
# Preservation Test 3 (Deterministic): OD point chart debug comments
# ------------------------------------------------------------------

def test_preservation_od_point_chart_comments():
    """OD G-code must include point chart debug comments with correct format.

    **Validates: Requirements 3.2**

    Generate OD G-code with a face+cylinder profile and verify that
    `; --- Point Chart` comments appear with `; X{value} -> Z{value}` entries.
    """
    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="OD",
        stock_dia="2.500",
        x_start="2.500",
        z_start="0.1",
        doc="0.050",
        fin_passes="1",
        fin_doc="0.002",
        feed_r="0.005",
        feed_f="0.003",
        retract="0.050",
        rough_tool="1",
        finish_tool="1",
        rpm="1200",
        safe_x="3.500",
        safe_z="1.000",
    )

    # Face from stock to X1.0, then straight to Z-2.0
    _add_segments(blk, [
        {"x_end": "1.000", "z_end": "0.000"},
        {"x_end": "1.000", "z_end": "-2.000"},
    ])

    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    # Check point chart header
    assert "; --- Point Chart (cleanup arc Z at each roughing X) ---" in gcode, (
        "Expected '; --- Point Chart (cleanup arc Z at each roughing X) ---' "
        "in OD G-code output, but not found."
    )

    # Check individual point chart entries
    point_chart_entries = [
        line for line in gcode.split("\n")
        if line.strip().startswith(";   X") and "-> Z" in line
    ]
    assert len(point_chart_entries) >= 1, (
        "Expected at least 1 point chart entry (';   X... -> Z...') "
        "in OD G-code output, but found none."
    )

    # Verify format: ;   X{float} -> Z{float}
    for entry in point_chart_entries:
        m = re.match(r'\s*;\s+X([+-]?\d+\.\d{4})\s+->\s+Z([+-]?\d+\.\d{4})', entry)
        assert m is not None, (
            f"Point chart entry has wrong format: '{entry.strip()}'. "
            f"Expected ';   X{{value}} -> Z{{value}}' with 4 decimal places."
        )


# ------------------------------------------------------------------
# Preservation Test 4 (Deterministic): OD _on_mode_changed
# ------------------------------------------------------------------

def test_preservation_od_mode_fields():
    """OD mode: stock_dia_label, x_start tooltip, and safe_x are OD-appropriate.

    **Validates: Requirements 3.3**

    When in OD mode (default), verify:
    - stock_dia_label says "Stock Dia:"
    - x_start tooltip contains "0 for face start"
    - safe_x is a large value (outside stock)
    """
    blk = _make_profile_block()

    # Default mode is OD
    assert blk.cmb_mode.currentText() == "OD", (
        f"Expected default mode to be 'OD', got '{blk.cmb_mode.currentText()}'"
    )

    # stock_dia_label
    assert blk.stock_dia_label.text() == "Stock Dia:", (
        f"Expected stock_dia_label='Stock Dia:' in OD mode, "
        f"got '{blk.stock_dia_label.text()}'"
    )

    # x_start tooltip should contain OD-appropriate text
    tooltip = blk.x_start.toolTip()
    assert "0 for face start" in tooltip, (
        f"Expected x_start tooltip to contain '0 for face start' in OD mode, "
        f"got '{tooltip}'"
    )

    # safe_x should be a reasonable OD value (default is 3.000)
    safe_x_val = float(blk.safe_x.text())
    assert safe_x_val >= 1.0, (
        f"Expected safe_x >= 1.0 in OD mode, got {safe_x_val}"
    )


# ------------------------------------------------------------------
# Preservation Test 5 (Deterministic): G-code header format
# ------------------------------------------------------------------

def test_preservation_gcode_header_format():
    """OD G-code header must contain preamble, tool change, G43, safe move, M2.

    **Validates: Requirements 3.7**

    Generate OD G-code and verify the preamble contains:
    - G20 G18 G40 G49 G80
    - G90
    - Tool change (T{n} M6)
    - G43 (tool length compensation)
    - Safe position move
    - M2 (program end)
    """
    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="OD",
        stock_dia="2.000",
        x_start="2.000",
        z_start="0.1",
        doc="0.030",
        fin_passes="1",
        fin_doc="0.002",
        feed_r="0.005",
        feed_f="0.003",
        retract="0.100",
        rough_tool="3",
        finish_tool="3",
        rpm="1200",
        safe_x="3.000",
        safe_z="1.000",
    )

    _add_segments(blk, [
        {"x_end": "1.000", "z_end": "0.000"},
        {"x_end": "1.000", "z_end": "-2.000"},
    ])

    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    # Preamble
    assert "G20 G18 G40 G49 G80" in gcode, "Missing G20 G18 G40 G49 G80 preamble"
    assert "G90" in gcode, "Missing G90 (absolute positioning)"

    # Tool change
    assert "T3 M6" in gcode, "Missing tool change T3 M6"

    # Tool length compensation
    assert "G43" in gcode, "Missing G43 (tool length compensation)"

    # Safe position move
    assert "G00 X3.0000 Z1.0000" in gcode, "Missing safe position move"

    # Program end
    assert "M2" in gcode, "Missing M2 program end"

    # Header comments should contain stock info
    header_lines = []
    for line in gcode.split("\n"):
        if line.strip().startswith("G20 G18"):
            break
        if line.strip().startswith(";"):
            header_lines.append(line.strip())

    header_text = "\n".join(header_lines)
    assert "2.0000" in header_text, "Stock diameter not in header"
    assert "T3" in header_text, "Tool number not in header"
    assert "0.005" in header_text, "Roughing feed not in header"
    assert "1200" in header_text, "RPM not in header"


# ------------------------------------------------------------------
# Preservation Test 6 (PBT): Cleanup pass preservation
# ------------------------------------------------------------------

@settings(max_examples=10, deadline=None,
          suppress_health_check=[HealthCheck.filter_too_much])
@given(
    stock_dia=floats(min_value=1.5, max_value=4.0, allow_nan=False, allow_infinity=False),
    retract_d=floats(min_value=0.020, max_value=0.100, allow_nan=False, allow_infinity=False),
    doc=floats(min_value=0.020, max_value=0.060, allow_nan=False, allow_infinity=False),
    target_frac=floats(min_value=0.2, max_value=0.5, allow_nan=False, allow_infinity=False),
)
def test_preservation_od_cleanup_pass(stock_dia, retract_d, doc, target_frac):
    """PBT: OD cleanup pass approach/retract X equals x_clear = stock_d + retract_d.

    **Validates: Requirements 3.4**

    For random OD profiles, verify the cleanup pass approach and retract X
    values equal x_clear (full stock-boundary clearance). This behavior must
    remain unchanged after the ID fix.
    """
    stock_dia = round(stock_dia, 4)
    retract_d = round(retract_d, 4)
    doc = round(doc, 4)

    target_dia = round(stock_dia * target_frac, 4)
    assume(target_dia >= 0.5)

    fin_doc = 0.002
    min_target_d = target_dia + fin_doc * 2
    assume(stock_dia - doc * 2 > min_target_d)

    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="OD",
        stock_dia=f"{stock_dia:.4f}",
        x_start=f"{stock_dia:.4f}",
        z_start="0.1",
        doc=f"{doc:.4f}",
        fin_passes="1",
        fin_doc=f"{fin_doc:.4f}",
        feed_r="0.005",
        feed_f="0.003",
        retract=f"{retract_d:.4f}",
        rough_tool="1",
        finish_tool="1",
        rpm="1200",
        safe_x=f"{stock_dia + 1.0:.4f}",
        safe_z="1.000",
    )

    _add_segments(blk, [
        {"x_end": f"{target_dia:.4f}", "z_end": "0.000"},
        {"x_end": f"{target_dia:.4f}", "z_end": "-2.000"},
    ])

    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    x_clear = round(stock_dia + retract_d, 4)
    cleanup = _parse_cleanup_pass_x_values(gcode)

    assert cleanup["approach_x"] is not None, "No cleanup pass approach found"
    assert cleanup["retract_x"] is not None, "No cleanup pass retract found"

    assert abs(cleanup["approach_x"] - x_clear) < 0.0001, (
        f"OD cleanup approach_x={cleanup['approach_x']:.4f}, "
        f"expected x_clear={x_clear:.4f}"
    )
    assert abs(cleanup["retract_x"] - x_clear) < 0.0001, (
        f"OD cleanup retract_x={cleanup['retract_x']:.4f}, "
        f"expected x_clear={x_clear:.4f}"
    )


# ------------------------------------------------------------------
# Preservation Test 7 (PBT): Finish pass preservation
# ------------------------------------------------------------------

@settings(max_examples=10, deadline=None,
          suppress_health_check=[HealthCheck.filter_too_much])
@given(
    stock_dia=floats(min_value=1.5, max_value=4.0, allow_nan=False, allow_infinity=False),
    retract_d=floats(min_value=0.020, max_value=0.100, allow_nan=False, allow_infinity=False),
    doc=floats(min_value=0.020, max_value=0.060, allow_nan=False, allow_infinity=False),
    target_frac=floats(min_value=0.2, max_value=0.5, allow_nan=False, allow_infinity=False),
)
def test_preservation_od_finish_pass(stock_dia, retract_d, doc, target_frac):
    """PBT: OD finish pass retract X equals x_clear = stock_d + retract_d.

    **Validates: Requirements 3.5**

    For random OD profiles, verify the finish pass retract X value equals
    x_clear (full stock-boundary clearance). This behavior must remain
    unchanged after the ID fix.
    """
    stock_dia = round(stock_dia, 4)
    retract_d = round(retract_d, 4)
    doc = round(doc, 4)

    target_dia = round(stock_dia * target_frac, 4)
    assume(target_dia >= 0.5)

    fin_doc = 0.002
    min_target_d = target_dia + fin_doc * 2
    assume(stock_dia - doc * 2 > min_target_d)

    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="OD",
        stock_dia=f"{stock_dia:.4f}",
        x_start=f"{stock_dia:.4f}",
        z_start="0.1",
        doc=f"{doc:.4f}",
        fin_passes="1",
        fin_doc=f"{fin_doc:.4f}",
        feed_r="0.005",
        feed_f="0.003",
        retract=f"{retract_d:.4f}",
        rough_tool="1",
        finish_tool="1",
        rpm="1200",
        safe_x=f"{stock_dia + 1.0:.4f}",
        safe_z="1.000",
    )

    _add_segments(blk, [
        {"x_end": f"{target_dia:.4f}", "z_end": "0.000"},
        {"x_end": f"{target_dia:.4f}", "z_end": "-2.000"},
    ])

    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    x_clear = round(stock_dia + retract_d, 4)
    retract_x = _parse_finish_pass_retract_x(gcode)

    assert retract_x is not None, "No finish pass retract found"

    assert abs(retract_x - x_clear) < 0.0001, (
        f"OD finish pass retract_x={retract_x:.4f}, "
        f"expected x_clear={x_clear:.4f}"
    )
