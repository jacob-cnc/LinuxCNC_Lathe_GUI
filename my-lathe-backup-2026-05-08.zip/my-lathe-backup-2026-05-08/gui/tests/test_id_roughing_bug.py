# Bugfix: id-roughing-z-interval-fix, Property 1: Bug Condition Exploration
"""
Bug condition exploration tests for ID roughing Z interval coverage.

These tests verify that `build_z_interval_chart()` returns Z intervals that
correspond to material zones (where boundary_x > cutting_x for ID mode).

**Validates: Requirements 1.1, 1.2, 2.1, 2.2**

On UNFIXED code, these tests were EXPECTED TO FAIL — failure confirmed the bug
exists. Now that the fix is implemented via build_z_interval_chart(), these
tests validate the correct behavior.
"""

import sys
import os
import math

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from hypothesis import given, settings, assume, HealthCheck
from hypothesis.strategies import floats, integers

from conv_profile import build_z_interval_chart


# ------------------------------------------------------------------
# Helper: interpolate boundary X at a given Z along the cleanup boundary
# ------------------------------------------------------------------

def _build_cleanup_segments(finish_moves, x_start_d, z_start, fin_allowance, mode="ID"):
    """Build cleanup boundary segments the same way build_z_interval_chart does."""
    offset_d = fin_allowance * 2
    if mode == "OD":
        cp_start_x = x_start_d + offset_d
    else:
        cp_start_x = x_start_d - offset_d

    segments = []
    prev_x, prev_z = cp_start_x, z_start
    for mv in finish_moves:
        if mv[0] == "LINE":
            ox = mv[1] + offset_d if mode == "OD" else mv[1] - offset_d
            oz = mv[2] + fin_allowance
            segments.append(("LINE", prev_x, prev_z, ox, oz))
            prev_x, prev_z = ox, oz
        elif mv[0] == "ARC":
            ox = mv[1] + offset_d if mode == "OD" else mv[1] - offset_d
            oz = mv[2] + fin_allowance
            segments.append(("ARC", prev_x, prev_z, ox, oz, mv[3]))
            prev_x, prev_z = ox, oz
    return segments


def _interpolate_boundary_x_at_z(segments, z_query):
    """Interpolate the boundary X at a given Z value along LINE segments.

    Returns the boundary X at z_query, or None if z_query is outside
    all segments.
    """
    for seg in segments:
        if seg[0] != "LINE":
            continue
        x1, z1, x2, z2 = seg[1], seg[2], seg[3], seg[4]
        z_lo = min(z1, z2)
        z_hi = max(z1, z2)
        if z_lo - 1e-9 <= z_query <= z_hi + 1e-9:
            if abs(z2 - z1) < 1e-9:
                return (x1 + x2) / 2.0
            t = (z_query - z1) / (z2 - z1)
            t = max(0.0, min(1.0, t))
            return x1 + t * (x2 - x1)
    return None


def _is_material_at_z(segments, z_query, cutting_x, mode="ID"):
    """Check if material exists at z_query for the given cutting_x.

    For ID mode: material exists where boundary_x > cutting_x.
    The boundary represents the finished bore profile. When boundary_x > cutting_x,
    the finished bore is wider than where we're cutting, meaning material exists
    between the tool (at cutting_x) and the bore wall (at boundary_x).

    This matches the code's "safe" check: safe = x > current_d (for ID).
    "Safe" means the boundary is farther from center than the tool — material
    exists there and the tool needs to remove it.

    For OD mode: material exists where boundary_x < cutting_x.

    Note: At the exact crossing point (boundary_x == cutting_x), we consider
    this as the boundary of the material zone (material exists at or beyond).
    """
    boundary_x = _interpolate_boundary_x_at_z(segments, z_query)
    if boundary_x is None:
        return False
    if mode == "ID":
        return boundary_x >= cutting_x - 1e-6
    else:
        return boundary_x <= cutting_x + 1e-6


# ------------------------------------------------------------------
# Test 1: Widening bore — intervals cover material zones correctly
# ------------------------------------------------------------------

def test_widening_bore_z_limit_in_material():
    """Widening bore: Z intervals must cover only material zones.

    **Validates: Requirements 1.1, 2.1**

    Profile: X=0.5 at Z=0 to X=1.0 at Z=-1.0 (bore widens as Z decreases).
    finish_moves = [("LINE", 1.0, -1.0)]
    x_start_d = 0.5, z_start = 0.1

    At roughing X=0.7:
    - The crossing point is at Z ≈ -0.4 (where boundary X = 0.7)
    - Material exists from Z≈-0.4 to Z=-1.0 (far side, where boundary > 0.7)
    - Empty space from Z=0.1 to Z≈-0.4 (near side, where boundary < 0.7)

    The fixed code should return intervals that only cover material zones.
    """
    finish_moves = [("LINE", 1.0, -1.0)]
    x_start_d = 0.5
    z_start = 0.1
    fin_allowance = 0.002
    x_levels = [0.7]

    z_interval_chart = build_z_interval_chart(finish_moves, x_start_d, z_start,
                                              x_levels, fin_allowance)

    # The function should return intervals for X=0.7
    assert 0.7 in z_interval_chart, (
        f"build_z_interval_chart() returned no intervals for X=0.7. "
        f"Chart: {z_interval_chart}"
    )

    intervals = z_interval_chart[0.7]
    assert len(intervals) >= 1, (
        f"build_z_interval_chart() returned empty intervals for X=0.7."
    )

    # Build the cleanup boundary segments to verify material location
    segments = _build_cleanup_segments(finish_moves, x_start_d, z_start,
                                       fin_allowance, "ID")

    # For each interval, ALL points within it should have material
    cutting_x = 0.7
    for z_begin, z_end in intervals:
        n_samples = 10
        z_min = min(z_begin, z_end)
        z_max = max(z_begin, z_end)

        empty_count = 0
        for i in range(n_samples + 1):
            z_sample = z_min + (z_max - z_min) * i / n_samples
            if not _is_material_at_z(segments, z_sample, cutting_x, "ID"):
                empty_count += 1

        assert empty_count == 0, (
            f"INTERVAL ERROR: At X=0.7, interval [{z_begin:.4f}, {z_end:.4f}] "
            f"has {empty_count}/{n_samples+1} points with NO material. "
            f"Intervals should only cover material zones."
        )


# ------------------------------------------------------------------
# Test 2: Multi-zone bore — multiple material zones identified
# ------------------------------------------------------------------

def test_multi_zone_bore_coverage():
    """Multi-zone bore: must identify all material zones.

    **Validates: Requirements 1.2, 2.2**

    Profile: X=0.5 → X=1.0 → X=0.6 → X=1.2
    finish_moves = [("LINE", 1.0, -1.0), ("LINE", 0.6, -1.5), ("LINE", 1.2, -2.5)]
    x_start_d = 0.5, z_start = 0.1

    At roughing X=0.8:
    - Multiple material zones exist due to the complex profile shape.
    - The fixed code should return multiple intervals covering all zones.
    """
    finish_moves = [
        ("LINE", 1.0, -1.0),
        ("LINE", 0.6, -1.5),
        ("LINE", 1.2, -2.5),
    ]
    x_start_d = 0.5
    z_start = 0.1
    fin_allowance = 0.002
    cutting_x = 0.8
    x_levels = [cutting_x]

    z_interval_chart = build_z_interval_chart(finish_moves, x_start_d, z_start,
                                              x_levels, fin_allowance)

    # Build cleanup segments to find all material zones
    segments = _build_cleanup_segments(finish_moves, x_start_d, z_start,
                                       fin_allowance, "ID")

    # The function should return intervals for this X level
    assert cutting_x in z_interval_chart, (
        f"build_z_interval_chart() returned no intervals for X={cutting_x}. "
        f"Chart: {z_interval_chart}"
    )

    intervals = z_interval_chart[cutting_x]

    # There should be multiple intervals for this complex profile
    assert len(intervals) >= 2, (
        f"Expected at least 2 intervals for multi-zone bore at X={cutting_x}, "
        f"but found {len(intervals)} intervals: {intervals}. "
        f"The complex profile should produce multiple material zones."
    )

    # Verify all intervals are in material zones
    for z_begin, z_end in intervals:
        n_samples = 10
        z_min = min(z_begin, z_end)
        z_max = max(z_begin, z_end)

        for i in range(n_samples + 1):
            z_sample = z_min + (z_max - z_min) * i / n_samples
            has_material = _is_material_at_z(segments, z_sample, cutting_x, "ID")
            assert has_material, (
                f"INTERVAL ERROR: At X={cutting_x}, interval [{z_begin:.4f}, {z_end:.4f}] "
                f"has no material at Z={z_sample:.4f}. "
                f"Intervals should only cover material zones."
            )

    # Verify that the intervals cover all material zones by sampling
    z_min_total = -2.5 + fin_allowance
    z_max_total = z_start
    n_samples = 50
    missed_material = []

    for i in range(n_samples + 1):
        z_sample = z_max_total - (z_max_total - z_min_total) * i / n_samples
        has_material = _is_material_at_z(segments, z_sample, cutting_x, "ID")
        if has_material:
            # Check if this point is covered by any interval
            covered = False
            for z_begin, z_end in intervals:
                iv_min = min(z_begin, z_end)
                iv_max = max(z_begin, z_end)
                if iv_min - 0.02 <= z_sample <= iv_max + 0.02:
                    covered = True
                    break
            if not covered:
                missed_material.append(z_sample)

    assert len(missed_material) == 0, (
        f"COVERAGE ERROR: At X={cutting_x}, {len(missed_material)} material points "
        f"are not covered by any interval: {[f'Z={z:.4f}' for z in missed_material[:5]]}. "
        f"Intervals: {intervals}"
    )


# ------------------------------------------------------------------
# Test 3: Simple widening bore (user's actual failing case)
# ------------------------------------------------------------------

def test_simple_widening_bore_wrong_side():
    """Simple widening bore: intervals must be on the correct side.

    **Validates: Requirements 1.1, 2.1**

    Profile: X=0.25 at Z=0 to X=0.5 at Z=-0.75 (matches user's actual case).
    finish_moves = [("LINE", 0.5, -0.75)]
    x_start_d = 0.25, z_start = 0.1

    At roughing X=0.35:
    - Crossing at Z ≈ -0.3 (where boundary X = 0.35)
    - Material exists from Z≈-0.3 to Z=-0.75 (far side)
    - Empty space from Z=0.1 to Z≈-0.3 (near side)

    The fixed code should return an interval on the far side (material zone).
    """
    finish_moves = [("LINE", 0.5, -0.75)]
    x_start_d = 0.25
    z_start = 0.1
    fin_allowance = 0.002
    cutting_x = 0.35
    x_levels = [cutting_x]

    z_interval_chart = build_z_interval_chart(finish_moves, x_start_d, z_start,
                                              x_levels, fin_allowance)

    assert cutting_x in z_interval_chart, (
        f"build_z_interval_chart() returned no intervals for X={cutting_x}. "
        f"Chart: {z_interval_chart}"
    )

    intervals = z_interval_chart[cutting_x]
    assert len(intervals) >= 1, (
        f"build_z_interval_chart() returned empty intervals for X={cutting_x}."
    )

    # Build cleanup segments
    segments = _build_cleanup_segments(finish_moves, x_start_d, z_start,
                                       fin_allowance, "ID")

    # For each interval, ALL points should have material
    for z_begin, z_end in intervals:
        n_samples = 10
        z_min = min(z_begin, z_end)
        z_max = max(z_begin, z_end)

        empty_points = []
        for i in range(n_samples + 1):
            z_sample = z_min + (z_max - z_min) * i / n_samples
            if not _is_material_at_z(segments, z_sample, cutting_x, "ID"):
                empty_points.append(z_sample)

        assert len(empty_points) == 0, (
            f"INTERVAL ERROR: At X={cutting_x}, interval [{z_begin:.4f}, {z_end:.4f}] "
            f"passes through {len(empty_points)} empty-space points: "
            f"{[f'Z={z:.4f}' for z in empty_points[:5]]}. "
            f"The bore widens from X={x_start_d} to X=0.5, so material is on the "
            f"FAR side of the crossing (toward Z=-0.75)."
        )

    # Verify the interval does NOT start at z_start (it should start at the crossing)
    first_interval_start = max(intervals[0][0], intervals[0][1])  # more positive Z
    assert first_interval_start < z_start - 0.05, (
        f"For a widening bore, the interval should NOT start at z_start={z_start}. "
        f"It should start at the crossing point (where material begins). "
        f"Got interval start at Z={first_interval_start:.4f}."
    )


# ------------------------------------------------------------------
# Test 4 (PBT): Random widening bore profiles — intervals in material
# ------------------------------------------------------------------

@settings(max_examples=50, deadline=None,
          suppress_health_check=[HealthCheck.filter_too_much])
@given(
    x_start_d=floats(min_value=0.2, max_value=0.8, allow_nan=False, allow_infinity=False),
    x_end_mult=floats(min_value=1.5, max_value=3.0, allow_nan=False, allow_infinity=False),
    z_end=floats(min_value=-2.0, max_value=-0.5, allow_nan=False, allow_infinity=False),
    cutting_frac=floats(min_value=0.2, max_value=0.8, allow_nan=False, allow_infinity=False),
)
def test_pbt_widening_bore_z_limit_in_material(x_start_d, x_end_mult, z_end, cutting_frac):
    """PBT: For random widening bore profiles, intervals must be in material zones.

    **Validates: Requirements 1.1, 2.1**

    Generates random widening bore profiles (x_end > x_start) and verifies
    that the returned Z intervals correspond to material zones only.

    For ID mode: material exists where boundary_x > cutting_x.

    For a widening bore (boundary goes from small X to large X):
    - Near z_start: boundary is small, boundary_x < cutting_x → no material
    - Near z_end: boundary is large, boundary_x > cutting_x → material exists

    The interval should start at the crossing (not at z_start) and extend
    to the back wall.
    """
    x_start_d = round(x_start_d, 4)
    x_end = round(x_start_d * x_end_mult, 4)
    z_end = round(z_end, 4)
    z_start = 0.1
    fin_allowance = 0.002

    # Cutting X is between x_start and x_end (in the widening range)
    cutting_x = round(x_start_d + (x_end - x_start_d) * cutting_frac, 4)

    # Ensure cutting_x is meaningfully between start and end
    assume(cutting_x > x_start_d + 0.05)
    assume(cutting_x < x_end - 0.05)

    finish_moves = [("LINE", x_end, z_end)]
    x_levels = [cutting_x]

    z_interval_chart = build_z_interval_chart(finish_moves, x_start_d, z_start,
                                              x_levels, fin_allowance)

    # Must return intervals for this X level
    assume(cutting_x in z_interval_chart)

    intervals = z_interval_chart[cutting_x]
    assume(len(intervals) >= 1)

    # Build cleanup segments
    segments = _build_cleanup_segments(finish_moves, x_start_d, z_start,
                                       fin_allowance, "ID")

    # For each interval, ALL points must have material (boundary_x > cutting_x)
    for z_begin, z_end_iv in intervals:
        z_min = min(z_begin, z_end_iv)
        z_max = max(z_begin, z_end_iv)

        # Skip degenerate intervals
        assume(z_max - z_min > 0.01)

        # Sample points within the interval
        n_samples = 5
        for i in range(n_samples + 1):
            z_sample = z_min + (z_max - z_min) * i / n_samples
            boundary_x = _interpolate_boundary_x_at_z(segments, z_sample)
            if boundary_x is not None:
                assert boundary_x > cutting_x - 0.01, (
                    f"INTERVAL ERROR: At X={cutting_x:.4f}, interval "
                    f"[{z_begin:.4f}, {z_end_iv:.4f}], at Z={z_sample:.4f}, "
                    f"boundary_x={boundary_x:.4f} <= cutting_x={cutting_x:.4f}. "
                    f"No material exists there — interval is incorrect. "
                    f"Profile: x_start={x_start_d:.4f}, x_end={x_end:.4f}, z_end={z_end:.4f}."
                )
