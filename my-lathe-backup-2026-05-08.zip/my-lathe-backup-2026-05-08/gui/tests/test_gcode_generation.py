# Feature: threading-conv-block, Properties 5-11, 13: G-code generation tests
"""
Property-based tests for ThreadingBlock.generate_gcode():
  - Property 5:  Pitch conversion round-trip
  - Property 6:  G76 parameter completeness
  - Property 7:  Multi-start G76 generation
  - Property 8:  Clearance positioning
  - Property 9:  Lead-in/lead-out Z travel
  - Property 10: RPM appears only in comments
  - Property 11: G-code contains section comments
  - Property 13: Invalid numeric input produces error comment
"""

import sys
import os
import re

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from hypothesis import given, settings, assume
from hypothesis.strategies import (
    sampled_from, floats, integers, text, one_of, just, composite,
)

from PyQt5.QtWidgets import QApplication

_app = None


def _get_app():
    global _app
    if _app is None:
        _app = QApplication.instance() or QApplication(sys.argv)
    return _app


def _make_block():
    _get_app()
    from conv_profile import ThreadingBlock
    return ThreadingBlock(block_num=1)


def _set_fields(blk, **kwargs):
    """Set ThreadingBlock fields from keyword arguments."""
    field_map = {
        "major_d": blk.inp_major_d,
        "minor_d": blk.inp_minor_d,
        "pitch_d": blk.inp_pitch_d,
        "pitch_tpi": blk.inp_pitch_tpi,
        "z_start": blk.inp_z_start,
        "thread_length": blk.inp_thread_length,
        "lead_in": blk.inp_lead_in,
        "lead_out": blk.inp_lead_out,
        "first_doc": blk.inp_first_doc,
        "min_doc": blk.inp_min_doc,
        "spring_passes": blk.inp_spring_passes,
        "compound_angle": blk.inp_compound_angle,
        "degression": blk.inp_degression,
        "num_starts": blk.inp_num_starts,
        "tool_num": blk.inp_tool_num,
        "rpm": blk.inp_rpm,
    }
    for k, v in kwargs.items():
        if k == "thread_type":
            idx = blk.cmb_thread_type.findText(v)
            if idx >= 0:
                blk.cmb_thread_type.setCurrentIndex(idx)
        elif k in field_map:
            field_map[k].setText(str(v))


def _valid_external_block(**overrides):
    """Create a block with valid external threading defaults."""
    blk = _make_block()
    defaults = dict(
        major_d="0.5000", minor_d="0.4056", pitch_d="0.4500",
        pitch_tpi="13", z_start="0.000", thread_length="1.000",
        lead_in="0.100", lead_out="0.050", first_doc="0.010",
        min_doc="0.002", spring_passes="2", compound_angle="29.5",
        degression="1.0", num_starts="1", tool_num="4", rpm="400",
    )
    defaults.update(overrides)
    _set_fields(blk, **defaults)
    return blk


def _parse_g76_lines(gcode):
    """Extract all G76 lines from generated G-code."""
    return [line for line in gcode.split("\n") if line.strip().startswith("G76")]


def _parse_param(line, param):
    """Parse a named parameter value from a G76 line."""
    match = re.search(rf'{param}([+-]?\d+\.?\d*)', line)
    return float(match.group(1)) if match else None


# ------------------------------------------------------------------
# Property 5: Pitch conversion round-trip
# ------------------------------------------------------------------

@settings(max_examples=100, deadline=None)
@given(tpi=integers(min_value=4, max_value=80))
def test_pitch_conversion_roundtrip_tpi(tpi):
    """TPI → G-code P parameter → inches/rev matches 1/TPI."""
    blk = _valid_external_block(pitch_tpi=str(tpi))
    gcode = blk.generate_gcode()
    g76_lines = _parse_g76_lines(gcode)
    assert len(g76_lines) >= 1, "No G76 line found"
    p_val = _parse_param(g76_lines[0], "P")
    assert p_val is not None, "P parameter not found"
    expected = 1.0 / tpi
    assert abs(p_val - expected) < 1e-5, (
        f"TPI {tpi}: P={p_val}, expected {expected}"
    )


@settings(max_examples=100, deadline=None)
@given(pitch_mm=floats(min_value=0.5, max_value=6.0, allow_nan=False, allow_infinity=False))
def test_pitch_conversion_roundtrip_metric(pitch_mm):
    """mm pitch → G-code P parameter → inches/rev matches mm/25.4."""
    blk = _make_block()
    # Select a metric preset to set the entry context, then override pitch
    import thread_data
    metric_entries = thread_data.get_threads_for_family("Metric")
    assume(len(metric_entries) > 0)
    key = metric_entries[0]["key"]
    idx = blk.cmb_preset.findText(key)
    assume(idx >= 0)
    blk.cmb_preset.setCurrentIndex(idx)
    # Override fields for test
    _set_fields(blk,
        pitch_tpi=f"{pitch_mm:.4f}",
        z_start="0.000",
        thread_length="1.000", lead_in="0.100", lead_out="0.050",
        first_doc="0.010", min_doc="0.002", spring_passes="2",
        compound_angle="29.5", degression="1.0", num_starts="1",
        tool_num="4", rpm="400",
    )
    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"Unexpected error: {gcode}"
    g76_lines = _parse_g76_lines(gcode)
    assert len(g76_lines) >= 1
    p_val = _parse_param(g76_lines[0], "P")
    expected = pitch_mm / 25.4
    assert abs(p_val - expected) < 1e-5, (
        f"mm={pitch_mm}: P={p_val}, expected {expected}"
    )


# ------------------------------------------------------------------
# Property 6: G76 parameter completeness
# ------------------------------------------------------------------

@settings(max_examples=100, deadline=None)
@given(
    tpi=integers(min_value=4, max_value=80),
    length=floats(min_value=0.1, max_value=5.0, allow_nan=False, allow_infinity=False),
)
def test_g76_parameter_completeness(tpi, length):
    """G76 line contains all required parameters: P, Z, I, J, K, Q, H, R."""
    blk = _valid_external_block(pitch_tpi=str(tpi), thread_length=f"{length:.4f}")
    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"Unexpected error: {gcode}"
    g76_lines = _parse_g76_lines(gcode)
    assert len(g76_lines) >= 1
    line = g76_lines[0]
    for param in ["P", "Z", "I", "J", "K", "Q", "H", "R"]:
        assert _parse_param(line, param) is not None, (
            f"Missing {param} in G76 line: {line}"
        )


# ------------------------------------------------------------------
# Property 7: Multi-start G76 generation
# ------------------------------------------------------------------

@settings(max_examples=100, deadline=None)
@given(num_starts=integers(min_value=2, max_value=8))
def test_multistart_g76_generation(num_starts):
    """num_starts > 1 produces exactly num_starts G76 lines with correct Z offsets."""
    blk = _valid_external_block(num_starts=str(num_starts))
    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"Unexpected error: {gcode}"
    g76_lines = _parse_g76_lines(gcode)
    assert len(g76_lines) == num_starts, (
        f"Expected {num_starts} G76 lines, got {len(g76_lines)}"
    )

    # Verify Z offsets between successive starts
    tpi = 13  # default
    pitch_dist = 1.0 / tpi
    expected_offset = pitch_dist / num_starts

    z_values = [_parse_param(line, "Z") for line in g76_lines]
    for i in range(1, len(z_values)):
        actual_offset = z_values[i - 1] - z_values[i]
        assert abs(actual_offset - expected_offset) < 1e-3, (
            f"Start {i}: Z offset {actual_offset}, expected {expected_offset}"
        )


# ------------------------------------------------------------------
# Property 8: Clearance positioning
# ------------------------------------------------------------------

@settings(max_examples=100, deadline=None)
@given(
    major_d=floats(min_value=0.2, max_value=3.0, allow_nan=False, allow_infinity=False),
)
def test_clearance_positioning_external(major_d):
    """External: X rapid position > major diameter."""
    minor_d = major_d - 0.1  # ensure valid thread depth
    blk = _valid_external_block(
        major_d=f"{major_d:.4f}",
        minor_d=f"{minor_d:.4f}",
        pitch_d=f"{(major_d + minor_d) / 2:.4f}",
    )
    _set_fields(blk, thread_type="External")
    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"Unexpected error: {gcode}"

    # Find G00 X position before G76
    for line in gcode.split("\n"):
        match = re.match(r'G00\s+X([+-]?\d+\.?\d*)', line)
        if match:
            x_pos = float(match.group(1))
            assert x_pos > major_d, (
                f"External: X={x_pos} not > major_d={major_d}"
            )
            break


@settings(max_examples=100, deadline=None)
@given(
    minor_d=floats(min_value=0.2, max_value=3.0, allow_nan=False, allow_infinity=False),
)
def test_clearance_positioning_internal(minor_d):
    """Internal: X rapid position < minor diameter."""
    major_d = minor_d + 0.1
    blk = _valid_external_block(
        major_d=f"{major_d:.4f}",
        minor_d=f"{minor_d:.4f}",
        pitch_d=f"{(major_d + minor_d) / 2:.4f}",
    )
    _set_fields(blk, thread_type="Internal")
    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"Unexpected error: {gcode}"

    for line in gcode.split("\n"):
        match = re.match(r'G00\s+X([+-]?\d+\.?\d*)', line)
        if match:
            x_pos = float(match.group(1))
            assert x_pos < minor_d, (
                f"Internal: X={x_pos} not < minor_d={minor_d}"
            )
            break


# ------------------------------------------------------------------
# Property 9: Lead-in and lead-out in Z travel
# ------------------------------------------------------------------

@settings(max_examples=100, deadline=None)
@given(
    lead_in=floats(min_value=0.01, max_value=1.0, allow_nan=False, allow_infinity=False),
    lead_out=floats(min_value=0.01, max_value=1.0, allow_nan=False, allow_infinity=False),
    thread_length=floats(min_value=0.1, max_value=5.0, allow_nan=False, allow_infinity=False),
    z_start=floats(min_value=-2.0, max_value=2.0, allow_nan=False, allow_infinity=False),
)
def test_lead_in_lead_out_z_travel(lead_in, lead_out, thread_length, z_start):
    """Z start pos = z_start + lead_in, G76 Z = z_start - length - lead_out."""
    blk = _valid_external_block(
        lead_in=f"{lead_in:.4f}",
        lead_out=f"{lead_out:.4f}",
        thread_length=f"{thread_length:.4f}",
        z_start=f"{z_start:.4f}",
    )
    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"Unexpected error: {gcode}"

    # Z start position from G00 before G76
    z_rapid = None
    for line in gcode.split("\n"):
        match = re.match(r'G00\s+X[+-]?\d+\.?\d*\s+Z([+-]?\d+\.?\d*)', line)
        if match:
            z_rapid = float(match.group(1))
            break
    assert z_rapid is not None, "No G00 with Z found"
    expected_z_rapid = z_start + lead_in
    assert abs(z_rapid - expected_z_rapid) < 1e-3, (
        f"Z rapid {z_rapid} != expected {expected_z_rapid}"
    )

    # G76 Z parameter
    g76_lines = _parse_g76_lines(gcode)
    assert len(g76_lines) >= 1
    z_end = _parse_param(g76_lines[0], "Z")
    expected_z_end = z_start - thread_length - lead_out
    assert abs(z_end - expected_z_end) < 1e-3, (
        f"G76 Z={z_end}, expected {expected_z_end}"
    )


# ------------------------------------------------------------------
# Property 10: RPM appears only in comments
# ------------------------------------------------------------------

@settings(max_examples=100, deadline=None)
@given(rpm=integers(min_value=50, max_value=2000))
def test_rpm_comment_only(rpm):
    """RPM value appears in comments but never as an S-word command."""
    blk = _valid_external_block(rpm=str(rpm))
    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"Unexpected error: {gcode}"

    rpm_in_comment = False
    for line in gcode.split("\n"):
        stripped = line.strip()
        # Check for S-word command (not in a comment)
        if not stripped.startswith(";") and re.search(r'\bS\d+', stripped):
            pytest.fail(f"S-word found in non-comment line: {stripped}")
        # Check RPM appears in at least one comment
        if stripped.startswith(";") and str(rpm) in stripped:
            rpm_in_comment = True

    assert rpm_in_comment, f"RPM {rpm} not found in any comment"


# ------------------------------------------------------------------
# Property 11: G-code contains section comments
# ------------------------------------------------------------------

@settings(max_examples=100, deadline=None)
@given(tpi=integers(min_value=4, max_value=80))
def test_gcode_section_comments(tpi):
    """G-code contains comment lines for thread spec, positioning, and cycle."""
    blk = _valid_external_block(pitch_tpi=str(tpi))
    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"Unexpected error: {gcode}"

    comments = [l.strip() for l in gcode.split("\n") if l.strip().startswith(";")]
    comment_text = " ".join(comments).lower()

    assert "threading" in comment_text, "Missing thread specification comment"
    assert "position" in comment_text, "Missing positioning section comment"
    assert "g76" in comment_text.lower() or "cycle" in comment_text, (
        "Missing threading cycle section comment"
    )


# ------------------------------------------------------------------
# Property 13: Invalid numeric input produces error comment
# ------------------------------------------------------------------

_NUMERIC_FIELDS = [
    "major_d", "minor_d", "pitch_d", "pitch_tpi", "z_start",
    "thread_length", "lead_in", "lead_out", "first_doc", "min_doc",
    "spring_passes", "compound_angle", "degression", "num_starts",
    "tool_num", "rpm",
]


@settings(max_examples=100, deadline=None)
@given(
    field=sampled_from(_NUMERIC_FIELDS),
    bad_value=sampled_from(["abc", "", "N/A", "---", "1.2.3"]),
)
def test_invalid_input_error_comment(field, bad_value):
    """Non-numeric input in any required field produces '; ERROR' output."""
    blk = _valid_external_block(**{field: bad_value})
    gcode = blk.generate_gcode()
    assert "; ERROR" in gcode, (
        f"Field {field}={bad_value!r}: expected error, got: {gcode[:200]}"
    )
