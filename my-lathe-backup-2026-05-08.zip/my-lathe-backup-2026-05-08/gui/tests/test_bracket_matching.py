"""Tests for EditGCodeEditor bracket/parenthesis matching (Req 17.1, 17.2).

Tests the static ``_find_matching_bracket`` helper and the
``_match_brackets`` method that produces ExtraSelection highlights.
"""

import os
import sys

import pytest

# Ensure the gui package is importable
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from tabs.edit import EditGCodeEditor


# ---------------------------------------------------------------------------
# _find_matching_bracket — pure logic tests (no Qt widgets needed)
# ---------------------------------------------------------------------------
class TestFindMatchingBracket:
    """Unit tests for EditGCodeEditor._find_matching_bracket."""

    def test_simple_open_paren(self):
        text = "(hello)"
        assert EditGCodeEditor._find_matching_bracket(text, 0, "(") == 6

    def test_simple_close_paren(self):
        text = "(hello)"
        assert EditGCodeEditor._find_matching_bracket(text, 6, ")") == 0

    def test_nested_parens_open(self):
        text = "(a(b)c)"
        # Opening paren at 0 should match closing at 6
        assert EditGCodeEditor._find_matching_bracket(text, 0, "(") == 6

    def test_nested_parens_inner_open(self):
        text = "(a(b)c)"
        # Inner opening paren at 2 should match closing at 4
        assert EditGCodeEditor._find_matching_bracket(text, 2, "(") == 4

    def test_nested_parens_inner_close(self):
        text = "(a(b)c)"
        # Inner closing paren at 4 should match opening at 2
        assert EditGCodeEditor._find_matching_bracket(text, 4, ")") == 2

    def test_unmatched_open(self):
        text = "(hello"
        assert EditGCodeEditor._find_matching_bracket(text, 0, "(") is None

    def test_unmatched_close(self):
        text = "hello)"
        assert EditGCodeEditor._find_matching_bracket(text, 5, ")") is None

    def test_gcode_comment(self):
        """G-code comments use parentheses: (this is a comment)."""
        text = "G0 X1.0 (rapid to start)"
        open_pos = text.index("(")
        close_pos = text.index(")")
        assert EditGCodeEditor._find_matching_bracket(text, open_pos, "(") == close_pos
        assert EditGCodeEditor._find_matching_bracket(text, close_pos, ")") == open_pos

    def test_multiple_comments_on_line(self):
        text = "(comment1) G0 (comment2)"
        # First '(' at 0 matches ')' at 9
        assert EditGCodeEditor._find_matching_bracket(text, 0, "(") == 9
        # Second '(' at 14 matches ')' at 23
        assert EditGCodeEditor._find_matching_bracket(text, 14, "(") == 23

    def test_empty_parens(self):
        text = "()"
        assert EditGCodeEditor._find_matching_bracket(text, 0, "(") == 1
        assert EditGCodeEditor._find_matching_bracket(text, 1, ")") == 0

    def test_multiline_text(self):
        text = "G0 X1\n(comment\nspanning lines)\nG1 Z0"
        open_pos = text.index("(")
        close_pos = text.index(")")
        assert EditGCodeEditor._find_matching_bracket(text, open_pos, "(") == close_pos
