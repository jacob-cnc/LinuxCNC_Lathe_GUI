# Feature: threading-conv-block, Property 2: Preset auto-fill correctness
# Feature: threading-conv-block, Property 3: Fit class options correctness
"""
Property-based tests for ThreadingBlock widget behavior:
  - Property 2: Selecting a preset auto-fills dimension fields correctly
  - Property 3: Fit class options match the family/thread-type mapping

**Validates: Requirements 2.3, 2.5, 3.2, 4.2, 4.3**
"""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from hypothesis import given, settings
from hypothesis.strategies import sampled_from

from PyQt5.QtWidgets import QApplication

import thread_data
from thread_data import THREAD_DATABASE, FAMILY_FIT_CLASSES

# Shared QApplication instance for all widget tests
_app = None


def _get_app():
    global _app
    if _app is None:
        _app = QApplication.instance() or QApplication(sys.argv)
    return _app


def _all_entries():
    entries = []
    for family_entries in THREAD_DATABASE.values():
        entries.extend(family_entries)
    return entries


_ALL_ENTRIES = _all_entries()


def _make_block():
    """Create a fresh ThreadingBlock instance."""
    _get_app()
    from conv_profile import ThreadingBlock
    return ThreadingBlock(block_num=1)


# ------------------------------------------------------------------
# Property 2: Preset auto-fill correctness
# ------------------------------------------------------------------

@settings(max_examples=max(len(_ALL_ENTRIES), 100), deadline=None)
@given(entry=sampled_from(_ALL_ENTRIES))
def test_preset_autofill_correctness(entry):
    """Selecting a preset populates dimension fields with matching
    database values.

    Checks: major_d, minor_d, pitch_d, pitch/TPI, compound angle.
    """
    blk = _make_block()
    key = entry["key"]

    # Find and select the preset
    idx = blk.cmb_preset.findText(key)
    assert idx >= 0, f"Preset {key!r} not found in combo"
    blk.cmb_preset.setCurrentIndex(idx)

    # After tolerance target is applied, dimensions may differ from basic
    # values. Verify they match compute_tolerance_target output instead.
    fit_class = blk.cmb_fit_class.currentText()
    target = blk.cmb_tol_target.currentText()
    thread_type = blk.cmb_thread_type.currentText()

    if fit_class:
        expected = thread_data.compute_tolerance_target(
            entry, fit_class, target, thread_type
        )
        assert float(blk.inp_major_d.text()) == pytest.approx(
            expected["major_d"], abs=1e-4
        ), f"{key}: major_d mismatch"
        assert float(blk.inp_minor_d.text()) == pytest.approx(
            expected["minor_d"], abs=1e-4
        ), f"{key}: minor_d mismatch"
        assert float(blk.inp_pitch_d.text()) == pytest.approx(
            expected["pitch_d"], abs=1e-4
        ), f"{key}: pitch_d mismatch"

    # Pitch/TPI should match raw entry value
    if entry["tpi"] is not None:
        assert blk.inp_pitch_tpi.text() == str(entry["tpi"]), (
            f"{key}: pitch_tpi mismatch"
        )
    elif entry["pitch_mm"] is not None:
        assert float(blk.inp_pitch_tpi.text()) == pytest.approx(
            entry["pitch_mm"], abs=1e-4
        ), f"{key}: pitch_mm mismatch"

    # Compound angle
    assert float(blk.inp_compound_angle.text()) == pytest.approx(
        entry["compound_angle"], abs=0.1
    ), f"{key}: compound_angle mismatch"


# ------------------------------------------------------------------
# Property 3: Fit class options correctness
# ------------------------------------------------------------------

_THREAD_TYPES = ["External", "Internal"]


@settings(max_examples=max(len(_ALL_ENTRIES) * 2, 100), deadline=None)
@given(
    entry=sampled_from(_ALL_ENTRIES),
    thread_type=sampled_from(_THREAD_TYPES),
)
def test_fit_class_options_correctness(entry, thread_type):
    """Fit class combo contains exactly the classes defined for the
    entry's family and selected thread type."""
    blk = _make_block()
    key = entry["key"]

    # Select preset
    idx = blk.cmb_preset.findText(key)
    assert idx >= 0, f"Preset {key!r} not found in combo"
    blk.cmb_preset.setCurrentIndex(idx)

    # Set thread type
    tt_idx = blk.cmb_thread_type.findText(thread_type)
    assert tt_idx >= 0
    blk.cmb_thread_type.setCurrentIndex(tt_idx)

    # Expected fit classes from the mapping
    family = entry["family"]
    expected_classes = FAMILY_FIT_CLASSES.get(family, {}).get(thread_type, [])

    # Actual fit classes in the combo
    actual_classes = [
        blk.cmb_fit_class.itemText(i)
        for i in range(blk.cmb_fit_class.count())
    ]

    assert actual_classes == expected_classes, (
        f"{key} / {thread_type}: fit classes {actual_classes} != "
        f"expected {expected_classes}"
    )
