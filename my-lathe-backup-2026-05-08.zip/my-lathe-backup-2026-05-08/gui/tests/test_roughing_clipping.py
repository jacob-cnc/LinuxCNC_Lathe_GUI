# Bugfix: roughing-profile-clipping, Property 1: Bug Condition Exploration
"""
Bug condition exploration tests for ProfileBlock roughing pass clipping.

These tests verify that roughing G01 Z moves do NOT extend past the Z position
where the profile boundary (offset by finish allowance) crosses the current
roughing X diameter level.

**Validates: Requirements 1.1, 1.2, 1.3, 2.1, 2.2, 2.5**

On UNFIXED code, these tests are EXPECTED TO FAIL — failure confirms the bug
exists (roughing cuts extend past profile crossings).
"""

import sys
import os
import re
import math

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from PyQt5.QtWidgets import QApplication

_app = None


def _get_app():
    global _app
    if _app is None:
        _app = QApplication.instance() or QApplication(sys.argv)
    return _app


def _make_profile_block():
    """Create a fresh ProfileBlock instance (requires QApplication)."""
    _get_app()
    from conv_profile import ProfileBlock
    return ProfileBlock(block_num=1)


def _set_profile_fields(blk, **kwargs):
    """Set ProfileBlock fields from keyword arguments."""
    field_map = {
        "stock_dia": blk.stock_dia,
        "x_start": blk.x_start,
        "z_start": blk.z_start,
        "doc": blk.doc,
        "fin_passes": blk.fin_passes,
        "fin_doc": blk.fin_doc,
        "feed_r": blk.feed_r,
        "feed_f": blk.feed_f,
        "retract": blk.retract,
        "rough_tool": blk.rough_tool,
        "finish_tool": blk.finish_tool,
        "rpm": blk.rpm,
        "safe_x": blk.safe_x,
        "safe_z": blk.safe_z,
    }
    for k, v in kwargs.items():
        if k == "mode":
            idx = blk.cmb_mode.findText(v)
            if idx >= 0:
                blk.cmb_mode.setCurrentIndex(idx)
        elif k in field_map:
            field_map[k].setText(str(v))


def _add_segments(blk, segments):
    """Add profile segments to a ProfileBlock.

    Each segment is a dict with keys: x_end, z_end, and optionally
    is_arc (bool), arc_r (str).
    The block starts with one default segment, so we remove it first.
    """
    # Remove the default segment that was added in __init__
    for seg in list(blk.segments):
        blk.remove_segment(seg)

    for seg_data in segments:
        blk.add_segment()
        seg = blk.segments[-1]
        seg.x_end.setText(str(seg_data["x_end"]))
        seg.z_end.setText(str(seg_data["z_end"]))
        if seg_data.get("is_arc"):
            seg.arc_check.setChecked(True)
            seg.arc_r.setText(str(seg_data.get("arc_r", "")))


def _parse_roughing_g01_z_moves(gcode):
    """Parse roughing G01 Z moves from generated G-code.

    Returns a list of (current_x_dia, z_endpoint) tuples for each roughing
    G01 Z move. We track the current X position from G00 X moves and capture
    G01 Z moves in the roughing section (before the finish pass section).
    """
    lines = gcode.split("\n")
    moves = []
    current_x = None
    in_roughing = False
    in_finish = False

    for line in lines:
        stripped = line.strip()

        # Detect roughing section
        if "Roughing passes" in stripped:
            in_roughing = True
            continue

        # Detect finish section — stop parsing roughing moves
        if "Finish pass" in stripped or "Roughing complete" in stripped:
            in_finish = True
            in_roughing = False

        if in_finish:
            continue

        if not in_roughing:
            continue

        # Track X position from G00 moves
        g00_x = re.match(r'G00\s+X([+-]?\d+\.?\d*)', stripped)
        if g00_x:
            current_x = float(g00_x.group(1))
            continue

        # Also track X from G00 with both X and Z
        g00_xz = re.match(r'G00\s+X([+-]?\d+\.?\d*)\s+Z', stripped)
        if g00_xz:
            current_x = float(g00_xz.group(1))
            continue

        # Capture G01 Z moves (roughing cuts)
        g01_z = re.match(r'G01\s+Z([+-]?\d+\.?\d*)', stripped)
        if g01_z and current_x is not None:
            z_end = float(g01_z.group(1))
            moves.append((current_x, z_end))

    return moves


def _compute_z_crossing(rough_pts, current_d, fin_allowance, mode="OD"):
    """Compute the Z position where the offset profile crosses current_d.

    For OD mode: offset_x = x + fin_allowance * 2
    For ID mode: offset_x = x - fin_allowance * 2

    Returns a list of Z crossing points where the offset profile crosses
    current_d between consecutive points.
    """
    crossings = []
    for j in range(1, len(rough_pts)):
        x1, z1 = rough_pts[j - 1]
        x2, z2 = rough_pts[j]

        if mode == "OD":
            offset_x1 = x1 + fin_allowance * 2
            offset_x2 = x2 + fin_allowance * 2
        else:
            offset_x1 = x1 - fin_allowance * 2
            offset_x2 = x2 - fin_allowance * 2

        # Check if segment crosses current_d
        if (offset_x1 - current_d) * (offset_x2 - current_d) < 0:
            t = (current_d - offset_x1) / (offset_x2 - offset_x1)
            z_cross = z1 + t * (z2 - z1)
            crossings.append(z_cross)

    return crossings


# ------------------------------------------------------------------
# Test 1: OD taper profile — roughing should clip to taper crossing
# ------------------------------------------------------------------

def test_roughing_clips_to_taper_profile():
    """OD taper: roughing G01 Z moves must not extend past profile crossing.

    **Validates: Requirements 1.1, 1.2, 2.1, 2.2**

    Profile: X_start=2.0 Z_start=0.1, taper from (X2.0, Z0.0) to (X1.0, Z-2.0)
    Stock: 2.0 dia, DOC=0.030, fin_passes=1, fin_doc=0.002

    At roughing pass X=1.5 (for example), the offset profile (x + 0.004)
    crosses X=1.5 at approximately Z = -0.996. The roughing G01 at that X
    should NOT extend past that Z crossing point.

    On UNFIXED code, the roughing cut extends to Z-2.0 regardless — this
    test will FAIL, confirming the bug.
    """
    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="OD",
        stock_dia="2.000",
        x_start="2.000",
        z_start="0.1",
        doc="0.030",
        fin_passes="1",
        fin_doc="0.002",
        feed_r="0.005",
        feed_f="0.003",
        retract="0.100",
        rough_tool="1",
        finish_tool="1",
        rpm="1200",
        safe_x="3.000",
        safe_z="1.000",
    )

    # Profile: face to X2.0 Z0.0, then taper to X1.0 Z-2.0
    _add_segments(blk, [
        {"x_end": "2.000", "z_end": "0.000"},
        {"x_end": "1.000", "z_end": "-2.000"},
    ])

    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    # Parse roughing G01 Z moves
    roughing_moves = _parse_roughing_g01_z_moves(gcode)
    assert len(roughing_moves) > 0, "No roughing G01 Z moves found in G-code"

    # Profile points for crossing calculation
    # x_start=2.0, z_start=0.1 -> (2.0, 0.0) -> (1.0, -2.0)
    rough_pts = [(2.0, 0.1), (2.0, 0.0), (1.0, -2.0)]
    fin_allowance = 1 * 0.002  # fin_passes * fin_doc

    violations = []
    for current_x_dia, z_endpoint in roughing_moves:
        crossings = _compute_z_crossing(rough_pts, current_x_dia, fin_allowance, "OD")
        if crossings:
            # The most positive (least negative) crossing is the limit
            z_limit = max(crossings)
            tolerance = 0.005  # small tolerance for rounding
            if z_endpoint < z_limit - tolerance:
                violations.append(
                    f"At X{current_x_dia:.4f}, profile crosses at Z{z_limit:.4f} "
                    f"but roughing G01 extends to Z{z_endpoint:.4f}"
                )

    assert len(violations) == 0, (
        f"Roughing passes extend past profile crossings:\n"
        + "\n".join(violations)
    )


# ------------------------------------------------------------------
# Test 2: Multi-crossing profile — roughing should split into segments
# ------------------------------------------------------------------

def test_roughing_splits_multi_crossing():
    """Multi-crossing profile: roughing at X1.5 should produce separate cuts.

    **Validates: Requirements 1.1, 1.2, 2.1, 2.5**

    Profile: X2.0 Z0.0 -> X1.0 Z-1.0 -> X2.0 Z-2.0 -> X1.0 Z-3.0
    Stock: 2.5 dia

    At X=1.5, the offset profile crosses at approximately Z=-0.5, Z=-1.5,
    and Z=-2.5. Material exists in two separate Z ranges:
      - Z=0.1 to ~Z=-0.5 (first taper going down)
      - Z~=-1.5 to ~Z=-2.5 (third taper going down)

    The roughing pass at X=1.5 should produce TWO separate G01 cuts, not
    one spanning from Z=0.1 to Z=-3.0.

    On UNFIXED code, a single cut spans the full Z range — this test will
    FAIL, confirming the bug.
    """
    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="OD",
        stock_dia="2.500",
        x_start="2.500",
        z_start="0.1",
        doc="0.030",
        fin_passes="1",
        fin_doc="0.002",
        feed_r="0.005",
        feed_f="0.003",
        retract="0.100",
        rough_tool="1",
        finish_tool="1",
        rpm="1200",
        safe_x="3.500",
        safe_z="1.000",
    )

    # Profile: face to X2.5 Z0.0, taper down to X1.0 Z-1.0,
    # taper back up to X2.0 Z-2.0, taper down to X1.0 Z-3.0
    _add_segments(blk, [
        {"x_end": "2.500", "z_end": "0.000"},
        {"x_end": "1.000", "z_end": "-1.000"},
        {"x_end": "2.000", "z_end": "-2.000"},
        {"x_end": "1.000", "z_end": "-3.000"},
    ])

    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    roughing_moves = _parse_roughing_g01_z_moves(gcode)
    assert len(roughing_moves) > 0, "No roughing G01 Z moves found in G-code"

    # Profile points
    rough_pts = [(2.5, 0.1), (2.5, 0.0), (1.0, -1.0), (2.0, -2.0), (1.0, -3.0)]
    fin_allowance = 1 * 0.002

    # For multi-crossing profiles, each G01 Z move should stay within its
    # material zone. The crossings divide the Z axis into alternating
    # material/no-material zones. We check that each G01 Z endpoint does
    # not extend into a no-material zone.
    violations = []
    for current_x_dia, z_endpoint in roughing_moves:
        crossings = _compute_z_crossing(rough_pts, current_x_dia, fin_allowance, "OD")
        if crossings:
            # Sort crossings from most positive to most negative Z
            sorted_crossings = sorted(crossings, reverse=True)
            tolerance = 0.005

            # Determine material zones. For OD mode, material exists where
            # boundary_x < cutting_x. The first point's boundary is
            # x_start + offset. If that's > cutting_x, first zone is no-material.
            first_boundary = rough_pts[0][0] + fin_allowance * 2
            first_zone_is_material = first_boundary < current_x_dia

            # Build zones: alternating material/no-material between crossings
            # Zone boundaries: [z_start, cross1, cross2, ..., z_end_profile]
            z_top = rough_pts[0][1]  # z_start
            z_bot = rough_pts[-1][1]  # last Z in profile
            boundaries = [z_top] + sorted_crossings + [z_bot]

            # Check if z_endpoint falls in a no-material zone
            in_material = first_zone_is_material
            for i in range(len(boundaries) - 1):
                zone_top = boundaries[i]
                zone_bot = boundaries[i + 1]
                if z_endpoint <= zone_top + tolerance and z_endpoint >= zone_bot - tolerance:
                    if not in_material:
                        violations.append(
                            f"At X{current_x_dia:.4f}, G01 extends to Z{z_endpoint:.4f} "
                            f"which is in a no-material zone between "
                            f"Z{zone_top:.4f} and Z{zone_bot:.4f}"
                        )
                    break
                in_material = not in_material

    # Additionally, for passes where there are multiple crossings,
    # verify that the code produces multiple separate cut segments
    # (not one spanning cut). We check this by looking at passes near X=1.5.
    target_x = 1.5
    moves_near_target = [
        (x, z) for x, z in roughing_moves
        if abs(x - target_x) < 0.1
    ]

    # With a multi-crossing profile at X=1.5, we expect at least 2 separate
    # G01 Z moves (two separate cut segments)
    multi_crossing_violation = None
    if len(moves_near_target) == 1:
        multi_crossing_violation = (
            f"At X~{target_x}, expected multiple separate cut segments "
            f"but found only 1 G01 Z move (single spanning cut to "
            f"Z{moves_near_target[0][1]:.4f})"
        )

    all_issues = violations
    if multi_crossing_violation:
        all_issues.append(multi_crossing_violation)

    assert len(all_issues) == 0, (
        f"Roughing pass issues with multi-crossing profile:\n"
        + "\n".join(all_issues)
    )


# ------------------------------------------------------------------
# Test 3: ID mode taper — roughing should clip to profile crossing
# ------------------------------------------------------------------

def test_roughing_clips_id_taper():
    """ID taper: boring roughing G01 Z moves must not extend past profile crossing.

    **Validates: Requirements 1.3, 2.3**

    Profile: ID mode, pilot_hole=0.500, profile tapers outward from
    (X0.500, Z0.0) to (X1.500, Z-2.0).

    At roughing pass X=1.0 (boring outward), the offset profile
    (x - fin_allowance*2) crosses X=1.0 at an intermediate Z position.
    The roughing G01 should NOT extend past that crossing.

    On UNFIXED code, the roughing cut extends to Z-2.0 regardless — this
    test will FAIL, confirming the bug.
    """
    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="ID",
        stock_dia="0.500",
        x_start="0.500",
        z_start="0.1",
        doc="0.020",
        fin_passes="1",
        fin_doc="0.002",
        feed_r="0.003",
        feed_f="0.002",
        retract="0.005",
        rough_tool="2",
        finish_tool="2",
        rpm="800",
        safe_x="0.300",
        safe_z="1.000",
    )

    # Profile: face to X0.500 Z0.0, then taper outward to X1.500 Z-2.0
    _add_segments(blk, [
        {"x_end": "0.500", "z_end": "0.000"},
        {"x_end": "1.500", "z_end": "-2.000"},
    ])

    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    roughing_moves = _parse_roughing_g01_z_moves(gcode)
    assert len(roughing_moves) > 0, "No roughing G01 Z moves found in G-code"

    # Profile points for ID mode
    rough_pts = [(0.5, 0.1), (0.5, 0.0), (1.5, -2.0)]
    fin_allowance = 1 * 0.002

    violations = []
    for current_x_dia, z_endpoint in roughing_moves:
        crossings = _compute_z_crossing(rough_pts, current_x_dia, fin_allowance, "ID")
        if crossings:
            # For ID mode: material exists where boundary_x > cutting_x.
            # The first point's boundary is x_start - offset.
            # If that's < cutting_x, first zone is no-material (bore hasn't
            # widened enough yet). Material starts after the crossing.
            first_boundary = rough_pts[0][0] - fin_allowance * 2
            first_zone_is_material = first_boundary > current_x_dia

            # Sort crossings from most positive to most negative Z
            sorted_crossings = sorted(crossings, reverse=True)
            tolerance = 0.005

            # Build zones: alternating material/no-material between crossings
            z_top = rough_pts[0][1]
            z_bot = rough_pts[-1][1]
            boundaries = [z_top] + sorted_crossings + [z_bot]

            # Check if z_endpoint falls in a no-material zone
            in_material = first_zone_is_material
            for i in range(len(boundaries) - 1):
                zone_top = boundaries[i]
                zone_bot = boundaries[i + 1]
                if z_endpoint <= zone_top + tolerance and z_endpoint >= zone_bot - tolerance:
                    if not in_material:
                        violations.append(
                            f"At X{current_x_dia:.4f}, G01 extends to Z{z_endpoint:.4f} "
                            f"which is in a no-material zone between "
                            f"Z{zone_top:.4f} and Z{zone_bot:.4f}"
                        )
                    break
                in_material = not in_material

    assert len(violations) == 0, (
        f"ID roughing passes extend past profile crossings:\n"
        + "\n".join(violations)
    )


# ======================================================================
# Bugfix: roughing-profile-clipping, Property 2: Preservation
# ======================================================================
"""
Preservation property tests for ProfileBlock roughing pass generation.

These tests verify that simple cylinder profiles (no profile crossings)
produce correct output on the UNFIXED code, and must continue to pass
after the fix is applied.

**Validates: Requirements 3.1, 3.2, 3.3, 3.4, 3.5**
"""

from hypothesis import given, settings, assume
from hypothesis.strategies import floats, integers
from collections import Counter


# ------------------------------------------------------------------
# Test: Preservation — Simple OD Cylinder
# ------------------------------------------------------------------

@settings(max_examples=50, deadline=None)
@given(
    stock_dia=floats(min_value=1.0, max_value=4.0, allow_nan=False, allow_infinity=False),
    target_dia_frac=floats(min_value=0.1, max_value=0.8, allow_nan=False, allow_infinity=False),
    z_end=floats(min_value=-3.0, max_value=-0.5, allow_nan=False, allow_infinity=False),
    doc=floats(min_value=0.010, max_value=0.100, allow_nan=False, allow_infinity=False),
    fin_doc=floats(min_value=0.001, max_value=0.010, allow_nan=False, allow_infinity=False),
)
def test_preservation_simple_cylinder_od(stock_dia, target_dia_frac, z_end, doc, fin_doc):
    """Simple OD cylinder: each roughing pass has one G01 Z, all to same Z depth.

    **Validates: Requirements 3.1, 3.3**

    For a constant-diameter profile (no crossings), the code produces a single
    straight Z cut per roughing pass spanning the full Z range. This must
    remain true after the fix.

    Uses x_start = target_dia so the profile is a true constant-diameter
    cylinder with no face move (no crossings).
    """
    # Derive target_dia from fraction of stock_dia to ensure target < stock
    target_dia = round(stock_dia * target_dia_frac, 4)
    assume(target_dia >= 0.2)
    assume(stock_dia - target_dia > 0.1)

    fin_allowance = 1 * fin_doc  # 1 finish pass
    min_target_d = target_dia + fin_allowance * 2
    # Need at least one roughing pass
    assume(stock_dia - doc * 2 > min_target_d)

    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="OD",
        stock_dia=f"{stock_dia:.4f}",
        x_start=f"{target_dia:.4f}",
        z_start="0.1",
        doc=f"{doc * 2:.4f}",
        fin_passes="1",
        fin_doc=f"{fin_doc * 2:.4f}",
        feed_r="0.005",
        feed_f="0.003",
        retract="0.100",
        rough_tool="1",
        finish_tool="1",
        rpm="1200",
        safe_x=f"{stock_dia + 1.0:.4f}",
        safe_z="1.000",
    )

    # Profile: constant diameter from (target_dia, 0.0) to (target_dia, z_end)
    # No face move — this is a true simple cylinder with no crossings.
    _add_segments(blk, [
        {"x_end": f"{target_dia:.4f}", "z_end": "0.000"},
        {"x_end": f"{target_dia:.4f}", "z_end": f"{z_end:.4f}"},
    ])

    gcode = blk.generate_gcode()

    # (d) No errors in output
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    roughing_moves = _parse_roughing_g01_z_moves(gcode)
    assert len(roughing_moves) > 0, "No roughing G01 Z moves found"

    # (a) Each roughing pass emits exactly one G01 Z move (single cut per pass)
    x_counts = Counter(round(x, 4) for x, _ in roughing_moves)
    for x_dia, count in x_counts.items():
        assert count == 1, (
            f"At X{x_dia:.4f}, expected 1 G01 Z move but found {count} "
            f"(simple cylinder should not split cuts)"
        )

    # (b) All roughing G01 Z endpoints are the same (full Z range)
    z_endpoints = set(round(z, 4) for _, z in roughing_moves)
    assert len(z_endpoints) == 1, (
        f"Expected all roughing Z endpoints to be the same for a straight "
        f"cylinder, but found {z_endpoints}"
    )
    z_target = z_endpoints.pop()
    # For LINE-only profiles, chart includes Z offset (fin_allowance)
    # so roughing stops short of the cleanup boundary
    expected_z = round(z_end + fin_allowance, 4)
    assert abs(z_target - expected_z) < 0.001, (
        f"Roughing Z endpoint {z_target} doesn't match expected "
        f"z_end + fin_allowance = {expected_z:.4f}"
    )

    # (c) Roughing X diameters step down by doc*2 from stock toward target + fin_allowance*2
    x_diameters = sorted(set(round(x, 4) for x, _ in roughing_moves), reverse=True)
    # Check step-down: each successive X should be ~doc*2 less than previous
    step = round(doc * 2, 4)
    for i in range(1, len(x_diameters)):
        if i < len(x_diameters) - 1:
            # Regular passes should step by doc*2
            actual_step = round(x_diameters[i - 1] - x_diameters[i], 4)
            assert abs(actual_step - step) < 0.001, (
                f"Step from X{x_diameters[i-1]:.4f} to X{x_diameters[i]:.4f} "
                f"is {actual_step:.4f}, expected {step:.4f}"
            )


# ------------------------------------------------------------------
# Test: Preservation — Finish Pass Unchanged
# ------------------------------------------------------------------

def test_preservation_finish_pass_unchanged():
    """Finish pass traces the profile endpoints correctly.

    **Validates: Requirements 3.2, 3.5**

    The finish pass section of G-code should contain G01 moves that trace
    the profile. This captures the current finish pass behavior so we can
    verify it's unchanged after the fix.
    """
    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="OD",
        stock_dia="2.000",
        x_start="2.000",
        z_start="0.1",
        doc="0.030",
        fin_passes="1",
        fin_doc="0.002",
        feed_r="0.005",
        feed_f="0.003",
        retract="0.100",
        rough_tool="1",
        finish_tool="1",
        rpm="1200",
        safe_x="3.000",
        safe_z="1.000",
    )

    # Taper profile from task 1 test
    _add_segments(blk, [
        {"x_end": "2.000", "z_end": "0.000"},
        {"x_end": "1.000", "z_end": "-2.000"},
    ])

    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    # Parse finish pass section
    lines = gcode.split("\n")
    in_finish = False
    finish_g01_moves = []

    for line in lines:
        stripped = line.strip()
        if "Finish pass" in stripped:
            in_finish = True
            continue
        if in_finish and stripped.startswith("G00 X") and "Return to safe" in stripped:
            break
        if not in_finish:
            continue

        # Capture G01 moves in finish section
        g01_match = re.match(
            r'G01\s+X([+-]?\d+\.?\d*)\s+Z([+-]?\d+\.?\d*)',
            stripped
        )
        if g01_match:
            x_val = float(g01_match.group(1))
            z_val = float(g01_match.group(2))
            finish_g01_moves.append((x_val, z_val))

    assert len(finish_g01_moves) >= 2, (
        f"Expected at least 2 G01 moves in finish pass, found {len(finish_g01_moves)}"
    )

    # Verify finish pass traces the profile endpoints
    # Profile: (2.0, 0.1) -> (2.0, 0.0) -> (1.0, -2.0)
    # Finish G01 moves should include (2.0, 0.0) and (1.0, -2.0)
    expected_endpoints = [(2.0, 0.0), (1.0, -2.0)]
    for exp_x, exp_z in expected_endpoints:
        found = any(
            abs(x - exp_x) < 0.001 and abs(z - exp_z) < 0.001
            for x, z in finish_g01_moves
        )
        assert found, (
            f"Expected finish pass to include G01 to X{exp_x:.4f} Z{exp_z:.4f}, "
            f"but finish moves are: {finish_g01_moves}"
        )


# ------------------------------------------------------------------
# Test: Preservation — Preamble Format
# ------------------------------------------------------------------

def test_preservation_preamble_format():
    """G-code preamble contains expected setup commands.

    **Validates: Requirements 3.4**

    Verify G-code starts with expected preamble: G20 G18 G40 G49 G80,
    G90, tool change T{n} M6, G43, and safe position move.
    """
    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="OD",
        stock_dia="2.000",
        x_start="2.000",
        z_start="0.1",
        doc="0.030",
        fin_passes="1",
        fin_doc="0.002",
        feed_r="0.005",
        feed_f="0.003",
        retract="0.100",
        rough_tool="3",
        finish_tool="3",
        rpm="1200",
        safe_x="3.000",
        safe_z="1.000",
    )

    _add_segments(blk, [
        {"x_end": "1.000", "z_end": "0.000"},
        {"x_end": "1.000", "z_end": "-2.000"},
    ])

    gcode = blk.generate_gcode()
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    # Check preamble contains expected G-code setup
    assert "G20 G18 G40 G49 G80" in gcode, "Missing G20 G18 G40 G49 G80 preamble"
    assert "G90" in gcode, "Missing G90 (absolute positioning)"
    assert "T3 M6" in gcode, "Missing tool change T3 M6"
    assert "G43" in gcode, "Missing G43 (tool length compensation)"

    # Verify safe position move is present
    assert "G00 X3.0000 Z1.0000" in gcode, "Missing safe position move"

    # Verify M2 program end
    assert "M2" in gcode, "Missing M2 program end"


# ------------------------------------------------------------------
# Test: Preservation — Simple ID Cylinder
# ------------------------------------------------------------------

@settings(max_examples=50, deadline=None)
@given(
    pilot_hole=floats(min_value=0.3, max_value=1.0, allow_nan=False, allow_infinity=False),
    target_dia_frac=floats(min_value=1.3, max_value=3.0, allow_nan=False, allow_infinity=False),
    z_end=floats(min_value=-3.0, max_value=-0.5, allow_nan=False, allow_infinity=False),
    doc=floats(min_value=0.010, max_value=0.050, allow_nan=False, allow_infinity=False),
    fin_doc=floats(min_value=0.001, max_value=0.010, allow_nan=False, allow_infinity=False),
)
def test_preservation_simple_cylinder_id(pilot_hole, target_dia_frac, z_end, doc, fin_doc):
    """Simple ID cylinder: each roughing pass has one G01 Z, all to same Z depth.

    **Validates: Requirements 3.1, 3.3**

    For a constant-diameter bore (no crossings), the code produces a single
    straight Z cut per roughing pass spanning the full Z range. This must
    remain true after the fix.

    Uses x_start = target_dia so the profile is a true constant-diameter
    bore with no face move (no crossings).
    """
    target_dia = round(pilot_hole * target_dia_frac, 4)
    assume(target_dia - pilot_hole > 0.1)
    assume(target_dia <= 3.0)

    fin_allowance = 1 * fin_doc
    max_target_d = target_dia - fin_allowance * 2
    # Need at least one roughing pass
    assume(pilot_hole + doc * 2 < max_target_d)

    # Retract must keep x_clear > 0
    retract = 0.005
    x_clear = pilot_hole - retract
    assume(x_clear > 0)

    blk = _make_profile_block()
    _set_profile_fields(blk,
        mode="ID",
        stock_dia=f"{pilot_hole:.4f}",
        x_start=f"{target_dia:.4f}",
        z_start="0.1",
        doc=f"{doc * 2:.4f}",
        fin_passes="1",
        fin_doc=f"{fin_doc * 2:.4f}",
        feed_r="0.003",
        feed_f="0.002",
        retract=f"{retract:.4f}",
        rough_tool="2",
        finish_tool="2",
        rpm="800",
        safe_x=f"{pilot_hole - 0.200:.4f}",
        safe_z="1.000",
    )

    # Profile: constant diameter bore from (target_dia, 0.0) to (target_dia, z_end)
    # No face move — this is a true simple bore with no crossings.
    _add_segments(blk, [
        {"x_end": f"{target_dia:.4f}", "z_end": "0.000"},
        {"x_end": f"{target_dia:.4f}", "z_end": f"{z_end:.4f}"},
    ])

    gcode = blk.generate_gcode()

    # No errors in output
    assert "; ERROR" not in gcode, f"G-code generation error: {gcode}"

    roughing_moves = _parse_roughing_g01_z_moves(gcode)
    if len(roughing_moves) == 0:
        # Some parameter combinations may not produce roughing passes
        # (e.g., if the profile is entirely face cuts)
        return

    # Each roughing pass emits exactly one G01 Z move
    x_counts = Counter(round(x, 4) for x, _ in roughing_moves)
    for x_dia, count in x_counts.items():
        assert count == 1, (
            f"At X{x_dia:.4f}, expected 1 G01 Z move but found {count} "
            f"(simple ID cylinder should not split cuts)"
        )

    # All roughing G01 Z endpoints are the same
    z_endpoints = set(round(z, 4) for _, z in roughing_moves)
    assert len(z_endpoints) == 1, (
        f"Expected all roughing Z endpoints to be the same for a straight "
        f"bore, but found {z_endpoints}"
    )
    z_target = z_endpoints.pop()
    expected_z = round(z_end + fin_allowance, 4)
    assert abs(z_target - expected_z) < 0.001, (
        f"Roughing Z endpoint {z_target} doesn't match expected "
        f"z_end + fin_allowance = {expected_z:.4f}"
    )
