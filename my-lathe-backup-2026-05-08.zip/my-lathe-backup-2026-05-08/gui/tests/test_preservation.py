# Bugfix: id-roughing-z-interval-fix, Property 2: Preservation
"""
Preservation property tests for OD mode and simple narrowing ID profiles.

These tests verify that `build_z_limit_chart()` returns correct Z limits for:
1. OD mode profiles (any geometry) — material exists from z_start to crossing
2. Simple narrowing ID profiles (bore narrows monotonically) — single Z limit
   from z_start to crossing works correctly
3. Straight bore (constant diameter) — single interval from z_start to back wall

**Validates: Requirements 3.1, 3.2, 3.3, 3.4, 3.5**

These tests MUST PASS on the current unfixed code, establishing the baseline
behavior that must be preserved after the fix is applied.
"""

import sys
import os
import math

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from hypothesis import given, settings, assume, HealthCheck
from hypothesis.strategies import (
    floats, integers, lists, tuples, composite, sampled_from
)

from conv_profile import build_z_limit_chart


# ------------------------------------------------------------------
# Helper: build cleanup segments (same logic as build_z_limit_chart)
# ------------------------------------------------------------------

def _build_cleanup_segments(finish_moves, x_start_d, z_start, fin_allowance, mode):
    """Build cleanup boundary segments the same way build_z_limit_chart does."""
    offset_d = fin_allowance * 2
    if mode == "OD":
        cp_start_x = x_start_d + offset_d
    else:
        cp_start_x = x_start_d - offset_d

    segments = []
    prev_x, prev_z = cp_start_x, z_start
    for mv in finish_moves:
        if mv[0] == "LINE":
            ox = mv[1] + offset_d if mode == "OD" else mv[1] - offset_d
            oz = mv[2] + fin_allowance
            segments.append(("LINE", prev_x, prev_z, ox, oz))
            prev_x, prev_z = ox, oz
        elif mv[0] == "ARC":
            ox = mv[1] + offset_d if mode == "OD" else mv[1] - offset_d
            oz = mv[2] + fin_allowance
            segments.append(("ARC", prev_x, prev_z, ox, oz, mv[3]))
            prev_x, prev_z = ox, oz
    return segments


def _interpolate_boundary_x_at_z(segments, z_query):
    """Interpolate the boundary X at a given Z value along LINE segments.

    Returns the boundary X at z_query, or None if z_query is outside
    all segments.
    """
    for seg in segments:
        if seg[0] != "LINE":
            continue
        x1, z1, x2, z2 = seg[1], seg[2], seg[3], seg[4]
        z_lo = min(z1, z2)
        z_hi = max(z1, z2)
        if z_lo - 1e-9 <= z_query <= z_hi + 1e-9:
            if abs(z2 - z1) < 1e-9:
                return (x1 + x2) / 2.0
            t = (z_query - z1) / (z2 - z1)
            t = max(0.0, min(1.0, t))
            return x1 + t * (x2 - x1)
    return None


# ------------------------------------------------------------------
# Hypothesis strategies for generating profiles
# ------------------------------------------------------------------

@composite
def od_profile_strategy(draw):
    """Generate a random OD mode profile with decreasing X (stock toward part).

    OD profiles: X starts large (stock) and decreases toward the part.
    finish_moves have X values less than x_start_d.
    """
    # Stock diameter (large)
    x_start_d = draw(floats(min_value=2.0, max_value=5.0,
                            allow_nan=False, allow_infinity=False))
    x_start_d = round(x_start_d, 4)

    # Generate 1-3 LINE segments with decreasing X
    n_segments = draw(integers(min_value=1, max_value=3))
    z_start = 0.1
    fin_allowance = draw(floats(min_value=0.001, max_value=0.01,
                                allow_nan=False, allow_infinity=False))
    fin_allowance = round(fin_allowance, 4)

    finish_moves = []
    prev_x = x_start_d
    prev_z = z_start
    for i in range(n_segments):
        # X decreases (toward part center for OD)
        x_step = draw(floats(min_value=0.1, max_value=0.8,
                             allow_nan=False, allow_infinity=False))
        new_x = round(prev_x - x_step, 4)
        # Z decreases (moves toward chuck)
        z_step = draw(floats(min_value=0.3, max_value=1.5,
                             allow_nan=False, allow_infinity=False))
        new_z = round(prev_z - z_step, 4)

        # Ensure X stays positive
        assume(new_x > 0.2)
        finish_moves.append(("LINE", new_x, new_z))
        prev_x = new_x
        prev_z = new_z

    # Generate X levels between the final X and x_start_d
    final_x = finish_moves[-1][1]
    assume(x_start_d - final_x > 0.3)  # Ensure meaningful range

    n_levels = draw(integers(min_value=1, max_value=4))
    x_levels = []
    for _ in range(n_levels):
        frac = draw(floats(min_value=0.15, max_value=0.85,
                           allow_nan=False, allow_infinity=False))
        level = round(final_x + (x_start_d - final_x) * frac, 4)
        x_levels.append(level)

    # Remove duplicates and sort
    x_levels = sorted(set(x_levels), reverse=True)
    assume(len(x_levels) >= 1)

    return {
        "finish_moves": finish_moves,
        "x_start_d": x_start_d,
        "z_start": z_start,
        "x_levels": x_levels,
        "fin_allowance": fin_allowance,
    }


@composite
def simple_narrowing_id_profile_strategy(draw):
    """Generate a random simple narrowing ID profile.

    Simple narrowing ID: bore narrows as Z decreases.
    X DECREASES as Z decreases (boundary gets closer to center).
    At z_start, boundary is large (safe). As Z decreases, boundary shrinks
    until it crosses cutting_x.
    """
    # Starting bore diameter (large)
    x_start_d = draw(floats(min_value=1.0, max_value=3.0,
                            allow_nan=False, allow_infinity=False))
    x_start_d = round(x_start_d, 4)

    # Generate 1-2 LINE segments with DECREASING X (bore narrows)
    n_segments = draw(integers(min_value=1, max_value=2))
    z_start = 0.1
    fin_allowance = draw(floats(min_value=0.001, max_value=0.01,
                                allow_nan=False, allow_infinity=False))
    fin_allowance = round(fin_allowance, 4)

    finish_moves = []
    prev_x = x_start_d
    prev_z = z_start
    for i in range(n_segments):
        # X decreases (bore narrows)
        x_step = draw(floats(min_value=0.1, max_value=0.5,
                             allow_nan=False, allow_infinity=False))
        new_x = round(prev_x - x_step, 4)
        # Z decreases
        z_step = draw(floats(min_value=0.3, max_value=1.5,
                             allow_nan=False, allow_infinity=False))
        new_z = round(prev_z - z_step, 4)

        assume(new_x > 0.2)
        finish_moves.append(("LINE", new_x, new_z))
        prev_x = new_x
        prev_z = new_z

    # For narrowing ID, the cleanup boundary starts at x_start - offset
    # and decreases. X levels should be LESS than the starting boundary
    # but GREATER than the final boundary, so the crossing happens within.
    final_x = finish_moves[-1][1]
    offset_d = fin_allowance * 2
    cp_start_x = x_start_d - offset_d
    cp_end_x = final_x - offset_d

    # X levels between cp_end_x and cp_start_x
    assume(cp_start_x - cp_end_x > 0.1)

    n_levels = draw(integers(min_value=1, max_value=3))
    x_levels = []
    for _ in range(n_levels):
        frac = draw(floats(min_value=0.15, max_value=0.85,
                           allow_nan=False, allow_infinity=False))
        level = round(cp_end_x + (cp_start_x - cp_end_x) * frac, 4)
        x_levels.append(level)

    x_levels = sorted(set(x_levels), reverse=True)
    assume(len(x_levels) >= 1)

    return {
        "finish_moves": finish_moves,
        "x_start_d": x_start_d,
        "z_start": z_start,
        "x_levels": x_levels,
        "fin_allowance": fin_allowance,
    }


# ==================================================================
# TEST 1: OD Mode Preservation (PBT)
# ==================================================================

@settings(max_examples=50, deadline=None,
          suppress_health_check=[HealthCheck.filter_too_much, HealthCheck.too_slow])
@given(profile=od_profile_strategy())
def test_pbt_od_mode_z_limit_at_crossing(profile):
    """PBT: For OD profiles, z_limit is at the crossing where boundary crosses cutting_x.

    **Validates: Requirements 3.2**

    For OD mode:
    - "safe" means boundary_x < cutting_x (boundary is closer to center than tool)
    - Material exists where boundary_x > cutting_x (stock hasn't been removed)
    - The profile goes from large X (stock) toward small X (part)
    - At z_start, boundary starts at x_start + offset (large, unsafe = material)
    - As Z decreases, boundary decreases until it crosses cutting_x (safe)
    - z_limit should be at the crossing point

    This test verifies that for each X level, the returned z_limit is at
    the point where the boundary crosses cutting_x, and that material exists
    from z_start to z_limit (boundary_x > cutting_x in that range).
    """
    finish_moves = profile["finish_moves"]
    x_start_d = profile["x_start_d"]
    z_start = profile["z_start"]
    x_levels = profile["x_levels"]
    fin_allowance = profile["fin_allowance"]

    z_chart = build_z_limit_chart(finish_moves, x_start_d, z_start,
                                  x_levels, fin_allowance, "OD")

    # Build cleanup segments for verification
    segments = _build_cleanup_segments(finish_moves, x_start_d, z_start,
                                       fin_allowance, "OD")

    for cutting_x in x_levels:
        if cutting_x not in z_chart:
            # If no z_limit returned, that's acceptable (X level may be
            # outside the boundary range)
            continue

        z_limit = z_chart[cutting_x]

        # Verify: z_limit should be between z_start and the back wall
        back_wall_z = segments[-1][4] if segments else z_start
        assert z_limit <= z_start + 0.01, (
            f"OD z_limit={z_limit:.4f} is beyond z_start={z_start} "
            f"for cutting_x={cutting_x:.4f}"
        )

        # Verify: at z_limit, boundary should be approximately equal to cutting_x
        # (this is the crossing point)
        boundary_at_limit = _interpolate_boundary_x_at_z(segments, z_limit)
        if boundary_at_limit is not None:
            # The crossing should be where boundary ≈ cutting_x
            # Allow some tolerance for interpolation
            assert abs(boundary_at_limit - cutting_x) < 0.1, (
                f"OD z_limit crossing check: at Z={z_limit:.4f}, "
                f"boundary_x={boundary_at_limit:.4f} should be ≈ cutting_x={cutting_x:.4f}"
            )

        # Verify: material exists between z_start and z_limit
        # For OD: material where boundary_x > cutting_x
        # Sample a few points in the cut range
        n_check = 5
        z_min = min(z_start, z_limit)
        z_max = max(z_start, z_limit)
        if abs(z_max - z_min) < 0.01:
            continue  # Skip degenerate cases

        for i in range(1, n_check):
            z_sample = z_max - (z_max - z_min) * i / n_check
            bx = _interpolate_boundary_x_at_z(segments, z_sample)
            if bx is not None:
                # For OD: boundary > cutting_x means material exists
                # (stock hasn't been cut away yet)
                # Near the crossing, boundary approaches cutting_x from above
                # Allow small tolerance near the crossing
                assert bx >= cutting_x - 0.05, (
                    f"OD material check failed: at Z={z_sample:.4f}, "
                    f"boundary_x={bx:.4f} < cutting_x={cutting_x:.4f}. "
                    f"Material should exist from z_start to z_limit."
                )


# ==================================================================
# TEST 2: Simple Narrowing ID Preservation (PBT)
# ==================================================================

@settings(max_examples=50, deadline=None,
          suppress_health_check=[HealthCheck.filter_too_much, HealthCheck.too_slow])
@given(profile=simple_narrowing_id_profile_strategy())
def test_pbt_simple_narrowing_id_z_limit_at_crossing(profile):
    """PBT: For simple narrowing ID profiles, z_limit is at the crossing.

    **Validates: Requirements 3.1**

    For simple narrowing ID (bore narrows as Z decreases):
    - "safe" means boundary_x > cutting_x (boundary farther from center)
    - Material exists where boundary_x > cutting_x
    - At z_start, boundary is large (safe, material exists)
    - As Z decreases, boundary shrinks until it crosses cutting_x
    - z_limit should be at the crossing point
    - Material exists from z_start to z_limit

    This is the CORRECT case that already works. The test captures this
    behavior to ensure it's preserved after the fix.
    """
    finish_moves = profile["finish_moves"]
    x_start_d = profile["x_start_d"]
    z_start = profile["z_start"]
    x_levels = profile["x_levels"]
    fin_allowance = profile["fin_allowance"]

    z_chart = build_z_limit_chart(finish_moves, x_start_d, z_start,
                                  x_levels, fin_allowance, "ID")

    # Build cleanup segments for verification
    segments = _build_cleanup_segments(finish_moves, x_start_d, z_start,
                                       fin_allowance, "ID")

    for cutting_x in x_levels:
        if cutting_x not in z_chart:
            continue

        z_limit = z_chart[cutting_x]

        # Verify: z_limit should be between z_start and the back wall
        assert z_limit <= z_start + 0.01, (
            f"ID narrowing z_limit={z_limit:.4f} is beyond z_start={z_start} "
            f"for cutting_x={cutting_x:.4f}"
        )

        # Verify: at z_limit, boundary should be approximately equal to cutting_x
        boundary_at_limit = _interpolate_boundary_x_at_z(segments, z_limit)
        if boundary_at_limit is not None:
            assert abs(boundary_at_limit - cutting_x) < 0.1, (
                f"ID narrowing z_limit crossing: at Z={z_limit:.4f}, "
                f"boundary_x={boundary_at_limit:.4f} should be ≈ cutting_x={cutting_x:.4f}"
            )

        # Verify: material exists from z_start to z_limit
        # For ID: material where boundary_x > cutting_x
        n_check = 5
        z_min = min(z_start, z_limit)
        z_max = max(z_start, z_limit)
        if abs(z_max - z_min) < 0.01:
            continue

        for i in range(1, n_check):
            z_sample = z_max - (z_max - z_min) * i / n_check
            bx = _interpolate_boundary_x_at_z(segments, z_sample)
            if bx is not None:
                # For narrowing ID: boundary starts large and decreases.
                # Between z_start and the crossing, boundary > cutting_x
                assert bx >= cutting_x - 0.05, (
                    f"ID narrowing material check: at Z={z_sample:.4f}, "
                    f"boundary_x={bx:.4f} < cutting_x={cutting_x:.4f}. "
                    f"Material should exist from z_start to z_limit."
                )


# ==================================================================
# TEST 3: Straight Bore Preservation (unit test)
# ==================================================================

def test_straight_bore_z_limit_equals_back_wall():
    """Straight bore: z_limit equals the back wall Z.

    **Validates: Requirements 3.3**

    A constant diameter bore means the boundary never crosses any X level
    that is less than the bore diameter. The tool should cut from z_start
    all the way to the back wall.

    Profile: constant X=1.5 bore from Z=0.1 to Z=-2.0
    finish_moves = [("LINE", 1.5, -2.0)]
    x_start_d = 1.5

    At any cutting_x < 1.5 (after offset), the boundary is always > cutting_x
    (safe/material), so z_limit should be the back wall Z.
    """
    finish_moves = [("LINE", 1.5, -2.0)]
    x_start_d = 1.5
    z_start = 0.1
    fin_allowance = 0.005
    offset_d = fin_allowance * 2

    # The cleanup boundary goes from (1.5 - 0.01) = 1.49 at z_start
    # to (1.5 - 0.01) = 1.49 at z=-2.0 + 0.005 = -1.995
    # Actually for a straight bore, x_start_d == finish X, so boundary is constant.
    # cp_start_x = 1.5 - 0.01 = 1.49
    # segment end x = 1.5 - 0.01 = 1.49
    # So boundary is constant at 1.49 for all Z.

    # X levels less than 1.49 should have z_limit at back wall
    x_levels = [1.0, 1.2, 1.4]

    z_chart = build_z_limit_chart(finish_moves, x_start_d, z_start,
                                  x_levels, fin_allowance, "ID")

    # The back wall Z (last segment endpoint Z with offset)
    back_wall_z = -2.0 + fin_allowance  # = -1.995

    for cutting_x in x_levels:
        if cutting_x not in z_chart:
            # For a straight bore where boundary is always > cutting_x,
            # the function should return the back wall Z (found_safe=True, no crossing)
            continue

        z_limit = z_chart[cutting_x]
        # z_limit should be at or very near the back wall
        assert abs(z_limit - back_wall_z) < 0.05, (
            f"Straight bore: at cutting_x={cutting_x}, z_limit={z_limit:.4f} "
            f"should be ≈ back_wall_z={back_wall_z:.4f}. "
            f"For a constant diameter bore, the tool should cut to the back wall."
        )


# ==================================================================
# TEST 4: OD Mode Z Limit Correctness (linear interpolation check)
# ==================================================================

def test_od_z_limit_linear_interpolation():
    """OD mode: z_limit is where boundary crosses cutting_x via linear interpolation.

    **Validates: Requirements 3.2**

    For a simple linear OD profile, we can compute the exact crossing point
    analytically and verify build_z_limit_chart matches.

    Profile: X=3.0 at Z=0.1 (stock) to X=1.0 at Z=-2.0 (part)
    finish_moves = [("LINE", 1.0, -2.0)]
    x_start_d = 3.0

    The cleanup boundary (with offset) goes from:
      cp_start_x = 3.0 + 2*fin_allowance at Z=0.1
      cp_end_x = 1.0 + 2*fin_allowance at Z=-2.0 + fin_allowance

    For cutting_x = 2.0:
      The crossing is where boundary_x = 2.0
      Linear interpolation: t = (2.0 - cp_start_x) / (cp_end_x - cp_start_x)
      z_cross = z_start + t * (cp_end_z - z_start)
    """
    finish_moves = [("LINE", 1.0, -2.0)]
    x_start_d = 3.0
    z_start = 0.1
    fin_allowance = 0.005
    offset_d = fin_allowance * 2

    # Compute expected crossing analytically
    cp_start_x = x_start_d + offset_d  # 3.01
    cp_end_x = 1.0 + offset_d  # 1.01
    cp_end_z = -2.0 + fin_allowance  # -1.995

    cutting_x = 2.0
    # Linear interpolation for crossing
    t_expected = (cutting_x - cp_start_x) / (cp_end_x - cp_start_x)
    z_expected = z_start + t_expected * (cp_end_z - z_start)

    x_levels = [cutting_x]
    z_chart = build_z_limit_chart(finish_moves, x_start_d, z_start,
                                  x_levels, fin_allowance, "OD")

    assert cutting_x in z_chart, (
        f"OD build_z_limit_chart returned no Z limit for cutting_x={cutting_x}. "
        f"Chart: {z_chart}"
    )

    z_limit = z_chart[cutting_x]

    # Verify z_limit matches expected crossing point
    assert abs(z_limit - z_expected) < 0.01, (
        f"OD z_limit={z_limit:.4f} doesn't match expected crossing "
        f"z_expected={z_expected:.4f} for cutting_x={cutting_x}. "
        f"Boundary goes from {cp_start_x:.4f} to {cp_end_x:.4f}, "
        f"Z from {z_start} to {cp_end_z:.4f}."
    )


# ==================================================================
# TEST 5: Multiple OD X levels all get correct Z limits
# ==================================================================

def test_od_multiple_x_levels_monotonic_z():
    """OD mode: multiple X levels produce monotonically decreasing Z limits.

    **Validates: Requirements 3.2**

    For a linear OD profile (X decreases linearly with Z), larger X levels
    (closer to stock) should have z_limits closer to z_start, and smaller
    X levels (closer to part) should have z_limits closer to the back wall.

    This means z_limits should be monotonically decreasing as X decreases.
    """
    finish_moves = [("LINE", 1.0, -3.0)]
    x_start_d = 4.0
    z_start = 0.1
    fin_allowance = 0.005

    # Multiple X levels from large to small
    x_levels = [3.5, 3.0, 2.5, 2.0, 1.5]

    z_chart = build_z_limit_chart(finish_moves, x_start_d, z_start,
                                  x_levels, fin_allowance, "OD")

    # All levels should have Z limits
    z_limits = []
    for x in x_levels:
        assert x in z_chart, f"OD: no z_limit for X={x}. Chart: {z_chart}"
        z_limits.append(z_chart[x])

    # Z limits should be monotonically decreasing (more negative)
    # as X decreases (deeper cuts go further)
    for i in range(len(z_limits) - 1):
        assert z_limits[i] >= z_limits[i + 1] - 0.001, (
            f"OD z_limits not monotonic: at X={x_levels[i]}, z={z_limits[i]:.4f} "
            f"but at X={x_levels[i+1]}, z={z_limits[i+1]:.4f}. "
            f"Smaller X should have more negative z_limit."
        )


# ==================================================================
# TEST 6: Simple narrowing ID with known geometry
# ==================================================================

def test_narrowing_id_known_geometry():
    """Simple narrowing ID: verify z_limit at known crossing point.

    **Validates: Requirements 3.1**

    Profile: X=2.0 at Z=0.1 narrowing to X=1.0 at Z=-2.0
    finish_moves = [("LINE", 1.0, -2.0)]
    x_start_d = 2.0

    Cleanup boundary (ID, offset inward):
      cp_start_x = 2.0 - 0.01 = 1.99 at Z=0.1
      cp_end_x = 1.0 - 0.01 = 0.99 at Z=-1.995

    At cutting_x = 1.5:
      Crossing where boundary = 1.5
      t = (1.5 - 1.99) / (0.99 - 1.99) = -0.49 / -1.0 = 0.49
      z_cross = 0.1 + 0.49 * (-1.995 - 0.1) = 0.1 + 0.49 * (-2.095) = 0.1 - 1.027 = -0.927

    Material exists from z_start (0.1) to z_cross (-0.927) because
    boundary > cutting_x in that range (boundary starts at 1.99 and
    decreases to 1.5 at the crossing).
    """
    finish_moves = [("LINE", 1.0, -2.0)]
    x_start_d = 2.0
    z_start = 0.1
    fin_allowance = 0.005
    offset_d = fin_allowance * 2

    cp_start_x = x_start_d - offset_d  # 1.99
    cp_end_x = 1.0 - offset_d  # 0.99
    cp_end_z = -2.0 + fin_allowance  # -1.995

    cutting_x = 1.5
    t_expected = (cutting_x - cp_start_x) / (cp_end_x - cp_start_x)
    z_expected = z_start + t_expected * (cp_end_z - z_start)

    x_levels = [cutting_x]
    z_chart = build_z_limit_chart(finish_moves, x_start_d, z_start,
                                  x_levels, fin_allowance, "ID")

    assert cutting_x in z_chart, (
        f"Narrowing ID: no z_limit for cutting_x={cutting_x}. Chart: {z_chart}"
    )

    z_limit = z_chart[cutting_x]

    # Verify z_limit matches expected crossing
    assert abs(z_limit - z_expected) < 0.02, (
        f"Narrowing ID: z_limit={z_limit:.4f} doesn't match expected "
        f"z_expected={z_expected:.4f} for cutting_x={cutting_x}. "
        f"Boundary: {cp_start_x:.4f} → {cp_end_x:.4f}, "
        f"Z: {z_start} → {cp_end_z:.4f}."
    )

    # Verify material exists from z_start to z_limit
    segments = _build_cleanup_segments(finish_moves, x_start_d, z_start,
                                       fin_allowance, "ID")
    n_check = 5
    z_min = min(z_start, z_limit)
    z_max = max(z_start, z_limit)
    for i in range(1, n_check):
        z_sample = z_max - (z_max - z_min) * i / n_check
        bx = _interpolate_boundary_x_at_z(segments, z_sample)
        if bx is not None:
            assert bx > cutting_x - 0.01, (
                f"Narrowing ID material check: at Z={z_sample:.4f}, "
                f"boundary_x={bx:.4f} should be > cutting_x={cutting_x}."
            )
