"""Per-tool Z-axis soft limit enforcement.

Monitors machine Z position each update cycle and issues soft stops
when a tool's configured limit is violated.
"""

import logging
from typing import Optional, Tuple

logger = logging.getLogger(__name__)


class LimitEnforcer:
    """Monitors machine Z position and issues soft stops on limit violations."""

    def __init__(self, limit_manager, cmd=None):
        """Initialize with LimitManager reference and optional linuxcnc.command.

        Args:
            limit_manager: LimitManager instance for looking up tool limits.
            cmd: linuxcnc.command() instance for issuing abort/feedhold,
                 or None in offline mode.
        """
        self._limit_manager = limit_manager
        self._cmd = cmd
        self._enabled = True
        self._last_violation: Optional[Tuple[int, str]] = None  # (tool_num, direction)
        self._current_tool: Optional[int] = None

    def set_enabled(self, enabled: bool) -> None:
        """Enable/disable enforcement (disabled during homing)."""
        self._enabled = enabled

    @property
    def active_limits(self) -> Optional[Tuple[Optional[float], Optional[float]]]:
        """Return the currently enforced (z_minus, z_plus) for graph display."""
        if self._current_tool is None:
            return None
        return self._limit_manager.get_limits(self._current_tool)

    def check(self, z_machine: float, tool_num: int, is_homed: bool,
              is_program_running: bool) -> Optional[str]:
        """Check position against active tool limits.

        Returns violation message string if limit hit, None otherwise.

        Args:
            z_machine: Current machine Z position in inches.
            tool_num: Active tool number (pocket number).
            is_homed: Whether all axes are homed.
            is_program_running: Whether a G-code program is executing.

        Returns:
            A message string like "Z- limit reached — T1" if a new violation
            is detected, or None if no violation or repeated violation.
        """
        # No enforcement if disabled or not homed
        if not self._enabled or not is_homed:
            return None

        # Track current tool for active_limits property
        self._current_tool = tool_num

        # Get limits for this tool
        limits = self._limit_manager.get_limits(tool_num)
        if limits is None:
            self._last_violation = None
            return None

        z_minus, z_plus = limits

        # Check Z- violation (toward headstock)
        violation_direction = None
        if z_minus is not None and z_machine <= z_minus:
            violation_direction = "Z-"

        # Check Z+ violation (toward tailstock)
        if z_plus is not None and z_machine >= z_plus:
            violation_direction = "Z+"

        if violation_direction is not None:
            # Check if this is the same violation as last time (avoid repeated messages)
            current_violation = (tool_num, violation_direction)
            if self._last_violation == current_violation:
                return None

            # New violation detected
            self._last_violation = current_violation

            # Issue soft stop commands
            if self._cmd is not None:
                try:
                    if is_program_running:
                        self._cmd.feedhold()
                    self._cmd.abort()
                except Exception as e:
                    logger.warning("Failed to issue soft stop command: %s", e)

            # Format violation message
            if is_program_running:
                message = f"{violation_direction} limit reached \u2014 T{tool_num} (program halted)"
            else:
                message = f"{violation_direction} limit reached \u2014 T{tool_num}"
            return message

        # No violation — clear last violation state
        self._last_violation = None
        return None
