"""G/M Code Library Tab — Glossary of LinuxCNC G and M codes for lathe use."""

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QScrollArea, QFrame, QTabWidget, QGridLayout, QSizePolicy
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

from theme import COLORS, FONT_SIZES, mono_font, ui_font


# ---------------------------------------------------------------------------
# G-Code Reference Data
# ---------------------------------------------------------------------------
GCODES = [
    {
        "code": "G00",
        "name": "Rapid Positioning",
        "desc": "Move to a position at maximum traverse rate. No cutting — used for repositioning.",
        "example": "G00 X1.0 Z0.1\n; Rapid to 1\" diameter, 0.1\" from face",
    },
    {
        "code": "G01",
        "name": "Linear Interpolation (Feed)",
        "desc": "Move in a straight line at the programmed feed rate. Primary cutting move.",
        "example": "G01 X0.75 Z-2.0 F0.005\n; Turn OD to 0.75\" dia, 2\" long at 0.005 ipr",
    },
    {
        "code": "G02",
        "name": "Circular Interpolation CW",
        "desc": "Arc move clockwise. Specify endpoint and arc center (I, K) or radius (R).",
        "example": "G02 X1.0 Z-0.5 I0.25 K0.0\n; CW arc to X1 Z-0.5, center offset I=0.25 K=0",
    },
    {
        "code": "G03",
        "name": "Circular Interpolation CCW",
        "desc": "Arc move counter-clockwise. Specify endpoint and arc center (I, K) or radius (R).",
        "example": "G03 X0.8 Z-0.3 R0.15\n; CCW arc with 0.15\" radius",
    },
    {
        "code": "G04",
        "name": "Dwell",
        "desc": "Pause motion for a specified time. Useful for spring passes or chip breaking.",
        "example": "G04 P0.5\n; Dwell 0.5 seconds (spring pass at bottom of bore)",
    },
    {
        "code": "G07",
        "name": "Diameter Mode",
        "desc": "X-axis values are interpreted as diameters. Default for lathe mode.",
        "example": "G07\nG01 X1.0\n; Move to 1.0\" diameter (0.5\" radius)",
    },
    {
        "code": "G08",
        "name": "Radius Mode",
        "desc": "X-axis values are interpreted as radii instead of diameters.",
        "example": "G08\nG01 X0.5\n; Move to 0.5\" radius (1.0\" diameter)",
    },
    {
        "code": "G10 L1",
        "name": "Set Tool Table (geometry)",
        "desc": "Set tool geometry offsets directly. P=tool number, X/Z=offset values.",
        "example": "G10 L1 P101 X-1.234 Z-3.567\n; Set T1 geometry: X=-1.234, Z=-3.567",
    },
    {
        "code": "G10 L2",
        "name": "Set Work Coordinate System",
        "desc": "Set the origin of a work coordinate system. P=WCS number (1=G54, etc.).",
        "example": "G10 L2 P1 X0 Z0\n; Set G54 origin to current machine position",
    },
    {
        "code": "G10 L10",
        "name": "Set Tool Table (calculated)",
        "desc": "Calculate tool offset so current position equals the given coordinate.",
        "example": "G10 L10 P101 X1.0 Z0.0\n; Touch off: current pos = X1.0 dia, Z0 face",
    },
    {
        "code": "G10 L11",
        "name": "Set Tool Table (from G59.3)",
        "desc": "Like G10 L10 but references the G59.3 coordinate system.",
        "example": "G10 L11 P101 Z0.0\n; Set Z offset relative to G59.3 origin",
    },
    {
        "code": "G17",
        "name": "XY Plane Select",
        "desc": "Select XY plane for arcs. Rarely used on lathes (G18 is default).",
        "example": "G17\n; Select XY plane (mill-turn operations)",
    },
    {
        "code": "G18",
        "name": "XZ Plane Select",
        "desc": "Select XZ plane for arcs. Default and standard for lathe operations.",
        "example": "G18\n; XZ plane — default for lathe arcs (G02/G03)",
    },
    {
        "code": "G20",
        "name": "Inch Units",
        "desc": "All subsequent coordinates and feed rates are in inches.",
        "example": "G20\nG01 X1.0 Z-2.0 F0.005\n; Inch mode, 0.005 in/rev feed",
    },
    {
        "code": "G21",
        "name": "Metric Units",
        "desc": "All subsequent coordinates and feed rates are in millimeters.",
        "example": "G21\nG01 X25.4 Z-50.8 F0.127\n; Metric mode, 0.127 mm/rev feed",
    },
    {
        "code": "G28",
        "name": "Return to Home (via ref point)",
        "desc": "Move through an intermediate point, then to machine home. Safe retract.",
        "example": "G28 U0 W0\n; Return to home via current position (no intermediate move)",
    },
    {
        "code": "G30",
        "name": "Return to Secondary Home",
        "desc": "Move to the secondary reference point (tool change position).",
        "example": "G30 U0 W0\n; Go to tool change position",
    },
    {
        "code": "G33",
        "name": "Spindle-Synchronized Motion",
        "desc": "Single-pass threading move synchronized to spindle encoder. K=pitch (distance/rev).",
        "example": "G33 Z-1.5 K0.05\n; Thread pass: 20 TPI (0.05\" pitch) to Z-1.5",
    },
    {
        "code": "G33.1",
        "name": "Rigid Tapping",
        "desc": "Synchronized tap cycle. Spindle reverses at bottom. K=pitch.",
        "example": "G33.1 Z-0.75 K0.05\n; Rigid tap 1/4-20 to 0.75\" depth",
    },
    {
        "code": "G40",
        "name": "Cutter Compensation Off",
        "desc": "Cancel tool nose radius compensation. Must be active before tool changes.",
        "example": "G40\n; Cancel cutter comp before rapid moves or tool change",
    },
    {
        "code": "G41",
        "name": "Cutter Compensation Left",
        "desc": "Tool nose radius compensation, tool on left side of cut (OD turning).",
        "example": "G41 G01 X1.0 Z0.1 F0.005\n; Engage comp on approach move",
    },
    {
        "code": "G42",
        "name": "Cutter Compensation Right",
        "desc": "Tool nose radius compensation, tool on right side of cut (boring).",
        "example": "G42 G01 X0.5 Z0.1 F0.005\n; Engage comp for boring operation",
    },
    {
        "code": "G43",
        "name": "Tool Length Offset",
        "desc": "Apply tool length (geometry) offset from tool table. H=tool number.",
        "example": "T0101 M06\nG43\n; Apply tool 1 geometry offsets",
    },
    {
        "code": "G49",
        "name": "Cancel Tool Length Offset",
        "desc": "Cancel active tool length compensation.",
        "example": "G49\n; Cancel tool offset before homing",
    },
    {
        "code": "G53",
        "name": "Move in Machine Coordinates",
        "desc": "Next move uses absolute machine coordinates (ignores WCS). Non-modal.",
        "example": "G53 G00 X0 Z0\n; Rapid to machine home (absolute machine zero)",
    },
    {
        "code": "G54",
        "name": "Work Coordinate System 1",
        "desc": "Select WCS 1. Most common for single-setup lathe work.",
        "example": "G54\n; Use WCS 1 (part zero at chuck face)",
    },
    {
        "code": "G55–G59",
        "name": "Work Coordinate Systems 2–6",
        "desc": "Additional work coordinate systems for multi-setup or fixture work.",
        "example": "G55\n; Switch to WCS 2 (e.g., second-op part zero)",
    },
    {
        "code": "G61",
        "name": "Exact Path Mode",
        "desc": "Machine decelerates to exact stop at each programmed point. Most accurate.",
        "example": "G61\nG01 X1.0 Z-1.0 F0.003\n; Exact stop at endpoint (sharp corners)",
    },
    {
        "code": "G64",
        "name": "Path Blending Mode",
        "desc": "Blend between moves for smoother motion. P=tolerance, Q=naive CAM tolerance.",
        "example": "G64 P0.001\n; Blend moves within 0.001\" tolerance (smooth profiles)",
    },
    {
        "code": "G70",
        "name": "Finishing Cycle",
        "desc": "LinuxCNC canned cycle: finish pass following a previously defined profile (G71/G72).",
        "example": "G70 P100 Q200\n; Finish pass over profile defined in N100–N200",
    },
    {
        "code": "G71",
        "name": "OD/ID Stock Removal (Longitudinal)",
        "desc": "Canned roughing cycle along Z-axis. Removes material in multiple passes.",
        "example": "G71 P100 Q200 U0.01 W0.005 D0.05 F0.008\n; Rough 0.050\" DOC, 0.01\" X finish, 0.005\" Z finish",
    },
    {
        "code": "G72",
        "name": "Facing Stock Removal",
        "desc": "Canned roughing cycle along X-axis (facing). Multiple passes toward center.",
        "example": "G72 P100 Q200 U0.01 W0.005 D0.05 F0.008\n; Face rough cycle, 0.050\" DOC",
    },
    {
        "code": "G73",
        "name": "Pattern Repeating Cycle",
        "desc": "Rough a profile that follows the finish shape (for castings/forgings).",
        "example": "G73 P100 Q200 U0.02 W0.01 D3 F0.006\n; 3 passes following near-net shape",
    },
    {
        "code": "G76",
        "name": "Threading Cycle (canned)",
        "desc": "Multi-pass threading cycle. Handles infeed, depth, and spring passes automatically.",
        "example": "G76 P010060 Z-1.0 I-0.0162 J0.005 K0.0325\n; 1/2-20 UNF thread, 1\" long",
    },
    {
        "code": "G80",
        "name": "Cancel Canned Cycle",
        "desc": "Cancel any active canned drilling/boring cycle.",
        "example": "G80\n; Cancel active drill cycle",
    },
    {
        "code": "G83",
        "name": "Peck Drilling Cycle",
        "desc": "Drill with peck retract for chip clearing. R=retract, Z=depth, Q=peck.",
        "example": "G83 Z-1.5 R0.1 Q0.125 F0.003\n; Peck drill 1.5\" deep, 0.125\" pecks",
    },
    {
        "code": "G85",
        "name": "Boring Cycle (feed out)",
        "desc": "Bore to depth at feed rate, retract at feed rate. For finish bores.",
        "example": "G85 Z-1.0 R0.1 F0.002\n; Finish bore to 1\" depth",
    },
    {
        "code": "G90",
        "name": "Absolute Distance Mode",
        "desc": "Coordinates are absolute positions from the current WCS origin.",
        "example": "G90\nG01 X1.0 Z-2.0\n; Move to absolute position X1.0 Z-2.0",
    },
    {
        "code": "G91",
        "name": "Incremental Distance Mode",
        "desc": "Coordinates are distances relative to the current position.",
        "example": "G91\nG01 Z-0.050\n; Move 0.050\" in -Z direction from current pos",
    },
    {
        "code": "G92",
        "name": "Coordinate System Offset",
        "desc": "Set current position to specified value (temporary offset). Use G10 L2 instead when possible.",
        "example": "G92 X1.0 Z0.0\n; Set current position as X1.0 dia, Z0 (part face)",
    },
    {
        "code": "G92.1",
        "name": "Reset G92 Offset",
        "desc": "Clear any G92 offset. Restores WCS to its defined origin.",
        "example": "G92.1\n; Clear G92 offset (restore true WCS origin)",
    },
    {
        "code": "G95",
        "name": "Feed Per Revolution",
        "desc": "Feed rate is in distance per spindle revolution (in/rev or mm/rev).",
        "example": "G95\nG01 Z-2.0 F0.005\n; Feed at 0.005 in/rev (synchronized to spindle)",
    },
    {
        "code": "G96",
        "name": "Constant Surface Speed (CSS)",
        "desc": "Spindle speed varies to maintain constant SFM as diameter changes. S=SFM.",
        "example": "G96 S400 M03\n; CSS at 400 SFM (RPM adjusts with diameter)",
    },
    {
        "code": "G97",
        "name": "RPM Mode (Cancel CSS)",
        "desc": "Spindle runs at constant RPM regardless of diameter. S=RPM.",
        "example": "G97 S1200 M03\n; Constant 1200 RPM (for drilling, threading)",
    },
    {
        "code": "G98",
        "name": "Feed Per Minute",
        "desc": "Feed rate is in distance per minute (in/min or mm/min).",
        "example": "G98\nG01 Z-1.0 F10.0\n; Feed at 10 in/min (not spindle-synced)",
    },
]

# ---------------------------------------------------------------------------
# M-Code Reference Data
# ---------------------------------------------------------------------------
MCODES = [
    {
        "code": "M00",
        "name": "Program Stop",
        "desc": "Unconditional program stop. Operator must press Cycle Start to continue.",
        "example": "M00\n; Stop for inspection or manual operation",
    },
    {
        "code": "M01",
        "name": "Optional Stop",
        "desc": "Program stops only if Optional Stop switch is active on the control.",
        "example": "M01\n; Optional stop — check dimension if switch is on",
    },
    {
        "code": "M02",
        "name": "Program End",
        "desc": "End program, reset to beginning. Saves parameters and tool table.",
        "example": "M02\n; End of program (rewind to start)",
    },
    {
        "code": "M03",
        "name": "Spindle On CW",
        "desc": "Start spindle clockwise (standard turning direction for OD work).",
        "example": "M03 S1200\n; Spindle on CW at 1200 RPM",
    },
    {
        "code": "M04",
        "name": "Spindle On CCW",
        "desc": "Start spindle counter-clockwise (for left-hand threading or reverse boring).",
        "example": "M04 S800\n; Spindle on CCW at 800 RPM",
    },
    {
        "code": "M05",
        "name": "Spindle Stop",
        "desc": "Stop spindle rotation. Required before tool changes.",
        "example": "M05\n; Stop spindle before tool change",
    },
    {
        "code": "M06",
        "name": "Tool Change",
        "desc": "Execute tool change. Loads tool data from tool table. Preceded by T-word.",
        "example": "T0101 M06\n; Change to tool 1, apply offset 1",
    },
    {
        "code": "M07",
        "name": "Mist Coolant On",
        "desc": "Activate mist coolant output.",
        "example": "M07\n; Mist coolant on (air blast for aluminum)",
    },
    {
        "code": "M08",
        "name": "Flood Coolant On",
        "desc": "Activate flood coolant output.",
        "example": "M08\n; Flood coolant on for heavy cutting",
    },
    {
        "code": "M09",
        "name": "Coolant Off",
        "desc": "Turn off all coolant (mist and flood).",
        "example": "M09\n; All coolant off",
    },
    {
        "code": "M19",
        "name": "Spindle Orient",
        "desc": "Orient spindle to a specific angle. Used for live tooling or indexing.",
        "example": "M19 R90\n; Orient spindle to 90 degrees",
    },
    {
        "code": "M30",
        "name": "Program End & Rewind",
        "desc": "End program and rewind. Equivalent to M02 in LinuxCNC.",
        "example": "M30\n; End program, rewind to start",
    },
    {
        "code": "M48",
        "name": "Enable Feed & Speed Override",
        "desc": "Allow operator feed rate and spindle speed override knobs to function.",
        "example": "M48\n; Re-enable overrides after critical section",
    },
    {
        "code": "M49",
        "name": "Disable Feed & Speed Override",
        "desc": "Lock out override knobs. Feed and speed run at programmed values only.",
        "example": "M49\n; Lock overrides during threading pass",
    },
    {
        "code": "M50",
        "name": "Feed Override Control",
        "desc": "P0 disables feed override, P1 enables it.",
        "example": "M50 P0\n; Disable feed override (threading)",
    },
    {
        "code": "M51",
        "name": "Spindle Override Control",
        "desc": "P0 disables spindle speed override, P1 enables it.",
        "example": "M51 P0\n; Disable spindle override (critical RPM)",
    },
    {
        "code": "M52",
        "name": "Adaptive Feed Control",
        "desc": "P1 enables adaptive feed (feed adjusts based on cutting load). P0 disables.",
        "example": "M52 P1\n; Enable adaptive feed for variable material",
    },
    {
        "code": "M53",
        "name": "Feed Stop Control",
        "desc": "P1 enables feed stop switch, P0 disables it.",
        "example": "M53 P1\n; Enable feed stop switch",
    },
    {
        "code": "M61",
        "name": "Set Current Tool Number",
        "desc": "Set the current tool number without a tool change motion. For manual tool post.",
        "example": "M61 Q1\n; Tell LinuxCNC tool 1 is loaded (manual change done)",
    },
    {
        "code": "M62–M65",
        "name": "Digital Output Control",
        "desc": "M62/M63: synced on/off. M64/M65: immediate on/off. P=output number.",
        "example": "M64 P0\n; Turn on digital output 0 immediately (e.g., air blast)",
    },
    {
        "code": "M66",
        "name": "Wait on Input",
        "desc": "Wait for a digital or analog input to reach a condition. P/E=input, L=mode.",
        "example": "M66 P0 L3 Q5\n; Wait up to 5s for digital input 0 to go high",
    },
    {
        "code": "M67–M68",
        "name": "Analog Output Control",
        "desc": "M67: synced analog output. M68: immediate. E=output, Q=value.",
        "example": "M68 E0 Q5.0\n; Set analog output 0 to 5.0V immediately",
    },
    {
        "code": "M100–M199",
        "name": "User-Defined M-Codes",
        "desc": "Call external scripts in the NC files directory. M1xx runs M1xx script.",
        "example": "M100 P1 Q2\n; Run user script M100 with P=1, Q=2 arguments",
    },
]


# ---------------------------------------------------------------------------
# Widget
# ---------------------------------------------------------------------------
class GCodeRefTab(QWidget):
    """G/M Code Library — searchable glossary of LinuxCNC codes."""

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setSpacing(6)
        layout.setContentsMargins(6, 6, 6, 6)

        # --- Search bar ---
        search_row = QHBoxLayout()
        search_row.setSpacing(8)
        search_lbl = QLabel("Search:")
        search_lbl.setFont(ui_font(FONT_SIZES['body'], QFont.Bold))
        search_row.addWidget(search_lbl)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Filter by code, name, or keyword…")
        self.search_input.setFont(mono_font(FONT_SIZES['body']))
        self.search_input.textChanged.connect(self._filter)
        search_row.addWidget(self.search_input, stretch=1)

        self.result_count = QLabel("")
        self.result_count.setFont(ui_font(FONT_SIZES['secondary']))
        self.result_count.setStyleSheet(f"color: {COLORS['text_dim']};")
        search_row.addWidget(self.result_count)
        layout.addLayout(search_row)

        # --- Sub-tabs for G-codes and M-codes ---
        self.sub_tabs = QTabWidget()
        self.sub_tabs.setStyleSheet(
            f"QTabBar::tab {{ min-height: 36px; min-width: 70px; "
            f"font-size: {FONT_SIZES['body']}px; padding: 4px 16px; }}"
        )

        # G-Code scroll area
        self.g_scroll = QScrollArea()
        self.g_scroll.setWidgetResizable(True)
        self.g_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.g_container = QWidget()
        self.g_layout = QVBoxLayout(self.g_container)
        self.g_layout.setSpacing(4)
        self.g_layout.setContentsMargins(4, 4, 4, 4)
        self.g_cards = self._build_cards(GCODES, self.g_layout)
        self.g_layout.addStretch()
        self.g_scroll.setWidget(self.g_container)
        self.sub_tabs.addTab(self.g_scroll, "G-Codes")

        # M-Code scroll area
        self.m_scroll = QScrollArea()
        self.m_scroll.setWidgetResizable(True)
        self.m_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.m_container = QWidget()
        self.m_layout = QVBoxLayout(self.m_container)
        self.m_layout.setSpacing(4)
        self.m_layout.setContentsMargins(4, 4, 4, 4)
        self.m_cards = self._build_cards(MCODES, self.m_layout)
        self.m_layout.addStretch()
        self.m_scroll.setWidget(self.m_container)
        self.sub_tabs.addTab(self.m_scroll, "M-Codes")

        layout.addWidget(self.sub_tabs, stretch=1)

        self._update_count()

    def _build_cards(self, data, parent_layout):
        """Create card widgets for each code entry and add to layout."""
        cards = []
        for entry in data:
            card = _CodeCard(entry)
            parent_layout.addWidget(card)
            cards.append(card)
        return cards

    def _filter(self, text):
        """Filter visible cards based on search text."""
        query = text.strip().lower()
        for card in self.g_cards:
            card.setVisible(card.matches(query))
        for card in self.m_cards:
            card.setVisible(card.matches(query))
        self._update_count()

    def _update_count(self):
        """Update the result count label."""
        g_vis = sum(1 for c in self.g_cards if c.isVisible())
        m_vis = sum(1 for c in self.m_cards if c.isVisible())
        total = g_vis + m_vis
        self.result_count.setText(f"{total} codes shown")


class _CodeCard(QFrame):
    """Single code reference card with code, name, description, and example."""

    def __init__(self, entry, parent=None):
        super().__init__(parent)
        self._entry = entry
        self._search_text = (
            f"{entry['code']} {entry['name']} {entry['desc']} {entry['example']}"
        ).lower()

        self.setStyleSheet(
            f"_CodeCard {{ "
            f"background-color: {COLORS['groupbox_dark']}; "
            f"border: 1px solid {COLORS['border']}; "
            f"border-radius: 8px; "
            f"padding: 8px; }}"
        )
        self.setFrameShape(QFrame.StyledPanel)

        layout = QHBoxLayout(self)
        layout.setSpacing(12)
        layout.setContentsMargins(10, 8, 10, 8)

        # Left: code badge
        code_lbl = QLabel(entry["code"])
        code_lbl.setFont(mono_font(FONT_SIZES['tab_label'], QFont.Bold))
        code_lbl.setFixedWidth(90)
        code_lbl.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        code_lbl.setStyleSheet(
            f"color: {COLORS['accent_blue_lt']}; background: transparent;"
        )
        layout.addWidget(code_lbl)

        # Middle: name + description
        mid = QVBoxLayout()
        mid.setSpacing(2)

        name_lbl = QLabel(entry["name"])
        name_lbl.setFont(ui_font(FONT_SIZES['body'], QFont.Bold))
        name_lbl.setStyleSheet(f"color: {COLORS['text']}; background: transparent;")
        name_lbl.setWordWrap(True)
        mid.addWidget(name_lbl)

        desc_lbl = QLabel(entry["desc"])
        desc_lbl.setFont(ui_font(FONT_SIZES['secondary']))
        desc_lbl.setStyleSheet(f"color: {COLORS['text_secondary']}; background: transparent;")
        desc_lbl.setWordWrap(True)
        mid.addWidget(desc_lbl)

        layout.addLayout(mid, stretch=1)

        # Right: example
        ex_lbl = QLabel(entry["example"])
        ex_lbl.setFont(mono_font(FONT_SIZES['secondary']))
        ex_lbl.setStyleSheet(
            f"color: {COLORS['dro_text']}; "
            f"background-color: {COLORS['dro_bg']}; "
            f"border-radius: 4px; padding: 6px;"
        )
        ex_lbl.setFixedWidth(320)
        ex_lbl.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        ex_lbl.setWordWrap(True)
        layout.addWidget(ex_lbl)

    def matches(self, query):
        """Return True if this card matches the search query."""
        if not query:
            return True
        return query in self._search_text
