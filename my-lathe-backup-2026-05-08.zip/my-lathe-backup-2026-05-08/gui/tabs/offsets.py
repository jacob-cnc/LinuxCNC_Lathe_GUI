"""Offsets Tab — Work coordinate offset management.

Work offsets (G54-G59) are persisted by LinuxCNC in the .var parameter file.
They survive power cycles as long as LinuxCNC shuts down cleanly.
This tab provides a GUI for viewing and setting offsets via G10 commands.

The active WCS is selected from the sidebar dropdown and displayed here.
All six coordinate systems are shown in a table for quick reference.
"""

import os

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel,
    QPushButton, QGroupBox, QLineEdit
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

from theme import COLORS, TOUCH_SIZES, mono_font


class OffsetsTab(QWidget):
    """Work coordinate offsets management.

    Offsets are stored by LinuxCNC in the parameter file (my-lathe.var)
    and persist between sessions. This tab sends G10 commands to
    set offsets, which LinuxCNC saves on clean shutdown.

    The active WCS is driven by the sidebar WCS combo — this tab displays
    it as a read-only label and provides touch-off controls for it.
    """

    # G-code P values for each coordinate system
    _WCS_P = {"G54": 1, "G55": 2, "G56": 3, "G57": 4, "G58": 5, "G59": 6}

    # .var file parameter numbers for each WCS (X is param+0, Z is param+2)
    # G54=5221, G55=5241, G56=5261, G57=5281, G58=5301, G59=5321
    _WCS_VAR_BASE = {"G54": 5221, "G55": 5241, "G56": 5261,
                     "G57": 5281, "G58": 5301, "G59": 5321}

    def __init__(self, stat=None, cmd=None, var_file_path=None, parent=None):
        super().__init__(parent)
        self._stat = stat
        self._cmd = cmd
        self._var_file_path = var_file_path
        self._metric_display = False
        self._active_wcs = "G54"

        layout = QVBoxLayout(self)
        layout.setSpacing(10)

        # --- Shared styles ---
        lbl_style = (
            f"color: {COLORS['text_secondary']}; font-size: 14px; "
            f"background: transparent; border: none;"
        )
        val_style = (
            f"background-color: {COLORS['dro_bg']}; color: {COLORS['dro_text']}; "
            f"border: 1px solid {COLORS['border']}; border-radius: 4px; "
            f"padding: 4px 8px;"
        )
        input_style = (
            f"QLineEdit {{ background-color: {COLORS['dro_bg']}; color: {COLORS['text']}; "
            f"border: 1px solid {COLORS['border']}; border-radius: 4px; "
            f"padding: 4px 8px; }}"
            f"QLineEdit:focus {{ border: 1px solid {COLORS['accent_blue_lt']}; }}"
        )

        # --- Active WCS display ---
        active_group = QGroupBox("Active Work Coordinate System")
        active_layout = QGridLayout(active_group)
        active_layout.setSpacing(8)
        active_layout.setContentsMargins(12, 20, 12, 12)

        # Row 0: Active WCS label (driven by sidebar)
        wcs_lbl = QLabel("Active WCS:")
        wcs_lbl.setStyleSheet(lbl_style)
        active_layout.addWidget(wcs_lbl, 0, 0)
        self.active_wcs_label = QLabel("G54")
        self.active_wcs_label.setFont(mono_font(22, QFont.Bold))
        self.active_wcs_label.setStyleSheet(
            f"color: {COLORS['accent_blue_lt']}; background: {COLORS['dro_bg']}; "
            f"border: 2px solid {COLORS['accent_blue_dk']}; border-radius: 6px; "
            f"padding: 4px 16px;"
        )
        active_layout.addWidget(self.active_wcs_label, 0, 1)

        # Row 1: Current X offset (read from LinuxCNC)
        x_lbl = QLabel("X Offset:")
        x_lbl.setStyleSheet(lbl_style)
        active_layout.addWidget(x_lbl, 1, 0)
        self.active_x_label = QLabel("0.0000")
        self.active_x_label.setFont(mono_font(16))
        self.active_x_label.setStyleSheet(val_style)
        active_layout.addWidget(self.active_x_label, 1, 1)

        # Row 2: Current Z offset (read from LinuxCNC)
        z_lbl = QLabel("Z Offset:")
        z_lbl.setStyleSheet(lbl_style)
        active_layout.addWidget(z_lbl, 2, 0)
        self.active_z_label = QLabel("0.0000")
        self.active_z_label.setFont(mono_font(16))
        self.active_z_label.setStyleSheet(val_style)
        active_layout.addWidget(self.active_z_label, 2, 1)

        # Row 3: Touch-off controls
        touchoff_group = QHBoxLayout()
        touchoff_group.setSpacing(6)

        # "Set X Here" — touch off X to a known value
        x_eq_lbl = QLabel("X=")
        x_eq_lbl.setFont(mono_font(13, QFont.Bold))
        x_eq_lbl.setStyleSheet(f"color: {COLORS['text']}; background: transparent; border: none;")
        touchoff_group.addWidget(x_eq_lbl)

        self.touchoff_x_val = QLineEdit("0.0000")
        self.touchoff_x_val.setFont(mono_font(13))
        self.touchoff_x_val.setFixedWidth(110)
        self.touchoff_x_val.setFixedHeight(TOUCH_SIZES['target_min'])
        self.touchoff_x_val.setStyleSheet(input_style)
        self.touchoff_x_val.setToolTip(
            "Known X diameter at current position.\n"
            "Enter 0 to set X origin here, or a known diameter\n"
            "(e.g., 2.000 if touching a 2\" diameter surface)."
        )
        touchoff_group.addWidget(self.touchoff_x_val)

        self.btn_set_x_here = QPushButton("Set X Here")
        self.btn_set_x_here.setFixedHeight(TOUCH_SIZES['target_min'])
        self.btn_set_x_here.setToolTip("Set WCS X so current position = entered value (G10 L20)")
        self.btn_set_x_here.clicked.connect(self._set_x_here)
        touchoff_group.addWidget(self.btn_set_x_here)

        touchoff_group.addSpacing(20)

        # "Set Z Here" — touch off Z to a known value
        z_eq_lbl = QLabel("Z=")
        z_eq_lbl.setFont(mono_font(13, QFont.Bold))
        z_eq_lbl.setStyleSheet(f"color: {COLORS['text']}; background: transparent; border: none;")
        touchoff_group.addWidget(z_eq_lbl)

        self.touchoff_z_val = QLineEdit("0.0000")
        self.touchoff_z_val.setFont(mono_font(13))
        self.touchoff_z_val.setFixedWidth(110)
        self.touchoff_z_val.setFixedHeight(TOUCH_SIZES['target_min'])
        self.touchoff_z_val.setStyleSheet(input_style)
        self.touchoff_z_val.setToolTip(
            "Known Z coordinate at current position.\n"
            "Enter 0 to set Z origin here (face of part),\n"
            "or a known value (e.g., -2.000 if 2\" from face)."
        )
        touchoff_group.addWidget(self.touchoff_z_val)

        self.btn_set_z_here = QPushButton("Set Z Here")
        self.btn_set_z_here.setFixedHeight(TOUCH_SIZES['target_min'])
        self.btn_set_z_here.setToolTip("Set WCS Z so current position = entered value (G10 L20)")
        self.btn_set_z_here.clicked.connect(self._set_z_here)
        touchoff_group.addWidget(self.btn_set_z_here)

        touchoff_group.addStretch()
        active_layout.addLayout(touchoff_group, 3, 0, 1, 2)

        # Status label
        self.status_label = QLabel("")
        self.status_label.setStyleSheet(
            f"color: {COLORS['text_dim']}; background: transparent; border: none;")
        active_layout.addWidget(self.status_label, 4, 0, 1, 2)

        layout.addWidget(active_group)

        layout.addStretch()

    def set_linuxcnc(self, stat, cmd):
        """Set LinuxCNC stat/cmd references (called after connection)."""
        self._stat = stat
        self._cmd = cmd

    def set_var_file_path(self, path):
        """Set the path to the .var parameter file for reading non-active WCS."""
        self._var_file_path = path

    def set_active_wcs(self, wcs_name):
        """Set the active WCS (called from sidebar combo change).

        Args:
            wcs_name: e.g. "G54", "G55", etc. "G53" is ignored (machine coords).
        """
        if wcs_name == "G53" or wcs_name not in self._WCS_P:
            return
        self._active_wcs = wcs_name
        self.active_wcs_label.setText(wcs_name)
        self._refresh_active_offset()

    def _refresh_active_offset(self):
        """Read the selected WCS offset.

        If the selected WCS matches LinuxCNC's active WCS, read from stat
        (most current). Otherwise, read from the .var parameter file.
        """
        if self._stat is None:
            # Offline — try var file
            self._refresh_from_var_file()
            return
        try:
            self._stat.poll()
            p = self._WCS_P.get(self._active_wcs, 1)
            if self._stat.g5x_index == p:
                # Selected WCS is the active one — read live from stat
                x_off = self._stat.g5x_offset[0]
                z_off = self._stat.g5x_offset[2]
            else:
                # Selected WCS is not active — read from var file
                var_data = self._read_var_file()
                if var_data:
                    base = self._WCS_VAR_BASE.get(self._active_wcs, 5221)
                    x_off = var_data.get(base, 0.0)
                    z_off = var_data.get(base + 2, 0.0)
                else:
                    x_off = 0.0
                    z_off = 0.0
            metric = self._metric_display
            conv = 25.4 if metric else 1.0
            d = 3 if metric else 4
            self.active_x_label.setText(f"{x_off * conv:.{d}f}")
            self.active_z_label.setText(f"{z_off * conv:.{d}f}")
        except Exception:
            self._refresh_from_var_file()

    def _refresh_from_var_file(self):
        """Fallback: read selected WCS offset from .var file."""
        var_data = self._read_var_file()
        if not var_data:
            return
        base = self._WCS_VAR_BASE.get(self._active_wcs, 5221)
        x_off = var_data.get(base, 0.0)
        z_off = var_data.get(base + 2, 0.0)
        metric = self._metric_display
        conv = 25.4 if metric else 1.0
        d = 3 if metric else 4
        self.active_x_label.setText(f"{x_off * conv:.{d}f}")
        self.active_z_label.setText(f"{z_off * conv:.{d}f}")

    def _read_var_file(self):
        """Parse the .var parameter file and return {param_num: value} dict."""
        if not self._var_file_path or not os.path.exists(self._var_file_path):
            return {}
        try:
            data = {}
            with open(self._var_file_path, "r") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    parts = line.split()
                    if len(parts) >= 2:
                        try:
                            param = int(parts[0])
                            value = float(parts[1])
                            data[param] = value
                        except ValueError:
                            continue
            return data
        except Exception:
            return {}

    def _send_mdi(self, command):
        """Send an MDI command to LinuxCNC."""
        if self._cmd is None or self._stat is None:
            self.status_label.setText("Not connected to LinuxCNC")
            self.status_label.setStyleSheet(
                f"color: {COLORS['accent']}; background: transparent; border: none;")
            return False
        try:
            import linuxcnc
            self._cmd.mode(linuxcnc.MODE_MDI)
            self._cmd.wait_complete()
            self._cmd.mdi(command)
            self._cmd.wait_complete()
            self.status_label.setText(f"Sent: {command}")
            self.status_label.setStyleSheet(
                f"color: {COLORS['accent_green']}; background: transparent; border: none;")
            return True
        except Exception as e:
            self.status_label.setText(f"Error: {e}")
            self.status_label.setStyleSheet(
                f"color: {COLORS['accent']}; background: transparent; border: none;")
            return False

    def _set_x_here(self):
        """Set WCS X so current position equals the entered value (G10 L20)."""
        from PyQt5.QtWidgets import QMessageBox
        wcs = self._active_wcs
        p = self._WCS_P.get(wcs, 1)
        try:
            x_val = float(self.touchoff_x_val.text())
        except ValueError:
            self.status_label.setText("Invalid X value")
            self.status_label.setStyleSheet(
                f"color: {COLORS['accent']}; background: transparent; border: none;")
            return
        # Convert from display units back to inches
        if self._metric_display:
            x_val /= 25.4

        if x_val == 0.0:
            desc = f"Set {wcs} X origin to current position?"
        else:
            desc = f"Set {wcs} so current position reads X={x_val * 2:.4f}\" (dia)?"

        msg = QMessageBox(self)
        msg.setWindowTitle("Set X Here")
        msg.setText(f"Touch off {wcs} X?")
        msg.setInformativeText(desc)
        msg.setIcon(QMessageBox.Question)
        msg.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        msg.setDefaultButton(QMessageBox.No)
        msg.setStyleSheet(
            f"QMessageBox {{ background-color: {COLORS['bg_dark']}; color: {COLORS['text']}; }}"
            f"QLabel {{ color: {COLORS['text']}; font-size: 14px; }}"
            f"QPushButton {{ min-width: 80px; min-height: 40px; font-size: 13px; }}"
        )
        if msg.exec_() != QMessageBox.Yes:
            return
        # G10 L20 sets offset so current position = specified value
        cmd = f"G10 L20 P{p} X{x_val:.4f}"
        if self._send_mdi(cmd):
            self._refresh_active_offset()

    def _set_z_here(self):
        """Set WCS Z so current position equals the entered value (G10 L20)."""
        from PyQt5.QtWidgets import QMessageBox
        wcs = self._active_wcs
        p = self._WCS_P.get(wcs, 1)
        try:
            z_val = float(self.touchoff_z_val.text())
        except ValueError:
            self.status_label.setText("Invalid Z value")
            self.status_label.setStyleSheet(
                f"color: {COLORS['accent']}; background: transparent; border: none;")
            return
        # Convert from display units back to inches
        if self._metric_display:
            z_val /= 25.4

        if z_val == 0.0:
            desc = f"Set {wcs} Z origin to current position (face of part)?"
        else:
            desc = f"Set {wcs} so current position reads Z={z_val:.4f}\"?"

        msg = QMessageBox(self)
        msg.setWindowTitle("Set Z Here")
        msg.setText(f"Touch off {wcs} Z?")
        msg.setInformativeText(desc)
        msg.setIcon(QMessageBox.Question)
        msg.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        msg.setDefaultButton(QMessageBox.No)
        msg.setStyleSheet(
            f"QMessageBox {{ background-color: {COLORS['bg_dark']}; color: {COLORS['text']}; }}"
            f"QLabel {{ color: {COLORS['text']}; font-size: 14px; }}"
            f"QPushButton {{ min-width: 80px; min-height: 40px; font-size: 13px; }}"
        )
        if msg.exec_() != QMessageBox.Yes:
            return
        cmd = f"G10 L20 P{p} Z{z_val:.4f}"
        if self._send_mdi(cmd):
            self._refresh_active_offset()

    def set_metric_display(self, metric: bool):
        """Toggle display-only metric conversion for offset fields."""
        self._metric_display = metric
        self._refresh_active_offset()

    def periodic_refresh(self):
        """Called from main GUI periodic_update to keep active offset current."""
        self._refresh_active_offset()
