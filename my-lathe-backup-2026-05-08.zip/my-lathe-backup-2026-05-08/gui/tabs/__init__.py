"""
Tabs Package — All tab widgets for the main LatheGUI window.
"""

from tabs.manual import ManualTab
from tabs.program import ProgramTab
from tabs.mdi import MDITab
from tabs.tool import ToolTab
from tabs.offsets import OffsetsTab
from tabs.tuning import TuningTab
from tabs.edit import EditTab
from tabs.wear_offsets import WearOffsetPage
from tabs.hal_monitor import HALMonitorTab
from tabs.gcode_ref import GCodeRefTab

__all__ = [
    "ManualTab", "ProgramTab", "MDITab",
    "ToolTab", "OffsetsTab", "TuningTab",
    "EditTab", "WearOffsetPage", "HALMonitorTab",
    "GCodeRefTab",
]
