"""Program Tab — G-code loading, display, and execution."""

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QPlainTextEdit, QSpinBox, QTextEdit
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QTextFormat

from theme import COLORS, mono_font
from line_numbers import resolve_n_word
from gcode_editor import LineNumberArea, GCodeEditor  # noqa: F401


# ---------------------------------------------------------------------------
# ProgramTab
# ---------------------------------------------------------------------------
class ProgramTab(QWidget):
    """G-code program management and execution."""

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setSpacing(4)  # Task 1.6: reduced from 8px

        # --- File controls + Run-from-line + DTG in one row ---
        file_row_widget = QWidget()
        file_row = QHBoxLayout(file_row_widget)
        file_row.setContentsMargins(0, 0, 0, 0)
        self.btn_open = QPushButton("Open")
        self.btn_reload = QPushButton("Reload")
        self.file_label = QLabel("No file loaded")
        self.file_label.setStyleSheet(f"color: {COLORS['text_dim']};")
        self.file_label.setTextFormat(Qt.PlainText)
        self.file_label.setWordWrap(False)
        file_row.addWidget(self.btn_open)
        file_row.addWidget(self.btn_reload)
        file_row.addWidget(self.file_label)

        # Run-from-line controls (moved here from bottom row)
        file_row.addStretch()
        n_label = QLabel("N#:")
        n_label.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 12px;")
        file_row.addWidget(n_label)

        self.start_line_input = QSpinBox()
        self.start_line_input.setRange(0, 99999)
        self.start_line_input.setSingleStep(10)
        self.start_line_input.setValue(0)
        self.start_line_input.setMaximumWidth(90)
        self.start_line_input.setMaximumHeight(28)
        self.start_line_input.setToolTip("Enter N# (e.g. 30 for N30)")
        file_row.addWidget(self.start_line_input)

        self.btn_run_from = QPushButton("Run From Line")
        self.btn_run_from.setMaximumHeight(28)
        self.btn_run_from.setStyleSheet(
            "QPushButton { max-height: 28px; font-size: 12px; }"
        )
        self.btn_run_from.setEnabled(False)
        self.btn_run_from.setToolTip("Requires LinuxCNC connection")
        file_row.addWidget(self.btn_run_from)

        # DTG readouts (right side of file row)
        dtg_label = QLabel("DTG")
        dtg_label.setStyleSheet(
            f"color: {COLORS['text_dim']}; font-weight: 700; font-size: 14px; background: transparent;"
        )
        file_row.addWidget(dtg_label)

        dtg_x_label = QLabel("X")
        dtg_x_label.setStyleSheet(
            f"color: {COLORS['accent_blue_lt']}; font-weight: 700; font-size: 14px; background: transparent;"
        )
        file_row.addWidget(dtg_x_label)

        self.dtg_x_value = QLabel("0.0000")
        self.dtg_x_value.setFont(mono_font(14))
        self.dtg_x_value.setStyleSheet(
            f"background-color: {COLORS['dro_bg']}; color: {COLORS['dro_text']}; "
            f"padding: 4px 8px; border-radius: 4px;"
        )
        file_row.addWidget(self.dtg_x_value)

        dtg_z_label = QLabel("Z")
        dtg_z_label.setStyleSheet(
            f"color: {COLORS['accent_blue_lt']}; font-weight: 700; font-size: 14px; background: transparent;"
        )
        file_row.addWidget(dtg_z_label)

        self.dtg_z_value = QLabel("0.0000")
        self.dtg_z_value.setFont(mono_font(14))
        self.dtg_z_value.setStyleSheet(
            f"background-color: {COLORS['dro_bg']}; color: {COLORS['dro_text']}; "
            f"padding: 4px 8px; border-radius: 4px;"
        )
        file_row.addWidget(self.dtg_z_value)

        layout.addWidget(file_row_widget)  # index 0

        # --- G-code display (Task 1.2: stretch=3, position index 1) ---
        self.gcode_display = GCodeEditor()
        self.gcode_display.setReadOnly(True)
        self.gcode_display.setFont(mono_font(18))
        self.gcode_display.setPlaceholderText("Load a G-code file to view...")
        self.gcode_display.setStyleSheet(
            f"QPlainTextEdit {{ background-color: {COLORS['dro_bg']}; "
            f"color: {COLORS['dro_text']}; "
            f"border: 2px solid {COLORS['bg_mid']}; "
            f"border-top: 2px solid {COLORS['bg_dark']}; "
            f"border-radius: 8px; padding: 6px; "
            f"selection-background-color: {COLORS['accent_blue']}; }}"
        )
        layout.addWidget(self.gcode_display, stretch=3)  # index 1

        # --- Execution controls (Task 1.4: compact row, no QGroupBox, 28px/12px) ---
        exec_row_widget = QWidget()
        exec_row = QHBoxLayout(exec_row_widget)
        exec_row.setContentsMargins(0, 0, 0, 0)

        self.btn_run = QPushButton("▶  Cycle Start")
        self.btn_run.setMaximumHeight(28)
        self.btn_run.setStyleSheet(
            f"QPushButton {{ background-color: {COLORS['accent_green']}; color: {COLORS['bg_dark']}; "
            f"font-size: 12px; font-weight: 700; border-radius: 10px; border: none; }}"
            f"QPushButton:hover {{ background-color: {COLORS['accent_green_lt']}; }}"
        )
        exec_row.addWidget(self.btn_run)

        self.btn_pause = QPushButton("⏸  Pause")
        self.btn_pause.setMaximumHeight(28)
        self.btn_pause.setStyleSheet(
            f"QPushButton {{ background-color: {COLORS['accent_orange']}; color: {COLORS['bg_dark']}; "
            f"font-size: 12px; font-weight: 700; border-radius: 10px; border: none; }}"
            f"QPushButton:hover {{ background-color: {COLORS['accent_warm']}; }}"
        )
        exec_row.addWidget(self.btn_pause)

        self.btn_stop = QPushButton("⏹  Stop")
        self.btn_stop.setMaximumHeight(28)
        self.btn_stop.setStyleSheet(
            f"QPushButton {{ background-color: {COLORS['accent']}; color: #ffffff; "
            f"font-size: 12px; font-weight: 700; border-radius: 10px; border: none; }}"
            f"QPushButton:hover {{ background-color: #d44637; }}"
        )
        exec_row.addWidget(self.btn_stop)
        layout.addWidget(exec_row_widget)

        # --- Connect highlight signal ---
        self.start_line_input.valueChanged.connect(self._on_start_line_changed)

    # --- Line highlighting ---
    def _on_start_line_changed(self, value):
        """Highlight the target line when operator enters an N-number."""
        if value == 0:
            # Clear all highlights
            self.gcode_display.setExtraSelections([])
            return

        gcode_text = self.gcode_display.toPlainText()
        if not gcode_text:
            self.gcode_display.setExtraSelections([])
            return

        line_index = resolve_n_word(gcode_text, value)
        if line_index is None:
            self.gcode_display.setExtraSelections([])
            return

        # Build ExtraSelection for the resolved line
        selection = QTextEdit.ExtraSelection()
        highlight_color = QColor(COLORS['accent_blue'])
        highlight_color.setAlpha(80)
        selection.format.setBackground(highlight_color)
        selection.format.setProperty(QTextFormat.FullWidthSelection, True)

        cursor = self.gcode_display.textCursor()
        block = self.gcode_display.document().findBlockByNumber(line_index)
        cursor.setPosition(block.position())
        selection.cursor = cursor

        self.gcode_display.setExtraSelections([selection])

        # Scroll to the highlighted line
        self.gcode_display.setTextCursor(cursor)
        self.gcode_display.centerCursor()

    # --- Distance to Go update ---
    def update_dtg(self, x_dtg: float, z_dtg: float, metric: bool = False) -> None:
        """Update the Distance to Go readouts.

        Parameters
        ----------
        x_dtg : float
            X-axis distance-to-go in radius (machine units).
            Converted to diameter for display (* 2).
        z_dtg : float
            Z-axis distance-to-go (machine units).
        metric : bool
            If True, convert from inches to mm for display.

        Both values are formatted to 4 decimal places.  Any non-numeric
        or otherwise invalid input silently falls back to "0.0000".
        """
        try:
            x_display = x_dtg * 2
            z_display = z_dtg
            if metric:
                x_display *= 25.4
                z_display *= 25.4
            self.dtg_x_value.setText(f"{x_display:.4f}")
            self.dtg_z_value.setText(f"{z_display:.4f}")
        except (TypeError, ValueError):
            self.dtg_x_value.setText("0.0000")
            self.dtg_z_value.setText("0.0000")
