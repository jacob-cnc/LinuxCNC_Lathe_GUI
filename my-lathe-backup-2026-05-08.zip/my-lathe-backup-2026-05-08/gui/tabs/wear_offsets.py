"""
Wear Offsets Module — Tool wear offset data model and UI components.
================================================================================
Pure data layer for managing tool wear compensation values, history,
stale-wear detection, and G10 command generation.  UI widgets for the
Tool Wear tab (IncrementControl, WearToolRow, WearOffsetPage).

All X-axis values are stored internally as **radius**.
Display values are converted to diameter (×2) with 4 decimal places.
"""

from functools import partial

from PyQt5.QtWidgets import (
    QWidget, QComboBox, QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QVBoxLayout, QScrollArea,
)
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QFont

from theme import COLORS, TOUCH_SIZES, mono_font, ui_font


# ---------------------------------------------------------------------------
# WearOffsetModel — pure data layer, no Qt dependency
# ---------------------------------------------------------------------------
class WearOffsetModel:
    """Data model for tool wear offsets — pure logic, no Qt dependency.

    Manages wear state, single-level undo history, geometry baselines
    for stale detection, and G10 command string generation.

    All X values stored as radius internally.  Display helpers convert
    to diameter (×2) for operator-facing output.
    """

    def __init__(self, num_tools: int = 6):
        self.num_tools = num_tools

        # Current geometry offsets read from LinuxCNC (radius for X)
        self.geometry: dict[int, dict[str, float]] = {
            t: {"x": 0.0, "z": 0.0} for t in range(1, num_tools + 1)
        }

        # Current wear offsets (radius for X)
        self.wear: dict[int, dict[str, float]] = {
            t: {"x": 0.0, "z": 0.0} for t in range(1, num_tools + 1)
        }

        # Single-level undo: previous wear value before last change
        self.history: dict[int, dict[str, float | None]] = {
            t: {"x": None, "z": None} for t in range(1, num_tools + 1)
        }

        # Geometry snapshot at last wear-zero (for stale detection)
        self.geo_baseline: dict[int, dict[str, float | None]] = {
            t: {"x": None, "z": None} for t in range(1, num_tools + 1)
        }

    # ------------------------------------------------------------------
    # Display formatting
    # ------------------------------------------------------------------
    def format_display_value(self, value: float, axis: str) -> str:
        """Format an internal value for operator display.

        X values are shown as diameter (internal radius × 2).
        Z values are shown unchanged.
        Both use 4 decimal places.
        """
        if axis == "x":
            return f"{value * 2:.4f}"
        return f"{value:.4f}"

    # ------------------------------------------------------------------
    # Total offset computation
    # ------------------------------------------------------------------
    def compute_total(self, tool_num: int, axis: str) -> float:
        """Return geometry + wear for a tool/axis (internal radius for X)."""
        return self.geometry[tool_num][axis] + self.wear[tool_num][axis]

    # ------------------------------------------------------------------
    # Incremental adjustment
    # ------------------------------------------------------------------
    def apply_increment(
        self, tool_num: int, axis: str, increment: float, direction: int
    ) -> float:
        """Apply an increment to a wear offset.

        Stores the previous value in history, then adds
        ``increment * direction`` to the current wear.

        Args:
            tool_num:  Tool number (1-based).
            axis:      ``'x'`` or ``'z'``.
            increment: Step size (always positive, e.g. 0.0001).
            direction: ``+1`` to add, ``-1`` to subtract.

        Returns:
            The new wear value (radius for X).
        """
        self.history[tool_num][axis] = self.wear[tool_num][axis]
        self.wear[tool_num][axis] += increment * direction
        return self.wear[tool_num][axis]

    # ------------------------------------------------------------------
    # Zero wear
    # ------------------------------------------------------------------
    def zero_wear(self, tool_num: int, axis: str) -> float:
        """Zero a tool's wear offset for the given axis.

        Saves the current wear to history, sets wear to 0.0,
        and records the current geometry as the new baseline
        (clearing any stale indicator).

        Returns:
            The previous wear value (before zeroing).
        """
        previous = self.wear[tool_num][axis]
        self.history[tool_num][axis] = previous
        self.wear[tool_num][axis] = 0.0
        self.geo_baseline[tool_num][axis] = self.geometry[tool_num][axis]
        return previous

    # ------------------------------------------------------------------
    # Undo
    # ------------------------------------------------------------------
    def undo(self, tool_num: int, axis: str) -> float | None:
        """Restore the previous wear value from history.

        If history exists, swaps the current wear with the stored
        value (so a second undo reverts the first undo).

        Returns:
            The restored wear value, or ``None`` if no history.
        """
        previous = self.history[tool_num][axis]
        if previous is None:
            return None
        # Save current value as new history (enables undo-of-undo)
        self.history[tool_num][axis] = self.wear[tool_num][axis]
        self.wear[tool_num][axis] = previous
        return previous

    # ------------------------------------------------------------------
    # Direct value set
    # ------------------------------------------------------------------
    def set_wear_direct(self, tool_num: int, axis: str, value: float) -> float:
        """Set a wear offset to an exact value (entered as radius).

        Stores the current wear in history before overwriting.

        Args:
            tool_num: Tool number (1-based).
            axis:     ``'x'`` or ``'z'``.
            value:    New wear value in internal units (radius for X).

        Returns:
            The previous wear value.
        """
        previous = self.wear[tool_num][axis]
        self.history[tool_num][axis] = previous
        self.wear[tool_num][axis] = value
        return previous

    # ------------------------------------------------------------------
    # Stale wear detection
    # ------------------------------------------------------------------
    def is_stale(self, tool_num: int) -> bool:
        """Check if geometry has diverged from the baseline.

        A tool is stale when a baseline exists for *any* axis and the
        current geometry differs from that recorded baseline.
        """
        for axis in ("x", "z"):
            baseline = self.geo_baseline[tool_num][axis]
            if baseline is not None:
                if self.geometry[tool_num][axis] != baseline:
                    return True
        return False

    # ------------------------------------------------------------------
    # G10 command builders
    # ------------------------------------------------------------------
    def build_g10_wear_command(
        self, tool_num: int, x_wear_radius: float, z_wear: float
    ) -> str:
        """Build a G10 L11 command for writing wear offsets.

        Args:
            tool_num:      Tool number (1-based).
            x_wear_radius: X wear value already in radius.
            z_wear:        Z wear value.

        Returns:
            Command string, e.g. ``G10 L11 P1 U0.0005 W-0.0010``
        """
        return f"G10 L11 P{tool_num} U{x_wear_radius:.4f} W{z_wear:.4f}"

    def build_g10_geo_command(
        self, tool_num: int, x_geo: float, z_geo: float
    ) -> str:
        """Build a G10 L1 command for writing geometry offsets.

        Args:
            tool_num: Tool number (1-based).
            x_geo:    X geometry value.
            z_geo:    Z geometry value.

        Returns:
            Command string, e.g. ``G10 L1 P1 X-1.2340 Z-3.5670``
        """
        return f"G10 L1 P{tool_num} X{x_geo:.4f} Z{z_geo:.4f}"


# ---------------------------------------------------------------------------
# IncrementControl — increment size selector widget
# ---------------------------------------------------------------------------
class IncrementControl(QWidget):
    """Increment size selector for wear adjustments.

    Compact widget with a label and a QComboBox offering three
    standard increment step sizes (in inches).  The middle value
    (0.0005") is selected by default.
    """

    INCREMENTS = [0.0001, 0.0005, 0.001]

    def __init__(self, parent=None):
        super().__init__(parent)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)

        # Label
        label = QLabel("Increment:")
        label.setFont(ui_font(size=13))
        label.setStyleSheet(f"color: {COLORS['text_secondary']};")
        layout.addWidget(label)

        # Combo box with increment options
        self._combo = QComboBox()
        self._combo.setFont(mono_font(size=13))
        for inc in self.INCREMENTS:
            self._combo.addItem(f"{inc}", inc)

        # Default to middle value (0.0005")
        self._combo.setCurrentIndex(1)

        self._combo.setStyleSheet(
            f"QComboBox {{"
            f"  background-color: {COLORS['bg_light']};"
            f"  color: {COLORS['text']};"
            f"  border: 1px solid {COLORS['border']};"
            f"  border-radius: 4px;"
            f"  padding: 4px 8px;"
            f"  min-height: {TOUCH_SIZES['target_min']}px;"
            f"}}"
            f"QComboBox QAbstractItemView {{"
            f"  background-color: {COLORS['bg_light']};"
            f"  color: {COLORS['text']};"
            f"  selection-background-color: {COLORS['accent_blue']};"
            f"}}"
            f"QComboBox QAbstractItemView::item {{"
            f"  min-height: {TOUCH_SIZES['target_min']}px;"
            f"  padding: 8px 12px;"
            f"}}"
        )
        layout.addWidget(self._combo)

    def get_increment(self) -> float:
        """Return the currently selected increment value (inches)."""
        return self._combo.currentData()


# ---------------------------------------------------------------------------
# WearToolRow — single tool row in the wear offset table
# ---------------------------------------------------------------------------
class WearToolRow(QFrame):
    """Single tool row in the wear offset table.

    Displays one tool's geometry, wear, and total offsets for X and Z
    axes, with +/- adjustment, zero, and undo buttons per axis.

    Signals:
        increment_requested(int, str, int): tool_num, axis, direction (+1/-1)
        zero_requested(int, str):           tool_num, axis
        undo_requested(int, str):           tool_num, axis
    """

    # Signals emitted when operator presses action buttons
    increment_requested = pyqtSignal(int, str, int)  # tool_num, axis, direction
    zero_requested = pyqtSignal(int, str)             # tool_num, axis
    undo_requested = pyqtSignal(int, str)             # tool_num, axis
    direct_input_requested = pyqtSignal(int, str, float)  # tool_num, axis, value (diameter for X)

    # Style constants
    _READONLY_COLOR = COLORS["text_dim"]
    _WEAR_COLOR = COLORS["text"]
    _HIGHLIGHT_COLOR = COLORS["accent_warm"]
    _STALE_COLOR = COLORS["accent"]
    _VALUE_MIN_WIDTH = 80
    _BTN_SIZE = 32

    def __init__(self, tool_num: int, parent=None):
        super().__init__(parent)
        self.tool_num = tool_num

        self.setFrameShape(QFrame.StyledPanel)
        self.setStyleSheet(
            f"WearToolRow {{"
            f"  background-color: {COLORS['bg_mid']};"
            f"  border: 1px solid {COLORS['border']};"
            f"  border-radius: 6px;"
            f"}}"
        )

        self._mono = mono_font(size=13)
        self._mono_bold = mono_font(size=13)
        self._mono_bold.setBold(True)

        # --- Build layout ---
        root = QHBoxLayout(self)
        root.setContentsMargins(6, 4, 6, 4)
        root.setSpacing(4)

        # Stale indicator (hidden by default)
        self._stale_label = QLabel("⚠")
        self._stale_label.setFont(ui_font(size=14))
        self._stale_label.setFixedWidth(20)
        self._stale_label.setAlignment(Qt.AlignCenter)
        self._stale_label.setStyleSheet(
            f"color: {self._STALE_COLOR}; background: transparent;"
        )
        self._stale_label.setToolTip(
            "Geometry changed since last wear zero — wear may be stale"
        )
        self._stale_label.hide()
        root.addWidget(self._stale_label)

        # Tool number label
        tool_label = QLabel(f"T{tool_num}")
        tool_label.setFont(ui_font(size=14, weight=70))
        tool_label.setFixedWidth(32)
        tool_label.setAlignment(Qt.AlignCenter)
        tool_label.setStyleSheet(
            f"color: {COLORS['accent_blue_lt']}; background: transparent;"
        )
        root.addWidget(tool_label)

        # Separator
        root.addWidget(self._separator())

        # --- Geometry columns (read-only, dimmer) ---
        geo_header_x = self._header_label("Geo X")
        self._geo_x = self._value_label(readonly=True)
        geo_header_z = self._header_label("Geo Z")
        self._geo_z = self._value_label(readonly=True)

        geo_group = QHBoxLayout()
        geo_group.setSpacing(4)
        geo_group.setContentsMargins(0, 0, 0, 0)
        for w in (geo_header_x, self._geo_x, geo_header_z, self._geo_z):
            geo_group.addWidget(w)
        root.addLayout(geo_group)

        root.addWidget(self._separator())

        # --- Wear X column with buttons ---
        wear_x_group = QHBoxLayout()
        wear_x_group.setSpacing(2)
        wear_x_group.setContentsMargins(0, 0, 0, 0)

        wear_x_header = self._header_label("Wear X")
        self._wear_x = self._value_label(readonly=False)
        self._btn_plus_x = self._action_btn("+", tooltip="Increase X wear")
        self._btn_minus_x = self._action_btn("−", tooltip="Decrease X wear")
        self._btn_zero_x = self._action_btn("0", tooltip="Zero X wear")
        self._btn_undo_x = self._action_btn("↩", tooltip="Undo X wear")
        self._btn_undo_x.setEnabled(False)

        for w in (
            wear_x_header, self._wear_x,
            self._btn_plus_x, self._btn_minus_x,
            self._btn_zero_x, self._btn_undo_x,
        ):
            wear_x_group.addWidget(w)
        root.addLayout(wear_x_group)

        root.addWidget(self._separator())

        # --- Wear Z column with buttons ---
        wear_z_group = QHBoxLayout()
        wear_z_group.setSpacing(2)
        wear_z_group.setContentsMargins(0, 0, 0, 0)

        wear_z_header = self._header_label("Wear Z")
        self._wear_z = self._value_label(readonly=False)
        self._btn_plus_z = self._action_btn("+", tooltip="Increase Z wear")
        self._btn_minus_z = self._action_btn("−", tooltip="Decrease Z wear")
        self._btn_zero_z = self._action_btn("0", tooltip="Zero Z wear")
        self._btn_undo_z = self._action_btn("↩", tooltip="Undo Z wear")
        self._btn_undo_z.setEnabled(False)

        for w in (
            wear_z_header, self._wear_z,
            self._btn_plus_z, self._btn_minus_z,
            self._btn_zero_z, self._btn_undo_z,
        ):
            wear_z_group.addWidget(w)
        root.addLayout(wear_z_group)

        root.addWidget(self._separator())

        # --- Total columns (read-only, dimmer) ---
        total_header_x = self._header_label("Total X")
        self._total_x = self._value_label(readonly=True)
        total_header_z = self._header_label("Total Z")
        self._total_z = self._value_label(readonly=True)

        total_group = QHBoxLayout()
        total_group.setSpacing(4)
        total_group.setContentsMargins(0, 0, 0, 0)
        for w in (total_header_x, self._total_x, total_header_z, self._total_z):
            total_group.addWidget(w)
        root.addLayout(total_group)

        # --- Connect button signals ---
        self._btn_plus_x.clicked.connect(
            partial(self.increment_requested.emit, tool_num, "x", 1)
        )
        self._btn_minus_x.clicked.connect(
            partial(self.increment_requested.emit, tool_num, "x", -1)
        )
        self._btn_zero_x.clicked.connect(
            partial(self.zero_requested.emit, tool_num, "x")
        )
        self._btn_undo_x.clicked.connect(
            partial(self.undo_requested.emit, tool_num, "x")
        )
        self._btn_plus_z.clicked.connect(
            partial(self.increment_requested.emit, tool_num, "z", 1)
        )
        self._btn_minus_z.clicked.connect(
            partial(self.increment_requested.emit, tool_num, "z", -1)
        )
        self._btn_zero_z.clicked.connect(
            partial(self.zero_requested.emit, tool_num, "z")
        )
        self._btn_undo_z.clicked.connect(
            partial(self.undo_requested.emit, tool_num, "z")
        )

        # Enable click-to-edit on wear value labels
        self._active_edit = None
        self._setup_click_to_edit()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def update_values(
        self,
        geo_x: str,
        geo_z: str,
        wear_x: str,
        wear_z: str,
        total_x: str,
        total_z: str,
    ) -> None:
        """Update all displayed value labels.

        All arguments are pre-formatted display strings — the caller
        is responsible for formatting (e.g. diameter conversion).
        """
        self._geo_x.setText(geo_x)
        self._geo_z.setText(geo_z)
        self._wear_x.setText(wear_x)
        self._wear_z.setText(wear_z)
        self._total_x.setText(total_x)
        self._total_z.setText(total_z)

    def set_highlight(self, axis: str, highlighted: bool) -> None:
        """Apply or remove non-zero wear highlight for an axis.

        Uses accent_warm (orange) to indicate active wear compensation.
        """
        label = self._wear_x if axis == "x" else self._wear_z
        if highlighted:
            label.setStyleSheet(
                f"color: {self._HIGHLIGHT_COLOR};"
                f" background: transparent;"
                f" font-weight: bold;"
            )
        else:
            label.setStyleSheet(
                f"color: {self._WEAR_COLOR};"
                f" background: transparent;"
            )

    def set_stale(self, stale: bool) -> None:
        """Show or hide the stale wear indicator.

        Uses accent (crimson) — visually distinct from the non-zero
        wear highlight (warm orange).
        """
        self._stale_label.setVisible(stale)

    def set_undo_enabled(self, axis: str, enabled: bool) -> None:
        """Enable or disable the undo button for an axis."""
        btn = self._btn_undo_x if axis == "x" else self._btn_undo_z
        btn.setEnabled(enabled)

    # ------------------------------------------------------------------
    # Click-to-edit for wear value labels
    # ------------------------------------------------------------------
    def _setup_click_to_edit(self) -> None:
        """Install mouse-press event filters on wear value labels."""
        self._wear_x.setCursor(Qt.PointingHandCursor)
        self._wear_z.setCursor(Qt.PointingHandCursor)
        self._wear_x.setToolTip("Click to enter a value directly")
        self._wear_z.setToolTip("Click to enter a value directly")
        self._wear_x.mousePressEvent = partial(self._start_edit, "x")
        self._wear_z.mousePressEvent = partial(self._start_edit, "z")

    def _start_edit(self, axis: str, event=None) -> None:
        """Replace the wear label with a QLineEdit for direct input."""
        label = self._wear_x if axis == "x" else self._wear_z

        # Don't open a second editor if one is already active
        if hasattr(self, "_active_edit") and self._active_edit is not None:
            return

        edit = QLineEdit(label.text().strip())
        edit.setFont(self._mono)
        edit.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        edit.setMinimumWidth(self._VALUE_MIN_WIDTH)
        edit.setStyleSheet(
            f"QLineEdit {{"
            f"  color: {COLORS['text']};"
            f"  background-color: {COLORS['bg_dark']};"
            f"  border: 2px solid {COLORS['accent_blue']};"
            f"  border-radius: 3px;"
            f"  padding: 2px 4px;"
            f"  selection-background-color: {COLORS['accent_blue']};"
            f"}}"
        )
        edit.selectAll()

        # Swap label for edit in the layout
        parent_layout = label.parentWidget().layout() if label.parentWidget() else None
        if parent_layout is None:
            # Fallback: find the layout containing this label
            parent_layout = label.parent().layout()

        # Find label position in its layout
        layout = self._find_layout_for_widget(label)
        if layout is None:
            return

        idx = layout.indexOf(label)
        label.hide()
        layout.insertWidget(idx, edit)
        edit.setFocus()

        self._active_edit = edit
        self._active_edit_axis = axis
        self._active_edit_label = label

        # Commit on Enter or focus loss
        edit.returnPressed.connect(partial(self._commit_edit, axis, edit, label, layout, idx))
        edit.editingFinished.connect(partial(self._commit_edit, axis, edit, label, layout, idx))

    def _commit_edit(self, axis: str, edit: QLineEdit, label: QLabel,
                     layout, idx: int) -> None:
        """Validate input, emit signal, and restore the label."""
        if not hasattr(self, "_active_edit") or self._active_edit is None:
            return

        text = edit.text().strip()
        self._active_edit = None

        # Remove the edit widget and restore the label
        edit.hide()
        edit.deleteLater()
        label.show()

        # Validate numeric input
        try:
            value = float(text)
        except ValueError:
            return  # Invalid input — discard silently

        # Emit signal with the diametrical value for X (user enters diameter)
        self.direct_input_requested.emit(self.tool_num, axis, value)

    def _find_layout_for_widget(self, widget):
        """Walk up to find the QHBoxLayout containing this widget."""
        parent = widget.parentWidget()
        if parent is None:
            return None
        layout = parent.layout()
        if layout is None:
            return None
        # Check direct children
        for i in range(layout.count()):
            item = layout.itemAt(i)
            if item.widget() is widget:
                return layout
            # Check nested layouts
            sub = item.layout()
            if sub is not None:
                for j in range(sub.count()):
                    if sub.itemAt(j).widget() is widget:
                        return sub
        return None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _header_label(self, text: str) -> QLabel:
        """Create a small column header label."""
        lbl = QLabel(text)
        lbl.setFont(ui_font(size=10))
        lbl.setAlignment(Qt.AlignCenter)
        lbl.setStyleSheet(
            f"color: {COLORS['text_secondary']}; background: transparent;"
        )
        return lbl

    def _value_label(self, readonly: bool = False) -> QLabel:
        """Create a numeric value display label."""
        lbl = QLabel("0.0000")
        lbl.setFont(self._mono)
        lbl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        lbl.setMinimumWidth(self._VALUE_MIN_WIDTH)
        color = self._READONLY_COLOR if readonly else self._WEAR_COLOR
        bg = COLORS["bg_dark"] if readonly else "transparent"
        lbl.setStyleSheet(
            f"color: {color}; background: {bg};"
            f" border-radius: 3px; padding: 2px 4px;"
        )
        return lbl

    def _action_btn(self, text: str, tooltip: str = "") -> QPushButton:
        """Create a compact square action button."""
        btn = QPushButton(text)
        btn.setFixedSize(self._BTN_SIZE, self._BTN_SIZE)
        btn.setFont(ui_font(size=12, weight=70))
        btn.setToolTip(tooltip)
        btn.setStyleSheet(
            f"QPushButton {{"
            f"  background-color: {COLORS['bg_light']};"
            f"  color: {COLORS['text']};"
            f"  border: 1px solid {COLORS['border']};"
            f"  border-radius: 4px;"
            f"  padding: 0px;"
            f"}}"
            f"QPushButton:hover {{"
            f"  background-color: {COLORS['bg_elevated']};"
            f"  border: 1px solid {COLORS['accent_blue_lt']};"
            f"}}"
            f"QPushButton:pressed {{"
            f"  background-color: {COLORS['bg_mid']};"
            f"}}"
            f"QPushButton:disabled {{"
            f"  background-color: {COLORS['bg_mid']};"
            f"  color: {COLORS['text_dim']};"
            f"  border: 1px solid {COLORS['bg_light']};"
            f"}}"
        )
        return btn

    def _separator(self) -> QFrame:
        """Create a thin vertical separator line."""
        sep = QFrame()
        sep.setFrameShape(QFrame.VLine)
        sep.setFixedWidth(1)
        sep.setStyleSheet(
            f"background-color: {COLORS['border']}; border: none;"
        )
        return sep


# ---------------------------------------------------------------------------
# WearOffsetPage — top-level tab widget composing model + UI
# ---------------------------------------------------------------------------
class WearOffsetPage(QWidget):
    """Tool wear offset management page.

    Composes an IncrementControl, a scrollable list of WearToolRow
    widgets, and a WearOffsetModel.  Handles LinuxCNC integration
    (G10 L11 writes, G43 reload, stat read-back) when connected,
    and operates in offline demo mode when stat/cmd are None.

    Args:
        stat: linuxcnc.stat() instance or None for offline mode.
        cmd:  linuxcnc.command() instance or None for offline mode.
        num_tools: Number of tool slots (default 6).
        parent: Parent QWidget.
    """

    NUM_TOOLS_DEFAULT = 6

    # Representative offline demo data (radius for X, raw for Z)
    _DEMO_DATA = {
        1: {"geo_x": -0.6170, "geo_z": -3.5670, "wear_x": 0.0006, "wear_z": -0.0003},
        2: {"geo_x": -0.5890, "geo_z": -2.1230, "wear_x": 0.0, "wear_z": 0.0},
        3: {"geo_x": -0.7250, "geo_z": -4.8900, "wear_x": -0.0012, "wear_z": 0.0005},
        4: {"geo_x": -0.4320, "geo_z": -1.7540, "wear_x": 0.0003, "wear_z": 0.0},
        5: {"geo_x": -0.8100, "geo_z": -5.2310, "wear_x": 0.0, "wear_z": -0.0008},
        6: {"geo_x": -0.5500, "geo_z": -3.0150, "wear_x": 0.0010, "wear_z": 0.0002},
    }

    def __init__(self, stat=None, cmd=None, num_tools=None, parent=None):
        super().__init__(parent)
        self._stat = stat
        self._cmd = cmd
        self._num_tools = num_tools or self.NUM_TOOLS_DEFAULT

        self._model = WearOffsetModel(self._num_tools)
        self._rows: dict[int, WearToolRow] = {}

        self._build_ui()
        self._wire_signals()

        # Populate initial data
        if self._stat is not None:
            self.refresh_from_stat()
        else:
            self._load_demo_data()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------
    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(6)

        # Title
        title = QLabel("Tool Wear Offsets")
        title.setFont(ui_font(size=16, weight=QFont.Bold))
        title.setStyleSheet(
            f"color: {COLORS['accent_blue_lt']}; background: transparent;"
        )
        root.addWidget(title)

        # Increment control
        self._increment_ctrl = IncrementControl()
        root.addWidget(self._increment_ctrl)

        # Scrollable area for tool rows
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet(f"background: {COLORS['bg_dark']};")

        scroll_content = QWidget()
        self._rows_layout = QVBoxLayout(scroll_content)
        self._rows_layout.setContentsMargins(0, 0, 0, 0)
        self._rows_layout.setSpacing(4)

        for t in range(1, self._num_tools + 1):
            row = WearToolRow(t)
            self._rows[t] = row
            self._rows_layout.addWidget(row)

        self._rows_layout.addStretch()
        scroll.setWidget(scroll_content)
        root.addWidget(scroll, stretch=1)

        # Status label at bottom
        self._status_label = QLabel("")
        self._status_label.setFont(ui_font(size=11))
        self._status_label.setStyleSheet(
            f"color: {COLORS['text_dim']}; background: transparent;"
            f" padding: 2px 4px;"
        )
        self._status_label.setWordWrap(True)
        root.addWidget(self._status_label)

    # ------------------------------------------------------------------
    # Signal wiring
    # ------------------------------------------------------------------
    def _wire_signals(self) -> None:
        for t, row in self._rows.items():
            row.increment_requested.connect(self.apply_increment)
            row.zero_requested.connect(self.zero_wear)
            row.undo_requested.connect(self.undo_wear)
            row.direct_input_requested.connect(self.set_wear_direct)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def get_selected_increment(self) -> float:
        """Return the currently selected increment value (inches)."""
        return self._increment_ctrl.get_increment()

    def refresh_from_stat(self) -> None:
        """Read all tool offsets from stat channel and update display.

        In offline mode (stat is None), this is a no-op.
        """
        if self._stat is None:
            return
        try:
            self._stat.poll()
            for t in range(1, self._num_tools + 1):
                entry = self._stat.tool_table[t]
                # LinuxCNC combines geometry + wear; we track wear
                # separately, so geometry = stat_total - our_wear
                stat_x = entry.xoffset  # radius
                stat_z = entry.zoffset
                wear_x = self._model.wear[t]["x"]
                wear_z = self._model.wear[t]["z"]
                self._model.geometry[t]["x"] = stat_x - wear_x
                self._model.geometry[t]["z"] = stat_z - wear_z
            self._refresh_all_rows()
            self._status_label.setText("")
        except Exception as e:
            self._status_label.setText(f"Communication error: {e}")
            self._status_label.setStyleSheet(
                f"color: {COLORS['accent']}; background: transparent;"
                f" padding: 2px 4px;"
            )

    def apply_increment(self, tool_num: int, axis: str, direction: int) -> None:
        """Apply incremental wear adjustment.

        Gets the selected increment, updates the model, issues G10 L11
        + G43 via MDI (if connected), and reads back from stat.
        """
        increment = self.get_selected_increment()
        self._model.apply_increment(tool_num, axis, increment, direction)
        self._write_wear_to_linuxcnc(tool_num)
        self._refresh_row(tool_num)

    def zero_wear(self, tool_num: int, axis: str) -> None:
        """Zero a tool's wear offset for the given axis.

        Updates the model (stores history, zeros wear, updates baseline),
        issues G10 L11 + G43, and reads back.
        """
        self._model.zero_wear(tool_num, axis)
        self._write_wear_to_linuxcnc(tool_num)
        self._refresh_row(tool_num)

    def undo_wear(self, tool_num: int, axis: str) -> None:
        """Restore previous wear value from history.

        If history exists, restores the value, issues G10 L11 + G43,
        and reads back.
        """
        restored = self._model.undo(tool_num, axis)
        if restored is None:
            return
        self._write_wear_to_linuxcnc(tool_num)
        self._refresh_row(tool_num)

    def set_wear_direct(self, tool_num: int, axis: str, value: float) -> None:
        """Set a wear offset to an exact value entered by the operator.

        The value is in diameter for X (as displayed to the operator).
        Converts to radius before storing. Stores history, issues
        G10 L11 + G43, and reads back.
        """
        # Convert diameter input to radius for X axis
        internal_value = value / 2.0 if axis == "x" else value
        self._model.set_wear_direct(tool_num, axis, internal_value)
        self._write_wear_to_linuxcnc(tool_num)
        self._refresh_row(tool_num)

    # ------------------------------------------------------------------
    # LinuxCNC write + read-back
    # ------------------------------------------------------------------
    def _write_wear_to_linuxcnc(self, tool_num: int) -> None:
        """Issue G10 L11 + G43 for the given tool, then read back.

        In offline mode, skips all LinuxCNC commands.
        """
        if self._cmd is None or self._stat is None:
            # Offline mode — local-only update
            return

        wear_x = self._model.wear[tool_num]["x"]
        wear_z = self._model.wear[tool_num]["z"]
        g10_cmd = self._model.build_g10_wear_command(tool_num, wear_x, wear_z)

        try:
            import linuxcnc
            self._cmd.mode(linuxcnc.MODE_MDI)
            self._cmd.wait_complete()
            self._cmd.mdi(g10_cmd)
            self._cmd.wait_complete()
            self._cmd.mdi("G43")
            self._cmd.wait_complete()

            # Read back to verify
            self._stat.poll()
            entry = self._stat.tool_table[tool_num]
            readback_x = entry.xoffset
            readback_z = entry.zoffset

            expected_total_x = self._model.compute_total(tool_num, "x")
            expected_total_z = self._model.compute_total(tool_num, "z")

            if (abs(readback_x - expected_total_x) > 1e-6
                    or abs(readback_z - expected_total_z) > 1e-6):
                self._status_label.setText(
                    f"Wear write verification failed for T{tool_num}"
                )
                self._status_label.setStyleSheet(
                    f"color: {COLORS['accent']}; background: transparent;"
                    f" padding: 2px 4px;"
                )
            else:
                # Update geometry from readback
                self._model.geometry[tool_num]["x"] = readback_x - wear_x
                self._model.geometry[tool_num]["z"] = readback_z - wear_z
                self._status_label.setText("")
                self._status_label.setStyleSheet(
                    f"color: {COLORS['text_dim']}; background: transparent;"
                    f" padding: 2px 4px;"
                )
        except Exception as e:
            self._status_label.setText(f"Write error T{tool_num}: {e}")
            self._status_label.setStyleSheet(
                f"color: {COLORS['accent']}; background: transparent;"
                f" padding: 2px 4px;"
            )

    # ------------------------------------------------------------------
    # Row refresh helpers
    # ------------------------------------------------------------------
    def _refresh_row(self, tool_num: int) -> None:
        """Update a single row's display values, highlight, stale, and undo state."""
        row = self._rows[tool_num]
        m = self._model

        geo_x = m.format_display_value(m.geometry[tool_num]["x"], "x")
        geo_z = m.format_display_value(m.geometry[tool_num]["z"], "z")
        wear_x = m.format_display_value(m.wear[tool_num]["x"], "x")
        wear_z = m.format_display_value(m.wear[tool_num]["z"], "z")
        total_x = m.format_display_value(m.compute_total(tool_num, "x"), "x")
        total_z = m.format_display_value(m.compute_total(tool_num, "z"), "z")

        row.update_values(geo_x, geo_z, wear_x, wear_z, total_x, total_z)

        # Highlight non-zero wear
        row.set_highlight("x", m.wear[tool_num]["x"] != 0.0)
        row.set_highlight("z", m.wear[tool_num]["z"] != 0.0)

        # Stale indicator
        row.set_stale(m.is_stale(tool_num))

        # Undo button state
        row.set_undo_enabled("x", m.history[tool_num]["x"] is not None)
        row.set_undo_enabled("z", m.history[tool_num]["z"] is not None)

    def _refresh_all_rows(self) -> None:
        """Refresh display for all tool rows."""
        for t in range(1, self._num_tools + 1):
            self._refresh_row(t)

    # ------------------------------------------------------------------
    # Offline demo data
    # ------------------------------------------------------------------
    def _load_demo_data(self) -> None:
        """Populate model with representative demo values for offline mode."""
        for t in range(1, self._num_tools + 1):
            if t in self._DEMO_DATA:
                d = self._DEMO_DATA[t]
                self._model.geometry[t]["x"] = d["geo_x"]
                self._model.geometry[t]["z"] = d["geo_z"]
                self._model.wear[t]["x"] = d["wear_x"]
                self._model.wear[t]["z"] = d["wear_z"]

        self._refresh_all_rows()
        self._status_label.setText(
            "Offline — changes are local only"
        )
        self._status_label.setStyleSheet(
            f"color: {COLORS['accent_yellow']}; background: transparent;"
            f" padding: 2px 4px;"
        )
