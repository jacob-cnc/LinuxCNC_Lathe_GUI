"""MDI Tab — Manual Data Input with command history."""

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel,
    QPushButton, QGroupBox, QTextEdit, QLineEdit
)

from theme import COLORS, mono_font


class MDITab(QWidget):
    """MDI command entry and history."""

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setSpacing(8)

        # --- Command entry ---
        cmd_group = QGroupBox("MDI Command")
        cmd_layout = QHBoxLayout(cmd_group)

        self.cmd_input = QLineEdit()
        self.cmd_input.setFont(mono_font(16))
        self.cmd_input.setPlaceholderText("Enter G-code command (e.g. G01 X1.0 Z-2.0 F5.0)")
        cmd_layout.addWidget(self.cmd_input, stretch=1)

        self.btn_execute = QPushButton("Execute")
        self.btn_execute.setStyleSheet(
            f"QPushButton {{ background-color: {COLORS['accent_green']}; color: {COLORS['bg_dark']}; "
            f"font-size: 18px; min-height: 38px; font-weight: 700; min-width: 100px; "
            f"border-radius: 8px; border: none; }}"
        )
        cmd_layout.addWidget(self.btn_execute)
        layout.addWidget(cmd_group)

        # --- Quick commands ---
        quick_group = QGroupBox("Quick Commands")
        quick_layout = QGridLayout(quick_group)

        quick_cmds = [
            ("G28", "Go Home"),
            ("G30", "Go Reference"),
            ("G92 X0 Z0", "Zero Both"),
            ("G92 X0", "Zero X"),
            ("G92 Z0", "Zero Z"),
            ("G20", "Inch Mode"),
            ("G90", "Absolute"),
            ("G91", "Incremental"),
        ]
        for i, (cmd, label) in enumerate(quick_cmds):
            btn = QPushButton(f"{label}\n{cmd}")
            btn.setStyleSheet("QPushButton { min-height: 45px; font-size: 16px; }")
            btn.setProperty("mdi_cmd", cmd)
            quick_layout.addWidget(btn, i // 4, i % 4)
        layout.addWidget(quick_group)

        # --- Command history ---
        hist_group = QGroupBox("History")
        hist_layout = QVBoxLayout(hist_group)
        self.history = QTextEdit()
        self.history.setReadOnly(True)
        self.history.setFont(mono_font(12))
        self.history.setMaximumHeight(200)
        hist_layout.addWidget(self.history)
        layout.addWidget(hist_group)

        layout.addStretch()
