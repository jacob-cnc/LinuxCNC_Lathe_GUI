"""
Edit Tab — G-code Editor with Syntax Highlighting
===================================================
Full-featured G-code editor tab: syntax highlighting, file management,
search/replace, and G-code-specific tooling (renumber, comment toggle,
block delete).
"""

import hashlib
import os
import re
from dataclasses import dataclass, field

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import (
    QColor, QFont, QKeySequence, QSyntaxHighlighter, QTextCharFormat,
    QTextCursor, QTextDocument,
)
from PyQt5.QtWidgets import (
    QFileDialog, QHBoxLayout, QInputDialog, QLabel, QLineEdit,
    QMenu, QMessageBox, QPlainTextEdit, QPushButton, QShortcut,
    QTextEdit, QToolButton, QVBoxLayout, QWidget,
)

from gcode_editor import GCodeEditor
from line_numbers import add_line_numbers
from theme import COLORS, TOUCH_SIZES, mono_font


# ---------------------------------------------------------------------------
# SyntaxRule — dataclass pairing a regex pattern with a QTextCharFormat
# ---------------------------------------------------------------------------
@dataclass
class SyntaxRule:
    """A single syntax-highlighting rule.

    Attributes:
        name:    Human-readable token name (e.g. "g_code", "comment_paren").
        pattern: Compiled regex that matches the token in a line of text.
        fmt:     QTextCharFormat to apply when the pattern matches.
    """
    name: str
    pattern: "re.Pattern[str]"
    fmt: QTextCharFormat


# ---------------------------------------------------------------------------
# Helper — build a QTextCharFormat from a COLORS key
# ---------------------------------------------------------------------------
def _make_fmt(color_key: str) -> QTextCharFormat:
    """Create a QTextCharFormat with the foreground set to COLORS[color_key]."""
    fmt = QTextCharFormat()
    fmt.setForeground(QColor(COLORS[color_key]))
    fmt.setFont(mono_font())
    return fmt


# ---------------------------------------------------------------------------
# GCodeSyntaxHighlighter — QSyntaxHighlighter for G-code tokens
# ---------------------------------------------------------------------------
class GCodeSyntaxHighlighter(QSyntaxHighlighter):
    """Applies color formatting to G-code tokens in a QTextDocument.

    Token rules are evaluated in priority order (first match wins per
    character span):

        1. comment (paren)     ``\\(.*?\\)``        → text_dim
        2. comment (semicolon) ``;.*$``             → text_dim
        3. O-word              ``^O\\d+``           → accent_orange
        4. N-word              ``^N\\d+``           → text_secondary
        5. G-code              ``G\\d{1,3}(\\.\\d)?`` → accent_blue
        6. M-code              ``M\\d{1,3}``        → accent_blue_dk
        7. coord word          ``[XZFSIKCR]-?\\d*\\.?\\d+`` → accent_green_lt
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._rules: list[SyntaxRule] = [
            SyntaxRule(
                name="comment_paren",
                pattern=re.compile(r"\(.*?\)"),
                fmt=_make_fmt("text_dim"),
            ),
            SyntaxRule(
                name="comment_semicolon",
                pattern=re.compile(r";.*$"),
                fmt=_make_fmt("text_dim"),
            ),
            SyntaxRule(
                name="o_word",
                pattern=re.compile(r"^O\d+"),
                fmt=_make_fmt("accent_orange"),
            ),
            SyntaxRule(
                name="n_word",
                pattern=re.compile(r"^N\d+"),
                fmt=_make_fmt("text_secondary"),
            ),
            SyntaxRule(
                name="g_code",
                pattern=re.compile(r"G\d{1,3}(\.\d)?"),
                fmt=_make_fmt("accent_blue"),
            ),
            SyntaxRule(
                name="m_code",
                pattern=re.compile(r"M\d{1,3}"),
                fmt=_make_fmt("accent_blue_dk"),
            ),
            SyntaxRule(
                name="coord_word",
                pattern=re.compile(r"[XZFSIKCR]-?\d*\.?\d+"),
                fmt=_make_fmt("accent_green_lt"),
            ),
        ]

    @property
    def rules(self) -> list[SyntaxRule]:
        """Expose rules for testing / introspection."""
        return list(self._rules)

    def highlightBlock(self, text: str) -> None:
        """Apply syntax rules to a single block (line) of text.

        Rules are iterated in priority order.  For each rule every
        non-overlapping match is formatted, but only if those character
        positions have not already been claimed by a higher-priority rule.
        """
        # Track which character positions are already formatted
        claimed = [False] * len(text)

        for rule in self._rules:
            for match in rule.pattern.finditer(text):
                start = match.start()
                length = match.end() - match.start()

                # Skip if any part of this span is already claimed
                if any(claimed[start:start + length]):
                    continue

                self.setFormat(start, length, rule.fmt)

                # Mark positions as claimed
                for i in range(start, start + length):
                    claimed[i] = True


# ---------------------------------------------------------------------------
# EditGCodeEditor — GCodeEditor subclass with editing enhancements
# ---------------------------------------------------------------------------
class EditGCodeEditor(GCodeEditor):
    """GCodeEditor subclass adding edit-mode behaviors.

    Features:
        - Current-line highlight (accent_blue, alpha 30)
        - Auto-indent on Enter (copies leading whitespace from previous line)
        - Smart Tab: insert 2 spaces (no selection) or indent selected lines
        - Shift+Tab: unindent selected lines by up to 2 spaces
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._loading = False  # guard against signals during setPlainText
        self.setFont(mono_font())
        self.cursorPositionChanged.connect(self._highlight_current_line)
        # Apply initial highlight
        self._highlight_current_line()

    def setPlainText(self, text: str) -> None:  # noqa: N802
        """Override to guard against signal-driven crashes during bulk load."""
        self._loading = True
        try:
            super().setPlainText(text)
        finally:
            self._loading = False
        # Re-apply highlights now that the document is stable
        self._highlight_current_line()

    # --- Current-line highlight (Req 4.1, 4.2, 4.3) ---
    def _highlight_current_line(self) -> None:
        """Highlight the line containing the text cursor.

        Uses COLORS["accent_blue"] with alpha 30 as the background tint.
        Also appends bracket-matching highlights so both are applied in
        a single ``setExtraSelections()`` call.
        """
        if self._loading:
            return

        extra_selections: list[QTextEdit.ExtraSelection] = []

        selection = QTextEdit.ExtraSelection()
        line_color = QColor(COLORS["accent_blue"])
        line_color.setAlpha(30)
        selection.format.setBackground(line_color)
        selection.format.setProperty(
            QTextCharFormat.FullWidthSelection, True
        )
        selection.cursor = self.textCursor()
        selection.cursor.clearSelection()
        extra_selections.append(selection)

        # Append bracket-matching highlights (Req 17.1, 17.2)
        extra_selections.extend(self._match_brackets())

        self.setExtraSelections(extra_selections)

    # --- Bracket / parenthesis matching (Req 17.1, 17.2) ---
    def _match_brackets(self) -> list:
        """Check for bracket adjacent to cursor and highlight its match.

        If the character immediately before or after the cursor is ``(``
        or ``)``, search the document for the matching counterpart.

        Returns:
            A list of ``QTextEdit.ExtraSelection`` items for the
            bracket highlights (0 or 2 items for a matched pair, 1 for
            an unmatched bracket).
        """
        selections: list[QTextEdit.ExtraSelection] = []
        cursor = self.textCursor()
        doc = self.document()
        text = doc.toPlainText()
        pos = cursor.position()

        # Determine which bracket character (if any) is adjacent to cursor
        bracket_char = None
        bracket_pos = None

        # Check character *before* cursor first, then *after*
        if pos > 0 and text[pos - 1] in ("(", ")"):
            bracket_char = text[pos - 1]
            bracket_pos = pos - 1
        elif pos < len(text) and text[pos] in ("(", ")"):
            bracket_char = text[pos]
            bracket_pos = pos

        if bracket_char is None:
            return selections

        # Search for the matching bracket
        match_pos = self._find_matching_bracket(text, bracket_pos, bracket_char)

        if match_pos is not None:
            # Matched pair — highlight both with accent_warm background
            color = QColor(COLORS["accent_warm"])
            color.setAlpha(80)
            for p in (bracket_pos, match_pos):
                sel = QTextEdit.ExtraSelection()
                sel.format.setBackground(color)
                c = QTextCursor(doc)
                c.setPosition(p)
                c.movePosition(QTextCursor.Right, QTextCursor.KeepAnchor, 1)
                sel.cursor = c
                selections.append(sel)
        else:
            # Unmatched bracket — highlight with accent (red) background
            color = QColor(COLORS["accent"])
            color.setAlpha(80)
            sel = QTextEdit.ExtraSelection()
            sel.format.setBackground(color)
            c = QTextCursor(doc)
            c.setPosition(bracket_pos)
            c.movePosition(QTextCursor.Right, QTextCursor.KeepAnchor, 1)
            sel.cursor = c
            selections.append(sel)

        return selections

    @staticmethod
    def _find_matching_bracket(
        text: str, pos: int, bracket: str
    ) -> int | None:
        """Find the position of the matching bracket in *text*.

        Uses a simple depth counter that respects nesting.

        Args:
            text:    The full document text.
            pos:     Position of the bracket to match.
            bracket: The bracket character at *pos* (``(`` or ``)``).

        Returns:
            The position of the matching bracket, or ``None`` if unmatched.
        """
        if bracket == "(":
            # Search forward for matching ')'
            depth = 1
            i = pos + 1
            while i < len(text):
                if text[i] == "(":
                    depth += 1
                elif text[i] == ")":
                    depth -= 1
                    if depth == 0:
                        return i
                i += 1
        elif bracket == ")":
            # Search backward for matching '('
            depth = 1
            i = pos - 1
            while i >= 0:
                if text[i] == ")":
                    depth += 1
                elif text[i] == "(":
                    depth -= 1
                    if depth == 0:
                        return i
                i -= 1
        return None

    # --- Key press overrides (Req 5.1, 5.2, 5.3, 5.4) ---
    def keyPressEvent(self, event) -> None:  # noqa: N802
        """Handle Enter (auto-indent), Tab (smart indent), Shift+Tab (unindent)."""
        # --- Auto-indent on Enter / Return ---
        if event.key() in (Qt.Key_Return, Qt.Key_Enter):
            cursor = self.textCursor()
            block_text = cursor.block().text()
            # Extract leading whitespace from the current line
            leading = ""
            for ch in block_text:
                if ch in (" ", "\t"):
                    leading += ch
                else:
                    break
            # Let Qt handle the newline insertion first
            super().keyPressEvent(event)
            # Then insert the copied leading whitespace
            if leading:
                self.textCursor().insertText(leading)
            return

        # --- Shift+Tab: unindent selected lines by up to 2 spaces ---
        if (event.key() == Qt.Key_Backtab
                or (event.key() == Qt.Key_Tab
                    and event.modifiers() & Qt.ShiftModifier)):
            self._unindent_selection()
            return

        # --- Tab: smart indent ---
        if event.key() == Qt.Key_Tab and not (event.modifiers() & Qt.ShiftModifier):
            cursor = self.textCursor()
            if cursor.hasSelection():
                self._indent_selection()
            else:
                cursor.insertText("  ")
            return

        # Default handling for all other keys
        super().keyPressEvent(event)

    def _indent_selection(self) -> None:
        """Indent all selected lines by 2 spaces (Req 5.3)."""
        cursor = self.textCursor()
        start = cursor.selectionStart()
        end = cursor.selectionEnd()

        cursor.beginEditBlock()

        # Move to the start of the first selected line
        cursor.setPosition(start)
        cursor.movePosition(QTextCursor.StartOfBlock)

        while cursor.position() <= end and not cursor.atEnd():
            cursor.movePosition(QTextCursor.StartOfBlock)
            cursor.insertText("  ")
            # Adjust end position to account for inserted characters
            end += 2
            # Move to next block
            if not cursor.movePosition(QTextCursor.NextBlock):
                break

        cursor.endEditBlock()

    def _unindent_selection(self) -> None:
        """Unindent all selected lines by up to 2 spaces (Req 5.4).

        If a line has no selection (cursor on a single line), still
        unindent that line.
        """
        cursor = self.textCursor()
        start = cursor.selectionStart()
        end = cursor.selectionEnd()

        cursor.beginEditBlock()

        cursor.setPosition(start)
        cursor.movePosition(QTextCursor.StartOfBlock)

        while cursor.position() <= end and not cursor.atEnd():
            cursor.movePosition(QTextCursor.StartOfBlock)
            line_text = cursor.block().text()

            # Remove up to 2 leading spaces
            remove_count = 0
            for i in range(min(2, len(line_text))):
                if line_text[i] == " ":
                    remove_count += 1
                else:
                    break

            if remove_count > 0:
                cursor.movePosition(
                    QTextCursor.Right, QTextCursor.KeepAnchor, remove_count
                )
                cursor.removeSelectedText()
                end -= remove_count

            if not cursor.movePosition(QTextCursor.NextBlock):
                break

        cursor.endEditBlock()


# ---------------------------------------------------------------------------
# GCODE_FILTER — file dialog filter for G-code files
# ---------------------------------------------------------------------------
GCODE_FILTER = "G-code Files (*.ngc *.nc *.gcode *.tap);;All Files (*)"


# ---------------------------------------------------------------------------
# FileState — dataclass tracking current file path, saved hash, recent files
# ---------------------------------------------------------------------------
@dataclass
class FileState:
    """Tracks the state of the file currently open in the editor.

    Attributes:
        path:         Absolute path to the current file, or None for untitled.
        saved_hash:   MD5 hex digest of the content at last save/load.
        recent_files: Up to 10 recently opened file paths, most recent first.
    """
    path: str | None = None
    saved_hash: str = ""
    recent_files: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# FileManager — file I/O, dirty detection, recent files
# ---------------------------------------------------------------------------
class FileManager:
    """Manages file operations for the G-code editor.

    Encapsulates new/open/save/save-as/reload, dirty-state tracking via
    MD5 hash comparison, recent-files list (up to 10, most-recent-first,
    deduplicated), and unsaved-changes prompts.

    All file I/O is wrapped in try/except for OSError and FileNotFoundError;
    errors are displayed in the status bar label rather than modal dialogs.

    Args:
        editor:     The EditGCodeEditor widget whose content is managed.
        status_bar: A QLabel (or any widget with ``setText``) used to
                    display error / informational messages.
    """

    MAX_RECENT = 10

    def __init__(self, editor: EditGCodeEditor, status_bar) -> None:
        self._editor = editor
        self._status_bar = status_bar
        self._state = FileState(
            saved_hash=self._content_hash(),
        )

    # ------------------------------------------------------------------
    # Dirty detection (Req 8.1, 8.2)
    # ------------------------------------------------------------------
    @property
    def is_dirty(self) -> bool:
        """True when editor content differs from the last saved state."""
        return self._content_hash() != self._state.saved_hash

    # ------------------------------------------------------------------
    # Current path
    # ------------------------------------------------------------------
    @property
    def current_path(self) -> str | None:
        """The active file path, or None for an untitled buffer."""
        return self._state.path

    # ------------------------------------------------------------------
    # Recent files (Req 7.1)
    # ------------------------------------------------------------------
    @property
    def recent_files(self) -> list[str]:
        """Up to 10 recent file paths, most recent first, deduplicated."""
        return list(self._state.recent_files)

    # ------------------------------------------------------------------
    # New file (Req 6.2)
    # ------------------------------------------------------------------
    def new_file(self) -> bool:
        """Clear the editor and reset the file path.

        Checks dirty state first — if the user cancels, returns False.

        Returns:
            True if the new-file operation proceeded, False if cancelled.
        """
        if not self.check_dirty("New File"):
            return False

        self._editor.clear()
        self._state.path = None
        self._state.saved_hash = self._content_hash()
        self._status_bar.setText("")
        return True

    # ------------------------------------------------------------------
    # Open file (Req 6.3, 7.1, 7.3, 7.4)
    # ------------------------------------------------------------------
    def open_file(self, path: str | None = None) -> bool:
        """Open a G-code file into the editor.

        If *path* is None a file dialog is shown.  On success the content
        is loaded, the saved hash updated, and the path added to the
        recent-files list.

        Args:
            path: Optional file path.  When None, a dialog is displayed.

        Returns:
            True if a file was successfully loaded, False otherwise.
        """
        if not self.check_dirty("Open File"):
            return False

        if path is None:
            path, _ = QFileDialog.getOpenFileName(
                self._editor,
                "Open G-code File",
                "",
                GCODE_FILTER,
            )
        if not path:
            return False

        try:
            with open(path, "r", encoding="utf-8") as fh:
                content = fh.read()
        except UnicodeDecodeError:
            # File was likely saved with the system default encoding
            try:
                with open(path, "r", encoding="cp1252") as fh:
                    content = fh.read()
            except (OSError, UnicodeDecodeError) as exc:
                self._status_bar.setText(f"Error opening file: {exc}")
                return False
        except FileNotFoundError:
            # Remove stale entry from recent list (Req 7.4)
            self._remove_recent(path)
            self._status_bar.setText(
                f"Recent file removed — no longer on disk: {os.path.basename(path)}"
            )
            return False
        except OSError as exc:
            self._status_bar.setText(f"Error opening file: {exc}")
            return False

        self._editor.setPlainText(content)
        self._state.path = path
        self._state.saved_hash = self._content_hash()
        self._add_recent(path)
        self._status_bar.setText("")
        return True

    # ------------------------------------------------------------------
    # Save (Req 6.4, 6.5)
    # ------------------------------------------------------------------
    def save(self) -> bool:
        """Write editor content to the current path.

        Delegates to :meth:`save_as` when no path is set.

        Returns:
            True on success, False on failure or cancellation.
        """
        if self._state.path is None:
            return self.save_as()
        return self._write_file(self._state.path)

    # ------------------------------------------------------------------
    # Save As (Req 6.6)
    # ------------------------------------------------------------------
    def save_as(self) -> bool:
        """Show a save dialog and write editor content to the chosen path.

        Returns:
            True on success, False on failure or cancellation.
        """
        path, _ = QFileDialog.getSaveFileName(
            self._editor,
            "Save G-code File As",
            self._state.path or "",
            GCODE_FILTER,
        )
        if not path:
            return False
        return self._write_file(path)

    # ------------------------------------------------------------------
    # Reload (Req 9.1, 9.2, 9.3, 9.4)
    # ------------------------------------------------------------------
    def reload(self) -> bool:
        """Re-read the current file from disk.

        Shows a confirmation dialog if the editor is dirty.

        Returns:
            True if the file was reloaded, False otherwise.
        """
        if self._state.path is None:
            self._status_bar.setText("No file to reload")
            return False

        if not self.check_dirty("Reload"):
            return False

        try:
            with open(self._state.path, "r", encoding="utf-8") as fh:
                content = fh.read()
        except UnicodeDecodeError:
            try:
                with open(self._state.path, "r", encoding="cp1252") as fh:
                    content = fh.read()
            except (OSError, UnicodeDecodeError) as exc:
                self._status_bar.setText(f"Error reloading file: {exc}")
                return False
        except FileNotFoundError:
            self._status_bar.setText(f"File not found: {self._state.path}")
            return False
        except OSError as exc:
            self._status_bar.setText(f"Error reloading file: {exc}")
            return False

        self._editor.setPlainText(content)
        self._state.saved_hash = self._content_hash()
        self._status_bar.setText("")
        return True

    # ------------------------------------------------------------------
    # Dirty check with Save/Discard/Cancel dialog (Req 8.3, 8.4, 8.5)
    # ------------------------------------------------------------------
    def check_dirty(self, action_name: str) -> bool:
        """Prompt the user if there are unsaved changes.

        Shows a Save / Discard / Cancel ``QMessageBox`` when the editor
        is dirty.

        Args:
            action_name: Human-readable name of the pending action
                         (e.g. "New File", "Open File", "Reload").

        Returns:
            True if the caller should proceed with the action, False if
            the user chose Cancel.
        """
        if not self.is_dirty:
            return True

        reply = QMessageBox.question(
            self._editor,
            f"Unsaved Changes — {action_name}",
            "The current file has unsaved changes.\n\n"
            "Do you want to save before proceeding?",
            QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel,
            QMessageBox.Save,
        )

        if reply == QMessageBox.Save:
            return self.save()
        if reply == QMessageBox.Cancel:
            return False
        # Discard — proceed without saving
        return True

    # ==================================================================
    # Private helpers
    # ==================================================================
    def _content_hash(self) -> str:
        """Return the MD5 hex digest of the current editor content."""
        text = self._editor.toPlainText()
        return hashlib.md5(text.encode("utf-8")).hexdigest()

    def _write_file(self, path: str) -> bool:
        """Write editor content to *path* and update state.

        Args:
            path: Destination file path.

        Returns:
            True on success, False on I/O error.
        """
        try:
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(self._editor.toPlainText())
        except OSError as exc:
            self._status_bar.setText(f"Error saving file: {exc}")
            return False

        self._state.path = path
        self._state.saved_hash = self._content_hash()
        self._add_recent(path)
        self._status_bar.setText("")
        return True

    def _add_recent(self, path: str) -> None:
        """Add *path* to the front of the recent-files list (deduplicated)."""
        norm = os.path.normpath(os.path.abspath(path))
        # Remove existing entry if present (dedup)
        self._state.recent_files = [
            p for p in self._state.recent_files
            if os.path.normpath(os.path.abspath(p)) != norm
        ]
        # Insert at front
        self._state.recent_files.insert(0, path)
        # Trim to max
        self._state.recent_files = self._state.recent_files[: self.MAX_RECENT]

    def _remove_recent(self, path: str) -> None:
        """Remove *path* from the recent-files list."""
        norm = os.path.normpath(os.path.abspath(path))
        self._state.recent_files = [
            p for p in self._state.recent_files
            if os.path.normpath(os.path.abspath(p)) != norm
        ]


# ---------------------------------------------------------------------------
# SearchBar — collapsible find/replace panel
# ---------------------------------------------------------------------------
class SearchBar(QWidget):
    """Collapsible find/replace bar for the G-code editor.

    Provides incremental search with match highlighting, case-sensitive
    and whole-word toggles, next/prev navigation, and replace/replace-all.

    The bar is hidden by default.  Call :meth:`show_find` to open in
    find-only mode, or :meth:`show_find_replace` to also reveal the
    replace input.

    Args:
        editor: The :class:`EditGCodeEditor` whose document is searched.
        parent: Optional parent widget.
    """

    # Highlight colours (used in _update_highlights)
    _MATCH_COLOR_KEY = "accent_blue"
    _MATCH_ALPHA = 55
    _CURRENT_COLOR_KEY = "accent_orange"
    _CURRENT_ALPHA = 120

    def __init__(self, editor: "EditGCodeEditor", parent=None) -> None:
        super().__init__(parent)
        self._editor = editor

        # --- Search state ---
        self._matches: list[tuple[int, int]] = []  # (start, length)
        self._current_index: int = -1

        # --- Layout ---
        outer = QVBoxLayout(self)
        outer.setContentsMargins(4, 4, 4, 4)
        outer.setSpacing(4)

        # -- Find row --
        find_row = QHBoxLayout()
        find_row.setSpacing(4)

        self.find_input = QLineEdit()
        self.find_input.setPlaceholderText("Find…")
        self.find_input.setMinimumWidth(180)
        self.find_input.textChanged.connect(self._on_query_changed)
        find_row.addWidget(self.find_input, stretch=1)

        # Toggle buttons — case sensitive / whole word
        toggle_style = (
            f"QPushButton {{ min-width: 32px; padding: 4px 8px; "
            f"font-size: 14px; font-weight: 700; border-radius: 6px; "
            f"background: {COLORS['bg_light']}; color: {COLORS['text_secondary']}; "
            f"border: 1px solid {COLORS['border']}; }}"
            f"QPushButton:checked {{ background: {COLORS['accent_blue']}; "
            f"color: #ffffff; border: 1px solid {COLORS['accent_blue_dk']}; }}"
        )

        self.btn_case = QPushButton("Aa")
        self.btn_case.setCheckable(True)
        self.btn_case.setToolTip("Case sensitive")
        self.btn_case.setStyleSheet(toggle_style)
        self.btn_case.toggled.connect(self._on_query_changed)
        find_row.addWidget(self.btn_case)

        self.btn_whole_word = QPushButton("W")
        self.btn_whole_word.setCheckable(True)
        self.btn_whole_word.setToolTip("Whole word")
        self.btn_whole_word.setStyleSheet(toggle_style)
        self.btn_whole_word.toggled.connect(self._on_query_changed)
        find_row.addWidget(self.btn_whole_word)

        # Navigation buttons
        nav_style = (
            f"QPushButton {{ min-width: 32px; padding: 4px 8px; "
            f"font-size: 14px; font-weight: 600; border-radius: 6px; "
            f"background: {COLORS['bg_light']}; color: {COLORS['text']}; "
            f"border: 1px solid {COLORS['border']}; }}"
            f"QPushButton:hover {{ background: {COLORS['bg_elevated']}; "
            f"border: 1px solid {COLORS['accent_blue_lt']}; }}"
        )

        self.btn_prev = QPushButton("▲")
        self.btn_prev.setToolTip("Previous match")
        self.btn_prev.setStyleSheet(nav_style)
        self.btn_prev.clicked.connect(self._find_prev)
        find_row.addWidget(self.btn_prev)

        self.btn_next = QPushButton("▼")
        self.btn_next.setToolTip("Next match")
        self.btn_next.setStyleSheet(nav_style)
        self.btn_next.clicked.connect(self._find_next)
        find_row.addWidget(self.btn_next)

        # Match count label
        self.match_count_label = QLabel("0 matches")
        self.match_count_label.setStyleSheet(
            f"color: {COLORS['text_dim']}; font-size: 14px; padding: 0 6px;"
        )
        self.match_count_label.setMinimumWidth(70)
        find_row.addWidget(self.match_count_label)

        outer.addLayout(find_row)

        # -- Replace row (hidden by default) --
        self._replace_row = QWidget()
        replace_layout = QHBoxLayout(self._replace_row)
        replace_layout.setContentsMargins(0, 0, 0, 0)
        replace_layout.setSpacing(4)

        self.replace_input = QLineEdit()
        self.replace_input.setPlaceholderText("Replace…")
        self.replace_input.setMinimumWidth(180)
        replace_layout.addWidget(self.replace_input, stretch=1)

        action_style = (
            f"QPushButton {{ padding: 4px 12px; font-size: 14px; "
            f"font-weight: 600; border-radius: 6px; "
            f"background: {COLORS['bg_light']}; color: {COLORS['text']}; "
            f"border: 1px solid {COLORS['border']}; }}"
            f"QPushButton:hover {{ background: {COLORS['bg_elevated']}; "
            f"border: 1px solid {COLORS['accent_blue_lt']}; }}"
        )

        self.btn_replace = QPushButton("Replace")
        self.btn_replace.setToolTip("Replace current match")
        self.btn_replace.setStyleSheet(action_style)
        self.btn_replace.clicked.connect(self._replace_current)
        replace_layout.addWidget(self.btn_replace)

        self.btn_replace_all = QPushButton("Replace All")
        self.btn_replace_all.setToolTip("Replace all matches")
        self.btn_replace_all.setStyleSheet(action_style)
        self.btn_replace_all.clicked.connect(self._replace_all)
        replace_layout.addWidget(self.btn_replace_all)

        self._replace_row.hide()
        outer.addWidget(self._replace_row)

        # Start hidden
        self.hide()

    # ------------------------------------------------------------------
    # Public show/hide API
    # ------------------------------------------------------------------
    def show_find(self) -> None:
        """Show the search bar in find-only mode (replace row hidden)."""
        self._replace_row.hide()
        self.show()
        self.find_input.setFocus()
        self.find_input.selectAll()

    def show_find_replace(self) -> None:
        """Show the search bar with the replace row visible."""
        self._replace_row.show()
        self.show()
        self.find_input.setFocus()
        self.find_input.selectAll()

    def hide(self) -> None:
        """Hide the search bar and clear highlights."""
        super().hide()
        self._clear_highlights()

    # ------------------------------------------------------------------
    # Search logic
    # ------------------------------------------------------------------
    def _on_query_changed(self, *_args) -> None:
        """Re-run the search whenever the query or toggle state changes."""
        self._find_all()
        if self._matches:
            self._current_index = 0
            self._go_to_current()
        else:
            self._current_index = -1
        self._update_highlights()
        self._update_match_label()

    def _find_all(self) -> None:
        """Populate ``self._matches`` with all (start, length) pairs."""
        self._matches.clear()
        query = self.find_input.text()
        if not query:
            return

        doc = self._editor.document()
        flags = self._build_find_flags()

        cursor = QTextCursor(doc)  # start of document
        while True:
            found = doc.find(query, cursor, flags)
            if found.isNull() or not found.hasSelection():
                break
            start = found.selectionStart()
            length = found.selectionEnd() - start
            self._matches.append((start, length))
            cursor = found  # continue from found position

    def _build_find_flags(self):
        """Build QTextDocument.FindFlags from toggle state."""
        flags = QTextDocument.FindFlags()
        if self.btn_case.isChecked():
            flags |= QTextDocument.FindCaseSensitively
        if self.btn_whole_word.isChecked():
            flags |= QTextDocument.FindWholeWords
        return flags

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------
    def _find_next(self) -> None:
        """Move to the next match, wrapping around at the end."""
        if not self._matches:
            return
        self._current_index = (self._current_index + 1) % len(self._matches)
        self._go_to_current()
        self._update_highlights()
        self._update_match_label()

    def _find_prev(self) -> None:
        """Move to the previous match, wrapping around at the start."""
        if not self._matches:
            return
        self._current_index = (self._current_index - 1) % len(self._matches)
        self._go_to_current()
        self._update_highlights()
        self._update_match_label()

    def _go_to_current(self) -> None:
        """Move the editor cursor to select the current match."""
        if self._current_index < 0 or self._current_index >= len(self._matches):
            return
        start, length = self._matches[self._current_index]
        cursor = QTextCursor(self._editor.document())
        cursor.setPosition(start)
        cursor.setPosition(start + length, QTextCursor.KeepAnchor)
        self._editor.setTextCursor(cursor)
        self._editor.centerCursor()

    # ------------------------------------------------------------------
    # Replace
    # ------------------------------------------------------------------
    def _replace_current(self) -> None:
        """Replace the current match and advance to the next."""
        if self._current_index < 0 or not self._matches:
            return

        replacement = self.replace_input.text()
        start, length = self._matches[self._current_index]

        cursor = QTextCursor(self._editor.document())
        cursor.setPosition(start)
        cursor.setPosition(start + length, QTextCursor.KeepAnchor)
        cursor.insertText(replacement)

        # Re-search and keep index in bounds
        self._find_all()
        if self._matches:
            if self._current_index >= len(self._matches):
                self._current_index = 0
            self._go_to_current()
        else:
            self._current_index = -1
        self._update_highlights()
        self._update_match_label()

    def _replace_all(self) -> None:
        """Replace all matches and report the count."""
        if not self._matches:
            self.match_count_label.setText("0 replaced")
            return

        replacement = self.replace_input.text()
        count = len(self._matches)

        # Replace in reverse order to preserve earlier positions
        cursor = QTextCursor(self._editor.document())
        cursor.beginEditBlock()
        for start, length in reversed(self._matches):
            cursor.setPosition(start)
            cursor.setPosition(start + length, QTextCursor.KeepAnchor)
            cursor.insertText(replacement)
        cursor.endEditBlock()

        self._matches.clear()
        self._current_index = -1
        self._update_highlights()
        self.match_count_label.setText(f"{count} replaced")

    # ------------------------------------------------------------------
    # Highlighting
    # ------------------------------------------------------------------
    def _update_highlights(self) -> None:
        """Apply ExtraSelection highlights for all matches + current."""
        selections: list[QTextEdit.ExtraSelection] = []

        for i, (start, length) in enumerate(self._matches):
            sel = QTextEdit.ExtraSelection()
            if i == self._current_index:
                bg = QColor(COLORS["accent_orange"])
                bg.setAlpha(120)
            else:
                bg = QColor(COLORS["accent_blue"])
                bg.setAlpha(55)
            sel.format.setBackground(bg)
            cursor = QTextCursor(self._editor.document())
            cursor.setPosition(start)
            cursor.setPosition(start + length, QTextCursor.KeepAnchor)
            sel.cursor = cursor
            selections.append(sel)

        self._editor.setExtraSelections(selections)

    def _clear_highlights(self) -> None:
        """Remove all search-related extra selections."""
        self._editor.setExtraSelections([])
        self._matches.clear()
        self._current_index = -1

    # ------------------------------------------------------------------
    # Match count label
    # ------------------------------------------------------------------
    def _update_match_label(self) -> None:
        """Update the 'N of M' match count display."""
        total = len(self._matches)
        if total == 0:
            self.match_count_label.setText("0 matches")
        else:
            self.match_count_label.setText(
                f"{self._current_index + 1} of {total}"
            )


# ---------------------------------------------------------------------------
# renumber_lines — apply N-word line numbers as a single undoable operation
# ---------------------------------------------------------------------------
def renumber_lines(editor: EditGCodeEditor) -> None:
    """Renumber all executable G-code lines with sequential N-words.

    Calls :func:`add_line_numbers` from ``line_numbers.py`` to generate
    the renumbered text, then replaces the entire editor content as a
    single undoable operation (``beginEditBlock`` / ``endEditBlock``).

    The cursor position is preserved as closely as possible by restoring
    the original character offset (clamped to the new document length).

    Args:
        editor: The :class:`EditGCodeEditor` whose content is renumbered.

    Requirements: 11.1, 11.2, 11.3
    """
    original_text = editor.toPlainText()
    renumbered_text = add_line_numbers(original_text)

    # Nothing to do if the text didn't change
    if renumbered_text == original_text:
        return

    # Preserve cursor position (clamped to new document length)
    old_cursor_pos = editor.textCursor().position()

    cursor = editor.textCursor()
    cursor.beginEditBlock()
    cursor.select(QTextCursor.Document)
    cursor.insertText(renumbered_text)
    cursor.endEditBlock()

    # Restore cursor position (clamp to new document length)
    new_pos = min(old_cursor_pos, len(renumbered_text))
    restored_cursor = editor.textCursor()
    restored_cursor.setPosition(new_pos)
    editor.setTextCursor(restored_cursor)


# ---------------------------------------------------------------------------
# toggle_comment — comment/uncomment selected lines as a single undo action
# ---------------------------------------------------------------------------
def toggle_comment(editor: EditGCodeEditor) -> None:
    """Toggle semicolon comments on the selected lines (or current line).

    If the majority of affected lines start with ``;``, the action
    *uncomments* (removes the leading ``;`` and an optional single space).
    Otherwise it *comments* (prepends ``"; "`` to every line).

    The entire operation is wrapped in ``beginEditBlock()`` /
    ``endEditBlock()`` so it can be undone with a single Ctrl+Z.

    Args:
        editor: The :class:`EditGCodeEditor` whose content is toggled.

    Requirements: 12.1, 12.2, 12.3, 12.4
    """
    cursor = editor.textCursor()
    has_selection = cursor.hasSelection()

    # --- Determine the block range to operate on ---
    if has_selection:
        sel_start = cursor.selectionStart()
        sel_end = cursor.selectionEnd()
    else:
        sel_start = cursor.position()
        sel_end = cursor.position()

    # Expand to full lines
    cursor.setPosition(sel_start)
    cursor.movePosition(QTextCursor.StartOfBlock)
    block_start_pos = cursor.position()

    cursor.setPosition(sel_end)
    # If selection ends at the very start of a block and we have a real
    # selection, don't include that trailing empty block.
    if has_selection and sel_end > sel_start and cursor.atBlockStart():
        cursor.movePosition(QTextCursor.PreviousBlock)
    cursor.movePosition(QTextCursor.EndOfBlock)
    block_end_pos = cursor.position()

    # --- Collect the lines ---
    cursor.setPosition(block_start_pos)
    lines: list[str] = []
    while True:
        lines.append(cursor.block().text())
        if cursor.block().position() + cursor.block().length() - 1 >= block_end_pos:
            break
        if not cursor.movePosition(QTextCursor.NextBlock):
            break

    if not lines:
        return

    # --- Decide: comment or uncomment (majority rule) ---
    commented_count = sum(1 for line in lines if line.lstrip().startswith(";"))
    should_uncomment = commented_count > len(lines) / 2

    # --- Build transformed lines ---
    new_lines: list[str] = []
    for line in lines:
        if should_uncomment:
            # Remove leading ';' and optional single space after it
            if line.startswith("; "):
                new_lines.append(line[2:])
            elif line.startswith(";"):
                new_lines.append(line[1:])
            else:
                new_lines.append(line)
        else:
            new_lines.append("; " + line)

    new_text = "\n".join(new_lines)

    # --- Apply as a single undoable operation ---
    cursor.setPosition(block_start_pos)
    cursor.setPosition(block_end_pos, QTextCursor.KeepAnchor)

    cursor.beginEditBlock()
    cursor.insertText(new_text)
    cursor.endEditBlock()

    # --- Restore selection over the replaced range ---
    new_end_pos = block_start_pos + len(new_text)
    cursor.setPosition(block_start_pos)
    cursor.setPosition(new_end_pos, QTextCursor.KeepAnchor)
    editor.setTextCursor(cursor)


# ---------------------------------------------------------------------------
# toggle_block_delete — toggle `/` prefix on selected lines (single undo)
# ---------------------------------------------------------------------------
def toggle_block_delete(editor: EditGCodeEditor) -> None:
    """Toggle the block-delete ``/`` prefix on the selected lines (or current line).

    If the majority of affected lines start with ``/``, the action
    *removes* the leading ``/``.  Otherwise it *adds* ``/`` to every line.

    The entire operation is wrapped in ``beginEditBlock()`` /
    ``endEditBlock()`` so it can be undone with a single Ctrl+Z.

    Args:
        editor: The :class:`EditGCodeEditor` whose content is toggled.

    Requirements: 14.1, 14.2, 14.3, 14.4
    """
    cursor = editor.textCursor()
    has_selection = cursor.hasSelection()

    # --- Determine the block range to operate on ---
    if has_selection:
        sel_start = cursor.selectionStart()
        sel_end = cursor.selectionEnd()
    else:
        sel_start = cursor.position()
        sel_end = cursor.position()

    # Expand to full lines
    cursor.setPosition(sel_start)
    cursor.movePosition(QTextCursor.StartOfBlock)
    block_start_pos = cursor.position()

    cursor.setPosition(sel_end)
    # If selection ends at the very start of a block and we have a real
    # selection, don't include that trailing empty block.
    if has_selection and sel_end > sel_start and cursor.atBlockStart():
        cursor.movePosition(QTextCursor.PreviousBlock)
    cursor.movePosition(QTextCursor.EndOfBlock)
    block_end_pos = cursor.position()

    # --- Collect the lines ---
    cursor.setPosition(block_start_pos)
    lines: list[str] = []
    while True:
        lines.append(cursor.block().text())
        if cursor.block().position() + cursor.block().length() - 1 >= block_end_pos:
            break
        if not cursor.movePosition(QTextCursor.NextBlock):
            break

    if not lines:
        return

    # --- Decide: add or remove block-delete prefix (majority rule) ---
    prefixed_count = sum(1 for line in lines if line.startswith("/"))
    should_remove = prefixed_count > len(lines) / 2

    # --- Build transformed lines ---
    new_lines: list[str] = []
    for line in lines:
        if should_remove:
            # Remove leading '/'
            if line.startswith("/"):
                new_lines.append(line[1:])
            else:
                new_lines.append(line)
        else:
            new_lines.append("/" + line)

    new_text = "\n".join(new_lines)

    # --- Apply as a single undoable operation ---
    cursor.setPosition(block_start_pos)
    cursor.setPosition(block_end_pos, QTextCursor.KeepAnchor)

    cursor.beginEditBlock()
    cursor.insertText(new_text)
    cursor.endEditBlock()

    # --- Restore selection over the replaced range ---
    new_end_pos = block_start_pos + len(new_text)
    cursor.setPosition(block_start_pos)
    cursor.setPosition(new_end_pos, QTextCursor.KeepAnchor)
    editor.setTextCursor(cursor)


# ---------------------------------------------------------------------------
# go_to_line — Go-to-Line dialog (Req 13.1, 13.2, 13.3)
# ---------------------------------------------------------------------------
def go_to_line(editor: EditGCodeEditor) -> None:
    """Show a Go-to-Line dialog and move the cursor to the chosen line.

    Displays a ``QInputDialog.getInt()`` asking for a line number.
    The value is clamped to [1, editor.document().blockCount()].
    The cursor is moved to the target line and centered in the viewport.

    Args:
        editor: The :class:`EditGCodeEditor` whose cursor will be moved.
    """
    max_line = editor.document().blockCount()

    line_number, ok = QInputDialog.getInt(
        editor,
        "Go to Line",
        f"Line number (1–{max_line}):",
        value=1,
        min=1,
        max=max_line,
    )
    if not ok:
        return

    # Clamp (QInputDialog already enforces min/max, but be defensive)
    line_number = max(1, min(line_number, max_line))

    # Move cursor to the target block (block index = line_number - 1)
    block = editor.document().findBlockByNumber(line_number - 1)
    cursor = QTextCursor(block)
    editor.setTextCursor(cursor)
    editor.centerCursor()


# ---------------------------------------------------------------------------
# EditTab — Top-level G-code editor tab (Req 1.4, 6.1, 7.2)
# ---------------------------------------------------------------------------
class EditTab(QWidget):
    """Full-featured G-code editor tab.

    Layout::

        ┌─────────────────────────────────────────────┐
        │ Toolbar: New Open Save SaveAs Reload         │
        │   Renumber Comment BlockDel Preview LoadProg │
        │   Undo Redo  A+ A-  [file label]            │
        ├─────────────────────────────────────────────┤
        │ SearchBar (collapsible)                      │
        ├─────────────────────────────────────────────┤
        │                                              │
        │  EditGCodeEditor + LineNumberArea             │
        │                                              │
        ├─────────────────────────────────────────────┤
        │ status_label                                 │
        └─────────────────────────────────────────────┘

    Requirements: 1.4, 6.1, 7.2
    """

    # Signal emitted when the Preview button is clicked.
    # Carries the current editor text for PositionGraph.sim_load().
    preview_requested = pyqtSignal(str)

    # Signal emitted when the "Load into Program" button is clicked.
    # Carries (editor_text, file_path) for ProgramTab (Req 16.1, 16.2, 16.3).
    load_program_requested = pyqtSignal(str, str)

    def __init__(self, parent=None):
        super().__init__(parent)

        # --- Main layout ---
        layout = QVBoxLayout(self)
        layout.setSpacing(4)
        layout.setContentsMargins(4, 4, 4, 4)

        # --- Editor widget ---
        self.editor = EditGCodeEditor()
        self.editor.setFont(mono_font(18))
        self.editor.setPlaceholderText("Open or create a G-code file…")
        self.editor.setStyleSheet(
            f"QPlainTextEdit {{ background-color: {COLORS['dro_bg']}; "
            f"color: {COLORS['dro_text']}; "
            f"border: 2px solid {COLORS['bg_mid']}; "
            f"border-top: 2px solid {COLORS['bg_dark']}; "
            f"border-radius: 8px; padding: 6px; "
            f"selection-background-color: {COLORS['accent_blue']}; }}"
        )

        # --- Syntax highlighter ---
        self.highlighter = GCodeSyntaxHighlighter(self.editor.document())

        # --- Status label (bottom bar for error / info messages) ---
        self.status_label = QLabel("")
        self.status_label.setStyleSheet(
            f"color: {COLORS['text_dim']}; font-size: 14px; padding: 2px 6px;"
        )

        # --- File manager ---
        self.file_manager = FileManager(self.editor, self.status_label)

        # --- Search bar (collapsible, hidden by default) ---
        self.search_bar = SearchBar(self.editor)

        # --- File label (shows current filename in toolbar) ---
        self.file_label = QLabel("Untitled")
        self.file_label.setStyleSheet(
            f"color: {COLORS['text_dim']}; font-size: 14px; padding: 0 8px;"
        )

        # --- Build toolbar ---
        toolbar = self._build_toolbar()

        # --- Assemble layout ---
        layout.addLayout(toolbar)
        layout.addWidget(self.search_bar)
        layout.addWidget(self.editor, stretch=1)
        layout.addWidget(self.status_label)

        # --- Keyboard shortcuts ---
        self._setup_shortcuts()

    # ------------------------------------------------------------------
    # Toolbar construction
    # ------------------------------------------------------------------
    def _build_toolbar(self) -> QHBoxLayout:
        """Build the toolbar row with all editor action buttons.

        Returns:
            The QHBoxLayout containing all toolbar widgets.
        """
        toolbar = QHBoxLayout()
        toolbar.setSpacing(4)

        # Compact button style — smaller padding for toolbar density
        btn_style = (
            f"QPushButton {{ background-color: qlineargradient("
            f"x1:0, y1:0, x2:0, y2:1, "
            f"stop:0 {COLORS['bg_elevated']}, stop:0.5 {COLORS['bg_light']}, "
            f"stop:1 {COLORS['bg_mid']}); "
            f"color: {COLORS['text']}; "
            f"border: 1px solid {COLORS['border']}; "
            f"border-bottom: 2px solid {COLORS['bg_mid']}; "
            f"border-radius: 6px; "
            f"padding: 4px 10px; font-size: 14px; font-weight: 600; }}"
            f"QPushButton:hover {{ background-color: qlineargradient("
            f"x1:0, y1:0, x2:0, y2:1, "
            f"stop:0 {COLORS['separator']}, stop:0.5 {COLORS['bg_elevated']}, "
            f"stop:1 {COLORS['bg_light']}); "
            f"border: 1px solid {COLORS['accent_blue_lt']}; "
            f"border-bottom: 2px solid {COLORS['bg_light']}; }}"
            f"QPushButton:pressed {{ background-color: qlineargradient("
            f"x1:0, y1:0, x2:0, y2:1, "
            f"stop:0 {COLORS['bg_mid']}, stop:1 {COLORS['bg_light']}); "
            f"border: 1px solid {COLORS['accent_blue']}; "
            f"border-top: 2px solid {COLORS['bg_mid']}; "
            f"border-bottom: 1px solid {COLORS['bg_light']}; }}"
            f"QPushButton:disabled {{ background-color: {COLORS['bg_mid']}; "
            f"color: {COLORS['text_dim']}; "
            f"border: 1px solid {COLORS['bg_light']}; }}"
        )

        def _make_btn(text: str, tooltip: str = "") -> QPushButton:
            btn = QPushButton(text)
            btn.setStyleSheet(btn_style)
            if tooltip:
                btn.setToolTip(tooltip)
            return btn

        # --- File operation buttons ---
        self.btn_new = _make_btn("New", "New file")
        self.btn_open = _make_btn("Open", "Open file")
        self.btn_save = _make_btn("Save", "Save file")
        self.btn_save_as = _make_btn("Save As", "Save file as…")
        self.btn_reload = _make_btn("Reload", "Reload from disk")

        # --- Search / Replace buttons ---
        self.btn_find = _make_btn("Find", "Find text (Ctrl+F)")
        self.btn_replace = _make_btn("Replace", "Find & Replace (Ctrl+H)")

        # --- G-code action buttons ---
        self.btn_renumber = _make_btn("Renumber", "Renumber N-words")
        self.btn_comment = _make_btn("Comment", "Toggle comment (Ctrl+/)")
        self.btn_block_delete = _make_btn("Block Del", "Toggle block delete /")

        # --- Integration buttons (Preview / Load into Program) ---
        self.btn_preview = _make_btn("Preview", "Preview toolpath")
        self.btn_load_program = _make_btn("Load Prog", "Load into Program tab")

        # --- Undo / Redo ---
        self.btn_undo = _make_btn("Undo", "Undo (Ctrl+Z)")
        self.btn_redo = _make_btn("Redo", "Redo (Ctrl+Y)")
        self.btn_undo.setEnabled(False)
        self.btn_redo.setEnabled(False)

        # --- Recent Files dropdown button ---
        self.btn_recent = QToolButton()
        self.btn_recent.setText("Recent ▾")
        self.btn_recent.setToolTip("Recent files")
        self.btn_recent.setPopupMode(QToolButton.InstantPopup)
        self.btn_recent.setStyleSheet(
            f"QToolButton {{ background-color: qlineargradient("
            f"x1:0, y1:0, x2:0, y2:1, "
            f"stop:0 {COLORS['bg_elevated']}, stop:0.5 {COLORS['bg_light']}, "
            f"stop:1 {COLORS['bg_mid']}); "
            f"color: {COLORS['text']}; "
            f"border: 1px solid {COLORS['border']}; "
            f"border-bottom: 2px solid {COLORS['bg_mid']}; "
            f"border-radius: 6px; "
            f"padding: 4px 10px; font-size: 14px; font-weight: 600; }}"
            f"QToolButton:hover {{ background-color: qlineargradient("
            f"x1:0, y1:0, x2:0, y2:1, "
            f"stop:0 {COLORS['separator']}, stop:0.5 {COLORS['bg_elevated']}, "
            f"stop:1 {COLORS['bg_light']}); "
            f"border: 1px solid {COLORS['accent_blue_lt']}; "
            f"border-bottom: 2px solid {COLORS['bg_light']}; }}"
            f"QToolButton::menu-indicator {{ image: none; }}"
        )
        self.recent_menu = QMenu(self)
        self.recent_menu.setStyleSheet(
            f"QMenu {{ background-color: {COLORS['bg_light']}; "
            f"color: {COLORS['text']}; "
            f"border: 1px solid {COLORS['border']}; "
            f"border-radius: 6px; padding: 4px; }}"
            f"QMenu::item {{ min-height: {TOUCH_SIZES['target_min']}px; "
            f"padding: 10px 20px; border-radius: 4px; }}"
            f"QMenu::item:selected {{ background-color: {COLORS['accent_blue']}; "
            f"color: #ffffff; }}"
        )
        self.btn_recent.setMenu(self.recent_menu)

        # --- Add buttons to toolbar ---
        for btn in (
            self.btn_new, self.btn_open, self.btn_save, self.btn_save_as,
            self.btn_reload,
        ):
            toolbar.addWidget(btn)

        toolbar.addWidget(self.btn_recent)

        toolbar.addSpacing(8)

        for btn in (self.btn_find, self.btn_replace):
            toolbar.addWidget(btn)

        toolbar.addSpacing(8)

        for btn in (
            self.btn_renumber, self.btn_comment, self.btn_block_delete,
        ):
            toolbar.addWidget(btn)

        toolbar.addSpacing(8)

        for btn in (self.btn_preview, self.btn_load_program):
            toolbar.addWidget(btn)

        toolbar.addSpacing(8)

        for btn in (self.btn_undo, self.btn_redo):
            toolbar.addWidget(btn)

        # --- File label (stretch to fill remaining space) ---
        toolbar.addWidget(self.file_label, stretch=1)

        # --- Wire button signals ---
        self._connect_buttons()

        return toolbar

    # ------------------------------------------------------------------
    # Signal / slot wiring
    # ------------------------------------------------------------------
    def _connect_buttons(self) -> None:
        """Connect toolbar button clicks to their respective actions."""
        # File operations
        self.btn_new.clicked.connect(self._on_new)
        self.btn_open.clicked.connect(self._on_open)
        self.btn_save.clicked.connect(self._on_save)
        self.btn_save_as.clicked.connect(self._on_save_as)
        self.btn_reload.clicked.connect(self._on_reload)

        # G-code actions
        self.btn_renumber.clicked.connect(self._on_renumber)
        self.btn_comment.clicked.connect(self._on_comment)
        self.btn_block_delete.clicked.connect(self._on_block_delete)

        # Search / Replace
        self.btn_find.clicked.connect(self.search_bar.show_find)
        self.btn_replace.clicked.connect(self.search_bar.show_find_replace)

        # Preview — emit signal with editor text (Req 15.1, 15.2, 15.3)
        self.btn_preview.clicked.connect(self._on_preview)
        # Load into Program — check dirty, then emit signal (Req 16.1, 16.2, 16.3)
        self.btn_load_program.clicked.connect(self._on_load_program)

        # Undo / Redo
        self.btn_undo.clicked.connect(self.editor.undo)
        self.btn_redo.clicked.connect(self.editor.redo)
        self.editor.undoAvailable.connect(self.btn_undo.setEnabled)
        self.editor.redoAvailable.connect(self.btn_redo.setEnabled)

        # Text changed → update file label dirty indicator
        self.editor.textChanged.connect(self._on_text_changed)

        # Recent files menu — refresh when about to show
        self.recent_menu.aboutToShow.connect(self._update_recent_menu)

    # ------------------------------------------------------------------
    # Keyboard shortcuts (Req 10.1, 10.2, 10.9, 12.1, 13.1)
    # ------------------------------------------------------------------
    def _setup_shortcuts(self) -> None:
        """Create keyboard shortcuts for the editor tab.

        Shortcuts:
            Ctrl+F  → show SearchBar in find mode
            Ctrl+H  → show SearchBar in find+replace mode
            Ctrl+G  → go-to-line dialog
            Ctrl+/  → toggle comment on selected lines
            Escape  → hide SearchBar and return focus to editor
        """
        # Ctrl+F → find
        shortcut_find = QShortcut(QKeySequence("Ctrl+F"), self)
        shortcut_find.activated.connect(self.search_bar.show_find)

        # Ctrl+H → find and replace
        shortcut_replace = QShortcut(QKeySequence("Ctrl+H"), self)
        shortcut_replace.activated.connect(self.search_bar.show_find_replace)

        # Ctrl+G → go-to-line
        shortcut_goto = QShortcut(QKeySequence("Ctrl+G"), self)
        shortcut_goto.activated.connect(lambda: go_to_line(self.editor))

        # Ctrl+/ → comment/uncomment toggle
        shortcut_comment = QShortcut(QKeySequence("Ctrl+/"), self)
        shortcut_comment.activated.connect(lambda: toggle_comment(self.editor))

        # Escape → hide search bar and return focus to editor
        shortcut_escape = QShortcut(QKeySequence(Qt.Key_Escape), self)
        shortcut_escape.activated.connect(self._on_escape)

    def _on_escape(self) -> None:
        """Hide the search bar and return focus to the editor."""
        if self.search_bar.isVisible():
            self.search_bar.hide()
        self.editor.setFocus()

    # ------------------------------------------------------------------
    # File operation slots
    # ------------------------------------------------------------------
    def _on_new(self) -> None:
        """Handle New button click."""
        if self.file_manager.new_file():
            self._update_file_label()

    def _on_open(self) -> None:
        """Handle Open button click."""
        try:
            if self.file_manager.open_file():
                self._update_file_label()
            self._update_recent_menu()
        except Exception as exc:
            self.status_label.setText(f"Error opening file: {exc}")

    def _on_save(self) -> None:
        """Handle Save button click."""
        if self.file_manager.save():
            self._update_file_label()
        self._update_recent_menu()

    def _on_save_as(self) -> None:
        """Handle Save As button click."""
        if self.file_manager.save_as():
            self._update_file_label()
        self._update_recent_menu()

    def _on_reload(self) -> None:
        """Handle Reload button click."""
        if self.file_manager.reload():
            self._update_file_label()

    # ------------------------------------------------------------------
    # Recent files menu (Req 7.1, 7.2, 7.3, 7.4)
    # ------------------------------------------------------------------
    def _update_recent_menu(self) -> None:
        """Rebuild the Recent Files dropdown menu from the file manager's list.

        Entries that no longer exist on disk are removed and a status bar
        message is shown.  The menu is repopulated with up to 10 entries,
        most recent first.
        """
        self.recent_menu.clear()

        recent = self.file_manager.recent_files
        if not recent:
            action = self.recent_menu.addAction("(no recent files)")
            action.setEnabled(False)
            return

        # Filter out paths that no longer exist on disk
        stale: list[str] = []
        for path in recent:
            if not os.path.exists(path):
                stale.append(path)

        if stale:
            for path in stale:
                self.file_manager._remove_recent(path)
            self.status_label.setText(
                f"Removed {len(stale)} recent file(s) no longer on disk"
            )

        # Rebuild menu from the (possibly pruned) list
        recent = self.file_manager.recent_files
        if not recent:
            action = self.recent_menu.addAction("(no recent files)")
            action.setEnabled(False)
            return

        for path in recent:
            display = os.path.basename(path)
            action = self.recent_menu.addAction(display)
            action.setToolTip(path)
            action.setData(path)
            action.triggered.connect(
                lambda checked, p=path: self._on_recent_file_selected(p)
            )

    def _on_recent_file_selected(self, path: str) -> None:
        """Open a file selected from the Recent Files menu.

        Args:
            path: The file path to open.
        """
        if self.file_manager.open_file(path):
            self._update_file_label()
        self._update_recent_menu()

    # ------------------------------------------------------------------
    # G-code action slots
    # ------------------------------------------------------------------
    def _on_renumber(self) -> None:
        """Handle Renumber button click."""
        renumber_lines(self.editor)

    def _on_comment(self) -> None:
        """Handle Comment toggle button click."""
        toggle_comment(self.editor)

    def _on_block_delete(self) -> None:
        """Handle Block Delete toggle button click."""
        toggle_block_delete(self.editor)

    # ------------------------------------------------------------------
    # Preview slot (Req 15.1, 15.2, 15.3)
    # ------------------------------------------------------------------
    def _on_preview(self) -> None:
        """Emit preview_requested with the current editor text."""
        self.preview_requested.emit(self.editor.toPlainText())

    # ------------------------------------------------------------------
    # Load into Program slot (Req 16.1, 16.2, 16.3)
    # ------------------------------------------------------------------
    def _on_load_program(self) -> None:
        """Check dirty state, prompt to save if needed, then emit load_program_requested."""
        if self.file_manager.is_dirty:
            if not self.file_manager.check_dirty("Load into Program"):
                return

        text = self.editor.toPlainText()
        path = self.file_manager.current_path
        file_label = os.path.basename(path) if path else "Untitled"
        self.load_program_requested.emit(text, file_label)

    # ------------------------------------------------------------------
    # Text changed / dirty indicator
    # ------------------------------------------------------------------
    def _on_text_changed(self) -> None:
        """Update the file label to reflect dirty state."""
        self._update_file_label()

    def _update_file_label(self) -> None:
        """Set the file label text based on current path and dirty state.

        Shows the filename (or "Untitled") with a ``*`` suffix when dirty.
        """
        path = self.file_manager.current_path
        if path:
            name = os.path.basename(path)
        else:
            name = "Untitled"

        if self.file_manager.is_dirty:
            self.file_label.setText(f"{name} *")
        else:
            self.file_label.setText(name)
