"""Manual Operation Tab — placeholder for future manual-only controls."""

from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel
from PyQt5.QtCore import Qt

from theme import COLORS


class ManualTab(QWidget):
    """Manual tab — touch-off and positioning now live on the persistent sidebar."""

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        placeholder = QLabel("Manual controls available on sidebar →")
        placeholder.setAlignment(Qt.AlignCenter)
        placeholder.setStyleSheet(
            f"color: {COLORS['text_dim']}; font-size: 14px; padding: 4px;"
        )
        layout.addWidget(placeholder)
