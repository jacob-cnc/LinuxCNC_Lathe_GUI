"""Tool Geometry Tab — Mazak-style tool data editor with orientation graphics
and integrated wear offset controls."""

import os
import re
import math
import json
import shutil

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel,
    QPushButton, QComboBox, QGroupBox, QLineEdit, QFrame,
    QScrollArea, QFileDialog
)
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QFont

from theme import COLORS, TOUCH_SIZES, mono_font


# Tool orientation descriptions matching LinuxCNC Q values
ORIENTATIONS = {
    1: "1 — Front Right  (OD Turning, standard RH)",
    2: "2 — Front Left   (OD Turning, LH / Facing)",
    3: "3 — Rear Left    (Back turning, LH)",
    4: "4 — Rear Right   (Back turning, RH)",
    5: "5 — Right         (Profiling, right side)",
    6: "6 — Top           (Facing from top)",
    7: "7 — Left          (Profiling, left side)",
    8: "8 — Bottom        (Boring, bottom)",
    9: "9 — Center        (Drill, center tool)",
}

TOOL_TYPES = [
    "Turning — RH",
    "Turning — LH",
    "Boring Bar",
    "Threading — External",
    "Threading — Internal",
    "Grooving / Parting",
    # "Drill / Center Drill",  # Removed from UI — re-enable when drill support is needed
    "Knurling",
    "Custom",
]

# Default orientation (Q value) for each tool type
TOOL_TYPE_ORIENTATION = {
    "Turning — RH": 1,          # Front right
    "Turning — LH": 2,          # Front left
    "Boring Bar": 2,             # Front left (internal)
    "Threading — External": 1,   # Front right
    "Threading — Internal": 2,   # Front left
    "Grooving / Parting": 9,     # Center
    "Drill / Center Drill": 9,   # Center
    "Knurling": 1,               # Front right
    "Custom": 1,                 # Default to front right
}

# Valid orientations for each tool type
TOOL_TYPE_VALID_ORIENTATIONS = {
    "Turning — RH": [1, 4],          # Front right, rear right
    "Turning — LH": [2, 3],          # Front left, rear left
    "Boring Bar": [2, 3],             # Front left, rear left
    "Threading — External": [1, 2],   # Front right or front left
    "Threading — Internal": [2, 3],   # Front left, rear left
    "Grooving / Parting": [6, 8, 9],  # Top, bottom, center
    "Drill / Center Drill": [9],      # Center only
    "Knurling": [1, 2],              # Front right or front left
    "Custom": [1, 2, 3, 4, 5, 6, 7, 8, 9],  # All
}

# Valid insert codes for each tool type
TOOL_TYPE_VALID_INSERTS = {
    "Turning — RH": ["—", "CNMG", "CCMT", "WNMG", "DNMG", "DCMT",
                      "VNMG", "TNMG", "SNMG", "RCMT", "Custom"],
    "Turning — LH": ["—", "CNMG", "CCMT", "WNMG", "DNMG", "DCMT",
                      "VNMG", "TNMG", "SNMG", "RCMT", "Custom"],
    "Boring Bar": ["—", "CCMT", "DCMT", "VNMG", "TNMG", "SNMG",
                   "RCMT", "Custom"],
    "Threading — External": ["—", "60° UN/Metric", "55° Whitworth", "ACME", "Custom"],
    "Threading — Internal": ["—", "60° UN/Metric", "55° Whitworth", "ACME", "Custom"],
    "Grooving / Parting": ["—", "Grooving", "Custom"],
    "Drill / Center Drill": ["—", "Custom"],
    "Knurling": ["—", "Custom"],
    "Custom": ["—", "CNMG", "CCMT", "WNMG", "DNMG", "DCMT",
               "VNMG", "TNMG", "SNMG", "RCMT",
               "Grooving", "60° UN/Metric", "55° Whitworth", "ACME", "Custom"],
}


class ToolOrientationGraphic(QFrame):
    """Insert-only graphic showing the cutter shape, nose radius, cutting edges,
    and control point from the operator's perspective at a manual lathe."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(160, 160)
        self._orientation = 1
        self._nose_radius = 0.0312
        self._front_angle = 90.0
        self._back_angle = 180.0
        self._tool_type = "Turning — RH"
        self.setStyleSheet("background: transparent; border: none;")

    def set_orientation(self, q):
        self._orientation = q
        self.update()

    def set_geometry(self, nose_r=None, front_a=None, back_a=None, tool_type=None):
        if nose_r is not None:
            try: self._nose_radius = float(nose_r)
            except (ValueError, TypeError): pass
        if front_a is not None:
            try: self._front_angle = float(front_a)
            except (ValueError, TypeError): pass
        if back_a is not None:
            try: self._back_angle = float(back_a)
            except (ValueError, TypeError): pass
        if tool_type is not None:
            self._tool_type = tool_type
        self.update()

    def paintEvent(self, event):
        from PyQt5.QtGui import QPainter, QPen, QBrush, QPolygonF, QColor
        from PyQt5.QtCore import QPointF, QRectF

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        w = self.width()
        h = self.height()
        cx, cy = w / 2, h / 2
        q = self._orientation

        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(QColor(COLORS["bg_light"])))
        painter.drawRoundedRect(QRectF(4, 4, w - 8, h - 8), 10, 10)

        # Axis indicator — lathe operator view: Z+ right, X- up (toward operator)
        ax_x, ax_y = 14, h - 14
        painter.setPen(QPen(QColor(COLORS["text_dim"]), 1))
        # Z arrow pointing right
        painter.drawLine(QPointF(ax_x, ax_y), QPointF(ax_x + 20, ax_y))
        painter.drawLine(QPointF(ax_x + 17, ax_y - 3), QPointF(ax_x + 20, ax_y))
        painter.drawLine(QPointF(ax_x + 17, ax_y + 3), QPointF(ax_x + 20, ax_y))
        # X arrow pointing up (X- direction = toward operator)
        painter.drawLine(QPointF(ax_x, ax_y), QPointF(ax_x, ax_y - 20))
        painter.drawLine(QPointF(ax_x - 3, ax_y - 17), QPointF(ax_x, ax_y - 20))
        painter.drawLine(QPointF(ax_x + 3, ax_y - 17), QPointF(ax_x, ax_y - 20))
        painter.setFont(mono_font(8))
        painter.drawText(QRectF(ax_x + 20, ax_y - 8, 14, 14), Qt.AlignLeft, "Z")
        painter.drawText(QRectF(ax_x + 4, ax_y - 28, 16, 14), Qt.AlignLeft, "-X")

        painter.setPen(QColor(COLORS["accent_blue"]))
        painter.setFont(mono_font(12, QFont.Bold))
        painter.drawText(QRectF(8, 8, 44, 18), Qt.AlignLeft, f"Q{q}")
        if q != 9:
            painter.setPen(QColor(COLORS["text_dim"]))
            painter.setFont(mono_font(8))
            painter.drawText(QRectF(8, 24, 80, 12), Qt.AlignLeft,
                             f"F:{self._front_angle:.0f}° B:{self._back_angle:.0f}°")

        if q == 9:
            # Round/drill — centered, no directional orientation
            r = 20
            painter.setPen(QPen(QColor(COLORS["text_secondary"]), 1.5))
            painter.setBrush(QBrush(QColor("#4a4a4c")))
            painter.drawEllipse(QPointF(cx, cy), r, r)
            tip = QPointF(cx, cy - r - 10)
            painter.setPen(QPen(QColor(COLORS["text"]), 2))
            painter.drawLine(QPointF(cx - r * 0.5, cy - r), tip)
            painter.drawLine(QPointF(cx + r * 0.5, cy - r), tip)
            nr_vis = max(4, min(12, self._nose_radius * 300))
            painter.setPen(QPen(QColor(COLORS["accent_green"]), 2))
            painter.setBrush(Qt.NoBrush)
            painter.drawEllipse(tip, nr_vis, nr_vis)
            cp = tip
        else:
            # Orientation determines mirror factors for the insert shape.
            # In operator view (Z+ right, X- up):
            #   Q1: tip bottom-right, insert extends up-left (standard RH)
            #   Q2: tip bottom-left, insert extends up-right (mirror Z)
            #   Q3: tip top-left, insert extends down-right (mirror Z + mirror X)
            #   Q4: tip top-right, insert extends down-left (mirror X)
            #   Q5: tip right, insert extends left
            #   Q6: tip top, insert extends down (mirror X)
            #   Q7: tip left, insert extends right (mirror Z)
            #   Q8: tip bottom, insert extends up
            #
            # mirror_z: flip horizontal (negate Z/dx component)
            # mirror_x: flip vertical (negate X/dy component)
            #
            # In operator view (Z+ right, X- up), the insert body extends
            # AWAY from the tip. The tip points toward the cutting direction.
            #   Q1: Front Right — tip toward Z- and X+ (down-left)
            #   Q2: Front Left  — tip toward Z- and X- (up-left)
            #   Q3: Rear Left   — tip toward Z+ and X- (up-right)
            #   Q4: Rear Right  — tip toward Z+ and X+ (down-right)
            #   Q5: Right       — tip toward Z- (left)
            #   Q6: Top         — tip toward X- (up)
            #   Q7: Left        — tip toward Z+ (right)
            #   Q8: Bottom      — tip toward X+ (down)
            #
            # Base drawing (no mirrors) has insert extending toward Z+ and X+
            # (down-right). We negate to flip toward the correct tip direction.
            mirror_z = -1.0 if q in (1, 2, 5) else 1.0
            mirror_x = -1.0 if q in (2, 3, 6) else 1.0

            # Position control point (tip) based on Q
            margin = 30
            tip_offsets = {
                1: (-margin * 0.4, margin * 0.4),    # down-left (toward chuck, toward centerline)
                2: (-margin * 0.4, -margin * 0.4),   # up-left (toward chuck, toward operator)
                3: (margin * 0.4, -margin * 0.4),    # up-right (toward tailstock, toward operator)
                4: (margin * 0.4, margin * 0.4),     # down-right (toward tailstock, toward centerline)
                5: (-margin * 0.6, 0),                # left (toward chuck)
                6: (0, -margin * 0.6),                # up (toward operator)
                7: (margin * 0.6, 0),                 # right (toward tailstock)
                8: (0, margin * 0.6),                 # down (toward centerline)
            }
            off_x, off_y = tip_offsets.get(q, (0, 0))
            tip_x = cx + off_x
            tip_y = cy + off_y

            insert_size = 30
            fa_rad = math.radians(self._front_angle)
            ba_rad = math.radians(self._back_angle)

            # Base direction vectors (CW from Z+ for Q1 reference)
            # Apply mirror factors for other orientations
            fe_dx = math.cos(fa_rad) * mirror_z
            fe_dy = math.sin(fa_rad) * mirror_x
            be_dx = math.cos(ba_rad) * mirror_z
            be_dy = math.sin(ba_rad) * mirror_x

            fe_end = QPointF(tip_x + insert_size * fe_dx, tip_y + insert_size * fe_dy)
            be_end = QPointF(tip_x + insert_size * be_dx, tip_y + insert_size * be_dy)
            # Opposite tip — mirror of the cutting tip through the center
            # This creates a symmetrical double-sided insert shape
            center_x = tip_x + insert_size * 0.5 * (fe_dx + be_dx)
            center_y = tip_y + insert_size * 0.5 * (fe_dy + be_dy)
            opp_tip_x = 2 * center_x - tip_x
            opp_tip_y = 2 * center_y - tip_y
            insert_poly = QPolygonF([
                QPointF(tip_x, tip_y), fe_end,
                QPointF(opp_tip_x, opp_tip_y), be_end,
            ])
            painter.setPen(QPen(QColor(COLORS["text_secondary"]), 1.5))
            painter.setBrush(QBrush(QColor("#4a4a4c")))
            painter.drawPolygon(insert_poly)
            # Cutting edges
            painter.setPen(QPen(QColor(COLORS["text"]), 2))
            painter.drawLine(QPointF(tip_x, tip_y), fe_end)
            painter.drawLine(QPointF(tip_x, tip_y), be_end)
            # Nose radius circle
            nr_vis = max(4, min(16, self._nose_radius * 300))
            bisect_dx = (fe_dx + be_dx)
            bisect_dy = (fe_dy + be_dy)
            blen = math.sqrt(bisect_dx**2 + bisect_dy**2) or 1
            bisect_dx /= blen
            bisect_dy /= blen
            nr_cx = tip_x + bisect_dx * nr_vis * 0.7
            nr_cy = tip_y + bisect_dy * nr_vis * 0.7
            painter.setPen(QPen(QColor(COLORS["accent_green"]), 2.5))
            painter.setBrush(Qt.NoBrush)
            painter.drawEllipse(QPointF(nr_cx, nr_cy), nr_vis, nr_vis)
            if self._nose_radius > 0.0001:
                painter.setPen(QColor(COLORS["accent_green"]))
                painter.setFont(mono_font(8))
                lx = min(nr_cx + nr_vis + 4, w - 54)
                ly = max(nr_cy - 5, 8)
                painter.drawText(QRectF(lx, ly, 54, 12), Qt.AlignLeft, f"R{self._nose_radius:.3f}")
            cp = QPointF(tip_x, tip_y)

        # Control point crosshair
        painter.setPen(QPen(QColor(COLORS["accent"]), 2))
        painter.setBrush(QBrush(QColor(COLORS["accent"])))
        painter.drawEllipse(cp, 4, 4)
        ch = 7
        painter.drawLine(QPointF(cp.x() - ch, cp.y()), QPointF(cp.x() + ch, cp.y()))
        painter.drawLine(QPointF(cp.x(), cp.y() - ch), QPointF(cp.x(), cp.y() + ch))
        painter.end()


# Insert code geometry — front angle and back angle for LinuxCNC tool table.
# Angles are measured clockwise from Z+ (toward tailstock).
# Values assume standard RH holder with ~5° lead angle, orientation Q1.
# Back angle = Front angle + insert included angle.
#
# ISO insert shape codes (first letter):
#   R = Round, S = 90° square, C = 80° diamond, W = 80° trigon,
#   T = 60° triangle, D = 55° diamond, V = 35° diamond
#
# Grooving/parting inserts have 0° front (perpendicular to Z) and
# back angle equal to the insert width angle (typically 0° for square-ground).
# Threading inserts use 60° (UN/ISO) or 55° (Whitworth) included angles.
#
# Format: { "CODE": (front_angle, back_angle) }
INSERT_GEOMETRY = {
    # --- No selection / custom ---
    "—":    (0, 0),         # No insert selected — leave angles unchanged
    "Custom": (0, 0),      # User-defined — leave angles unchanged
    # --- Turning inserts ---
    "CNMG": (95, 175),     # C = 80° diamond: 95 + 80 = 175
    "CCMT": (95, 175),     # C = 80° diamond
    "WNMG": (95, 175),    # W = 80° trigon (same included angle as C at tip)
    "DNMG": (95, 150),    # D = 55° diamond: 95 + 55 = 150
    "DCMT": (95, 150),    # D = 55° diamond
    "VNMG": (95, 130),    # V = 35° diamond: 95 + 35 = 130
    "TNMG": (95, 155),    # T = 60° triangle: 95 + 60 = 155
    "SNMG": (95, 185),    # S = 90° square: 95 + 90 = 185
    "RCMT": (0, 0),       # R = round — no meaningful edge angles (use Q9)
    # --- Grooving / Parting inserts ---
    "Grooving":  (90, 270),    # Square edges perpendicular to Z, Q9
    # --- Threading inserts ---
    "60° UN/Metric": (60, 120),   # 60° UN/ISO/Metric thread
    "55° Whitworth": (62.5, 117.5),  # 55° Whitworth/BSP thread
    "ACME":  (75.5, 104.5),   # 29° ACME thread: symmetric about 90°
}


class ToolGeometryRow(QFrame):
    """Single tool geometry entry row — compact layout with integrated wear offsets."""

    # Signal-like callback for delete; set by parent
    on_delete = None

    # Signal for wear offset changes (tool_num, axis, new_value_radius)
    wear_changed = pyqtSignal(int, str, float)

    def __init__(self, tool_num=1, parent=None):
        super().__init__(parent)
        self.tool_num = tool_num
        self._wear_x = 0.0  # internal radius
        self._wear_z = 0.0

        self.setStyleSheet(
            f"QFrame {{ background-color: {COLORS['bg_mid']}; "
            f"border: 1px solid {COLORS['border']}; border-radius: 4px; "
            f"margin: 1px; padding: 2px; }}"
        )

        layout = QGridLayout(self)
        layout.setSpacing(3)
        layout.setContentsMargins(6, 4, 6, 4)

        lbl_style = f"color: {COLORS['text_dim']}; font-size: 13px; background: transparent; border: none;"
        val_style = (
            f"background-color: {COLORS['dro_bg']}; color: {COLORS['text']}; "
            f"border: 1px solid {COLORS['border']}; border-radius: 2px; "
            f"padding: 2px 4px; font-family: Consolas; font-size: 15px;"
        )
        wear_val_style = (
            f"background-color: {COLORS['dro_bg']}; color: {COLORS['accent_warm']}; "
            f"border: 1px solid {COLORS['border']}; border-radius: 3px; "
            f"padding: 6px 6px; font-family: Consolas; font-size: 20px;"
        )

        # --- Column 0: Tool number labels ---
        lib_tool_id = 100 + tool_num
        t_label = QLabel(f"T{lib_tool_id}")
        t_label.setStyleSheet(
            f"color: {COLORS['accent_yellow']}; background: transparent; border: none; "
            f"font-family: 'JetBrains Mono', 'Consolas', monospace; font-size: 42px; font-weight: bold;"
        )
        t_label.setMinimumSize(140, 50)
        t_label.setAlignment(Qt.AlignLeft | Qt.AlignBottom)
        layout.addWidget(t_label, 0, 0, 2, 1)

        prog_label = QLabel(f"(T{tool_num})")
        prog_label.setStyleSheet(
            f"color: {COLORS['text_dim']}; background: transparent; border: none; "
            f"font-family: 'JetBrains Mono', 'Consolas', monospace; font-size: 26px;"
        )
        prog_label.setMinimumSize(140, 36)
        prog_label.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        prog_label.setToolTip(f"Program call: T{tool_num} → library T{lib_tool_id}")
        layout.addWidget(prog_label, 2, 0, 2, 1)

        # =====================================================================
        # Column 1 (cols 1-3): Wear X, Wear Z, X Offset, Z Offset
        # =====================================================================

        # Row 0: Wear X + buttons
        layout.addWidget(self._make_label("Wear X:", lbl_style), 0, 1)
        self.wear_x_field = QLineEdit("0.0000")
        self.wear_x_field.setStyleSheet(wear_val_style)
        self.wear_x_field.setFixedWidth(125)
        self.wear_x_field.setFixedHeight(36)
        self.wear_x_field.setToolTip("X wear offset (diameter)")
        self.wear_x_field.returnPressed.connect(self._on_wear_x_edited)
        layout.addWidget(self.wear_x_field, 0, 2)



        # Row 1: Wear Z + buttons
        layout.addWidget(self._make_label("Wear Z:", lbl_style), 1, 1)
        self.wear_z_field = QLineEdit("0.0000")
        self.wear_z_field.setStyleSheet(wear_val_style)
        self.wear_z_field.setFixedWidth(125)
        self.wear_z_field.setFixedHeight(36)
        self.wear_z_field.setToolTip("Z wear offset")
        self.wear_z_field.returnPressed.connect(self._on_wear_z_edited)
        layout.addWidget(self.wear_z_field, 1, 2)



        # Row 2: X Offset
        layout.addWidget(self._make_label("X Offset:", lbl_style), 2, 1)
        self.offset_x = QLineEdit("0.0000")
        self.offset_x.setStyleSheet(val_style)
        self.offset_x.setFixedWidth(125)
        layout.addWidget(self.offset_x, 2, 2)

        # Row 3: Z Offset
        layout.addWidget(self._make_label("Z Offset:", lbl_style), 3, 1)
        self.offset_z = QLineEdit("0.0000")
        self.offset_z.setStyleSheet(val_style)
        self.offset_z.setFixedWidth(125)
        layout.addWidget(self.offset_z, 3, 2)

        # =====================================================================
        # Column 2 (cols 4-5): Type, Insert Code, Orientation, Desc
        # =====================================================================

        # Row 0: Type
        layout.addWidget(self._make_label("Type:", lbl_style), 0, 4)
        self.tool_type = QComboBox()
        self.tool_type.addItems(TOOL_TYPES)
        self.tool_type.setFixedWidth(200)
        layout.addWidget(self.tool_type, 0, 5)

        # Row 1: Insert Code
        layout.addWidget(self._make_label("Insert:", lbl_style), 1, 4)
        self.insert_code = QComboBox()
        self.insert_code.addItems(["—"])  # populated by _on_tool_type_changed
        self.insert_code.setFixedWidth(200)
        self.insert_code.setToolTip("Insert designation code (ISO standard)")
        layout.addWidget(self.insert_code, 1, 5)

        # Row 2: Orientation
        layout.addWidget(self._make_label("Orient:", lbl_style), 2, 4)
        self.orientation = QComboBox()
        for q, desc in ORIENTATIONS.items():
            self.orientation.addItem(desc, q)
        self.orientation.setFixedWidth(250)
        self.orientation.setToolTip(
            "Imaginary tool tip point — defines which quadrant the nose radius is in.\n"
            "Critical for correct cutter compensation (G41/G42)."
        )
        # Make dropdown wide enough to show full orientation descriptions
        self.orientation.view().setMinimumWidth(380)
        self.orientation.view().setStyleSheet(
            f"QAbstractItemView::item {{ min-height: {TOUCH_SIZES['target_min']}px; padding: 8px 12px; }}"
        )
        layout.addWidget(self.orientation, 2, 5)

        # Row 3: Description
        layout.addWidget(self._make_label("Desc:", lbl_style), 3, 4)
        self.description = QLineEdit()
        self.description.setPlaceholderText("e.g. CNMG 432 insert")
        self.description.setStyleSheet(val_style)
        self.description.setFixedWidth(200)
        layout.addWidget(self.description, 3, 5)

        # =====================================================================
        # Column 3 (cols 6-7): Nose R, Front Angle, Back Angle, Blade Width
        # =====================================================================

        # Row 0: Nose Radius
        layout.addWidget(self._make_label("Nose R:", lbl_style), 0, 6)
        self.nose_radius = QLineEdit("0.0000")
        self.nose_radius.setStyleSheet(val_style)
        self.nose_radius.setFixedWidth(95)
        self.nose_radius.setToolTip("Tool nose radius (inch). Used for cutter compensation (G41/G42).")
        layout.addWidget(self.nose_radius, 0, 7)

        # Row 1: Front Angle
        layout.addWidget(self._make_label("Front ∠:", lbl_style), 1, 6)
        self.front_angle = QLineEdit("0")
        self.front_angle.setStyleSheet(val_style)
        self.front_angle.setFixedWidth(95)
        self.front_angle.setToolTip("Front cutting edge angle (degrees CW from Z+).")
        layout.addWidget(self.front_angle, 1, 7)

        # Row 2: Back Angle
        layout.addWidget(self._make_label("Back ∠:", lbl_style), 2, 6)
        self.back_angle = QLineEdit("0")
        self.back_angle.setStyleSheet(val_style)
        self.back_angle.setFixedWidth(95)
        self.back_angle.setToolTip("Back cutting edge angle (degrees CW from Z+).")
        layout.addWidget(self.back_angle, 2, 7)

        # Row 3: Blade Width (only for Grooving / Parting)
        self.blade_width_label = self._make_label("Blade W:", lbl_style)
        layout.addWidget(self.blade_width_label, 3, 6)
        self.blade_width = QLineEdit("0.1250")
        self.blade_width.setStyleSheet(val_style)
        self.blade_width.setFixedWidth(95)
        self.blade_width.setToolTip("Width of the parting/grooving blade (inches).")
        layout.addWidget(self.blade_width, 3, 7)
        self.blade_width_label.setVisible(False)
        self.blade_width.setVisible(False)

        # =====================================================================
        # Orientation graphic (far right, spanning all rows)
        # =====================================================================
        self.tool_graphic = ToolOrientationGraphic()
        layout.addWidget(self.tool_graphic, 0, 8, 4, 1, Qt.AlignCenter)

        # Delete button (top-right corner)
        self.btn_delete = QPushButton("✕")
        self.btn_delete.setFixedSize(22, 22)
        self.btn_delete.setToolTip(f"Delete tool T{lib_tool_id}")
        self.btn_delete.setStyleSheet(
            f"QPushButton {{ background-color: transparent; color: {COLORS['text_dim']}; "
            f"border: 1px solid {COLORS['border']}; border-radius: 4px; font-size: 11px; font-weight: bold; }}"
            f"QPushButton:hover {{ background-color: {COLORS['accent']}; color: white; border: none; }}"
        )
        self.btn_delete.clicked.connect(self._request_delete)
        layout.addWidget(self.btn_delete, 0, 9, 1, 1, Qt.AlignRight | Qt.AlignTop)

        # Connect signals for graphic updates
        self.orientation.currentIndexChanged.connect(self._update_graphic)
        self.nose_radius.textChanged.connect(self._update_graphic)
        self.front_angle.textChanged.connect(self._update_graphic)
        self.back_angle.textChanged.connect(self._update_graphic)
        self.tool_type.currentIndexChanged.connect(self._update_graphic)
        self.tool_type.currentTextChanged.connect(self._on_tool_type_changed)
        self.insert_code.currentTextChanged.connect(self._on_insert_code_changed)
        self._on_tool_type_changed(self.tool_type.currentText())

    # ------------------------------------------------------------------
    # Wear offset methods
    # ------------------------------------------------------------------
    def _on_wear_x_edited(self):
        """Handle direct entry in wear X field (user enters diameter in display units)."""
        try:
            val_dia = float(self.wear_x_field.text())
            metric = getattr(self, '_metric_display', False)
            if metric:
                val_dia /= 25.4  # convert mm back to inches
            self._wear_x = val_dia / 2.0  # store as radius in inches
            self.wear_changed.emit(self.tool_num, "x", self._wear_x)
            self._update_wear_highlight()
        except ValueError:
            self._refresh_wear_display()

    def _on_wear_z_edited(self):
        """Handle direct entry in wear Z field (user enters in display units)."""
        try:
            val = float(self.wear_z_field.text())
            metric = getattr(self, '_metric_display', False)
            if metric:
                val /= 25.4  # convert mm back to inches
            self._wear_z = val
            self.wear_changed.emit(self.tool_num, "z", self._wear_z)
            self._update_wear_highlight()
        except ValueError:
            self._refresh_wear_display()

    def _update_wear_highlight(self):
        """Highlight wear fields when non-zero."""
        highlight_style = (
            f"background-color: {COLORS['dro_bg']}; color: {COLORS['accent_warm']}; "
            f"border: 1px solid {COLORS['accent_warm']}; border-radius: 3px; "
            f"padding: 6px 6px; font-family: Consolas; font-size: 20px; font-weight: bold;"
        )
        normal_style = (
            f"background-color: {COLORS['dro_bg']}; color: {COLORS['accent_warm']}; "
            f"border: 1px solid {COLORS['border']}; border-radius: 3px; "
            f"padding: 6px 6px; font-family: Consolas; font-size: 20px;"
        )
        self.wear_x_field.setStyleSheet(highlight_style if self._wear_x != 0.0 else normal_style)
        self.wear_z_field.setStyleSheet(highlight_style if self._wear_z != 0.0 else normal_style)

    def set_wear_values(self, x_radius, z_value):
        """Set wear values programmatically (x in radius, z direct)."""
        self._wear_x = x_radius
        self._wear_z = z_value
        self._refresh_wear_display()
        self._update_wear_highlight()

    def set_metric_display(self, metric: bool):
        """Toggle display-only metric conversion for wear and geometry fields."""
        old_metric = getattr(self, '_metric_display', False)
        self._metric_display = metric
        self._refresh_wear_display()
        # Convert offset/geometry fields in-place (same pattern as conv tab)
        if old_metric != metric:
            for field in (self.offset_x, self.offset_z, self.nose_radius, self.blade_width):
                try:
                    val = float(field.text())
                except (ValueError, TypeError):
                    continue
                if metric:
                    field.setText(f"{val * 25.4:.3f}")
                else:
                    field.setText(f"{val / 25.4:.4f}")

    def _refresh_wear_display(self):
        """Refresh wear field text based on current unit mode."""
        metric = getattr(self, '_metric_display', False)
        conv = 25.4 if metric else 1.0
        d = 3 if metric else 4
        x_dia = self._wear_x * 2 * conv
        z_val = self._wear_z * conv
        self.wear_x_field.setText(f"{x_dia:.{d}f}")
        self.wear_z_field.setText(f"{z_val:.{d}f}")

    def get_wear_values(self):
        """Return current wear values as dict (x in radius, z direct)."""
        return {"x": self._wear_x, "z": self._wear_z}

    # ------------------------------------------------------------------
    # Graphic and tool type updates
    # ------------------------------------------------------------------
    def _update_graphic(self, *args):
        q = self.orientation.currentData()
        if q is not None:
            self.tool_graphic.set_orientation(q)
        self.tool_graphic.set_geometry(
            nose_r=self.nose_radius.text(),
            front_a=self.front_angle.text(),
            back_a=self.back_angle.text(),
            tool_type=self.tool_type.currentText(),
        )

    def _request_delete(self):
        """Request deletion of this tool row via parent callback."""
        if self.on_delete:
            self.on_delete(self)

    def _on_tool_type_changed(self, text):
        """Show/hide blade width field, filter orientations and inserts, and auto-set defaults."""
        is_grooving = text == "Grooving / Parting"
        self.blade_width_label.setVisible(is_grooving)
        self.blade_width.setVisible(is_grooving)

        # Filter orientation options to only those valid for this tool type
        valid_qs = TOOL_TYPE_VALID_ORIENTATIONS.get(text, [1, 2, 3, 4, 5, 6, 7, 8, 9])
        self.orientation.blockSignals(True)
        self.orientation.clear()
        for q, desc in ORIENTATIONS.items():
            if q in valid_qs:
                self.orientation.addItem(desc, q)
        self.orientation.blockSignals(False)

        # Auto-populate default orientation
        if text in TOOL_TYPE_ORIENTATION:
            default_q = TOOL_TYPE_ORIENTATION[text]
            idx = self.orientation.findData(default_q)
            if idx >= 0:
                self.orientation.setCurrentIndex(idx)

        # Filter insert code options to only those valid for this tool type
        valid_inserts = TOOL_TYPE_VALID_INSERTS.get(text, ["—", "Custom"])
        self.insert_code.blockSignals(True)
        self.insert_code.clear()
        self.insert_code.addItems(valid_inserts)
        self.insert_code.blockSignals(False)
        self.insert_code.setCurrentIndex(0)

        self._update_graphic()

    def _on_insert_code_changed(self, text):
        """Auto-populate front/back angles from insert geometry lookup."""
        if text in INSERT_GEOMETRY and text not in ("—", "Custom"):
            front_a, back_a = INSERT_GEOMETRY[text]
            self.front_angle.setText(str(int(front_a)) if front_a == int(front_a) else f"{front_a:.1f}")
            self.back_angle.setText(str(int(back_a)) if back_a == int(back_a) else f"{back_a:.1f}")
            self._update_graphic()

    def _make_label(self, text, style):
        lbl = QLabel(text)
        lbl.setStyleSheet(style)
        lbl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        return lbl

    def get_data(self):
        metric = getattr(self, '_metric_display', False)
        conv = 1.0 / 25.4 if metric else 1.0
        # offset_x, offset_z, nose_radius, blade_width need conversion back to inches
        try:
            ox = float(self.offset_x.text()) * conv
            ox_str = f"{ox:.4f}"
        except ValueError:
            ox_str = self.offset_x.text()
        try:
            oz = float(self.offset_z.text()) * conv
            oz_str = f"{oz:.4f}"
        except ValueError:
            oz_str = self.offset_z.text()
        try:
            nr = float(self.nose_radius.text()) * conv
            nr_str = f"{nr:.4f}"
        except ValueError:
            nr_str = self.nose_radius.text()
        try:
            bw = float(self.blade_width.text()) * conv
            bw_str = f"{bw:.4f}"
        except ValueError:
            bw_str = self.blade_width.text()
        return {
            "tool_num": self.tool_num,
            "tool_type": self.tool_type.currentText(),
            "description": self.description.text(),
            "insert_code": self.insert_code.currentText(),
            "offset_x": ox_str,
            "offset_z": oz_str,
            "nose_radius": nr_str,
            "orientation": self.orientation.currentData(),
            "front_angle": self.front_angle.text(),
            "back_angle": self.back_angle.text(),
            "blade_width": bw_str,
            "wear_x": self._wear_x,
            "wear_z": self._wear_z,
        }

    def set_data(self, data):
        # Block signals during bulk data load to prevent cascading resets
        # (e.g., tool_type change resetting insert_code and angles)
        self.tool_type.blockSignals(True)
        self.insert_code.blockSignals(True)
        self.orientation.blockSignals(True)
        self.front_angle.blockSignals(True)
        self.back_angle.blockSignals(True)

        if "tool_type" in data:
            idx = self.tool_type.findText(data["tool_type"])
            if idx >= 0:
                self.tool_type.setCurrentIndex(idx)
                # Manually repopulate orientation and insert options for this type
                # without triggering further signals
                text = data["tool_type"]
                is_grooving = text == "Grooving / Parting"
                self.blade_width_label.setVisible(is_grooving)
                self.blade_width.setVisible(is_grooving)

                valid_qs = TOOL_TYPE_VALID_ORIENTATIONS.get(text, [1, 2, 3, 4, 5, 6, 7, 8, 9])
                self.orientation.blockSignals(True)
                self.orientation.clear()
                for q, desc in ORIENTATIONS.items():
                    if q in valid_qs:
                        self.orientation.addItem(desc, q)
                self.orientation.blockSignals(False)

                valid_inserts = TOOL_TYPE_VALID_INSERTS.get(text, ["—", "Custom"])
                self.insert_code.blockSignals(True)
                self.insert_code.clear()
                self.insert_code.addItems(valid_inserts)
                self.insert_code.blockSignals(False)

        if "description" in data: self.description.setText(data["description"])
        if "insert_code" in data:
            idx = self.insert_code.findText(data["insert_code"])
            if idx >= 0: self.insert_code.setCurrentIndex(idx)
        if "offset_x" in data: self.offset_x.setText(data["offset_x"])
        if "offset_z" in data: self.offset_z.setText(data["offset_z"])
        if "nose_radius" in data: self.nose_radius.setText(data["nose_radius"])
        if "orientation" in data:
            idx = self.orientation.findData(data["orientation"])
            if idx >= 0: self.orientation.setCurrentIndex(idx)
        if "front_angle" in data: self.front_angle.setText(data["front_angle"])
        if "back_angle" in data: self.back_angle.setText(data["back_angle"])
        if "blade_width" in data: self.blade_width.setText(data["blade_width"])
        if "wear_x" in data and "wear_z" in data:
            self.set_wear_values(data["wear_x"], data["wear_z"])

        # Restore signals
        self.tool_type.blockSignals(False)
        self.insert_code.blockSignals(False)
        self.orientation.blockSignals(False)
        self.front_angle.blockSignals(False)
        self.back_angle.blockSignals(False)

        self._update_graphic()

    def to_tool_table_line(self):
        """Generate a LinuxCNC tool table line using library naming.

        Convention: program T# maps to library T1## (T1->T101, T2->T102, etc.)
        The pocket number P matches the program tool number for offset lookup.

        Extra metadata (tool_type, insert_code, blade_width) is encoded in the
        comment field as pipe-delimited key:value pairs after the description.
        """
        d = self.get_data()
        t = d["tool_num"]
        lib_t = 100 + t  # T1 -> T101, T2 -> T102, etc.
        try:
            x = float(d["offset_x"])
            z = float(d["offset_z"])
            nr = float(d["nose_radius"])
            fa = float(d["front_angle"])
            ba = float(d["back_angle"])
            q = int(d["orientation"])
        except ValueError:
            return f"T{lib_t}  P{t}  X+0.0000 Z+0.0000 D0.0000 I0 J0 Q1 ;{d['description']}"
        d_val = nr * 2.0
        x_sign = "+" if x >= 0 else ""
        z_sign = "+" if z >= 0 else ""
        desc = d["description"] or d["tool_type"]
        # Build metadata suffix for the comment field
        meta_parts = []
        if d["tool_type"]:
            meta_parts.append(f"type:{d['tool_type']}")
        insert = d.get("insert_code", "—")
        if insert and insert != "—":
            meta_parts.append(f"insert:{insert}")
        if d["tool_type"] == "Grooving / Parting":
            try:
                bw = float(d["blade_width"])
                meta_parts.append(f"W:{bw:.4f}")
            except ValueError:
                pass
        meta_suffix = "|" + "|".join(meta_parts) if meta_parts else ""
        return (
            f"T{lib_t}  P{t}  X{x_sign}{x:.4f} Z{z_sign}{z:.4f} "
            f"D{d_val:.4f} I{fa:.0f} J{ba:.0f} Q{q} ;{desc}{meta_suffix}"
        )


class ToolTab(QWidget):
    """Tool table management with Mazak-style geometry editor and integrated wear offsets."""

    # Signal emitted when touch-off is requested: (axis, tool_num, value_str)
    touchoff_requested = pyqtSignal(str, int, str)

    # Signal emitted when a tool is deleted: (tool_num) — pocket number before renumbering
    tool_deleted = pyqtSignal(int)

    def __init__(self, tool_table_path=None, stat=None, cmd=None, parent=None):
        super().__init__(parent)
        self.tool_table_path = tool_table_path
        self._stat = stat
        self._cmd = cmd
        self.tool_rows = []

        layout = QVBoxLayout(self)
        layout.setSpacing(4)


        # --- Button bar ---
        btn_bar = QHBoxLayout()
        self.btn_load = QPushButton("Load Table")
        self.btn_save = QPushButton("Save Table As")
        self.btn_save.setStyleSheet(
            f"QPushButton {{ background-color: {COLORS['accent_green']}; color: {COLORS['bg_dark']}; "
            f"font-weight: 700; border: none; border-radius: 8px; }}"
            f"QPushButton:hover {{ background-color: {COLORS['accent_green_lt']}; }}"
        )
        self.btn_add_tool = QPushButton("+ Add Tool")
        btn_bar.addWidget(self.btn_load)
        btn_bar.addWidget(self.btn_save)
        btn_bar.addWidget(self.btn_add_tool)

        # Current table name display
        self.table_name_label = QLabel("No table loaded")
        self.table_name_label.setFont(mono_font(11))
        self.table_name_label.setStyleSheet(
            f"color: {COLORS['text_secondary']}; background: {COLORS['bg_dark']}; "
            f"border: 1px solid {COLORS['border']}; border-radius: 4px; padding: 4px 8px;"
        )
        self.table_name_label.setMinimumWidth(200)
        btn_bar.addWidget(self.table_name_label)

        # Limits toggle button — shows/hides the per-tool soft limits panel
        self.btn_limits = QPushButton("Limits")
        self.btn_limits.setCheckable(True)
        self.btn_limits.setChecked(False)
        self.btn_limits.setStyleSheet(
            f"QPushButton {{ background-color: {COLORS['bg_light']}; color: {COLORS['text']}; "
            f"font-weight: 600; border: 1px solid {COLORS['border']}; border-radius: 8px; "
            f"padding: 4px 12px; font-size: 12px; }}"
            f"QPushButton:hover {{ background-color: {COLORS['accent_blue']}; color: white; }}"
            f"QPushButton:checked {{ background-color: {COLORS['accent_blue']}; color: white; "
            f"border: 1px solid {COLORS['accent_blue_lt']}; }}"
        )
        self.btn_limits.setToolTip("Toggle per-tool Z-axis soft limits panel")
        btn_bar.addWidget(self.btn_limits)

        # --- Current Tool + Wear Increment (compact) ---
        self.current_tool_label = QLabel("T0")
        self.current_tool_label.setFont(mono_font(14, QFont.Bold))
        self.current_tool_label.setStyleSheet(f"color: {COLORS['accent_yellow']};")
        btn_bar.addWidget(self.current_tool_label, alignment=Qt.AlignVCenter)

        self.current_tool_desc = QLabel("No tool loaded")
        self.current_tool_desc.setFont(mono_font(10))
        self.current_tool_desc.setStyleSheet(f"color: {COLORS['text_dim']};")
        btn_bar.addWidget(self.current_tool_desc, alignment=Qt.AlignVCenter)

        # --- Touch-Off (right side of button bar) ---
        btn_bar.addStretch()

        touchoff_lbl = QLabel("Touch-Off:")
        touchoff_lbl.setFont(mono_font(11, QFont.Bold))
        touchoff_lbl.setStyleSheet(f"color: {COLORS['text_dim']};")
        btn_bar.addWidget(touchoff_lbl, alignment=Qt.AlignVCenter)

        x_lbl = QLabel("X:")
        x_lbl.setFont(mono_font(11, QFont.Bold))
        x_lbl.setStyleSheet(f"color: {COLORS['text']};")
        btn_bar.addWidget(x_lbl, alignment=Qt.AlignVCenter)

        self.touchoff_x_val = QLineEdit("0.0000")
        self.touchoff_x_val.setFixedWidth(80)
        self.touchoff_x_val.setFixedHeight(26)
        self.touchoff_x_val.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.touchoff_x_val.setStyleSheet(
            f"QLineEdit {{ background-color: {COLORS['bg_light']}; color: {COLORS['text']}; "
            f"border: 1px solid {COLORS['border']}; border-radius: 4px; padding: 2px 4px; "
            f"font-family: 'JetBrains Mono', monospace; font-size: 11px; }}"
        )
        btn_bar.addWidget(self.touchoff_x_val, alignment=Qt.AlignVCenter)

        self.btn_touchoff_x = QPushButton("Set X")
        self.btn_touchoff_x.setFixedHeight(26)
        self.btn_touchoff_x.setStyleSheet(
            f"QPushButton {{ background-color: {COLORS['accent_blue']}; color: white; "
            f"font-weight: 600; border: none; border-radius: 4px; padding: 2px 10px; "
            f"font-size: 11px; }}"
            f"QPushButton:hover {{ background-color: {COLORS['accent_blue_lt']}; }}"
        )
        btn_bar.addWidget(self.btn_touchoff_x, alignment=Qt.AlignVCenter)

        btn_bar.addSpacing(8)

        z_lbl = QLabel("Z:")
        z_lbl.setFont(mono_font(11, QFont.Bold))
        z_lbl.setStyleSheet(f"color: {COLORS['text']};")
        btn_bar.addWidget(z_lbl, alignment=Qt.AlignVCenter)

        self.touchoff_z_val = QLineEdit("0.0000")
        self.touchoff_z_val.setFixedWidth(80)
        self.touchoff_z_val.setFixedHeight(26)
        self.touchoff_z_val.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.touchoff_z_val.setStyleSheet(
            f"QLineEdit {{ background-color: {COLORS['bg_light']}; color: {COLORS['text']}; "
            f"border: 1px solid {COLORS['border']}; border-radius: 4px; padding: 2px 4px; "
            f"font-family: 'JetBrains Mono', monospace; font-size: 11px; }}"
        )
        btn_bar.addWidget(self.touchoff_z_val, alignment=Qt.AlignVCenter)

        self.btn_touchoff_z = QPushButton("Set Z")
        self.btn_touchoff_z.setFixedHeight(26)
        self.btn_touchoff_z.setStyleSheet(
            f"QPushButton {{ background-color: {COLORS['accent_blue']}; color: white; "
            f"font-weight: 600; border: none; border-radius: 4px; padding: 2px 10px; "
            f"font-size: 11px; }}"
            f"QPushButton:hover {{ background-color: {COLORS['accent_blue_lt']}; }}"
        )
        btn_bar.addWidget(self.btn_touchoff_z, alignment=Qt.AlignVCenter)

        layout.addLayout(btn_bar)

        # --- Scrollable tool list ---
        self.tool_scroll = QScrollArea()
        self.tool_scroll.setWidgetResizable(True)
        self.tool_scroll.setStyleSheet(
            f"QScrollArea {{ border: 1px solid {COLORS['border']}; background: {COLORS['bg_dark']}; }}"
        )
        self.tool_container = QWidget()
        self.tool_list_layout = QVBoxLayout(self.tool_container)
        self.tool_list_layout.setSpacing(2)
        self.tool_list_layout.setContentsMargins(4, 4, 4, 4)
        self.tool_list_layout.addStretch()
        self.tool_scroll.setWidget(self.tool_container)
        layout.addWidget(self.tool_scroll, stretch=1)

        self._populate_defaults()
        self._active_table_path = None  # path of currently loaded table for autosave
        self._autosave_enabled = False
        self.btn_add_tool.clicked.connect(self._add_tool)
        self.btn_save.clicked.connect(self.save_tool_table)
        self.btn_load.clicked.connect(self.load_tool_table)
        self.btn_touchoff_x.clicked.connect(self._on_touchoff_x)
        self.btn_touchoff_z.clicked.connect(self._on_touchoff_z)

        # Auto-load last used table
        self._load_last_table()

    def set_metric_display(self, metric: bool):
        """Propagate metric display mode to all tool rows."""
        self._metric_display = metric
        for row in self.tool_rows:
            row.set_metric_display(metric)

    def _populate_defaults(self):
        defaults = [
            {"tool_type": "Turning — RH", "description": "Turning tool", "orientation": 1},
            {"tool_type": "Boring Bar", "description": "Boring bar", "orientation": 2},
            {"tool_type": "Threading — External", "description": "Threading tool", "orientation": 1},
            {"tool_type": "Grooving / Parting", "description": "Parting tool", "orientation": 9, "blade_width": "0.1250"},
        ]
        for i, d in enumerate(defaults):
            self._create_and_add_row(i + 1, d)

    def _create_and_add_row(self, tool_num, data=None):
        """Create a tool row, wire up its delete callback, and add to layout."""
        row = ToolGeometryRow(tool_num=tool_num)
        if data:
            row.set_data(data)
        row.on_delete = self._delete_tool
        row.wear_changed.connect(self._on_wear_changed)
        # Connect field changes for autosave
        row.offset_x.textChanged.connect(self._autosave)
        row.offset_z.textChanged.connect(self._autosave)
        row.nose_radius.textChanged.connect(self._autosave)
        row.front_angle.textChanged.connect(self._autosave)
        row.back_angle.textChanged.connect(self._autosave)
        row.description.textChanged.connect(self._autosave)
        row.blade_width.textChanged.connect(self._autosave)
        row.tool_type.currentIndexChanged.connect(self._autosave)
        row.orientation.currentIndexChanged.connect(self._autosave)
        row.insert_code.currentIndexChanged.connect(self._autosave)
        row.wear_changed.connect(lambda *a: self._autosave())
        self.tool_rows.append(row)
        self.tool_list_layout.insertWidget(self.tool_list_layout.count() - 1, row)
        return row

    def _on_wear_changed(self, tool_num, axis, value):
        """Handle wear change from a tool row — update tool offset via G10 L1.

        LinuxCNC doesn't have a separate wear offset register on a lathe.
        We manage wear locally and write the combined (geometry + wear) offset
        to the tool table using G10 L1. The geometry offset is the base, and
        wear is added on top.
        """
        if self._cmd is None or self._stat is None:
            return  # offline mode
        for row in self.tool_rows:
            if row.tool_num == tool_num:
                wear = row.get_wear_values()
                data = row.get_data()
                try:
                    geo_x = float(data["offset_x"])  # radius
                    geo_z = float(data["offset_z"])
                except ValueError:
                    break
                # Combined offset = geometry + wear (both in radius for X)
                total_x = geo_x + wear["x"]
                total_z = geo_z + wear["z"]
                lib_tool = 100 + tool_num
                g10_cmd = f"G10 L1 P{lib_tool} X{total_x:.4f} Z{total_z:.4f}"
                try:
                    import linuxcnc
                    self._cmd.mode(linuxcnc.MODE_MDI)
                    self._cmd.wait_complete()
                    self._cmd.mdi(g10_cmd)
                    self._cmd.wait_complete()
                    self._cmd.mdi("G43")
                    self._cmd.wait_complete()
                except Exception as e:
                    print(f"Wear write error T{tool_num}: {e}")
                break

    def _on_touchoff_x(self):
        """Handle Set X touch-off button — emit signal for main GUI to process."""
        tool_num = self._get_current_tool_num()
        if tool_num is None:
            return
        val = self.touchoff_x_val.text().strip()
        if val:
            self.touchoff_requested.emit("x", tool_num, val)

    def _on_touchoff_z(self):
        """Handle Set Z touch-off button — emit signal for main GUI to process."""
        tool_num = self._get_current_tool_num()
        if tool_num is None:
            return
        val = self.touchoff_z_val.text().strip()
        if val:
            self.touchoff_requested.emit("z", tool_num, val)

    def _get_current_tool_num(self):
        """Return the currently active tool number (from the label), or None."""
        text = self.current_tool_label.text()
        if text.startswith("T"):
            try:
                return int(text[1:])
            except ValueError:
                pass
        return None

    def _add_tool(self):
        next_num = len(self.tool_rows) + 1
        self._create_and_add_row(next_num)
        self._autosave()

    def _delete_tool(self, row):
        """Delete a specific tool row after user confirmation."""
        from PyQt5.QtWidgets import QMessageBox
        lib_id = 100 + row.tool_num
        msg = QMessageBox(self)
        msg.setWindowTitle("Delete Tool")
        msg.setText(f"Delete tool T{lib_id}?")
        msg.setInformativeText("This will remove the tool from the library and renumber remaining tools.")
        msg.setIcon(QMessageBox.Warning)
        msg.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        msg.setDefaultButton(QMessageBox.No)
        if msg.exec_() != QMessageBox.Yes:
            return
        if row in self.tool_rows:
            deleted_tool_num = row.tool_num
            self.tool_rows.remove(row)
            self.tool_list_layout.removeWidget(row)
            row.deleteLater()
            self._renumber_tools()
            self._autosave()
            # Notify listeners (e.g., LatheGUI) that a tool was deleted
            self.tool_deleted.emit(deleted_tool_num)

    def _renumber_tools(self):
        """Renumber all tool rows sequentially after a deletion."""
        for i, row in enumerate(self.tool_rows):
            new_num = i + 1
            row.tool_num = new_num
            lib_id = 100 + new_num
            grid = row.layout()
            # T-label (library ID) is at row 0, col 0
            item = grid.itemAtPosition(0, 0)
            if item and item.widget():
                item.widget().setText(f"T{lib_id}")
            # Program label is at row 1, col 0
            item = grid.itemAtPosition(1, 0)
            if item and item.widget():
                item.widget().setText(f"(T{new_num})")
                item.widget().setToolTip(
                    f"Program call: T{new_num} → library T{lib_id}")
            row.btn_delete.setToolTip(f"Delete tool T{lib_id}")

    def _autosave(self, *args):
        """Auto-save to the active table file if one is loaded."""
        if self._autosave_enabled and self._active_table_path:
            self._write_table_to_path(self._active_table_path)

    def _settings_path(self):
        """Return path to the tool tab settings file."""
        return os.path.join(os.path.dirname(__file__), ".tool_tab_settings.json")

    def _save_last_table_path(self):
        """Persist the active table path so it auto-loads next time."""
        if self._active_table_path:
            try:
                with open(self._settings_path(), "w") as f:
                    json.dump({"last_table": self._active_table_path}, f)
            except Exception:
                pass

    def _load_last_table(self):
        """Load the last used table on startup if it still exists."""
        settings_path = self._settings_path()
        if not os.path.exists(settings_path):
            return
        try:
            with open(settings_path, "r") as f:
                settings = json.load(f)
            last_path = settings.get("last_table")
            if last_path and os.path.exists(last_path):
                self._load_table_from_path(last_path)
                self._active_table_path = last_path
                self._autosave_enabled = True
                self.table_name_label.setText(os.path.basename(last_path))
        except Exception:
            pass

    def save_tool_table(self):
        """Open a Save As dialog and write the tool table to the chosen file."""
        default_dir = os.path.dirname(os.path.dirname(__file__))
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Tool Table", default_dir,
            "Tool Table Files (*.tbl);;All Files (*)"
        )
        if not path:
            return False
        if not path.endswith(".tbl"):
            path += ".tbl"
        success = self._write_table_to_path(path)
        if success:
            self._active_table_path = path
            self._autosave_enabled = True
            self.table_name_label.setText(os.path.basename(path))
            self._save_last_table_path()
        return success

    def load_tool_table(self):
        """Open a file dialog and load the selected tool table."""
        default_dir = os.path.dirname(os.path.dirname(__file__))
        path, _ = QFileDialog.getOpenFileName(
            self, "Load Tool Table", default_dir,
            "Tool Table Files (*.tbl);;All Files (*)"
        )
        if not path or not os.path.exists(path):
            return
        self._load_table_from_path(path)
        self._active_table_path = path
        self._autosave_enabled = True
        self.table_name_label.setText(os.path.basename(path))
        self._save_last_table_path()

    def _write_table_to_path(self, path):
        """Write the current tool data to the specified file path.

        Creates a .bak backup of the existing file before overwriting so
        accidental deletions or edits can be recovered.
        """
        # Create backup of existing file before overwriting
        if os.path.exists(path):
            bak_path = path + ".bak"
            try:
                shutil.copy2(path, bak_path)
            except Exception as e:
                print(f"Warning: could not create backup {bak_path}: {e}")

        lines = [
            "; Tool Table for Lathe",
            "; Generated by My-Lathe GUI",
            "; Library naming: T1xx series (T101=tool 1, T102=tool 2, etc.)",
            "; Program T# maps to library T(100+#) — T1->T101, T2->T102",
            "; P=pocket (program tool#), X/Z=offsets, D=nose radius dia,",
            "; I=front angle, J=back angle, Q=orientation (1-9)",
            ";",
        ]
        for row in self.tool_rows:
            lines.append(row.to_tool_table_line())
        lines.append("")
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write("\n".join(lines))
            return True
        except Exception as e:
            print(f"Error saving tool table: {e}")
            return False

    def _load_table_from_path(self, path):
        """Load tool table data from the specified file path."""
        try:
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception:
            return

        # Disable autosave while loading to avoid writing back during population
        self._autosave_enabled = False

        for row in self.tool_rows:
            self.tool_list_layout.removeWidget(row)
            row.deleteLater()
        self.tool_rows.clear()

        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith(";"):
                continue
            m = re.match(
                r"T(\d+)\s+P(\d+)\s+X([+\-]?[\d.]+)\s+Z([+\-]?[\d.]+)\s+"
                r"D([\d.]+)\s+I([+\-]?[\d.]+)\s+J([+\-]?[\d.]+)\s+Q(\d+)"
                r"(?:\s*;(.*))?",
                line,
            )
            if not m:
                continue
            p_num = int(m.group(2))
            x_off, z_off = m.group(3), m.group(4)
            d_val = float(m.group(5))
            f_angle, b_angle = m.group(6), m.group(7)
            q_val = int(m.group(8))
            comment = (m.group(9) or "").strip()
            nose_r = d_val / 2.0

            # Parse metadata from comment: "description|type:...|insert:...|W:..."
            desc = comment
            tool_type = None
            insert_code = None
            blade_width = None
            if "|" in comment:
                parts = comment.split("|")
                desc = parts[0].strip()
                for part in parts[1:]:
                    part = part.strip()
                    if part.startswith("type:"):
                        tool_type = part[5:]
                    elif part.startswith("insert:"):
                        insert_code = part[7:]
                    elif part.startswith("W:"):
                        blade_width = part[2:]
            else:
                # Legacy format: "description W0.1250" for grooving tools
                bw_match = re.search(r'\sW([\d.]+)$', desc)
                if bw_match:
                    blade_width = bw_match.group(1)
                    desc = desc[:bw_match.start()]

            row_data = {
                "offset_x": x_off, "offset_z": z_off,
                "nose_radius": f"{nose_r:.4f}",
                "front_angle": f_angle, "back_angle": b_angle,
                "orientation": q_val, "description": desc,
            }
            if tool_type:
                row_data["tool_type"] = tool_type
            if insert_code:
                row_data["insert_code"] = insert_code
            if blade_width:
                row_data["blade_width"] = blade_width
            self._create_and_add_row(p_num, row_data)

        # Re-enable autosave now that loading is complete
        self._autosave_enabled = True

    def refresh_wear_from_stat(self):
        """Read wear offsets from LinuxCNC stat channel and update rows."""
        if self._stat is None:
            return
        try:
            self._stat.poll()
            for row in self.tool_rows:
                t = row.tool_num
                entry = self._stat.tool_table[t]
                # LinuxCNC stores total (geo + wear); we'd need to track
                # the split ourselves. For now, wear is managed locally.
        except Exception as e:
            print(f"Wear refresh error: {e}")
