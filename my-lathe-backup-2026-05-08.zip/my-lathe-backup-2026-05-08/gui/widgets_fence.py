"""Go-To Fence Widget — soft limit for safe manual jogging."""

from PyQt5.QtWidgets import (
    QGroupBox, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QCheckBox
)
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QFont

from theme import COLORS, mono_font, ui_font


class GoToFenceWidget(QGroupBox):
    """Go-To fence panel for the sidebar.

    The fence acts as a soft limit — the user jogs manually toward the
    target and the fence prevents overshooting.  Motion away from the
    fence is unrestricted.  Fence direction is determined by approach
    direction (which side of the fence the user is currently on).
    """

    # Emitted when fence state changes: (axis, enabled, value)
    # axis: 'x' or 'z', enabled: bool, value: float (radius for X)
    fence_changed = pyqtSignal(str, bool, float)

    def __init__(self, parent=None):
        super().__init__("Go To", parent)

        self._fence_x_enabled = False
        self._fence_z_enabled = False
        self._fence_x_value = 0.0  # stored as radius internally
        self._fence_z_value = 0.0

        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 5, 6, 45)
        layout.setSpacing(4)

        row_h = 30

        # X fence row
        x_row = QHBoxLayout()
        x_row.setSpacing(4)

        self.chk_fence_x = QCheckBox("X")
        self.chk_fence_x.setFont(mono_font(12, QFont.Bold))
        self.chk_fence_x.setStyleSheet(f"color: {COLORS['text']}; background: transparent;")
        self.chk_fence_x.toggled.connect(self._on_fence_x_toggled)
        x_row.addWidget(self.chk_fence_x)

        self.input_fence_x = QLineEdit("0.0000")
        self.input_fence_x.setFont(mono_font(13))
        self.input_fence_x.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.input_fence_x.setFixedHeight(row_h)
        self.input_fence_x.setToolTip("X fence position (diameter)")
        self.input_fence_x.editingFinished.connect(self._on_fence_x_value_changed)
        x_row.addWidget(self.input_fence_x, stretch=1)

        layout.addLayout(x_row)

        # Z fence row
        z_row = QHBoxLayout()
        z_row.setSpacing(4)

        self.chk_fence_z = QCheckBox("Z")
        self.chk_fence_z.setFont(mono_font(12, QFont.Bold))
        self.chk_fence_z.setStyleSheet(f"color: {COLORS['text']}; background: transparent;")
        self.chk_fence_z.toggled.connect(self._on_fence_z_toggled)
        z_row.addWidget(self.chk_fence_z)

        self.input_fence_z = QLineEdit("0.0000")
        self.input_fence_z.setFont(mono_font(13))
        self.input_fence_z.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.input_fence_z.setFixedHeight(row_h)
        self.input_fence_z.setToolTip("Z fence position")
        self.input_fence_z.editingFinished.connect(self._on_fence_z_value_changed)
        z_row.addWidget(self.input_fence_z, stretch=1)

        layout.addLayout(z_row)

    # --- Properties for external access ---
    @property
    def fence_x_enabled(self):
        return self._fence_x_enabled

    @property
    def fence_z_enabled(self):
        return self._fence_z_enabled

    @property
    def fence_x_value(self):
        """Fence X value in radius (internal coords)."""
        return self._fence_x_value

    @property
    def fence_z_value(self):
        return self._fence_z_value

    # --- Callbacks ---
    def _on_fence_x_toggled(self, checked):
        self._fence_x_enabled = checked
        self._parse_fence_x()
        self.fence_changed.emit('x', checked, self._fence_x_value)

    def _on_fence_z_toggled(self, checked):
        self._fence_z_enabled = checked
        self._parse_fence_z()
        self.fence_changed.emit('z', checked, self._fence_z_value)

    def _on_fence_x_value_changed(self):
        self._parse_fence_x()
        if self._fence_x_enabled:
            self.fence_changed.emit('x', True, self._fence_x_value)

    def _on_fence_z_value_changed(self):
        self._parse_fence_z()
        if self._fence_z_enabled:
            self.fence_changed.emit('z', True, self._fence_z_value)

    def _parse_fence_x(self):
        """Parse X input (diameter) and store as radius."""
        try:
            dia = float(self.input_fence_x.text())
            metric = getattr(self, '_metric_display', False)
            if metric:
                dia /= 25.4  # convert mm input back to inches
            self._fence_x_value = dia / 2.0
        except ValueError:
            pass

    def _parse_fence_z(self):
        try:
            val = float(self.input_fence_z.text())
            metric = getattr(self, '_metric_display', False)
            if metric:
                val /= 25.4  # convert mm input back to inches
            self._fence_z_value = val
        except ValueError:
            pass

    def set_metric_display(self, metric: bool):
        """Toggle display-only metric conversion for fence input fields."""
        self._metric_display = metric
        # Refresh displayed values
        conv = 25.4 if metric else 1.0
        d = 3 if metric else 4
        self.input_fence_x.setText(f"{self._fence_x_value * 2 * conv:.{d}f}")
        self.input_fence_z.setText(f"{self._fence_z_value * conv:.{d}f}")

    def check_fence(self, current_x, current_z, target_x, target_z):
        """Apply fence clamping to a target position.

        Returns (clamped_x, clamped_z, was_clamped).

        Logic: if moving toward the fence, clamp at the fence.
        If moving away from the fence, allow freely.
        """
        clamped_x = target_x
        clamped_z = target_z
        was_clamped = False

        if self._fence_x_enabled:
            fence_x = self._fence_x_value
            if current_x < fence_x:
                # Approaching from below (X-), fence blocks X > fence
                if target_x > fence_x:
                    clamped_x = fence_x
                    was_clamped = True
            elif current_x > fence_x:
                # Approaching from above (X+), fence blocks X < fence
                if target_x < fence_x:
                    clamped_x = fence_x
                    was_clamped = True
            else:
                # At fence — block motion in either direction
                if target_x != fence_x:
                    clamped_x = fence_x
                    was_clamped = True

        if self._fence_z_enabled:
            fence_z = self._fence_z_value
            if current_z < fence_z:
                if target_z > fence_z:
                    clamped_z = fence_z
                    was_clamped = True
            elif current_z > fence_z:
                if target_z < fence_z:
                    clamped_z = fence_z
                    was_clamped = True
            else:
                if target_z != fence_z:
                    clamped_z = fence_z
                    was_clamped = True

        return clamped_x, clamped_z, was_clamped
