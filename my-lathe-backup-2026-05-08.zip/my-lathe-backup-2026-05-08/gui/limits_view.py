"""Per-tool Z-axis soft limits UI panel.

Displays a card-per-tool layout for viewing and editing Z- and Z+ limits,
accessible from the tool tab header. Each card provides editable fields
and "Set Here" capture buttons for setting limits at the current machine position.
"""

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QScrollArea, QFrame,
    QLabel, QLineEdit, QPushButton, QGridLayout,
)
from PyQt5.QtCore import pyqtSignal, Qt
from PyQt5.QtGui import QDoubleValidator


class LimitCard(QFrame):
    """Card widget representing a single tool's Z-axis limit configuration."""

    # Signal emitted when field values are edited; carries the tool_num
    values_edited = pyqtSignal(int)

    # Colors matching the task specification
    CARD_BG = "#2a3a4a"
    CARD_BORDER = "#3d5a6e"
    TEXT_COLOR = "#e0e0e0"
    TOOL_NUM_COLOR = "#87CEEB"
    BUTTON_BG = "#4a6a7a"
    ERROR_COLOR = "#ff6b6b"

    def __init__(self, tool_num: int, limits_view=None, description: str = "", parent=None):
        """Initialize a limit card for a single tool.

        Args:
            tool_num: Tool pocket number (1-based).
            limits_view: Parent LimitsView instance (for accessing machine Z and limit_manager).
            description: Optional tool description text.
            parent: Optional parent widget.
        """
        super().__init__(parent)
        self.tool_num = tool_num
        self._limits_view = limits_view

        # Frame styling — rounded border, dark blue-gray background
        self.setStyleSheet(
            f"LimitCard {{ background-color: {self.CARD_BG}; "
            f"border: 1px solid {self.CARD_BORDER}; border-radius: 6px; "
            f"padding: 8px; }}"
        )

        # Main layout
        layout = QGridLayout(self)
        layout.setSpacing(6)
        layout.setContentsMargins(10, 8, 10, 8)

        # --- Left side: Tool number label (large, bold, light blue) ---
        lib_tool_id = 100 + tool_num
        tool_label = QLabel(f"T{lib_tool_id}")
        tool_label.setStyleSheet(
            f"color: {self.TOOL_NUM_COLOR}; background: transparent; border: none; "
            f"font-family: 'JetBrains Mono', 'Consolas', monospace; "
            f"font-size: 32px; font-weight: bold;"
        )
        tool_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        layout.addWidget(tool_label, 0, 0, 2, 1)

        # --- Optional description label (smaller, gray) ---
        if description:
            desc_label = QLabel(description)
            desc_label.setStyleSheet(
                f"color: #7B9AAC; background: transparent; border: none; "
                f"font-size: 12px;"
            )
            desc_label.setAlignment(Qt.AlignLeft | Qt.AlignTop)
            layout.addWidget(desc_label, 2, 0, 1, 1)

        # --- Field styling (stored for validation state toggling) ---
        self._field_style_normal = (
            f"background-color: #1a2028; color: {self.TEXT_COLOR}; "
            f"border: 1px solid {self.CARD_BORDER}; border-radius: 3px; "
            f"padding: 4px 6px; font-family: 'JetBrains Mono', 'Consolas', monospace; "
            f"font-size: 14px;"
        )
        self._field_style_error = (
            f"background-color: #1a2028; color: {self.TEXT_COLOR}; "
            f"border: 1px solid {self.ERROR_COLOR}; border-radius: 3px; "
            f"padding: 4px 6px; font-family: 'JetBrains Mono', 'Consolas', monospace; "
            f"font-size: 14px;"
        )
        field_style = self._field_style_normal
        label_style = (
            f"color: {self.TEXT_COLOR}; background: transparent; border: none; "
            f"font-size: 13px; font-weight: bold;"
        )
        btn_style = (
            f"QPushButton {{ background-color: {self.BUTTON_BG}; color: {self.TEXT_COLOR}; "
            f"border: 1px solid {self.CARD_BORDER}; border-radius: 3px; "
            f"padding: 4px 10px; font-size: 12px; }}"
            f"QPushButton:hover {{ background-color: #5a7a8a; }}"
            f"QPushButton:disabled {{ background-color: #2a3a4a; color: #5a6a7a; }}"
        )

        # Validator for float fields (allow negative, 4 decimal places)
        validator = QDoubleValidator(-99999.0, 99999.0, 4, self)
        validator.setNotation(QDoubleValidator.StandardNotation)

        # --- Z- row ---
        z_minus_label = QLabel("Z\u2212")
        z_minus_label.setStyleSheet(label_style)
        z_minus_label.setFixedWidth(30)
        layout.addWidget(z_minus_label, 0, 1)

        self.z_minus_field = QLineEdit()
        self.z_minus_field.setPlaceholderText("Not set")
        self.z_minus_field.setStyleSheet(field_style)
        self.z_minus_field.setValidator(validator)
        self.z_minus_field.setFixedWidth(120)
        self.z_minus_field.setFixedHeight(32)
        layout.addWidget(self.z_minus_field, 0, 2)

        self.z_minus_set_btn = QPushButton("Set Here")
        self.z_minus_set_btn.setStyleSheet(btn_style)
        self.z_minus_set_btn.setFixedHeight(32)
        self.z_minus_set_btn.setToolTip("Capture current machine Z position as Z\u2212 limit")
        layout.addWidget(self.z_minus_set_btn, 0, 3)

        # --- Z+ row ---
        z_plus_label = QLabel("Z+")
        z_plus_label.setStyleSheet(label_style)
        z_plus_label.setFixedWidth(30)
        layout.addWidget(z_plus_label, 1, 1)

        self.z_plus_field = QLineEdit()
        self.z_plus_field.setPlaceholderText("Not set")
        self.z_plus_field.setStyleSheet(field_style)
        self.z_plus_field.setValidator(validator)
        self.z_plus_field.setFixedWidth(120)
        self.z_plus_field.setFixedHeight(32)
        layout.addWidget(self.z_plus_field, 1, 2)

        self.z_plus_set_btn = QPushButton("Set Here")
        self.z_plus_set_btn.setStyleSheet(btn_style)
        self.z_plus_set_btn.setFixedHeight(32)
        self.z_plus_set_btn.setToolTip("Capture current machine Z position as Z+ limit")
        layout.addWidget(self.z_plus_set_btn, 1, 3)

        # --- Error label (hidden by default, red text) ---
        self.error_label = QLabel("")
        self.error_label.setStyleSheet(
            f"color: {self.ERROR_COLOR}; background: transparent; border: none; "
            f"font-size: 11px;"
        )
        self.error_label.setVisible(False)
        layout.addWidget(self.error_label, 2, 1, 1, 3)

        # --- Connect editingFinished signals for validation and save ---
        self.z_minus_field.editingFinished.connect(self._on_field_edited)
        self.z_plus_field.editingFinished.connect(self._on_field_edited)

        # --- Connect "Set Here" buttons ---
        self.z_minus_set_btn.clicked.connect(self._on_set_z_minus)
        self.z_plus_set_btn.clicked.connect(self._on_set_z_plus)

    def _on_field_edited(self) -> None:
        """Handle field editing: validate, show/hide error, save if valid.

        If both values are set and z_minus >= z_plus, shows red border on
        both fields and displays an inline error message.
        Otherwise hides the error, resets field borders, saves via LimitManager
        (converting from display units back to inches if metric mode is active),
        and emits values_edited signal.
        """
        z_minus, z_plus = self.get_values()

        # Validate: z_minus must be less than z_plus when both are set
        if z_minus is not None and z_plus is not None and z_minus >= z_plus:
            # Show error state — red border on both fields
            self.z_minus_field.setStyleSheet(self._field_style_error)
            self.z_plus_field.setStyleSheet(self._field_style_error)
            self.error_label.setText("Z\u2212 must be less than Z+")
            self.error_label.setVisible(True)
            # Emit signal (parent will see validation failed via set_limit returning False)
            self.values_edited.emit(self.tool_num)
            return

        # Valid or partial — reset to normal styling
        self.z_minus_field.setStyleSheet(self._field_style_normal)
        self.z_plus_field.setStyleSheet(self._field_style_normal)
        self.error_label.setVisible(False)

        # Save via LimitManager if we have a limits_view reference
        if self._limits_view is not None:
            manager = self._limits_view._limit_manager
            # Convert from display units back to inches for storage
            store_z_minus = z_minus
            store_z_plus = z_plus
            if self._limits_view._metric:
                if store_z_minus is not None:
                    store_z_minus = store_z_minus / 25.4
                if store_z_plus is not None:
                    store_z_plus = store_z_plus / 25.4

            if store_z_minus is None and store_z_plus is None:
                manager.remove_tool(self.tool_num)
                manager.save()
                self._limits_view.limits_changed.emit()
            else:
                success = manager.set_limit(self.tool_num, z_minus=store_z_minus, z_plus=store_z_plus)
                if success:
                    manager.save()
                    self._limits_view.limits_changed.emit()

        # Emit signal so the parent LimitsView can react
        self.values_edited.emit(self.tool_num)

    def _on_set_z_minus(self) -> None:
        """Handle Z- 'Set Here' button click.

        Captures the current machine Z position from the parent LimitsView
        and populates the Z- field (converting to display units if metric),
        then triggers validation and save.
        """
        if self._limits_view is None:
            return
        z = self._limits_view._machine_z
        # Display in current units (metric = mm, otherwise inches)
        display_z = z * 25.4 if self._limits_view._metric else z
        self.z_minus_field.setText(f"{display_z:.4f}")
        self._on_field_edited()

    def _on_set_z_plus(self) -> None:
        """Handle Z+ 'Set Here' button click.

        Captures the current machine Z position from the parent LimitsView
        and populates the Z+ field (converting to display units if metric),
        then triggers validation and save.
        """
        if self._limits_view is None:
            return
        z = self._limits_view._machine_z
        # Display in current units (metric = mm, otherwise inches)
        display_z = z * 25.4 if self._limits_view._metric else z
        self.z_plus_field.setText(f"{display_z:.4f}")
        self._on_field_edited()

    def set_homed(self, homed: bool) -> None:
        """Enable/disable 'Set Here' buttons based on homing state.

        Args:
            homed: True if all axes are homed.
        """
        self.z_minus_set_btn.setEnabled(homed)
        self.z_plus_set_btn.setEnabled(homed)
        tooltip = "" if homed else "Home all axes first"
        if not homed:
            self.z_minus_set_btn.setToolTip(tooltip)
            self.z_plus_set_btn.setToolTip(tooltip)
        else:
            self.z_minus_set_btn.setToolTip("Capture current machine Z position as Z\u2212 limit")
            self.z_plus_set_btn.setToolTip("Capture current machine Z position as Z+ limit")

    def set_values(self, z_minus, z_plus) -> None:
        """Populate fields with limit values.

        Args:
            z_minus: Z- limit value as float, or None for empty.
            z_plus: Z+ limit value as float, or None for empty.
        """
        if z_minus is not None:
            self.z_minus_field.setText(f"{z_minus:.4f}")
        else:
            self.z_minus_field.clear()

        if z_plus is not None:
            self.z_plus_field.setText(f"{z_plus:.4f}")
        else:
            self.z_plus_field.clear()

    def get_values(self) -> tuple:
        """Return (z_minus, z_plus) as floats or None for empty fields.

        Returns:
            Tuple of (z_minus, z_plus) where each is a float or None.
        """
        z_minus = None
        z_plus = None

        z_minus_text = self.z_minus_field.text().strip()
        if z_minus_text:
            try:
                z_minus = float(z_minus_text)
            except ValueError:
                pass

        z_plus_text = self.z_plus_field.text().strip()
        if z_plus_text:
            try:
                z_plus = float(z_plus_text)
            except ValueError:
                pass

        return (z_minus, z_plus)


class LimitsView(QWidget):
    """UI panel for viewing and editing per-tool Z-axis soft limits."""

    limits_changed = pyqtSignal()  # Emitted when any limit is modified

    def __init__(self, limit_manager, tool_tab, parent=None):
        """Initialize with LimitManager and ToolTab references.

        Args:
            limit_manager: LimitManager instance for reading/writing limits.
            tool_tab: ToolTab instance for accessing the current tool library.
            parent: Optional parent widget.
        """
        super().__init__(parent)

        # Store references
        self._limit_manager = limit_manager
        self._tool_tab = tool_tab

        # State
        self._machine_z = 0.0
        self._is_homed = False
        self._metric = False

        # Main layout with no margins
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)

        # Scroll area for cards
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(QFrame.NoFrame)
        main_layout.addWidget(scroll_area)

        # Container widget inside the scroll area
        container = QWidget()
        self._card_layout = QVBoxLayout(container)
        self._card_layout.setContentsMargins(0, 0, 0, 0)
        scroll_area.setWidget(container)

        # List of card widgets
        self._cards = []

    def set_machine_z(self, z: float) -> None:
        """Update the current machine Z position for 'Set Here' capture.

        Args:
            z: Current machine Z position in inches (machine coordinates).
        """
        self._machine_z = z

    def set_homed(self, homed: bool) -> None:
        """Enable/disable 'Set Here' buttons based on homing state.

        Args:
            homed: True if all axes are homed.
        """
        self._is_homed = homed
        # Update card buttons when homing state changes
        for card in self._cards:
            card.set_homed(homed)

    def set_metric_display(self, metric: bool) -> None:
        """Toggle display units between inches and millimeters.

        Stores the metric flag and re-populates all card fields with
        converted values. Stored values are always in inches; metric
        display multiplies by 25.4.

        Args:
            metric: True for millimeter display, False for inches.
        """
        self._metric = metric
        # Re-populate all card fields with converted values
        for card in self._cards:
            limits = self._limit_manager.get_limits(card.tool_num)
            if limits is not None:
                z_minus, z_plus = limits
                display_z_minus = z_minus * 25.4 if (z_minus is not None and metric) else z_minus
                display_z_plus = z_plus * 25.4 if (z_plus is not None and metric) else z_plus
                card.set_values(display_z_minus, display_z_plus)
            else:
                card.set_values(None, None)

    def refresh(self) -> None:
        """Rebuild the card list from current tool library and limit data.

        Clears all existing cards, then creates a new LimitCard for each
        tool in the tool tab's tool_rows list. Loads existing limit values
        from LimitManager and applies unit conversion if metric mode is active.
        """
        # Clear existing cards
        for card in self._cards:
            self._card_layout.removeWidget(card)
            card.deleteLater()
        self._cards.clear()

        # Remove any stretch items from the layout
        while self._card_layout.count() > 0:
            item = self._card_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        # Get tool list from tool_tab
        tool_rows = []
        try:
            if hasattr(self._tool_tab, 'tool_rows'):
                tool_rows = self._tool_tab.tool_rows
        except (AttributeError, TypeError):
            pass

        # Create a card for each tool
        for row in tool_rows:
            tool_num = row.tool_num
            # Get description from the row's description field or tool_type
            desc = ""
            try:
                desc = row.description.text() if hasattr(row, 'description') else ""
                if not desc and hasattr(row, 'tool_type'):
                    desc = row.tool_type.currentText()
            except (AttributeError, RuntimeError):
                pass

            card = LimitCard(tool_num, limits_view=self, description=desc)

            # Load existing limit values from LimitManager
            limits = self._limit_manager.get_limits(tool_num)
            if limits is not None:
                z_minus, z_plus = limits
                # Convert to display units if metric mode is active
                display_z_minus = z_minus * 25.4 if (z_minus is not None and self._metric) else z_minus
                display_z_plus = z_plus * 25.4 if (z_plus is not None and self._metric) else z_plus
                card.set_values(display_z_minus, display_z_plus)

            # Set homing state on the card
            card.set_homed(self._is_homed)

            # Connect the card's values_edited signal
            self._connect_card(card)

            # Add card to layout and list
            self._card_layout.addWidget(card)
            self._cards.append(card)

        # Add stretch at the end to push cards to the top
        self._card_layout.addStretch()

    def _on_card_edited(self, tool_num: int) -> None:
        """Handle a card's values_edited signal — persist valid limits.

        Finds the card for the given tool_num, reads its values, and
        attempts to save via LimitManager. If set_limit succeeds (validation
        passes), persists to disk and emits limits_changed. If set_limit
        returns False, the card is already showing the validation error.

        Args:
            tool_num: The tool pocket number whose card was edited.
        """
        # Find the card for this tool
        card = None
        for c in self._cards:
            if c.tool_num == tool_num:
                card = c
                break
        if card is None:
            return

        z_minus, z_plus = card.get_values()

        # Attempt to set the limit in the manager (validates z_minus < z_plus)
        success = self._limit_manager.set_limit(tool_num, z_minus, z_plus)
        if success:
            self._limit_manager.save()
            self.limits_changed.emit()

    def _connect_card(self, card) -> None:
        """Connect a card's values_edited signal to the view handler.

        Args:
            card: LimitCard instance to connect.
        """
        card.values_edited.connect(self._on_card_edited)
